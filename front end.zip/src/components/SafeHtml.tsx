// SafeHtml.tsx
import React from 'react';
import DOMPurify from 'dompurify';

interface ISafeHtmlProps {
  htmlContent: string;
}

const SafeHtml: React.FC<ISafeHtmlProps> = ({ htmlContent }) => {
  // // Sanitize HTML content before rendering
  // Add style="margin: 0px" to <p> and any other tags that you need
  const modifiedHtmlContent = htmlContent.replace(/<p>/g, '<p style="margin: 0px;">');

  // Sanitize the modified HTML content
  const sanitizedHtml = DOMPurify.sanitize(modifiedHtmlContent);
  return (
    <span
    style={{wordWrap:"break-word", width:"100%" ,margin : "0px"}}
      dangerouslySetInnerHTML={{ __html: sanitizedHtml }}
    />
  );
};

export default SafeHtml;
