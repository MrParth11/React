import React, { useState } from "react";

const IntroductionVideo = () => {
  const [showVideo, setShowVideo] = useState(true);

  const closeVideo = () => setShowVideo(false);

  return (
    <>
      {showVideo && (
        <div
          className="video-overlay"
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: "rgba(0,0,0,0.7)",
            zIndex: 9999,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            className="video-modal"
            style={{
              position: "relative",
              width: "70%",
              maxWidth: "960px",
              background: "#fff",
              borderRadius: "8px",
              padding: "20px",
              boxShadow: "0 4px 12px rgba(0, 0, 0, 0.2)",
              overflow: "hidden",
            }}
          >
            {/* Close Button */}
            <button
              onClick={closeVideo}
              style={{
                position: "absolute",
                top: "10px",
                right: "15px",
                background: "transparent",
                border: "none",
                fontSize: "24px",
                color: "#000",
                cursor: "pointer",
              }}
            >
              &times;
            </button>

            {/* Title */}
            <h2
              style={{
                textAlign: "center",
              }}
            >
              Best Way To Use All Features
            </h2>
            <p className="text-center" style={{ color: "rgb(153,153,153" }}>
              Please Watch This Video
            </p>

            {/* Fixed Size Video */}
            <div
              style={{
                height: "70vh",
                display: "flex",
                justifyContent: "center",
              }}
            >
              <iframe
                width="100%"
                src="https://www.youtube.com/embed/xFhooD4GVIQ?si=EFa6P5fDyqO4d_oY"
                title="Introduction Video"
                allowFullScreen
                style={{
                  border: "none",
                  borderRadius: "8px",
                }}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default IntroductionVideo;
