import React, { useEffect, useState } from "react";
import "./ConfirmationModal.css";
import { IUserList } from "../../pages/left-side/LeftSideController";

interface IRadioButtonModalProps {
  show: boolean;
  onHide: () => void;
  handleSubmit: (selectedOption: any) => void;
  title: string;
  message: string;
  btn1: string;
  btn2: string;
  options: any[];
  selectedLabelIds?: any;
  contactId: number | undefined;
  getOptionColor?: (option: any) => string;
  getOptionName: (option: any) => string;
  showColorBadge: boolean;
}

const RadioButtonModal: React.FC<IRadioButtonModalProps> = ({
  show,
  onHide,
  handleSubmit,
  title,
  message,
  btn1,
  btn2,
  options,
  selectedLabelIds,
  contactId,
  getOptionColor,
  getOptionName,
  showColorBadge,
}) => {
  const [selectedOption, setSelectedOption] = useState<number | undefined>();

  useEffect(() => {
    const parsedLabelId = selectedLabelIds
      ? Number(selectedLabelIds)
      : undefined;
    setSelectedOption(parsedLabelId); // Set the single value directly
  }, [selectedLabelIds, contactId]);
  const handleRadioChange = (optionId: any) => {
    setSelectedOption(optionId); // Set only one option as selected
  };

  const onSubmit = () => {
    if (selectedOption !== undefined) handleSubmit(selectedOption);
  };
  const getDisplayOrderRange = () => {
    if (selectedOption) {
      const selectedOptionObj = options.find((opt) => opt.id === selectedOption);
      if (selectedOptionObj) {
        const prevOrderType = selectedOptionObj.display_order_type - 1;
        const nextOrderType = selectedOptionObj.display_order_type + 1;
  
        return {
          prevOrderType,
          selectedOrderType: selectedOptionObj.display_order_type,
          nextOrderType,
        };
      }
    }
    return { prevOrderType: null, selectedOrderType: 0, nextOrderType: 1 };
  };
  
  const { prevOrderType, selectedOrderType, nextOrderType } = getDisplayOrderRange();
  
  // Show all options if selected display_order_type is 0, otherwise filter
  const filteredOptions =
    selectedOrderType === 0
      ? options
      : options.filter(
          (opt) =>
            opt.display_order_type === prevOrderType ||
            opt.id === selectedOption ||
            opt.display_order_type === nextOrderType
        );
  

  return show ? (
    <div className="modal-overlay">
      <div className="modal-content_label">
        <h2 className="modal-title1 form_header_text">{title}</h2>
        <p>{message}</p>
        <div className="overflow-auto " style={{ maxHeight: "500px" }}>
          <table className="table table-hover" border={0}>
            <tbody className="text-center">
              {filteredOptions.map((option) => (
                <tr key={option.id}>
                  <td className="text-start">
                    {showColorBadge ? (
                      <span
                        style={{
                          backgroundColor: getOptionColor
                            ? getOptionColor(option)
                            : "",
                        }}
                        className="badge rounded-pill"
                      >
                         {getOptionName(option)}
                      </span>
                    ) : (
                      <span>{getOptionName(option)}</span>
                    )}
                  </td>
                  <td className="text-end">
                    <input
                      className="custom-radio"
                      type="radio"
                      id={`radio-${option.id}`}
                      checked={selectedOption === option.id}
                      onChange={() => handleRadioChange(option.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="modal-buttons">
          <button className="modal-button1 ig-btn" onClick={onHide}>
            {btn1}
          </button>
          <button className="modal-button2 ig-btn" onClick={onSubmit}>
            {btn2}
          </button>
        </div>
      </div>
    </div>
  ) : null;
};

export default RadioButtonModal;
