import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import { useTheme } from "../ThemeContext";
import OTPInput from "react-otp-input";
import {axiosInstance} from "../../services/axiosInstance";
import { toast } from "react-toastify";
import { DEFAULT_STATUS_CODE_SUCCESS } from "../../helpers/AppConstants";
//1 => Delete Account 2 => Change Mobile number 3 => verify Email profile 4 => verify Email company  
const OtpConfirmationModal = ({
  show,
  onHide,
  handleSubmit,
  title,
  message,
  btn1 = "yes",
  btn2 = "no",
  mobileNumber,
  emailId,
  profileId,
  position,
}: {
  show: boolean;
  onHide: () => void;
  handleSubmit: () => void;
  title: string;
  message?: string;
  btn1: string;
  btn2: string;
  mobileNumber?: number;
  emailId?: string;
  profileId: number;
  position: number;
}) => {
  const { darkMode } = useTheme();
  const modalThemeClass = darkMode ? "modal-light-1" : "modal-light-1";
  const modalThemeClass1 = darkMode ? "modal-dark" : "modal-light-1";
  const [selectedOption, setSelectedOption] = useState("whatsapp"); // Default to WhatsApp

  const [otp, setOtp] = useState("");
  const [otpChangeNumber, setOtpChangeNumber] = useState("");
  const [otpEmailVerify, setOtpEmailVerify] = useState("");
  const [otpEmailVerifyCompany, setOtpEmailVerifyCompany] = useState("");

  const [responseMessage, setResponseMessage] = useState(""); // To store the response message
  const [responseMessageChangeNumber, setResponseMessageChangeNumber] =
    useState(""); // To store the response message

  const [isSending, setIsSending] = useState(false); // To show loading state for the
  const [isSendingChangeNumber, setIsSendingChangeNumber] = useState(false); // To show loading state for the

  const [phoneNumber, setPhoneNumber] = useState<string>(); // To show loading state for the
  const [error, setError] = useState<string>("");
  const handleOptionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedOption(event.target.value);
  };
  const handleSendOTP = async () => {
    const token = await localStorage.getItem("token");

    // Simulate API call
    try {
      if (position === 2) {
        if (phoneNumber) {
          setIsSendingChangeNumber(true);
          setResponseMessageChangeNumber(""); // Clear the previous response message

          const responseVerifyOtpChangeNumber = await axiosInstance.post(
            "changeNumberOtpSend",
            {
              contact_number: phoneNumber,
              loginId: profileId,
            },
            {
              headers: {
                Authorization: `${token}`,
              },
            }
          );

          if (responseVerifyOtpChangeNumber.data.code === 200) {
            if (
              responseVerifyOtpChangeNumber.data.ack ===
              DEFAULT_STATUS_CODE_SUCCESS
            ) {
            }
            const response = await new Promise(
              (resolve) =>
                setTimeout(
                  () => resolve(`OTP sent via ${selectedOption}`),
                  1000
                ) // Simulated delay
            );
            setResponseMessageChangeNumber(response as string);
          } else {
            setIsSendingChangeNumber(false);

            toast.error(responseVerifyOtpChangeNumber.data.ack_msg);
          }
        } else {
          toast.error("Please Write Mobile Number");
        }
      } else {
        setIsSending(true);
        setResponseMessage(""); // Clear the previous response message

        let responseData;
        if (selectedOption === "whatsapp") {
          responseData = await axiosInstance.post(
            "verifyUserOtp",
            {
              contact_number: mobileNumber,
              loginId: profileId,
            },
            {
              headers: {
                Authorization: `${token}`,
              },
            }
          );
        } else {
          responseData = await axiosInstance.post(
            "verifyUserOtp",
            {
              emailId: emailId,
              loginId: profileId,
            },
            {
              headers: {
                Authorization: `${token}`,
              },
            }
          );
        }
        if (responseData.data.code === 200) {
          const response = await new Promise(
            (resolve) =>
              setTimeout(() => resolve(`OTP sent via ${selectedOption}`), 1000) // Simulated delay
          );
          setResponseMessage(response as string);
        }
      }
    } catch (error) {
      setResponseMessage("Failed to send OTP. Please try again.");
      toast.error("Failed to send OTP. Please try again.");
    } finally {
      setIsSending(false);
      setIsSendingChangeNumber(false);
    }
  };
  const handelClose = () => {
    switch (position) {
      case 2:
        setOtpChangeNumber("");
        setIsSendingChangeNumber(false);
        setResponseMessageChangeNumber("");
        setPhoneNumber("");
        setError("");
        onHide();
        break;
      case 1:
        setOtp("");
        setIsSending(false);
        setResponseMessage("");
        onHide();
        break;
      case 3:
        setOtpEmailVerify("")
        onHide();
        break;
        case 4:
        setOtpEmailVerifyCompany("")
        onHide();
        break;
      default:
        // Handle other cases if needed
        break;
    }
  };
  const handleConfirm = async () => {
    const token = await localStorage.getItem("token");
    switch (position) {
      case 2:
        if (otpChangeNumber !== null) {
          try {
            const responseData = await axiosInstance.post(
              "changeNumberOtpVerify",
              {
                otp: otpChangeNumber,
                loginId: profileId,
                contact_number: phoneNumber,
              },
              {
                headers: {
                  Authorization: `${token}`,
                },
              }
            );
  
            if (responseData.data.code === 200) {
              if (responseData.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
                handleSubmit();
              } else {
                toast.error(responseData.data.ack_msg);
              }
            } else {
              toast.error(responseData.data.ack_msg);
            }
          } catch (error) {
            toast.error("Failed to send OTP. Please try again.");
          }
        } else {
          toast.error("Please write OTP.");
        }
        break;
  
      case 1:
        if (responseMessage !== "") {
          try {
            const responseData = await axiosInstance.post(
              "loginDelete",
              {
                otp: otp,
                loginId: profileId,
              },
              {
                headers: {
                  Authorization: `${token}`,
                },
              }
            );
  
            if (responseData.data.code === 200) {
              if (responseData.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
                handleSubmit();
              } else {
                toast.error(responseData.data.ack_msg);
              }
            } else {
              toast.error(responseData.data.ack_msg);
            }
          } catch (error) {
            toast.error("Failed to send OTP. Please try again.");
          }
        } else {
          toast.error("Please select the type and send.");
        }
        break;
  
      case 3:
        // Add logic for position 3
          try {
            const responseData = await axiosInstance.post(
              "emailVerification",
              {
                // Include relevant payload for position 3
                loginId:profileId,
                otp: otpEmailVerify,
              },
              {
                headers: {
                  Authorization: `${token}`,
                },
              }
            );
  
            if (responseData.data.code === 200) {
              if (responseData.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
                handleSubmit();
              } else {
                toast.error(responseData.data.ack_msg);
              }
            } else {
              toast.error(responseData.data.ack_msg);
            }
          } catch (error) {
            toast.error("Failed to complete , Please try again.");
          }
        break;
        case 4:
          // Add logic for position 3
            try {
              const responseData = await axiosInstance.post(
                "otpEmailVerificationCompany",
                {
                  // Include relevant payload for position 3
                  company_id:profileId,
                  company_otp: otpEmailVerifyCompany,
                },
                {
                  headers: {
                    Authorization: `${token}`,
                  },
                }
              );
    
              if (responseData.data.code === 200) {
                if (responseData.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
                  handleSubmit();
                } else {
                  toast.error(responseData.data.ack_msg);
                }
              } else {
                toast.error(responseData.data.ack_msg);
              }
            } catch (error) {
              toast.error("Failed to complete , Please try again.");
            }
          break;
    
      default:
        toast.error("Invalid position.");
        break;
    }
  };
  const handlePhoneNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value;
    // Allow only numeric values
    if (!/^\d*$/.test(input)) {
      setError("Only numbers are allowed.");
      setPhoneNumber(input);
      return;
    }

    const numericValue = parseInt(input, 10);
    const min = 1000000000; // Example: 10-digit minimum
    const max = 9999999999; // Example: 10-digit maximum

    // Clear error and update state if input is valid
    if (input === "") {
      setError("");
      setPhoneNumber("");
    } else if (numericValue < min || numericValue > max) {
        if(numericValue < min){
      setError(`Min mobile number 10.`);
      // Max mobile number 15
      setPhoneNumber(input);
        }else{
          setError(`Max mobile number 10.`);
          // Max mobile number 15
          setPhoneNumber(input);
        }
    } else {
      setError(""); // Clear error if valid
      setPhoneNumber(input);
    }
  };
  return (
    <React.Fragment>
      <Modal
        show={show}
        onHide={handelClose}
        centered
        backdrop="static" // Prevents closing on outside click
        className={modalThemeClass1}
      >
        <div className={` p-10 m-title text-center ${modalThemeClass}`}>
          {title}
        </div>
        <Modal.Body className={`${modalThemeClass}`}>
          {message ? (
            <>
              <p
                className={`m-title-2 text-center ${modalThemeClass}`}
              >
                {message}
              </p>
            </>
          ) : (
            <span></span>
          )}
          {position === 1 && (
            <>
              <div className="text-center mb-3">
                <label className="fw-bold">Verify using</label>
                <div className="d-flex justify-content-center mt-2">
                  <div className="form-check me-3">
                    <input
                      type="radio"
                      id="whatsapp"
                      name="verificationOption"
                      value="whatsapp"
                      checked={selectedOption === "whatsapp"}
                      onChange={handleOptionChange}
                      className="form-check-input-custom"
                    />
                    <label htmlFor="whatsapp" className="form-check-label">
                      WhatsApp Number {mobileNumber ? `(${mobileNumber})` : ""}
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      type="radio"
                      id="email"
                      name="verificationOption"
                      value="email"
                      checked={selectedOption === "email"}
                      onChange={handleOptionChange}
                      className="form-check-input-custom"
                    />
                    <label htmlFor="email" className="form-check-label">
                      Email {emailId ? `(${emailId})` : ""}
                    </label>
                  </div>
                </div>
                <button
                  onClick={handleSendOTP}
                  className="btn btn-primary mt-3"
                  disabled={isSending}
                >
                  {isSending ? "Sending..." : "Send"}
                </button>
              </div>
              {responseMessage && (
                <>
                  <div className="text-center text-success mb-3">
                    <strong>{responseMessage}</strong>
                  </div>
                  <div className=" text-center ">
                    <label htmlFor="OTP" className="  mb-2 fw-bold">
                      Enter OTP
                      <span className="text-danger">*</span>
                    </label>

                    <span
                      style={{ margin: "8px" }}
                      className="d-flex justify-content-center"
                    >
                      <OTPInput
                        value={otp}
                        onChange={setOtp}
                        numInputs={6}
                        renderSeparator={
                          <span style={{ margin: "5px" }}>-</span>
                        }
                        renderInput={(props: any) => (
                          <input
                            {...props}
                            style={{ width: "40px", padding: "5px" }}
                          />
                        )}
                      />
                    </span>
                  </div>
                </>
              )}
            </>
          )}
          {position === 2 && (
            <>
              <div className="text-center mb-3">
                <label className="fw-bold">Verify using</label>
                <div className="d-flex justify-content-center mt-2">
                  <input
                    type="text"
                    className="form-control mt-2"
                    placeholder="Enter new WhatsApp number"
                    value={phoneNumber || ""}
                    onChange={(e) => handlePhoneNumberChange(e)} // Update state on change
                  />
                </div>
                {error && (
                  <small className="text-danger mt-1 d-block">{error}</small>
                )}
                {!error && (
                  <button
                    onClick={handleSendOTP}
                    className="btn btn-primary mt-3"
                    disabled={isSendingChangeNumber}
                  >
                    {isSendingChangeNumber ? "Sending..." : "Send"}
                  </button>
                )}
              </div>
              {responseMessageChangeNumber && (
                <>
                  <div className="text-center text-success mb-3">
                    <strong>{responseMessageChangeNumber}</strong>
                  </div>
                  <div className=" text-center ">
                    <label htmlFor="OTP" className="  mb-2 fw-bold">
                      Enter OTP
                      <span className="text-danger">*</span>
                    </label>

                    <span
                      style={{ margin: "8px" }}
                      className="d-flex justify-content-center"
                    >
                      <OTPInput
                        value={otpChangeNumber}
                        onChange={setOtpChangeNumber}
                        numInputs={6}
                        renderSeparator={
                          <span style={{ margin: "5px" }}>-</span>
                        }
                        renderInput={(props: any) => (
                          <input
                            {...props}
                            style={{ width: "40px", padding: "5px" }}
                          />
                        )}
                      />
                    </span>
                  </div>
                </>
              )}
            </>
          )}
{position === 3 && (
            <>

                <>
                  <div className=" text-center ">
                    <label htmlFor="OTP" className="  mb-2 fw-bold">
                      Enter OTP
                      <span className="text-danger">*</span>
                    </label>

                    <span
                      style={{ margin: "8px" }}
                      className="d-flex justify-content-center"
                    >
                      <OTPInput
                        value={otpEmailVerify}
                        onChange={setOtpEmailVerify}
                        numInputs={6}
                        renderSeparator={
                          <span style={{ margin: "5px" }}>-</span>
                        }
                        renderInput={(props: any) => (
                          <input
                            {...props}
                            style={{ width: "40px", padding: "5px" }}
                          />
                        )}
                      />
                    </span>
                  </div>
                </>
            </>
          )}
          {position === 4 && (
            <>

                <>
                  <div className=" text-center ">
                    <label htmlFor="OTP" className="  mb-2 fw-bold">
                      Enter OTP
                      <span className="text-danger">*</span>
                    </label>

                    <span
                      style={{ margin: "8px" }}
                      className="d-flex justify-content-center"
                    >
                      <OTPInput
                        value={otpEmailVerifyCompany}
                        onChange={setOtpEmailVerifyCompany}
                        numInputs={6}
                        renderSeparator={
                          <span style={{ margin: "5px" }}>-</span>
                        }
                        renderInput={(props: any) => (
                          <input
                            {...props}
                            style={{ width: "40px", padding: "5px" }}
                          />
                        )}
                      />
                    </span>
                  </div>
                </>
            </>
          )}
          <div className="d-flex justify-content-end  m-btn">
            <Button className="mr-2 px-4 btn1" onClick={handelClose}>
              {btn1}
            </Button>
            <Button className="px-4 ms-2 btn2" onClick={handleConfirm}>
              {btn2}
            </Button>
          </div>
        </Modal.Body>
      </Modal>
    </React.Fragment>
  );
};

export default OtpConfirmationModal;
