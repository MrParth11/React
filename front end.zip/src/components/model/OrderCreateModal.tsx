import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import "./ConfirmationModal.css";
import { toast } from "react-toastify";
import {
  DEFAULT_MESSAGE_ERROR_PERMISSION,
  DEFAULT_STATUS_CODE_SUCCESS,
  DEFAULT_TCS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
  SMALL_TEXT_LENGTH,
  TEXTAREA_TEXT_LENGTH,
} from "../../helpers/AppConstants";
import { axiosInstance } from "../../services/axiosInstance";
import CustomSearchDropdown from "../CustomSearchDropdown";
import { SingleValue } from "react-select";
import { IOption } from "../../helpers/AppInterface";
import { IUserList } from "../../pages/left-side/LeftSideController";
import ConfirmationModal from "./ConfirmationModal";
import {
  formatDateSendDataBase,
  formatDateTimeSendDataBase,
  formatNumber,
  openInNewTab,
} from "../../common/SharedFunction";
import { useReactToPrint } from "react-to-print";
import useCheckUserPermission from "../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../helpers/AppEnum";

//isOrderShowNum 1 => quotation/Estimate,2 => order,3 => Invoice
interface IOrderCreateModal {
  show: boolean;
  onHide: () => void;
  handleSubmit: () => void;
  title: string;
  message: string;
  btn1: string;
  btn2: string;
  Contact?: IUserList;
  isOrderShowNum: number;
  orderById?: any;
  companyDetail?: any;
}

interface ICart {

  id: number;
  company_masters_id: number;
  a_application_login_id: number;
  product_name: number;
  category_id: number;
  unit: string;
  rate: number | string;
  GST: number;
  net_rate: number;
  category_name: string;
  quantity: number;
  item_discount_pct: number | string;
  price_list_discount: number;
}

interface ICartItem {
  id: number;
  cart_id: number;
  item_category_id: number;
  item_category_name: string;
  item_product_id: number;
  item_product_name: string;
  item_unit_name: string;
  item_rate: number;
  item_gst: number;
  item_net_rate: number;
  item_qty: number;
  item_total: number;
  item_product_description: string;
  item_discount_pct: number;
}
const OrderCreateModal: React.FC<IOrderCreateModal> = ({
  show,
  onHide,
  handleSubmit,
  title,
  message,
  btn1,
  btn2,
  Contact,
  isOrderShowNum,
  orderById,
  companyDetail,
}) => {

  const [productList, setProductList] = useState<any>([]);
  const [cart, setCart] = useState<ICart[]>([]);
  const [categoryList, setCategoryList] = useState<any>([]);
  const [selectedCategory, setSelectedCategory] = useState<any>(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchBarcodeNum, setSearchBarcodeNum] = useState(0);

  const [typingTimeout, setTypingTimeout] = useState<NodeJS.Timeout | null>(
    null
  );
  const [isCloseConfirmation, setIsCloseConfirmation] = useState(false);
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);

  const [discount, setDiscount] = useState<string | number>(0);
  const [cartId, setCartId] = useState(0);
  const [packingForwardingCharge, setPackingForwardingCharge] = useState<
    string | number
  >(0);
  const [transportCharge, setTransportCharge] = useState<string | number>(0);
  const [isTcsActive, setIsTcsActive] = useState(false);
  const [isGstActive, setIsGstActive] = useState(true);
  const [isOrderPdfShow, setIsOrderPdfShow] = useState(false);

  const [grandTotal, setGrandTotal] = useState(0);
  const [tcsAmount, setTcsAmount] = useState(0);
  const [roundOffAmount, setRoundOffAmount] = useState(0);
  const [taxAbleAmount, setTaxAbleAmount] = useState(0);
  const [gstAmount, setGstAmount] = useState(0);
  const [cartRemark, setCartRemark] = useState("");
  const [productWiseDescription, setProductWiseDescription] = useState(
    cart.map(() => "")
  );
  const [isBarcode, setIsBarcode] = useState(false);

  const [cartTermsAndCondition, setCartTermsAndCondition] = useState("");
  const [cartnumber, setCartNumber] = useState("");

  const componentRef = useRef<HTMLDivElement>(null);
  const [highlightedProductId, setHighlightedProductId] = useState<
    number | null
  >(null);

  const canViewProduct = useCheckUserPermission(
    PAGE_ID.PRODUCT,
    PERMISSION_TYPE.VIEW
  );
  const canViewCategory = useCheckUserPermission(
    PAGE_ID.CATEGORY,
    PERMISSION_TYPE.VIEW
  );
  const canApproveQuo = useCheckUserPermission(
    PAGE_ID.QUOTATION,
    PERMISSION_TYPE.APPROVE
  );
  const canApproveOrder = useCheckUserPermission(
    PAGE_ID.ORDER,
    PERMISSION_TYPE.APPROVE
  );
  const canApproveInv = useCheckUserPermission(
    PAGE_ID.INVOICE,
    PERMISSION_TYPE.APPROVE
  );
  const canApprovePurchase = useCheckUserPermission(
    PAGE_ID.PURCHASE,
    PERMISSION_TYPE.APPROVE
  );
  const canEditQuo = useCheckUserPermission(
    PAGE_ID.QUOTATION,
    PERMISSION_TYPE.EDIT
  );
  const canEditOrder = useCheckUserPermission(
    PAGE_ID.ORDER,
    PERMISSION_TYPE.EDIT
  );
  const canEditInv = useCheckUserPermission(
    PAGE_ID.INVOICE,
    PERMISSION_TYPE.EDIT
  );
  const canEditPurchase = useCheckUserPermission(
    PAGE_ID.PURCHASE,
    PERMISSION_TYPE.EDIT
  );
  const canPrintInv = useCheckUserPermission(
    PAGE_ID.INVOICE,
    PERMISSION_TYPE.PRINT
  );

  const canPrintOrder = useCheckUserPermission(
    PAGE_ID.ORDER,
    PERMISSION_TYPE.PRINT
  );
  const canPrintQuo = useCheckUserPermission(
    PAGE_ID.QUOTATION,
    PERMISSION_TYPE.PRINT
  );
  const canPrintPurchase = useCheckUserPermission(
    PAGE_ID.PURCHASE,
    PERMISSION_TYPE.PRINT
  );

  const canPdfInv = useCheckUserPermission(
    PAGE_ID.INVOICE,
    PERMISSION_TYPE.SHARE
  );

  const canPdfOrder = useCheckUserPermission(
    PAGE_ID.ORDER,
    PERMISSION_TYPE.SHARE
  );
  const canPdfQuo = useCheckUserPermission(
    PAGE_ID.QUOTATION,
    PERMISSION_TYPE.SHARE
  );
  const canPdfPurchase = useCheckUserPermission(
    PAGE_ID.PURCHASE,
    PERMISSION_TYPE.SHARE
  );

  useEffect(() => {
    if (companyDetail && companyDetail.length > 0) {
      setCartTermsAndCondition(
        companyDetail[0]
          .replace(/<br\s*\/?>/gi, "\n") // Replace <br> or <br/> with \n
          .replace(/<[^>]*>/g, "")
      ); // Set first element as default
    }
  }, [companyDetail]);
  const [cartItemDelete, setCartItemDelete] = useState<
    { cart_item_id_del: number }[]
  >([]);

  const orderTypesList = [
    { id: "1", order_type: "Quotation" },
    { id: "2", order_type: "Sales Order" },
    { id: "3", order_type: "Sales Invoice" },
    { id: "4", order_type: "Purchase Invoice" },
  ];

  useEffect(() => {
    if (orderById && orderById.items) {
      const formattedItems = orderById.items.map((item: ICartItem) => ({
        id: item.item_product_id,
        product_name: item.item_product_name,
        net_rate: item.item_net_rate,
        quantity: item.item_qty,
        unit: item.item_unit_name,
        cart_item_id: item.id,
        category_id: item.item_category_id,
        category_name: item.item_category_name,
        GST: item.item_gst,
        rate: item.item_rate,
        item_discount_pct: item.item_discount_pct,
      }));
      const descriptions = orderById.items.map(
        (item: ICartItem) => item.item_product_description || ""
      );

      setCart(formattedItems);
      setProductWiseDescription(descriptions);
    }
    if (orderById && orderById.cart) {
      setCartId(orderById.cart.id);
      setDiscount(orderById.cart.discount_pct);
      setCartNumber(orderById.cart.cart_number);
      setPackingForwardingCharge(orderById.cart.packing_forwarding_charge);
      setTransportCharge(orderById.cart.transport_charge);
      setGrandTotal(orderById.cart.grand_total);
      setIsTcsActive(orderById.cart.tcs_amt > 0);
      setTcsAmount(orderById.cart.grand_total.tcs_amt);
      setIsGstActive(orderById.cart.gst_amt > 0);

      setGstAmount(orderById.cart.grand_total.gst_amt);

      setRoundOffAmount(orderById.cart.round_off);
      setTaxAbleAmount(orderById.cart.taxable_amt);
      setCartRemark(orderById.cart.cart_remark);
      setCartTermsAndCondition(
        orderById.cart.cart_terms_and_condition
          .replace(/<br\s*\/?>/gi, "\n") // Replace <br> or <br/> with \n
          .replace(/<[^>]*>/g, "")
      );
    }
  }, [orderById]);
  const addToCart = (item: ICart) => {
    setCart((prevCart) => {
      const initialRate = item.rate || 0;
      const initialDiscount = item.price_list_discount || 0;
      const initialNetRate = calculateNetRate(
        Number(initialRate),
        Number(initialDiscount),
        item.GST
      );

      // Add the same product as a new entry in the cart
      return [
        ...prevCart,
        {
          ...item,
          quantity: 1,
          rate: initialRate,
          item_discount_pct: item.price_list_discount || 0,
          net_rate: initialNetRate,
        },
      ];
    });
  };


  const handleQuantityChange = (index: number, newQuantity: number) => {
    const updatedCart = [...cart];
    updatedCart[index].quantity = newQuantity > 0 ? newQuantity : 1; // Ensure quantity is at least 1
    setCart(updatedCart);
  };

  const calculateAmount = (netRate: number | string, quantity: number) => {
    return Number(netRate) * quantity;
  };
  const isProductInCart = (itemId: number) => {
    return cart.some((cartItem) => cartItem.id === itemId);
  };
  // Remove item from cart
  const handleRemoveItem = (removeItem: any, indexToRemove: number) => {
    setProductWiseDescription([]);
    if (orderById && orderById) {
      setIsDeleteConfirmation(true);
      setCartItemDelete((prevDeletedIds) => [
        ...prevDeletedIds,
        { cart_item_id_del: removeItem.cart_item_id },
      ]);
      setCart((prevCart) =>
        prevCart.filter((_, index) => index !== indexToRemove)
      );
    } else {
      setIsDeleteConfirmation(false);

      setCart((prevCart) =>
        prevCart.filter((_, index) => index !== indexToRemove)
      );
    }

  };

  const handleHide = () => {
    setCart([]);
    setDiscount(0);
    setPackingForwardingCharge(0);
    setTransportCharge(0);
    setTcsAmount(0);
    setGstAmount(0);
    setGrandTotal(0);
    setRoundOffAmount(0);
    setCartItemDelete([]);
    setIsTcsActive(false);
    setSelectedCategory("");
    setCartRemark("");
    setCartTermsAndCondition("");
    setProductWiseDescription([]);
    onHide();
    setHighlightedProductId(0);
    setSearchTerm("");
    setSearchBarcodeNum(0);
    setIsCloseConfirmation(false);
  };

  const handleCategoryChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedCategory(selectedOption);
  };
  const categoryOptions = categoryList.map((category: any) => ({
    value: category.id,
    label: category.category_name,
  }));
  const fetchProductApiForOrder = async (
    search: string,
    searchBarcodeNum1: number
  ) => {
    const token = await localStorage.getItem("token");

    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      a_application_login_id: getUUID,
      searchTerm: search || "",
      searchBarcodeNum: searchBarcodeNum1,
      searchCategoryId: selectedCategory ? selectedCategory.value : null,
      assinged_to_price_list: Contact?.assinged_to_price_list,
    };
    if (canViewProduct) {
      try {
        const data = await axiosInstance.post("product", requestData, {
          headers: {
            Authorization: `${token}`,
            "x-tenant-id": getUUID,
          },
        }
        );
        if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
          setProductList([]);

        }
        setProductList(data.data.data.item);
      } catch (error: any) {
        toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  };
  const fetchCategoryApiForOrder = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "categories",
      columns: "id,category_name",
      where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
      request_flag: 0,
      order: `{"id":"DESC"}`,
    };
    if (canViewCategory) {
      try {
        const response = await axiosInstance.post("commonGet", requestData, {
          headers: {
            "x-tenant-id": getUUID,
          },
        });

        setCategoryList(response.data.data); // Assuming API response is an array of countries
      } catch (error) {
        console.error("Error fetching countries:", error);
        // Handle error (e.g., show error message, clear filtered list)
        setCategoryList([]);
      }
    }
  };
  useEffect(() => {

    fetchProductApiForOrder(searchTerm, searchBarcodeNum);
    fetchCategoryApiForOrder();
    // }
  }, [selectedCategory, show]);
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const barcodeDetected = !!(Number(value) && value.length === 13);
    setIsBarcode(barcodeDetected); // Update barcode detection state

    setSearchTerm(value);

    // If there is a timeout already, clear it
    if (typingTimeout) {
      clearTimeout(typingTimeout);
    }

    // Set a new timeout to delay the API call
    const newTimeout = setTimeout(() => {
      if (barcodeDetected) {
        console.log("Searching barcode:", value);
        fetchProductApiForOrder("", Number(value)); // Search only by barcode
      } else {
        if (value.length >= 3) {
          fetchProductApiForOrder(value, 0); // Search by product name if 3+ characters
        } else if (value.length === 0) {
          fetchProductApiForOrder("", 0); // Fetch all products if cleared
          setSearchTerm("");
        } else {
          setProductList([]); // Clear product list if input is less than 3 characters
        }
      }
    }, 100); // 1-second delay

    setTypingTimeout(newTimeout);
  };

  // Calculate total quantity
  const totalQuantity = cart.reduce((total, item) => total + item.quantity, 0);

  //  // Calculate total amount
  // Calculate total amount using beforeGstRate
  const totalAmount = cart.reduce((total, item) => {
    const beforeGstRate =
      Number(item.rate) -
      (Number(item.rate) * Number(item.item_discount_pct)) / 100;
    return total + item.quantity * beforeGstRate;
  }, 0);

  const totalGst = cart.reduce((total, item) => {
    // Step 2: DISCOUNT_AMOUNT = (rate * discount) / 100
    const discount_amount =
      (Number(item.rate) * Number(item.item_discount_pct)) / 100;
    // Step 3: discounted_amount = rate - discount_amount
    const discounted_amount = Number(item.rate) - discount_amount;
    // Step 1: gst_amount = (gst * discounted_amount) / 100
    const gst_amount = (item.GST * discounted_amount) / 100;

    const totalQut = gst_amount * item.quantity;
    return total + totalQut;
  }, 0);

  // Handle discount input
  const handleDiscountChange = (e: { target: HTMLInputElement }) => {
    const target = e.target as HTMLInputElement;
    let value = target.value; // Allow only numbers and a single decimal point
    console.log("handleDiscountChange", value);
    // Allow only numbers and a single decimal point
    if (!/^\d*\.?\d*$/.test(value)) {
      return; // Do nothing if the input is invalid
    }
    // Convert to a number for validation, then back to a string if within range
    const discountValue = value;

    if (Number(discountValue) < 100) {
      setDiscount(discountValue);
    } else {
      toast.error("You cant add Discount More Than Total Amount");
      setDiscount(0);
    }
  };
  const showDiscount = (totalAmount * parseFloat(discount as string)) / 100;

  const handlePackingForwardingChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    let value = e.target.value;

    // Allow only numbers and a single decimal point
    if (!/^\d*\.?\d*$/.test(value)) {
      return; // Ignore invalid input
    }

    // Ensure there's at most one decimal point and valid format
    if (value.startsWith(".")) {
      value = "0" + value; // Prepend '0' if input starts with a decimal point
    }

    setPackingForwardingCharge(value); // Store as string for accurate display

    const numericValue = parseFloat(value) || 0; // Convert to number for calculations
    console.log("handlePackingForwardingChange", numericValue);

  };

  const handleTransportCharge = (e: React.ChangeEvent<HTMLInputElement>) => {
    const target = e.target;
    let value = e.target.value; // Allow only numbers and a single decimal point

    // Allow only numbers and a single decimal point
    if (!/^\d*\.?\d*$/.test(value)) {
      return; // Ignore invalid input
    }
    // Ensure there's at most one decimal point and valid format
    if (value.startsWith(".")) {
      value = "0" + value; // Prepend '0' if input starts with a decimal point
    }
    setTransportCharge(value);

    const numericValue = parseFloat(value) || 0; // Convert to number for calculations
    console.log("handleTransportCharge", numericValue);

  };
  const handleRateChange = (
    index: number,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    let item_vir_rate = e.target.value;

    // Allow only numbers and a single decimal point
    if (!/^\d*\.?\d*$/.test(item_vir_rate)) {
      return; // Ignore invalid input
    }

    if (Number(item_vir_rate) === 0) {
      toast.error("Add Price Greater Than Minimum Selling Price");
      setCart((prevCart) =>
        prevCart.map((item, i) =>
          i === index
            ? {
              ...item,
              rate: item.rate,
              net_rate: calculateNetRate(
                Number(item.rate),
                Number(item.item_discount_pct),
                item.GST
              ),
            }
            : item
        )
      );
    } else {
      setCart((prevCart) =>
        prevCart.map((item, i) =>
          i === index
            ? {
              ...item,
              rate: item_vir_rate,
              net_rate: calculateNetRate(
                parseFloat(item_vir_rate),
                Number(item.item_discount_pct),
                item.GST
              ),
            }
            : item
        )
      );
    }
  };

  const handleProductItemDiscountChange = (
    index: number,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    let item_vir_discount = e.target.value;

    // Allow only numbers and a single decimal point
    if (!/^\d*\.?\d*$/.test(item_vir_discount)) {
      return; // Ignore invalid input
    }
    if (Number(item_vir_discount) < 100) {
      setCart((prevCart) =>
        prevCart.map((item, i) =>
          i === index
            ? {
              ...item,
              item_discount_pct: item_vir_discount,
              net_rate: calculateNetRate(
                Number(item.rate),
                parseFloat(item_vir_discount),
                item.GST
              ),
            }
            : item
        )
      );
    } else {
      toast.error("You cant add Discount More Than Rate");
      setCart((prevCart) =>
        prevCart.map((item, i) =>
          i === index
            ? {
              ...item,
              item_discount_pct: 0,
              itemVirNetRate: calculateNetRate(
                Number(item.rate),
                0,
                item.GST
              ),
            }
            : item
        )
      );
    }
  };

  const calculateNetRate = (rate: number, discount: number, gst: number) => {
    // Step 2: DISCOUNT_AMOUNT = (rate * discount) / 100
    const discount_amount = (rate * discount) / 100;
    // Step 3: discounted_amount = rate - discount_amount
    const discounted_amount = rate - discount_amount;
    // Step 1: gst_amount = (gst * discounted_amount) / 100
    const gst_amount = (gst * discounted_amount) / 100;
    // Step 4: final = gst_amount + discounted_amount
    const final = gst_amount + discounted_amount;

    return final;
  };
  const orderTypesNameFind =
    orderTypesList.find((option) => Number(option.id) === isOrderShowNum)
      ?.order_type || "";
  const handleDescriptionChange = (index: number, value: string) => {
    const updatedDescriptions = [...productWiseDescription];
    updatedDescriptions[index] = value;
    setProductWiseDescription(updatedDescriptions);
  };
  useEffect(() => {
    const packingCharge = parseFloat(packingForwardingCharge as string) || 0;
    const transportChargeValue = parseFloat(transportCharge as string) || 0;

    setTaxAbleAmount(
      totalAmount - showDiscount + packingCharge + transportChargeValue
    );
  }, [totalAmount, showDiscount, packingForwardingCharge, transportCharge]);

  useEffect(() => {
    const tcs = isTcsActive ? (taxAbleAmount + gstAmount) * DEFAULT_TCS : 0;
    setTcsAmount(tcs);
  }, [gstAmount, isTcsActive, taxAbleAmount]);
  useEffect(() => {
    const gstFinal = isGstActive ? totalGst : 0;
    setGstAmount(gstFinal);
  }, [isGstActive, totalGst]);
  useEffect(() => {
    const findRound = taxAbleAmount + gstAmount + tcsAmount;
    const findRound1 = Math.floor(taxAbleAmount + gstAmount + tcsAmount);

    const roundAmount = findRound - findRound1;

    setRoundOffAmount(roundAmount);
  }, [gstAmount, taxAbleAmount, tcsAmount]);
  useEffect(() => {
    const grandAmount = Math.round(taxAbleAmount + gstAmount + tcsAmount);

    setGrandTotal(grandAmount);
  }, [gstAmount, taxAbleAmount, tcsAmount]);
  const onSaveAndDraft = async (isApprove: number) => {

    const token = await localStorage.getItem("token");
    const localId = await localStorage.getItem("UUID");
    const currentDateTime = new Date();
    const formattedDateTime = formatDateSendDataBase(currentDateTime);
    const a_application_login_id = Number(localId);
    const cartPayload = {
      country_id: Contact?.country,
      state_id: Contact?.state,
      city_id: Contact?.city,
      area_id: Contact?.area,
      PinCode: Contact?.pincode,
      Address: Contact?.address,
      shipping_address: Contact?.shipping_address,
      to_customer_id: Contact?.id,
      to_customer_name: Contact?.person_name,
      to_customer_phone: Contact?.mobile_number,
      to_customer_gst_number: Contact?.gst_number,
      to_customer_price_list_id: Contact?.assinged_to_price_list,
      type: isOrderShowNum,
      cart_remark: cartRemark,
      account_transactions_ref_table: "carts",
      grand_total: grandTotal ? formatNumber(grandTotal, 2) : 0,
      transport_charge: transportCharge,
      taxable_amt: taxAbleAmount,
      tcs_amt: tcsAmount,
      gst_amt: gstAmount,
      round_off: roundOffAmount,
      total_amt: totalAmount,
      total_qty: totalQuantity,
      discount_pct: discount,
      discount_pr: showDiscount,
      packing_forwarding_charge: packingForwardingCharge,
      cart_terms_and_condition: cartTermsAndCondition.replace(/\n/g, "<br>"),
      cart_date: formattedDateTime,
    };

    const cartItemsPayload = cart.map((item, index) => ({
      item_category_id: item.category_id,
      item_category_name: item.category_name,
      item_product_id: item.id,
      item_product_name: item.product_name,
      item_unit_name: item.unit,
      item_rate: item.rate,
      item_gst: item.GST,
      item_net_rate: item.net_rate,
      item_qty: item.quantity,
      item_total: calculateAmount(item.net_rate, item.quantity),
      item_discount_pct: item.item_discount_pct,
      item_product_description: productWiseDescription[index],
    }));
    console.log("cartItemsPayload", cartItemsPayload);

    const combinedPayload = {
      cart: cartPayload,
      items: cartItemsPayload,
      a_application_login_id,
      is_approve: isApprove,
    };

    const cartItemsForUpdatePayload = cart.map((item: any, index: number) => ({
      id: item.cart_item_id,
      item_category_id: item.category_id,
      item_category_name: item.category_name,
      item_product_id: item.id,
      item_product_name: item.product_name,
      item_unit_name: item.unit,
      item_rate: item.rate,
      item_gst: item.GST,
      item_net_rate: item.net_rate,
      item_qty: item.quantity,
      item_total: calculateAmount(item.net_rate, item.quantity),
      item_discount_pct: item.item_discount_pct,
      item_product_description: productWiseDescription[index],
    }));
    const { cart_date, type, ...filteredCartPayload } = cartPayload; // Exclude cart_date

    console.log("cartItemsForUpdatePayload", cartItemsForUpdatePayload);
    const update_cart_items: any = cartItemDelete.concat(
      cartItemsForUpdatePayload as any
    );

    const combinedPayloadUpdate = {
      update_cart: cartPayload,
      update_cart_items: update_cart_items,
      cart_id: cartId,
      a_application_login_id,
      is_approve: isApprove,
    };
    console.log("combinedPayloadUpdate", combinedPayloadUpdate);

    try {
      if (orderById && orderById) {
        const { data } = await axiosInstance.post(
          "updateOrder",
          combinedPayloadUpdate,
          {
            headers: {
              Authorization: `${token}`,
              "x-tenant-id": localId,
            },
          }
        );
        if (data.code === 200) {
          if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
            console.log("createData", data);
            handleSubmit();
            handleHide();
          } else {
            toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
          }
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      } else {
        const { data } = await axiosInstance.post(
          "createOrder",
          combinedPayload,
          {
            headers: {
              Authorization: `${token}`,
              "x-tenant-id": localId,
            },
          }
        );
        if (data.code === 200) {
          if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
            console.log("createData", data);
            handleSubmit();
            handleHide();
          } else {
            toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
          }
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };
  const printFn = useReactToPrint({
    contentRef: componentRef,
    documentTitle: "AwesomeFileName",
  });
  const openInNewTabPrint = (path: string) => {
    const baseURL = window.location.origin; // Get the current base URL
    const token = localStorage.getItem("token");

    window.open(`${baseURL}${path}/${cartId}`, "_blank");
  };
  const openInNewTabPdf = (path: string) => {
    const baseURL = window.location.origin; // Get the current base URL
    const url = `${baseURL}${path}/${cartId}`;

    // Open a new tab with the PDF URL
    const newTab = window.open(url, "_blank");

    if (newTab) {
      // Optionally, close the new tab after 5 seconds (or some other condition)
      setTimeout(() => {
        newTab.close();
      }, 1000);
    }
  };
  const editCart = () => {
    console.log("cartnumber", orderById);

    if (!orderById) {
      onSaveAndDraft(2);
    } else {
      const permissionMap: Record<number, boolean> = {
        1: canEditQuo,
        2: canEditOrder,
        3: canEditInv,
        4: canEditPurchase,
      };

      if (permissionMap[isOrderShowNum]) {
        onSaveAndDraft(2);
      } else {
        toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
      }
    }
  };

  const onSubmit = async () => {
    if (orderById) {
      const permissionMap1: Record<number, boolean> = {
        1: canApproveQuo,
        2: canApproveOrder,
        3: canApproveInv,
        4: canApprovePurchase,
      };
      const permissionMap: Record<number, boolean> = {
        1: canEditQuo,
        2: canEditOrder,
        3: canEditInv,
        4: canEditPurchase,
      };

      if (permissionMap[isOrderShowNum] && permissionMap1[isOrderShowNum]) {
        onSaveAndDraft(1);
      } else {
        toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
      }
    } else {
      const permissionMap: Record<number, boolean> = {
        1: canApproveQuo,
        2: canApproveOrder,
        3: canApproveInv,
        4: canApprovePurchase,
      };

      if (permissionMap[isOrderShowNum]) {
        onSaveAndDraft(1);
      } else {
        toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
      }
    }
  };
  function openPrint() {
    const permissionMap: Record<number, boolean> = {
      1: canPrintQuo,
      2: canPrintOrder,
      3: canPrintInv,
      4: canPrintPurchase,
    };

    if (permissionMap[isOrderShowNum]) {
      openInNewTabPrint("/OrderPrintViewV1");
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }

  const handleDownload = async () => {
    try {
      const token = localStorage.getItem("token")
      const getUUID = localStorage.getItem("UUID")

      const resops = await axiosInstance.post("/order-pdf", { cart_id: cartId }, {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      })
      if (resops.data.ack === 1) {
        const fileUrl = resops.data.data;

        // Fetch the file using axios
        const response = await axios.get(fileUrl, { responseType: "blob" });

        // Create a Blob from the file data
        const fileName = "Pdf"; // Optionally extract the filename

        const blob = new Blob([response.data], {
          type: response.headers["content-type"],
        });
        const url = URL.createObjectURL(blob);

        // Create a link and trigger download
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", fileName); // Set the filename dynamically
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url); // Free up memory
        handleHide()
      } else {
        toast.error(resops.data.ack_msg)
      }
    } catch (error: any) {
      toast.error(error)

      console.error("Error downloading the file", error);
    }
  };
  function openPdf() {
    const permissionMap: Record<number, boolean> = {
      1: canPdfQuo,
      2: canPdfOrder,
      3: canPdfInv,
      4: canPdfPurchase,
    };

    if (permissionMap[isOrderShowNum]) {
      handleDownload();
      //  openInNewTabPdf("/OrderPdfViewV1");
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      if (isBarcode && productList && productList.length > 0) {
        addToCart(productList[0]); // Automatically add the first product
        toast.success("Product add successfully in cart ");
      }
      setSearchTerm(""); // Clear the input field after pressing Enter
      setSearchBarcodeNum(0);
      setIsBarcode(false);
      fetchProductApiForOrder("", 0); // Fetch all products if cleared
    }
  };

  return (
    <div>
      {show && (
        <div className="modal1">
          <div
            className="modal-content1"
            style={{
              width: "98%",
              backgroundColor: "rgb(240 242 245)",
              marginTop: "10px",
            }}
          >
            <div className="row">
              <div className="col-10">

                <h2
                  className="modal-title1 form_header_text "
                  style={{ paddingLeft: "20%", paddingTop: "15px" }}
                >
                  {title} {orderTypesNameFind} ({Contact?.person_name})
                </h2>

              </div>
              <div className="col-2">
                <div className="d-flex align-items-center justify-content-end">
                  <span>
                    <p
                      className="landing-page-text text-end"
                      style={{ cursor: "pointer", color: "blue", float: "right", fontSize: "13px" }}
                    onClick={() => openInNewTab("/videoTutorial", 12)}
                    >
                      Learn More : <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#0000FF"><path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" /></svg>
                    </p>
                  </span>
                  
                  <span
                    className="close ms-3 pb-3"
                    onClick={() => setIsCloseConfirmation(true)}
                  >
                    &times;
                  </span>
                </div>
                {orderById && orderById ? (
                  <>
                    <span className="close px-1" onClick={openPrint}>
                      <svg
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="24px"
                        fill="currentColor"
                      >
                        <path d="M640-640v-120H320v120h-80v-200h480v200h-80Zm-480 80h640-640Zm560 100q17 0 28.5-11.5T760-500q0-17-11.5-28.5T720-540q-17 0-28.5 11.5T680-500q0 17 11.5 28.5T720-460Zm-80 260v-160H320v160h320Zm80 80H240v-160H80v-240q0-51 35-85.5t85-34.5h560q51 0 85.5 34.5T880-520v240H720v160Zm80-240v-160q0-17-11.5-28.5T760-560H200q-17 0-28.5 11.5T160-520v160h80v-80h480v80h80Z" />
                      </svg>
                    </span>
                    <span className="close " onClick={openPdf}>
                      <svg
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="24px"
                        fill="currentColor"
                      >
                        <path d="M480-320 280-520l56-58 104 104v-326h80v326l104-104 56 58-200 200ZM240-160q-33 0-56.5-23.5T160-240v-120h80v120h480v-120h80v120q0 33-23.5 56.5T720-160H240Z" />
                      </svg>
                    </span>
                  </>
                ) : (
                  <span></span>
                )}
              </div>
            </div>
            <p className="text-center" style={{ color: "#999" }}>
              <p>{message}</p>
            </p>
            <div className={`m-title-2 row `}>
              <div
                className="col-6  card"
                style={{ borderRadius: "0px", width: "55%" }}
              >
                <div
                  className="mt-2 table-responsive"
                  style={{ maxHeight: "50vh", overflowY: "auto" }}
                >
                  <table
                    className="table table-bordered"
                    border={0}
                    style={{ tableLayout: "fixed", width: "100%" }}
                  >
                    <thead
                      style={{
                        position: "sticky",
                        top: 0,
                        zIndex: 1000,
                        backgroundColor: "#F0F2F5",
                      }}
                    >
                      <tr>
                        <th
                          className="text-center"
                          style={{ width: "50px" }}
                        ></th>
                        <th
                          className="text-center order-text"
                        >
                          Product
                        </th>
                        <th
                          className="text-center order-text"
                        >
                          Desc.
                        </th>

                        <th
                          className="text-center order-text"
                        >
                          Rate
                        </th>
                        <th
                          className="text-center order-text"
                        >
                          Dis(%)
                        </th>
                        <th
                          className="text-center order-text"
                        >
                          GST(%)
                        </th>

                        <th
                          className="text-center order-text"
                        >
                          Net Rate
                        </th>
                        <th
                          className="text-center order-text"
                        >
                          Qty/unit
                        </th>

                        <th
                          className="text-center order-text"
                        >
                          Amt
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {cart.length > 0 ? (
                        cart.map((item, index) => {
                          return (
                            <tr key={index}>
                              <td className="text-center">
                                {cartnumber ? (
                                  <span></span>
                                ) : (
                                  <span
                                    style={{ cursor: "pointer" }}
                                    onClick={() =>
                                      handleRemoveItem(item, index)
                                    }
                                  >
                                    <svg
                                      viewBox="0 -960 960 960"
                                      width="22px"
                                      fill="currentColor"
                                    >
                                      <path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" />
                                    </svg>
                                  </span>
                                )}
                              </td>
                              <td className="text-start order-text">
                                {item.product_name}
                              </td>
                              <td>
                                <textarea
                                  className="form-control"
                                  value={productWiseDescription[index]}
                                  disabled={cartnumber ? true : false}
                                  onChange={(e) =>
                                    handleDescriptionChange(
                                      index,
                                      e.target.value
                                    )
                                  } // Update the specific index
                                ></textarea>
                              </td>
                              <td>
                                <input
                                  className="form-control"
                                  type="text"
                                  title="Rate"
                                  placeholder="Rate"
                                  value={item.rate}
                                  onChange={(e) => handleRateChange(index, e)}
                                  style={{ textAlign: "right" }}
                                  disabled={cartnumber ? true : false}
                                />
                              </td>
                              <td>
                                <input
                                  className="form-control"
                                  type="text"
                                  title="Discount"
                                  placeholder="Discount"
                                  style={{ textAlign: "right" }}
                                  disabled={cartnumber ? true : false}
                                  value={item.item_discount_pct}
                                  onChange={(e) =>
                                    handleProductItemDiscountChange(index, e)
                                  }
                                />
                              </td>

                              <td className="text-end order-text">
                                {item.GST}
                              </td>
                              <td className="text-end order-text">
                                {item.net_rate
                                  ? formatNumber(item.net_rate, 2)
                                  : 0}
                              </td>
                              <td className="">
                                <input
                                  className="form-control"
                                  type="text"
                                  title="Quantity"
                                  placeholder="Qty"
                                  value={item.quantity}
                                  onChange={(e) =>
                                    handleQuantityChange(
                                      index,
                                      parseInt(e.target.value)
                                    )
                                  }
                                  disabled={cartnumber ? true : false}
                                  style={{ textAlign: "right" }}
                                />
                                <span
                                  className="order-text text-end"
                                  style={{ fontSize: "12px" }}
                                >
                                  /{item?.unit}
                                </span>
                              </td>
                              <td className="text-end">
                                <span
                                  style={{
                                    width: "100%",
                                    textAlign: "right",
                                    display: "inline-block",
                                  }}
                                  title="Amount"
                                >
                                  {formatNumber(
                                    calculateAmount(
                                      item.net_rate,
                                      item.quantity
                                    ),
                                    2
                                  )}
                                </span>
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={9} className="text-center order-text">
                            No Products in the Cart
                          </td>
                        </tr>
                      )}
                    </tbody>
                    <tfoot style={{ backgroundColor: "rgb(240, 242, 245)" }}>
                      {cart.length > 0 ? (
                        <>
                          <tr className="table-bordered">
                            <td colSpan={7} className="order-text">
                              Total
                            </td>
                            <td className="text-end order-text">
                              {totalQuantity}
                            </td>
                            <td className="text-end order-text">
                              {totalAmount ? formatNumber(totalAmount, 2) : ""}
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={7} className="order-text">
                              Discount (%)
                            </td>
                            <td>
                              <input
                                type="text"
                                title="Discount"
                                placeholder="Discount"
                                className=""
                                style={{ width: "100%", textAlign: "right" }}
                                disabled={cartnumber ? true : false}
                                onChange={(e) => handleDiscountChange(e)}
                                value={discount}
                              />
                            </td>
                            <td style={{ textAlign: "right" }}>
                              <span>
                                {showDiscount
                                  ? formatNumber(showDiscount, 2)
                                  : 0}
                              </span>
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={8} className="order-text">
                              Packing Forwarding charge
                            </td>
                            <td>
                              <input
                                type="text"
                                title="Packing Forwarding charge"
                                placeholder="Charge"
                                style={{ width: "100%", textAlign: "right" }}
                                onChange={handlePackingForwardingChange}
                                value={packingForwardingCharge}
                                disabled={cartnumber ? true : false}
                              />
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={8} className="order-text">
                              Transport charge
                            </td>
                            <td>
                              <input
                                type="text"
                                title="Transport charge"
                                placeholder="Charge"
                                onBeforeInput={(e) => {
                                  const currentValue = (
                                    e.target as HTMLInputElement
                                  ).value;
                                  const nextValue =
                                    currentValue +
                                    (e as unknown as InputEvent).data;

                                  // Allow only numbers or a single decimal point
                                  if (!/^\d*\.?\d*$/.test(nextValue)) {
                                    e.preventDefault();
                                  }
                                }}
                                style={{ width: "100%", textAlign: "right" }}
                                disabled={cartnumber ? true : false}
                                onChange={handleTransportCharge}
                                value={transportCharge}
                              />
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={8} className="order-text">
                              Taxable Amount
                            </td>
                            <td>
                              <span
                                style={{
                                  width: "100%",
                                  textAlign: "right",
                                  display: "inline-block",
                                }}
                                title="Taxable Amount"
                              >
                                {taxAbleAmount
                                  ? formatNumber(taxAbleAmount, 2)
                                  : 0}

                              </span>
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={7} className="order-text">
                              GST
                            </td>
                            <td style={{ padding: "0px" }}>
                              <div className="form-check form-switch d-flex justify-content-center align-items-center">
                                <input
                                  className="form-check-input text-center"
                                  type="checkbox"
                                  role="switch"
                                  disabled={cartnumber ? true : false}
                                  // id="flexSwitchCheckDefault"
                                  checked={isGstActive}
                                  onChange={() => setIsGstActive(!isGstActive)}
                                />
                              </div>
                            </td>
                            <td style={{ textAlign: "end" }}>
                              <span>
                                {gstAmount}
                              </span>
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={7} className="order-text">
                              TCS
                            </td>
                            <td style={{ padding: "0px" }}>
                              <div className="form-check form-switch d-flex justify-content-center align-items-center">
                                <input
                                  className="form-check-input"
                                  type="checkbox"
                                  role="switch"
                                  disabled={cartnumber ? true : false}
                                  id="flexSwitchCheckDefault"
                                  checked={isTcsActive}
                                  onChange={() => setIsTcsActive(!isTcsActive)}
                                />
                              </div>
                            </td>
                            <td style={{ textAlign: "end" }}>
                              <span>
                                {tcsAmount ? formatNumber(tcsAmount, 4) : 0}
                              </span>
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={8} className="order-text">
                              Round Off
                            </td>
                            <td>
                              <span
                                style={{
                                  width: "100%",
                                  textAlign: "right",
                                  display: "inline-block",
                                }}
                                title="Round Off"
                              >
                                {roundOffAmount
                                  ? formatNumber(roundOffAmount, 4)
                                  : 0}
                              </span>
                            </td>
                          </tr>
                          <tr>
                            <td colSpan={8} className="order-text">
                              Grand Total
                            </td>
                            <td>
                              <span
                                style={{
                                  width: "100%",
                                  textAlign: "right",
                                  display: "inline-block",
                                }}
                                title="Grand Total"
                              >
                                {grandTotal ? formatNumber(grandTotal, 4) : 0}
                              </span>
                            </td>
                          </tr>
                        </>
                      ) : (
                        <span></span>
                      )}
                    </tfoot>
                  </table>
                </div>
                <div>
                  <div className="form-group">
                    <label>Remark</label>
                    <textarea
                      className="form-control"
                      rows={1}
                      value={cartRemark}
                      maxLength={TEXTAREA_TEXT_LENGTH}
                      onChange={(e) => setCartRemark(e.target.value)}
                      disabled={cartnumber ? true : false}
                    ></textarea>
                  </div>
                  <div className="form-group">
                    <label> Terms and Condition</label>
                    <textarea
                      className="form-control"
                      rows={1}
                      value={cartTermsAndCondition}
                      maxLength={TEXTAREA_TEXT_LENGTH}
                      onChange={(e) => setCartTermsAndCondition(e.target.value)}
                      disabled={cartnumber ? true : false}
                    ></textarea>
                  </div>
                </div>

                <div
                  className="modal-buttons"
                  style={{ marginTop: "30px", marginBottom: "10px" }}
                >
                  <button
                    className="modal-button1"
                    onClick={() => setIsCloseConfirmation(true)}
                  >
                    {btn1}
                  </button>
                  {cartnumber ? (
                    <span></span>
                  ) : (
                    <button className="modal-button2" onClick={editCart}>
                      Save&nbsp;&&nbsp;Draft
                    </button>
                  )}
                  {cartnumber ? (
                    <span></span>
                  ) : (
                    <button
                      className="modal-button2"
                      style={{
                        backgroundColor: "#06cf9c",
                        border: "1.5px solid #06cf9c",
                      }}
                      onClick={onSubmit}
                    >
                      {btn2}
                    </button>
                  )}
                </div>
              </div>
              <div
                className="col-5 card   mx-2"
                style={{ borderRadius: "0px" }}
              >
                <div className=" d-flex justify-content-between">
                  <div className="search-bar-order pe-2">
                    <div style={{ width: "70%" }}>
                      <button className="search" style={{ left: "10px" }}>
                        <span className="">
                          <svg
                            viewBox="0 0 24 24"
                            width="24"
                            height="24"
                            className=""
                          >
                            < path
                              fill="currentColor"
                              d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"
                            ></path>
                          </svg>
                        </span>
                      </button>

                      <span className="go-back">
                        <svg
                          viewBox="0 0 24 24"
                          width="24"
                          height="24"
                          className=""
                        >
                          <path
                            fill="currentColor"
                            d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                          ></path>
                        </svg>
                      </span>

                      <input
                        type="text"
                        title="Search"
                        aria-label="Search"
                        placeholder="Search"
                        value={searchTerm}
                        maxLength={SMALL_TEXT_LENGTH}
                        onChange={handleSearchChange}
                        onKeyDown={handleKeyDown} // Attach the keydown event
                        disabled={
                          cartnumber
                            ? true
                            : false || canViewProduct
                              ? false
                              : true
                        }
                      />
                    </div>
                  </div>
                  <div className="mt-2 w-50 ">
                    <CustomSearchDropdown
                      options={categoryOptions}
                      value={selectedCategory}
                      onChange={handleCategoryChange}
                      className="w-100 "
                      isDisabled={cartnumber ? "disabled" : false}
                    />
                  </div>
                  {/* <div className="mt-3 px-2">
                    <span>
                      <svg
                        width="24"
                        height="24px"
                        viewBox="0 0 16 16"
                      >
                        <path
                          d="m 2 1 c -0.554688 0 -1 0.445312 -1 1 v 2 c 0 0.554688 0.445312 1 1 1 h 2 c 0.554688 0 1 -0.445312 1 -1 v -2 c 0 -0.554688 -0.445312 -1 -1 -1 z m 5 1 v 2 h 8 v -2 z m -5 4.015625 c -0.554688 0 -1 0.445313 -1 1 v 1.980469 c 0 0.550781 0.445312 1 1 1 h 2 c 0.554688 0 1 -0.449219 1 -1 v -1.980469 c 0 -0.554687 -0.445312 -1 -1 -1 z m 5 0.984375 v 2 h 8 v -2 z m -5 4 c -0.554688 0 -1 0.445312 -1 1 v 1.980469 c 0 0.550781 0.445312 1 1 1 h 2 c 0.554688 0 1 -0.449219 1 -1 v -1.980469 c 0 -0.554688 -0.445312 -1 -1 -1 z m 5 0.984375 v 2 h 8 v -2 z m 0 0"
                          fill="currentColor"
                        />
                      </svg>
                    </span>
                  </div> */}
                </div>
                <div>
                  {productList ? (
                    <>
                      <div
                        className="row"
                        style={{ overflow: "scroll", maxHeight: "70vh" }}
                      >
                        {productList &&
                          productList.map((item: any) => (
                            <div className="col-md-3" key={item.id}>
                              <div
                                className="card mb-3"
                                style={{
                                  cursor: cartnumber
                                    ? "not-allowed"
                                    : "pointer",
                                  opacity: cartnumber ? 0.6 : 1,
                                  borderColor:
                                    highlightedProductId === item.id
                                      ? "#f58634"
                                      : isProductInCart(item.id)
                                        ? "#f58634"
                                        : "",
                                  borderRadius: "0px",
                                }}
                                onClick={() =>
                                  cartnumber
                                    ? !isProductInCart(item.id)
                                    : addToCart(item)
                                }
                              >
                                <div
                                  style={{
                                    backgroundImage: item?.product_img
                                      ? `url(${item.product_img})`
                                      : `url(${require("../../assets/images/no_image.jpeg")})`,
                                    backgroundSize: "cover", // This will cover the entire div
                                    backgroundPosition: "center", // Center the image
                                    height: "12vh", // Set your desired height
                                    width: "100%", // Full width
                                    backgroundRepeat: "no-repeat",
                                  }}
                                >
                                </div>
                                <div className="p-1">
                                  <h4 className="order-text-card-body">
                                    <b> {item.product_name}</b>
                                  </h4>
                                  <h4 className="order-text-card-body">
                                    <b> {item.category_name}</b>
                                  </h4>
                                  <h4 className="order-text-card-body">
                                    <svg
                                      height="12px"
                                      viewBox="0 -960 960 960"
                                      width="12px"
                                      fill="currentColor"
                                    >
                                      <path d="M549-120 280-400v-80h140q53 0 91.5-34.5T558-600H240v-80h306q-17-35-50.5-57.5T420-760H240v-80h480v80H590q14 17 25 37t17 43h88v80h-81q-8 85-70 142.5T420-400h-29l269 280H549Z" />
                                    </svg>

                                    {item.net_rate}
                                  </h4>
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </>
                  ) : (
                    <p>
                      {`No products available! \n Go to Settings > Products and add
                      your products.`}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {isCloseConfirmation && (
        <ConfirmationModal
          show={isCloseConfirmation}
          onHide={() => setIsCloseConfirmation(false)}
          handleSubmit={() => handleHide()}
          title={`Close this ${orderTypesNameFind}`}
          message={`Are you sure you want Close this ${orderTypesNameFind}?`}
          btn1="No"
          btn2="Yes"
        />
      )}
      {isDeleteConfirmation && (
        <ConfirmationModal
          show={isDeleteConfirmation}
          onHide={() => setIsDeleteConfirmation(false)}
          handleSubmit={() => setIsDeleteConfirmation(false)}
          title={`Delete this Product`}
          message={`Are you sure you want to delete this product? This message appears when you click on 'Save & Draft'`}
          btn1="CANCEL"
          btn2="Delete"
        />
      )}
    </div>
  );
};

export default OrderCreateModal;
