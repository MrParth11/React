import React, { useEffect, useState } from "react";
import "./ConfirmationModal.css";
import { IUserList } from "../../pages/left-side/LeftSideController";
interface ICheckBoxModalProps {
  show: boolean;
  onHide: () => void;
  handleSubmit: (contactId: number | undefined, checkedOptions: any[]) => void;
  title: string;
  message: string;
  btn1: string;
  btn2: string;
  options: any[];
  selectedLabelIds?: any;
  contactId: number | undefined;
  getOptionColor?: (option: any) => string;
  getOptionName: (option: any) => string;
  showColorBadge: boolean;
}

const CheckBoxModal: React.FC<ICheckBoxModalProps> = ({
  show,
  onHide,
  handleSubmit,
  title,
  message,
  btn1,
  btn2,
  options,
  selectedLabelIds,
  contactId,
  getOptionColor,
  getOptionName,
  showColorBadge
}) => {
  const [checkedOptions, setCheckedOptions] = useState<any[] | undefined>([]);
  useEffect(() => {
    const parsedLabelIds = selectedLabelIds
      ? selectedLabelIds.split(",").map(Number)
      : [];
    setCheckedOptions(parsedLabelIds);
  }, [selectedLabelIds, contactId]);

  const handleCheckboxChange = (optionId: any) => {
    setCheckedOptions((prev) =>
      prev?.includes(optionId)
        ? prev.filter((id) => id !== optionId)
        : [...(prev || []), optionId]
    );
  };

  const onSubmit = () => {
    if (checkedOptions) handleSubmit(contactId, checkedOptions);
  };

  return show ? (
    <div className="modal-overlay">
      <div className="modal-content_label">
        <h2 className="modal-title1 form_header_text">{title}</h2>
        <p>{message}</p>
        <div className="overflow-auto " style={{ maxHeight: "500px" }}>
          <table className="table table-hover" border={0}>
            <tbody className="text-center">
              {options.map((option) => (
                <tr
                  key={option.id}
                  className="text-left"
                  style={{
                    border: "1px solid white",
                    borderCollapse: "collapse",
                    height: "10px",
                  }}
                >
                  <td className="text-start">
                    {showColorBadge ? (
                      <span
                        style={{
                          backgroundColor: getOptionColor
                            ? getOptionColor(option)
                            : "",
                        }}
                        className="badge rounded-pill"
                      >
                        {getOptionName(option)}
                      </span>
                    ) : (
                      <span>{getOptionName(option)}</span> // Just the label text without badge
                    )}
                  </td>
                  <td className="text-end">
                    <input
                      className="custom-checkbox"
                      type="checkbox"
                      id={`checkbox-${option.id}`}
                      checked={checkedOptions?.includes(option.id)}
                      onChange={() => handleCheckboxChange(option.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="modal-buttons">
          <button className="modal-button1 ig-btn" onClick={onHide}>
            {btn1}
          </button>
          <button className="modal-button2 ig-btn" onClick={onSubmit}>
            {btn2}
          </button>
        </div>
      </div>
    </div>
  ) : null;
};

export default CheckBoxModal;
