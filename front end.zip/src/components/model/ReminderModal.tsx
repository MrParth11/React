import React, { useEffect, useState } from "react";
import { Modal, Button } from "react-bootstrap";
import { useTheme } from "../ThemeContext";
import { toast } from "react-toastify";
import CustomSearchDropdown from "../CustomSearchDropdown";
import { SingleValue } from "react-select";
import { IOption } from "../../helpers/AppInterface";
import {axiosInstance} from "../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../helpers/AppConstants";
const ReminderModal = ({
  show,
  onHide,
  handleSubmit,
  title,
  message,
  btn1 = "yes",
  btn2 = "no",
  remarkMsg,
  ContactMessageId,
  request_flag,
}: {
  show: boolean;
  onHide: () => void;
  handleSubmit: (data: {
    dateTime: string;
    remark: string;
    status: string;
    selectedCategory: any;
  }) => void;
  title: string;
  message?: string;
  btn1: string;
  btn2: string;
  remarkMsg?: string;
  ContactMessageId?:number;
  request_flag:string;
}) => {
  const { darkMode } = useTheme();
  const modalThemeClass = darkMode ? "modal-light-1" : "modal-light-1";
  const getUUID = localStorage.getItem("UUID");
  const modalThemeClass1 = darkMode ? "modal-dark" : "modal-light-1";
  const [dateTime, setDateTime] = useState<string>("");
  const [remark, setRemark] = useState<string>(remarkMsg || "");
  const [status, setStatus] = useState<string>("");
  const [selectedCategory, setSelectedCategory] =
    useState<SingleValue<IOption> | null>(null);
  const [categoryList, setCategoryList] = useState<any>([]);
 

  

  useEffect(() => {
    const getIndianDateTimeWithOffset = (): string => {
      // Create date object for current time
      const now = new Date();
      
      // Convert to IST (UTC+5:30)
      const utcTime = now.getTime() + (now.getTimezoneOffset() * 60000);
      const istTime = new Date(utcTime + (5.5 * 60 * 60000));
      
      // Add 5 minutes
      istTime.setMinutes(istTime.getMinutes() + 5);
      
      // Format to YYYY-MM-DDTHH:MM
      const year = istTime.getFullYear();
      const month = String(istTime.getMonth() + 1).padStart(2, '0');
      const day = String(istTime.getDate()).padStart(2, '0');
      const hours = String(istTime.getHours()).padStart(2, '0');
      const minutes = String(istTime.getMinutes()).padStart(2, '0');
      
      return `${year}-${month}-${day}T${hours}:${minutes}`;
    };

    setDateTime(getIndianDateTimeWithOffset());
  }, []);
  const handleDateTimeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setDateTime(event.target.value);
  };
  const fetchAllCompanyApi = async () => {
    const token = await localStorage.getItem("token");
    const getUUID = await localStorage.getItem("UUID");

    const requestData = {
      a_application_login_id: getUUID,
    };
    try {
      const data = await axiosInstance.post(
        "my-team",
        requestData,

        {
          headers: {
            Authorization: `${token}`,
          },
        }
      );
      if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
        setCategoryList([]);
      }
      setCategoryList(data.data.data.item);
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };


  const fetchConactMessageApiForRemark = async () => {
    const getUUID = await localStorage.getItem("UUID");
  
    const requestData = {
      table: "contact_message_histories",
      columns: "id,description",
      where: `{"id": "${ContactMessageId}"}`,
    };
  
    try {
      const response = await axiosInstance.post("commonGet", requestData, {
        headers: {
          "x-tenant-id": getUUID,
        },
      });
  
      const data = response.data.data[0] || {};
      const plainDescription = data.description?.replace(/<[^>]*>/g, '') || "";
      setRemark(plainDescription); 
    } catch (error) {
      console.error("Error fetching contact message:", error);
      setRemark(""); // Clear in case of error
    }
  };
  useEffect(() => {
    if (show) fetchAllCompanyApi();
    if (show){
      if(request_flag === "2"){
        fetchConactMessageApiForRemark();
      }
    }
  }, [show]);
  const handleRemarkChange = (
    event: React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    setRemark(event.target.value);
  };

  const handleStatusChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setStatus(event.target.value);
  };

  const categoryOptions = categoryList.map((category: any) => ({
    value: category.id,
    label: category.username,
  }));
  const defaultCategory = categoryOptions.find(
    (option: { value: number }) => option.value === Number(getUUID)
  );

  const handleSave = () => {
    const now = new Date();
    const selectedDateTime = new Date(dateTime);

    // // Check if the selected date-time is in the past
    if (selectedDateTime <= now) {
      // Show error toast if dateTime is in the past or the current time
      toast.error("Please select a future date and time.");
      return;
    }
    const data = {
      dateTime,
      remark,
      status,
      selectedCategory: selectedCategory || defaultCategory,
    };

    handleSubmit(data);
  };
  const handleCategoryChange = (
    selectedOption: SingleValue<IOption> | null
  ) => {
    setSelectedCategory(selectedOption);
  };

 
  const now = new Date();
  const minDateTime = now.toISOString().slice(0, 16); 
 

  return (
    <React.Fragment>
      <Modal show={show} onHide={onHide} centered  backdrop="static"className={modalThemeClass1}>
        <div className={` p-10 m-title ${modalThemeClass}`}>{title}</div>
        <Modal.Body className={`${modalThemeClass}`}>
          {message ? (
            <div
              className={`m-title-2 col-12 ${modalThemeClass}`}
            >
              <div className="col-12 mt-1">
                <label className="form-check-label" htmlFor="flexCheckDefault">
                  <h4>
                    Assign to Team Member<span className="text-danger">*</span>
                  </h4>
                </label>
                <div className="">
                  <div className="add-source-of-type-section ">
                    <CustomSearchDropdown
                      options={categoryOptions}
                      value={selectedCategory}
                      onChange={handleCategoryChange}
                      className="w-100  "
                      defaultValue={defaultCategory}
                    />
                  </div>
                </div>
              </div>
              <label className="col-12">
                Select date and time <span className="text-danger">*</span>
                <input
                  type="datetime-local"
                  value={dateTime}
                  onChange={handleDateTimeChange}
                  className="form-control font-size-15 rounded-1"
                  min={minDateTime} // Disallow past date and time
                />
              </label>
              <br />
              <br />

              <label className="col-12">
                Remark<span className="text-danger">*</span>
                <textarea
                  rows={1}
                  cols={30}
                  value={remark}
                  onChange={handleRemarkChange}
                  className="form-control font-size-15 rounded-1"
                />
              </label>
            </div>
          ) : (
            <span></span>
          )}
          <div className="d-flex justify-content-end  m-btn">
            <Button className="mr-2 px-4 btn1" onClick={onHide}>
              {btn1}
            </Button>
            <Button className="px-4 ms-2 btn2" onClick={handleSave}>
              {btn2}
            </Button>
          </div>
        </Modal.Body>
      </Modal>
    </React.Fragment>
  );
};

export default ReminderModal;
