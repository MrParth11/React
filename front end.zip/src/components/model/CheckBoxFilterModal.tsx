import React, { useEffect, useState } from "react";
import "./ConfirmationModal.css";
import { axiosInstance } from "../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../helpers/AppConstants";
import { toast } from "react-toastify";
import { ISourceOfTypes } from "../../pages/left-side/header/Setting/source-of-types/SourceOfTypesController";
import { ILabelView } from "../../pages/left-side/header/Setting/label/LabelController";
import { SingleValue } from "react-select";
import { IOption } from "../../helpers/AppInterface";
import CustomSearchDropdown from "../CustomSearchDropdown";
import { TOnChangeInput } from "../../helpers/AppType";
import { IStageStatusView } from "../../pages/left-side/header/Setting/stage-status/StageStatusController";
import { openInNewTab } from "../../common/SharedFunction";

// 1 => StartDate&EndDate , 2=> Label , 3=> Source type ,4 => Stage and Status ,5 => Team  Member , 6 =>Demography , 7 => Category / Product

interface CheckBoxModalProps {
  show: boolean;
  onHide: () => void;
  handleSubmit: (
    filterData: any,
    checkedOptionsLabel: any[],
    checkedOptionsSourceType: any[],
    startSearchDate: string,
    endSearchDate: string,
    checkedOptionsStageStatus: any,
    checkedOptionsUser: any,
    selectedCategoryId: any,
    selectedProductId: any
  ) => void;
  title: string;
  message: string;
  btn1: string;
  btn2: string;
  filtersToShow: number[];
  pageId: number
}

const CheckBoxFilterModal: React.FC<CheckBoxModalProps> = ({
  show,
  onHide,
  handleSubmit,
  title,
  message,
  btn1,
  btn2,
  filtersToShow,
}) => {
  const [checkedOptions, setCheckedOptions] = useState<any[]>();

  const [checkedOptionsSourceType, setCheckedOptionsSourceType] =
    useState<any>(); // State to manage selected checkboxes
  const [checkedOptionsStageStatus, setCheckedOptionsStageStatus] =
    useState<any>();
  const [checkedOptionsUser, setCheckedOptionsUser] = useState<any>();
  const [sourceOfTypesLists, setSourceOfTypesLists] = useState<
    ISourceOfTypes[]
  >([]);
  const [stageStatusList, setStageStatusList] = useState<IStageStatusView[]>(
    []
  );
  const [labelLists, setLabelList] = useState<ILabelView[]>([]);
  const [countriesList, setCountriesList] = useState([]);
  const [categoryList, setCategoryList] = useState([]);

  const [productList, setProductList] = useState([]);
  const [areaList, setAreaList] = useState([]);
  const [selectedCountryId, setSelectedCountryId] = useState<any>(false);
  const [selectedCategoryId, setSelectedCategoryId] = useState<any>(false);
  const [selectedProductId, setSelectedProductId] = useState<any>(false);
  const [filteredProductOptions, setFilteredProductOptions] = useState<
    Array<{ value: number; label: string }>
  >([]);

  const [selectedAreaId, setSelectedAreaId] = useState<any>(false);
  const [stateList, setStateList] = useState([]);
  const [selectedStateId, setSelectedStateId] = useState<any>(false);
  const [cityList, setCityList] = useState([]);
  const [selectedCityId, setSelectedCityId] = useState<any>(false);
  const [startSearchDate, setStartSearchDate] = useState<string>("");
  const [endSearchDate, setEndSearchDate] = useState<string>("");
  const [optionJoinCompany, setOptionJoinCompany] = useState<any[]>([]);

  const onSubmit = async () => {
    const filterData = {
      country: selectedCountryId?.value,
      state: selectedStateId?.value,
      city: selectedCityId?.value,
      area: selectedAreaId?.value,
    };
    handleSubmit(
      filterData,
      checkedOptions ?? [],
      checkedOptionsSourceType ?? [],
      startSearchDate,
      endSearchDate,
      checkedOptionsStageStatus ?? [],
      checkedOptionsUser,
      selectedCategoryId,
      selectedProductId
    );
  };

  const handleHide = () => {
    setCheckedOptions([]);
    setCheckedOptionsSourceType([]);
    setCheckedOptionsStageStatus([]);
    setCheckedOptionsUser([]);
    setSelectedCountryId(null);
    setSelectedStateId(null);
    setSelectedCityId(null);
    setSelectedAreaId(null);
    setSelectedCategoryId(null);
    setSelectedProductId(null);
    setStartSearchDate("");
    setEndSearchDate("");
    onHide();
    handleSubmit([], [], [], "", "", [], [], null, null);
  };
  const handleCountryChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedCountryId(selectedOption);
  };
  const handleCategoryChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedCategoryId(selectedOption);
  };
  const handleProductChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedProductId(selectedOption);
  };
  const handleAreaChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedAreaId(selectedOption);
  };
  const handleStateChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedStateId(selectedOption);
  };
  const handleCityChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedCityId(selectedOption);
  };

  const fetchStageStatusApi = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "stage_status_masters",
      columns: "id,name,color,order_type,display_order_type",
      where: ["isDelete=0", `a_application_login_id=${getUUID}||0`, 'order_type=1'],
      request_flag: 0,
      order: `{"id":"DESC"}`,
    };
    try {
      const data = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,
          },
        }
      );
      if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
        setStageStatusList([]);
      }
      setStageStatusList(data.data.data);
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };
  const fetchCountryApiForPriceList = async () => {
    const requestData = {
      table: "a_countries",
      columns: "id,country_name,country_code",
      where: `{"isDelete": "0"}`,
    };
    const getUUID = localStorage.getItem("UUID")
    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,
          },
        }
      );

      setCountriesList(response.data.data);
    } catch (error) {
      console.error("Error fetching countries:", error);
      setCountriesList([]);
    }
  };
  const fetchAllCompanyApi = async () => {
    const token = await localStorage.getItem("token");
    const getUUID = await localStorage.getItem("UUID");

    const requestData = {
      a_application_login_id: getUUID,
    };
    try {
      const data = await axiosInstance.post(
        "my-team",
        requestData,

        {
          headers: {
            Authorization: `${token}`,
          },
        }
      );
      if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
        setOptionJoinCompany([]);
      }
      setOptionJoinCompany(data.data.data.item);
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };

  const fetchStateApiForFilter = async () => {
    const requestData = {
      table: "a_states",
      columns: "id,state_name",
      where: `{"country_id": "${selectedCountryId.value}"}`,
    };
    const getUUID = localStorage.getItem("UUID")
    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,
          },
        }
      );
      setStateList(response.data.data);
    } catch (error) {
      console.error("Error fetching countries:", error);
      setStateList([]);
    }
  };
  const fetchCategoryApiForFilter = async () => {
    const getUUID = await localStorage.getItem("UUID");

    const requestData = {
      table: "categories",
      columns: "id,category_name",
      where: `{"isDelete":"0","a_application_login_id":"${getUUID}"}`,
    };

    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,
          },
        }
      );
      setCategoryList(response.data.data);
    } catch (error) {
      console.error("Error fetching countries:", error);
      setCategoryList([]);
    }
  };
  const fetchProductApiForFilter = async () => {
    const getUUID = await localStorage.getItem("UUID");

    const requestData = {
      table: "products",
      columns: "id,product_name,category_id",
      where: `{"isDelete":"0","a_application_login_id":"${getUUID}"}`,
    };

    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,
          },
        }
      );
      setProductList(response.data.data);
    } catch (error) {
      console.error("Error fetching countries:", error);
      setProductList([]);
    }
  };
  const fetchCityApiForFilter = async () => {
    const requestData = {
      table: "a_cities",
      columns: "id,city_name",
      where: `{"state_id": ${selectedStateId.value}}`,
    };
    const getUUID = localStorage.getItem("UUID")
    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,
          },
        }
      );

      setCityList(response.data.data);
    } catch (error) {
      console.error("Error fetching countries:", error);
      setCityList([]);
    }
  };
  const fetchAreaApiForFilter = async () => {
    const requestData = {
      table: "a_areas",
      columns: "id,area_name",
      where: `{"city_id": "${selectedCityId.value}"}`,
    };
    const getUUID = localStorage.getItem("UUID")

    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,
          },
        }
      );
      setAreaList(response.data.data);
    } catch (error) {
      console.error("Error fetching countries:", error);
      setAreaList([]);
    }
  };
  const fetchLabelApi = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "lable_masters",
      columns: "id,lable_name,color",
      where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
      request_flag: 0,
      order: `{"id":"DESC"}`,
    };
    try {
      const data = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,

          },
        }

      );
      if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
        setLabelList([]);
      }
      setLabelList(data.data.data);
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };

  const handleCheckboxChange = (optionId: any) => {
    setCheckedOptions((prev) =>
      prev?.includes(optionId)
        ? prev.filter((id) => id !== optionId)
        : [...(prev || []), optionId]
    );
  };

  const handleSourceTypeCheckboxChange = (optionId: any) => {
    setCheckedOptionsSourceType((prev: any[]) =>
      prev?.includes(optionId)
        ? prev.filter((id) => id !== optionId)
        : [...(prev || []), optionId]
    );
  };
  const handleStageStatusTypeCheckboxChange = (optionId: any) => {
    setCheckedOptionsStageStatus((prev: any[]) =>
      prev?.includes(optionId)
        ? prev.filter((id) => id !== optionId)
        : [...(prev || []), optionId]
    );
  };
  const handleUsersTypeCheckboxChange = (optionId: any) => {
    setCheckedOptionsUser((prev: any[]) =>
      prev?.includes(optionId)
        ? prev.filter((id) => id !== optionId)
        : [...(prev || []), optionId]
    );
  };
  const fetchSourceOfTypesApi = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const token = await localStorage.getItem("token");

    const requestData = {
      a_application_login_id: getUUID,
    };
    try {
      const data = await axiosInstance.post("sourceOfTypes", requestData, {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
      );
      if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
        setSourceOfTypesLists([]);
      }
      setSourceOfTypesLists(data.data.data.item);
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };
  useEffect(() => {
    if (selectedCategoryId) {

      const filteredProducts = productList
        .filter(
          (product: any) => product.category_id === selectedCategoryId.value
        )
        .map((product: any) => ({
          value: product.id,
          label: product.product_name,
        }));

      console.log("Filtered Products:", filteredProducts);
      setFilteredProductOptions(filteredProducts);
    } else {
      setFilteredProductOptions(productOptions);
    }
  }, [selectedCategoryId, productList]);
  useEffect(() => {
    const fetchData = async () => {
      try {
        await fetchSourceOfTypesApi();
        await fetchLabelApi();
        await fetchCountryApiForPriceList();
        await fetchStageStatusApi();
        await fetchAllCompanyApi();
        await fetchCategoryApiForFilter();
        await fetchProductApiForFilter();
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    if (show) {
      fetchData();
    }
  }, [show]);
  useEffect(() => {
    if (selectedCountryId) {
      const fetchState = async () => {
        try {
          await fetchStateApiForFilter();
        } catch (error) {
          console.error("Error fetching city options:", error);
        }
      };
      fetchState();
    }
  }, [selectedCountryId]);
  useEffect(() => {
    if (selectedStateId) {
      const fetchCities = async () => {
        try {
          await fetchCityApiForFilter();
        } catch (error) {
          console.error("Error fetching city options:", error);
        }
      };
      fetchCities();
    }
  }, [selectedStateId]);
  useEffect(() => {
    if (selectedCityId) {
      const fetchCities = async () => {
        try {
          await fetchAreaApiForFilter();
        } catch (error) {
          console.error("Error fetching city options:", error);
        }
      };
      fetchCities();
    }
  }, [selectedCityId]);

  const countryOptions = countriesList.map((country: any) => ({
    value: country.id,
    label: country.country_name,
  }));
  const categoryOptions = categoryList.map((category: any) => ({
    value: category.id,
    label: category.category_name,
  }));
  const productOptions = productList.map((product: any) => ({
    value: product.id,
    label: product.product_name,
  }));
  const stateOptions = stateList.map((state: any) => ({
    value: state.id,
    label: state.state_name,
  }));
  const cityOptions = cityList.map((city: any) => ({
    value: city.id,
    label: city.city_name,
  }));
  const areaOptions = areaList.map((area: any) => ({
    value: area.id,
    label: area.area_name,
  }));
  const handleStartDateChange = (event: TOnChangeInput) => {
    // setStartSearchDate(event.target.value);
    const newStartDate = event.target.value;
    setStartSearchDate(newStartDate);
    setEndSearchDate(newStartDate);
  };
  const handleEndDateChange = (event: TOnChangeInput) => {

    const newEndDate = event.target.value;
    if (newEndDate < startSearchDate) {
      if (typeof toast.error === 'function') {
        toast.error("End date must be greater than start date");
      }
      return;
    }
    setEndSearchDate(newEndDate);
  };
  useEffect(() => {
    setEndSearchDate(startSearchDate);
  }, [startSearchDate]);
  return (
    <div>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1" style={{ width: "82%" }}>
            <div className="d-flex align-items-center justify-content-end">
              <span>
                <p
                  className="landing-page-text text-end"
                  style={{ cursor: "pointer", color: "blue", float: "right", fontSize: "13px" }}
                  onClick={() => openInNewTab("/videoTutorial", 3)}
                >
                  Learn More : <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#0000FF"><path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" /></svg>
                </p>
              </span>

              <span
                className="close ms-3 pb-3"
                onClick={onHide}
              >
                &times;
              </span>
            </div>
            <h2 className="modal-title1 form_header_text">
              {title}
            </h2>
            <p className="text-center " style={{ color: "#999" }}>
              <p>{message}</p>
            </p>
            <div className={`m-title-2 `}>
              {filtersToShow.includes(1) && (
                <div className="row ">
                  <div className="col-6 px-2" >
                    <label className="ms-2"> StartDate</label>
                    <input
                      type="date"
                      value={startSearchDate}
                      onChange={handleStartDateChange}
                      className="form-control font-size-15 rounded-1"
                    />
                  </div>
                  <div className="col-6 " style={{ paddingLeft: "0px", paddingRight: "20px" }}>
                    <label className="ms-2">EndDate</label>
                    <input
                      type="date"
                      value={endSearchDate}
                      onChange={handleEndDateChange}
                      className="form-control font-size-15 rounded-1"
                      min={startSearchDate}
                    />
                  </div>
                </div>
              )}
              <div className="row ">
                {filtersToShow.includes(2) && (
                  <div className="col-3 card mx-1" style={{ width: "19%" }}>
                    <div className="mx-1">
                      <div className="ms-2 mt-1">
                        <label>Label </label>
                      </div>
                      <div
                        className="overflow-auto "
                        style={{ maxHeight: "500px" }}
                      >
                        <table className="table table-hover" border={0}>
                          <tbody className="text-center">
                            {labelLists.map((option) => (
                              <tr
                                key={option.id}
                                className="text-left"
                                style={{
                                  border: "1px solid white",
                                  borderCollapse: "collapse",
                                  height: "10px",
                                }}
                              >
                                <td className="text-start">
                                  <span
                                    style={{
                                      backgroundColor: option.color
                                        ? option.color
                                        : "#808080",
                                    }}
                                    className="badge rounded-pill"
                                  >
                                    {option.lable_name}
                                  </span>
                                </td>
                                <td className="text-end">
                                  <input
                                    type="checkbox"
                                    id={`checkbox-${option.id}`}
                                    checked={checkedOptions?.includes(
                                      option.id
                                    )}
                                    onChange={() =>
                                      handleCheckboxChange(option.id)
                                    }
                                    className="custom-checkbox"
                                  />
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
                {filtersToShow.includes(3) && (
                  <div className="col-3 card mx-1 " style={{ width: "19%" }}>
                    <div className="mx-1">
                      <div className="ms-2 mt-1">
                        <label>Source type</label>
                      </div>
                      <div
                        className="overflow-auto "
                        style={{ maxHeight: "500px" }}
                      >
                        <table className="table table-hover" border={0}>
                          <tbody className="text-center">
                            {sourceOfTypesLists.map((option) => (
                              <tr
                                key={option.id}
                                className="text-left"
                                style={{
                                  border: "1px solid white",
                                  borderCollapse: "collapse",
                                  height: "10px",
                                }}
                              >
                                <td className="text-start">
                                  <span
                                    style={{
                                      backgroundColor: option.color
                                        ? option.color
                                        : "#808080",
                                    }}
                                    className="badge rounded-pill"
                                  >
                                    {option.source_name}
                                  </span>
                                </td>
                                <td className="text-end">
                                  <input
                                    type="checkbox"
                                    id={`checkbox-${option.id}`}
                                    checked={checkedOptionsSourceType?.includes(
                                      option.id
                                    )}
                                    onChange={() =>
                                      handleSourceTypeCheckboxChange(option.id)
                                    }
                                    className="custom-checkbox"
                                  />
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
                {filtersToShow.includes(4) && (
                  <div className="col-3 card mx-1" style={{ width: "19%" }}>
                    <div className="mx-1">
                      <div className="ms-2 mt-1">
                        <label>Stage and Status</label>
                      </div>
                      <div
                        className="overflow-auto "
                        style={{ maxHeight: "500px" }}
                      >
                        <table className="table table-hover" border={0}>
                          <tbody className="text-center">
                            {stageStatusList.map((option) => (
                              <tr
                                key={option.id}
                                className="text-left"
                                style={{
                                  border: "1px solid white",
                                  borderCollapse: "collapse",
                                  height: "10px",
                                }}
                              >
                                <td className="text-start">
                                  <span
                                    style={{
                                      backgroundColor: option.color
                                        ? option.color
                                        : "#808080",
                                    }}
                                    className="badge rounded-pill"
                                  >
                                    {option.name}
                                  </span>
                                </td>
                                <td className="text-end">
                                  <input
                                    type="checkbox"
                                    id={`checkbox-${option.id}`}
                                    checked={checkedOptionsStageStatus?.includes(
                                      option.id
                                    )}
                                    onChange={() =>
                                      handleStageStatusTypeCheckboxChange(
                                        option.id
                                      )
                                    }
                                    className="custom-checkbox"
                                  />
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
                {filtersToShow.includes(5) && (
                  <div className="col-3 card mx-1" style={{ width: "19%" }}>
                    <div className="mx-1">
                      <div className="ms-2 mt-1">
                        <label>Team Member</label>
                      </div>
                      <div
                        className="overflow-auto "
                        style={{ maxHeight: "500px" }}
                      >
                        <table className="table table-hover" border={0}>
                          <tbody className="text-center">
                            {optionJoinCompany.map((option) => (
                              <tr
                                key={option.id}
                                className="text-left"
                                style={{
                                  border: "1px solid white",
                                  borderCollapse: "collapse",
                                  height: "10px",
                                }}
                              >
                                <td className="text-start">
                                  <span
                                    className=""
                                  >
                                    {option.username}
                                  </span>
                                </td>
                                <td className="text-end">
                                  <input
                                    type="checkbox"
                                    id={`checkbox-${option.id}`}
                                    checked={checkedOptionsUser?.includes(
                                      option.id
                                    )}
                                    onChange={() =>
                                      handleUsersTypeCheckboxChange(option.id)
                                    }
                                    className="custom-checkbox"
                                  />
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}

                {filtersToShow.includes(6) && (
                  <div className="col-3 card mx-1" style={{ width: "19%" }}>
                    <div className="mx-1">
                      <div className="ms-2 mt-1">
                        <label>Demography</label>
                      </div>
                      <div
                        className="overflow-auto "
                        style={{ maxHeight: "500px" }}
                      >
                        <table className="table table-hover" border={0}>
                          <tbody className="text-center">
                            <tr
                              className="text-left"
                              style={{
                                border: "1px solid white",
                                borderCollapse: "collapse",
                                height: "10px",
                              }}
                            >
                              <td className="text-start">
                                <div className="col-12 ">
                                  <label
                                    className="form-check-label"
                                    htmlFor="flexCheckDefault"
                                  >
                                    Select Country
                                  </label>
                                  <div className="add-source-of-type-section ">
                                    <CustomSearchDropdown
                                      options={countryOptions}
                                      value={selectedCountryId}
                                      onChange={handleCountryChange}
                                      className="w-100  "
                                    />
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr
                              className="text-left"
                              style={{
                                border: "1px solid white",
                                borderCollapse: "collapse",
                                height: "10px",
                              }}
                            >
                              <td className="text-start">
                                <div className="col-12 ">
                                  <label
                                    className="form-check-label"
                                    htmlFor="flexCheckDefault"
                                  >
                                    Select State
                                  </label>
                                  <div className="add-source-of-type-section ">
                                    <CustomSearchDropdown
                                      options={stateOptions}
                                      value={selectedStateId}
                                      onChange={handleStateChange}
                                      className="w-100  "
                                    />
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr
                              className="text-left"
                              style={{
                                border: "1px solid white",
                                borderCollapse: "collapse",
                                height: "10px",
                              }}
                            >
                              <td className="text-start">
                                <div className="col-12 ">
                                  <label
                                    className="form-check-label"
                                    htmlFor="flexCheckDefault"
                                  >
                                    Select City
                                  </label>
                                  <div className="add-source-of-type-section ">
                                    <CustomSearchDropdown
                                      options={cityOptions}
                                      value={selectedCityId}
                                      onChange={handleCityChange}
                                      className="w-100  "
                                    />
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr
                              className="text-left"
                              style={{
                                border: "1px solid white",
                                borderCollapse: "collapse",
                                height: "10px",
                              }}
                            >
                              <td className="text-start">
                                <div className="col-12 ">
                                  <label
                                    className="form-check-label"
                                    htmlFor="flexCheckDefault"
                                  >
                                    Select Area
                                  </label>
                                  <div className="add-source-of-type-section ">
                                    <CustomSearchDropdown
                                      options={areaOptions}
                                      value={selectedAreaId}
                                      onChange={handleAreaChange}
                                      className="w-100  "
                                    />
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
                {filtersToShow.includes(7) && (
                  <div
                    className="col-3 card mx-1 my-1"
                    style={{ width: "19%" }}
                  >
                    <div className="mx-1">
                      <div className="ms-2 mt-1">
                        <label>Category / Product</label>
                      </div>
                      <div
                        className="overflow-auto "
                        style={{ maxHeight: "500px" }}
                      >
                        <table className="table table-hover" border={0}>
                          <tbody className="text-center">
                            <tr
                              className="text-left"
                              style={{
                                border: "1px solid white",
                                borderCollapse: "collapse",
                                height: "10px",
                              }}
                            >
                              <td className="text-start">
                                <div className="col-12 ">
                                  <label
                                    className="form-check-label"
                                    htmlFor="flexCheckDefault"
                                  >
                                    Select Category
                                  </label>
                                  <div className="add-source-of-type-section ">
                                    <CustomSearchDropdown
                                      options={categoryOptions}
                                      value={selectedCategoryId}
                                      onChange={handleCategoryChange}
                                      className="w-100  "
                                    />
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr
                              className="text-left"
                              style={{
                                border: "1px solid white",
                                borderCollapse: "collapse",
                                height: "10px",
                              }}
                            >
                              <td className="text-start">
                                <div className="col-12 ">
                                  <label
                                    className="form-check-label"
                                    htmlFor="flexCheckDefault"
                                  >
                                    Select Product
                                  </label>
                                  <div className="add-source-of-type-section ">
                                    <CustomSearchDropdown
                                      options={filteredProductOptions}
                                      value={selectedProductId}
                                      onChange={handleProductChange}
                                      className="w-100  "
                                    />
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="modal-buttons">
              <button className="modal-button1" onClick={handleHide}>
                {btn1}
              </button>
              <button className="modal-button2" onClick={onSubmit}>
                {btn2}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CheckBoxFilterModal;
