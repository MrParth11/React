import React, { useState } from "react";
import axios from "axios";
import "./ConfirmationModal.css";
import { toast } from "react-toastify";
import { MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../helpers/AppConstants";
import { axiosInstanceFormData } from "../../services/axiosInstance";
// 1 => contact 2 => product
interface IImportExcelForContactModal {
  show: boolean;
  onHide: () => void;
  handleSubmit: () => void;
  title: string;
  message: string;
  btn1: string;
  btn2: string;
  sampleLocation: string;
  potions: number;
}

const ImportExcelForContactModal: React.FC<IImportExcelForContactModal> = ({
  show,
  onHide,
  handleSubmit,
  title,
  message,
  btn1,
  btn2,
  sampleLocation,
  potions,
}) => {
  const [attachment, setAttachment] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const onSubmit = async () => {
    if (!attachment) {
      toast.error("Please select a file to upload");
      return;
    }
    const validExcelTypes = [
      "application/vnd.ms-excel", // .xls
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
    ];
    if (!validExcelTypes.includes(attachment.type)) {
      toast.error("Please upload a valid Excel file (.xls or .xlsx)");
      return;
    }

    const getUUID = await localStorage.getItem("UUID");
    if (!getUUID) {
      return;
    }

    const formData = new FormData();
    formData.append("file", attachment);
    formData.append("a_application_login_id", getUUID);

    switch (potions) {
      case 1:
        try {
          const response = await axiosInstanceFormData.post(
            "excel-sheet",
            formData,
            {
              headers: {
                "Content-Type": "multipart/form-data",
                "x-tenant-id": getUUID,
              },
              onUploadProgress: (progressEvent) => {
                if (progressEvent.total) {
                  const percentCompleted = Math.round(
                    (progressEvent.loaded * 100) / progressEvent.total
                  );
                  console.log(`File upload progress: ${percentCompleted}%`);
                  setUploadProgress(percentCompleted);
                } else {
                  console.log(
                    `File upload progress: Unable to determine total file size`
                  );
                }
              },
            }
          );

          if (response && response.data.ack === 1) {
            handleSubmit();
            setAttachment(null);
          } else {
            toast.error(
              response.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED
            );
          }
          console.log("File uploaded successfully:", response.data);
        } catch (error) {
          console.error("Error uploading file:", error);
        } finally {
          setTimeout(() => {
            setUploadProgress(0);
          }, 30000);
        }
        break;
      case 2:
        try {
          const response = await axiosInstanceFormData.post(
            "excel-sheet-product",
            formData,
            {
              headers: {
                "Content-Type": "multipart/form-data",
                "x-tenant-id": getUUID,
              },
              onUploadProgress: (progressEvent) => {
                if (progressEvent.total) {
                  const percentCompleted = Math.round(
                    (progressEvent.loaded * 100) / progressEvent.total
                  );
                  console.log(`File upload progress: ${percentCompleted}%`);
                  setUploadProgress(percentCompleted);
                } else {
                  console.log(
                    `File upload progress: Unable to determine total file size`
                  );
                }
              },
            }
          );

          if (response && response.data.ack === 1) {
            handleSubmit();
            setAttachment(null);
          } else {
            toast.error(
              response.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED
            );
          }
          console.log("File uploaded successfully:", response.data);
        } catch (error) {
          console.error("Error uploading file:", error);
        } finally {
          setTimeout(() => {
            setUploadProgress(0);
          }, 30000);
        }
        break;
      default:
        alert("default");
        break;
    }
  };

  const handleHide = () => {
    setAttachment(null);
    onHide();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachment(e.target.files[0]);
    }
  };

  return (
    <div>
      {show && (
        <div className="modal1">
          <div className="modal-content1" style={{ width: "40%" }}>
            <span className="close" onClick={onHide}>
              &times;
            </span>
            <h2 className="modal-title1 form_header_text">{title}</h2>
            <p className="text-center" style={{ color: "#999" }}>
              <p>{message}</p>
            </p>
            <div className={`m-title-2 row`}>
              <label
                style={{
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                }}
                htmlFor="file-upload-contact"
              >
                <div className="col-12 card p-4">
                  <div className="text-center">
                    {attachment ? (
                      <span>
                        <b>{attachment.name}</b>
                      </span>
                    ) : (
                      <span>No file selected</span>
                    )}
                  </div>
                </div>
              </label>
              <input
                type="file"
                id="file-upload-contact"
                onChange={handleFileChange}
                style={{ display: "none" }}
                accept=".xlsx"
              />
              <a
                href={require(`../../assets/sample/${sampleLocation}`)}
                download={`${sampleLocation}`}
                className=""
                style={{ marginTop: "10px" }}
              >
                Download Sample Excel
              </a>
            </div>
            <div>
              <p className="text-danger"> The Excel file you are importing will automatically Accept the current date from the system.</p>
            </div>
            <div className="modal-buttons">
              <button className="modal-button1 ig-btn" onClick={handleHide}>
                {btn1}
              </button>
              <button className="modal-button2 ig-btn" onClick={onSubmit}>
                {btn2}
              </button>
            </div>
          </div>
          {uploadProgress > 0 && (
            <div className="fullscreen-loader">
              <div className="loader-content">
                <div className="spinner"></div>
                <p>Uploading... {uploadProgress}%</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ImportExcelForContactModal;
