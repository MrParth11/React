import React, { useState, useEffect, useRef, useLayoutEffect } from "react";
import {
  EditorState,
  RichUtils,
  DraftHandleValue,
  Modifier,
  ContentState,
  convertFromHTML,
} from "draft-js";
import { stateToHTML } from "draft-js-export-html";
import { stateFromHTML } from "draft-js-import-html";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { Editor } from "react-draft-wysiwyg";
import axios from "axios";
import { toast } from "react-toastify";
import { MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../helpers/AppConstants";
import ConfirmationModal from "./model/ConfirmationModal";
import { axiosInstanceFormData } from "../services/axiosInstance";
import { TReactSetState } from "../helpers/AppType";
import useSpeechRecognition from "../pages/voice/Voice";
import EmojiPicker, { Theme } from 'emoji-picker-react';

interface ICustomEditorProps {
  fieldName: string;
  text: string;
  onChange: (fieldName: string, html: string) => void;
  onSend: (html: string) => void;
  isToggledButton: boolean;
  handleChangeToggleButton: any;
  contactData: any;
  setIsLoadedMessage: any;
  editMsg: string;
  isWhatsAppAuto: boolean;
  handleWhatsAppToggle: (checked: boolean) => void;
  setIsWhatsAppAuto: React.Dispatch<React.SetStateAction<boolean>>;
}

const MAX_FILE_SIZE_MB = 10;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

const createEditorState = (text: string): EditorState => {
  const contentState = stateFromHTML(text);
  return EditorState.createWithContent(contentState);
};

const CustomEditor: React.FC<ICustomEditorProps> = ({
  fieldName,
  text,
  onChange,
  onSend,
  isToggledButton,
  handleChangeToggleButton,
  contactData,
  setIsLoadedMessage,
  editMsg,
  isWhatsAppAuto,
  handleWhatsAppToggle,
  setIsWhatsAppAuto,
}) => {
  const {
    voice,
    startListening,
    stopListening,
    isListening,
    setVoice,
    hasRecognitionSupport,
  } = useSpeechRecognition();

  const [editorState, setEditorState] = useState(EditorState.createEmpty());
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isAttachmentConfirmation, setIsAttachmentConfirmation] =
    useState(false);
  const lastVoiceRef = useRef("");
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  useEffect(() => {
    if (editMsg) {
      const blocksFromHTML = convertFromHTML(editMsg);
      const contentState = ContentState.createFromBlockArray(
        blocksFromHTML.contentBlocks,
        blocksFromHTML.entityMap
      );
      setEditorState(EditorState.createWithContent(contentState));
    } else {
      setEditorState(EditorState.createEmpty());
    }

    return () => {
      setEditorState(EditorState.createEmpty());
    };
  }, [editMsg, contactData.id]);

  useEffect(() => {
    setIsWhatsAppAuto(false);
  }, [contactData.id]);

  useEffect(() => {
    setEditorState(createEditorState(text || ""));
  }, [text]);
  const prevVoiceRef = useRef<string | undefined>();

  useLayoutEffect(() => {
    console.log("voice", voice);
    if (prevVoiceRef.current !== voice) {
      setEditorState(createEditorState(voice || ""));
      prevVoiceRef.current = voice;
    }
  }, [voice, setEditorState, createEditorState]);

  const onEditorStateChange = (editorState: EditorState) => {
    setEditorState(editorState);
    const html = stateToHTML(editorState.getCurrentContent());
    onChange(fieldName, html);
  };

  const handleSend = () => {
    const html = stateToHTML(editorState.getCurrentContent());
    console.log("html", html);

    if (html === "<p><br></p>") {
      toast.error("Please enter a message.");
      return;
    }

    if (html.length < 8 || html.length > 1000) {
      console.log("html length", html.length);
      toast.error("Message length should be between 1 and 1000 characters.");
      return;
    }
    if (html.trim()) {
      onSend(html);
    } else {
      console.log("Empty content, not sending.");
    }

    setEditorState(EditorState.createEmpty());
  };

  const handleKeyCommand = (
    command: string,
    editorState: EditorState
  ): DraftHandleValue => {
    if (command === "stop-enter") {
      return "handled";
    }
    return RichUtils.handleKeyCommand(
      editorState,
      command
    ) as unknown as DraftHandleValue;
  };

  const handleReturn = (event: React.KeyboardEvent): boolean => {
    if (event.shiftKey) {
      return false;
    }
    handleSend();
    return true;
  };

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setIsLoadedMessage(false);

    const getUUID = await localStorage.getItem("UUID");
    const file = event.target.files && event.target.files[0];

    if (!getUUID || !file) return;
    console.log("Editor State Changed");
    console.log("Voice Text:", voice);
    console.log("Selected File:", selectedFile);
    console.log("Attachment Confirmation:", isAttachmentConfirmation);
    console.log("WhatsApp Auto:", isWhatsAppAuto);
    console.log("Editor State Changed");
    console.log("Voice Text:", voice);
    console.log("Selected File:", selectedFile);
    console.log("Attachment Confirmation:", isAttachmentConfirmation);
    console.log("WhatsApp Auto:", isWhatsAppAuto);
    console.log("Editor State Changed");
    console.log("Voice Text:", voice);
    console.log("Selected File:", selectedFile);
    console.log("Attachment Confirmation:", isAttachmentConfirmation);
    console.log("WhatsApp Auto:", isWhatsAppAuto);
    console.log("Editor State Changed");
    console.log("Voice Text:", voice);
    console.log("Selected File:", selectedFile);
    console.log("Attachment Confirmation:", isAttachmentConfirmation);
    console.log("WhatsApp Auto:", isWhatsAppAuto);
    const validTypes = [
      "image/jpeg",
      "image/png",
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/zip",
      "image/svg+xml",
      "video/mp4",
      "video/x-matroska",
      "video/mpeg",
      "text/plain",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-excel",
      "application/vnd.ms-powerpoint",
      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
      "text/csv",
      "audio/mpeg",
      "audio/ogg",
      "audio/wav",
      "application/xml",
      "text/xml",
      "application/x-zip-compressed",
    ];

    if (!validTypes.includes(file.type)) {
      toast.error("Invalid file format.");
      event.target.value = "";
      return;
    }

    if (file.size > MAX_FILE_SIZE_BYTES) {
      toast.error(`File is too large. Max: ${MAX_FILE_SIZE_MB}MB`);
      event.target.value = "";
      return;
    }

    setSelectedFile(file);
    setIsAttachmentConfirmation(true);
  };

  const handleAttachmentConfirm = async () => {
    const token = localStorage.getItem("token");

    try {
      if (selectedFile) {
        const getUUID = await localStorage.getItem("UUID");
        const getUserName = await localStorage.getItem("USERNAME");

        if (!getUUID || !getUserName) throw new Error("Missing user info");

        const formData = new FormData();
        formData.append("file", selectedFile);
        formData.append("contact_masters_id", contactData.id);
        formData.append("a_application_login_id", getUUID);
        formData.append("message_type_id", "1");
        formData.append("application_login_name", getUserName);
        formData.append("message_side", `${isToggledButton ? 2 : 1}`);
        formData.append("msg", `${isWhatsAppAuto ? 0 : 1}`);

        const response = await axiosInstanceFormData.post(
          "messageAttachmentsUpload",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
              Authorization: token,
              "x-tenant-id": getUUID,
            },
          }
        );

        if (response.status === 200) {
          setIsLoadedMessage(true);
          toast.success("Attachment added successfully.");
        } else {
          toast.error("Failed to upload attachment.");
        }
      }
    } catch (error: any) {
      toast.error(error.response?.data?.message || "Upload failed.");
    } finally {
      setIsAttachmentConfirmation(false);
      setSelectedFile(null);
    }
  };

  const onEmojiClick = (emojiData: any) => {
    const contentState = editorState.getCurrentContent();
    const selectionState = editorState.getSelection();
    const newContentState = Modifier.insertText(
      contentState,
      selectionState,
      emojiData.emoji
    );
    const newEditorState = EditorState.push(editorState, newContentState, 'insert-characters');
    setEditorState(newEditorState);
    setShowEmojiPicker(false);
  };

  return (
    <div className="ig-chat-input-bar" ref={wrapperRef}>
      <div style={{ position: 'relative' }}>
        <button
          className="icons Marg"
          type="button"
          onClick={() => setShowEmojiPicker((v) => !v)}
          aria-label="Add emoji"
        >
          <span role="img" aria-label="emoji">😊</span>
        </button>
        {showEmojiPicker && (
          <div style={{ position: 'absolute', bottom: '48px', left: 0, zIndex: 1000 }}>
            <EmojiPicker onEmojiClick={onEmojiClick} theme={Theme.DARK} height={350} width={300} />
          </div>
        )}
      </div>
      <button className="icons Marg" id="chat-popup">
        <div className="form-group1">
          <label htmlFor="input-files">
            <span data-testid="camera" data-icon="camera" className="">
              <svg
                viewBox="0 0 24 24"
                width="24"
                height="24"
                className=""
              >
                <path
                  fill="currentColor"
                  d="M1.816 15.556v.002c0 1.502.584 2.912 1.646 3.972s2.472 1.647 3.974 1.647a5.58 5.58 0 0 0 3.972-1.645l9.547-9.548c.769-.768 1.147-1.767 1.058-2.817-.079-.968-.548-1.927-1.319-2.698-1.594-1.592-4.068-1.711-5.517-.262l-7.916 7.915c-.881.881-.792 2.25.214 3.261.959.958 2.423 1.053 3.263.215l5.511-5.512c.28-.28.267-.722.053-.936l-.244-.244c-.191-.191-.567-.349-.957.04l-5.506 5.506c-.18.18-.635.127-.976-.214-.098-.097-.576-.613-.213-.973l7.915-7.917c.818-.817 2.267-.699 3.23.262.5.501.802 1.1.849 1.685.051.573-.156 1.111-.589 1.543l-9.547 9.549a3.97 3.97 0 0 1-2.829 1.171 3.975 3.975 0 0 1-2.83-1.173 3.973 3.973 0 0 1-1.172-2.828c0-1.071.415-2.076 1.172-2.83l7.209-7.211c.157-.157.264-.579.028-.814L11.5 4.36a.572.572 0 0 0-.834.018l-7.205 7.207a5.577 5.577 0 0 0-1.645 3.971z"
                ></path>
              </svg>
            </span>
          </label>
          <input
            type="file"
            name="image"
            id="input-files"
            className="form-control-file border"
            onChange={(e) => handleFileChange(e)}
            style={{ display: "none" }}
          />
        </div>
      </button>
      {!editMsg && (
        <button
          onClick={handleChangeToggleButton}
          className={`toggle-button ${isToggledButton ? "on" : "off"}`}
        >
          {isToggledButton ? "CL" : "ME"}
        </button>
      )}
      <div className="form-check form-switch mx-2">
        <label className="form-check-label">WA</label>
        <input
          className="form-check-input"
          type="checkbox"
          role="switch"
          checked={isWhatsAppAuto}
          onChange={(e) => handleWhatsAppToggle(e.target.checked)}
        />
      </div>
      <div className="flex-grow-1 mx-2" style={{ minWidth: 0 }}>
        <Editor
          editorState={editorState}
          toolbar={{ options: [] }}
          onEditorStateChange={onEditorStateChange}
          handleReturn={handleReturn}
          placeholder="Type a message..."
        />
      </div>
      <button
        className="send_box_icons ig-btn"
        onClick={isListening ? stopListening : startListening}
        style={{ color: isListening ? "#fd1d1d" : "", transition: "color 0.3s ease" }}
        title={isListening ? "Stop Listening" : "Start Listening"}
      >
        <svg className="ig-icon" xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor">
          <path d="M480-400q-50 0-85-35t-35-85v-240q0-50 35-85t85-35q50 0 85 35t35 85v240q0 50-35 85t-85 35Zm0-240Zm-40 520v-123q-104-14-172-93t-68-184h80q0 83 58.5 141.5T480-320q83 0 141.5-58.5T680-520h80q0 105-68 184t-172 93v123h-80Zm40-360q17 0 28.5-11.5T520-520v-240q0-17-11.5-28.5T480-800q-17 0-28.5 11.5T440-760v240q0 17 11.5 28.5T480-480Z" />
        </svg>
      </button>
      <button className="send_box_icons ig-btn" onClick={handleSend}>
        <span className="ig-icon">
          <svg height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor">
            <path d="M120-160v-640l760 320-760 320Zm80-120 474-200-474-200v140l240 60-240 60v140Zm0 0v-400 400Z" />
          </svg>
        </span>
      </button>
      {isListening && (
        <div className="text-sm text-red-500 mt-1">Listening...</div>
      )}
      {isAttachmentConfirmation && (
        <ConfirmationModal
          show={isAttachmentConfirmation}
          onHide={() => setIsAttachmentConfirmation(false)}
          handleSubmit={handleAttachmentConfirm}
          title={" Add This Attachment"}
          message={"Are you sure you want Add This Attachment?"}
          btn1="CANCEL"
          btn2="Send"
        />
      )}
    </div>
  );
};

export default CustomEditor;
