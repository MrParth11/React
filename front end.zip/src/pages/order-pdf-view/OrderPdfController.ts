import { toast } from "react-toastify";
import { DEFAULT_STATUS_CODE_SUCCESS, MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../helpers/AppConstants";
import { TReactSetState } from "../../helpers/AppType";
import { axiosInstance } from "../../services/axiosInstance";


interface IOrderCompanyDetail {
  company_contact: string
  company_email: string
  company_name: string
  footer_img: string
  header_img: string
  address: string
  gst_number: string
  bank_detail: string
}

interface IOrderLoginDetail {
  recovery_email: string
  recovery_mobile: string
  username: string
}

interface IOrderCartPdf {
  id: number;
  type: number;
  cart_date: string;
  cart_status: number;
  a_application_login_id: number;
  company_masters_id: number;
  to_customer_id: number;
  total_qty: number;
  total_amt: number
  discount_pct: number
  discount_pr: number
  packing_forwarding_charge: number
  transport_charge: number
  taxable_amt: number
  gst_amt: number
  tcs_amt: number
  round_off: number
  grand_total: number
  to_customer_name: string
  to_customer_phone: string
  to_customer_gst_number: string
  shipping_address: string
  cart_number: string
  Address: string
  cart_terms_and_condition: string
}

export interface IOrderItemPdf {
  id: number
  item_product_name: string
  item_product_description: string
  item_unit_name: string
  item_rate: number
  item_gst: number
  item_net_rate: number
  item_qty: number
  item_total: number
  item_discount_pct: number
}

export interface ItemDetails {
  cart: IOrderCartPdf;
  items: IOrderItemPdf[];
  companyDetail: IOrderCompanyDetail
  loginDetail: IOrderLoginDetail
}

export const orderTypesListPdf = [
  { id: "1", type: "Quotation" },
  { id: "2", type: "Order" },
  { id: "3", type: "Invoice" },
  { id: "4", type: "Purchase" },

];

export const fetchOrderByForPdfIdApi = async (
  cartId: number | undefined,
  setOrderPdfViewById: TReactSetState<ItemDetails | undefined>,
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = localStorage.getItem("token");
  try {
    const { data } = await axiosInstance.post(
      "orderById",
      {
        cart_id: cartId,
        request_flag: 2,
        a_application_login_id: Number(getUUID)
      },
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {

        setOrderPdfViewById(data.data.item);

      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }

};