
import React, { useEffect, useRef, useState } from "react";
import "./OrderPrintView.css";
import { fetchOrderByForPrintIdApi } from "./orderPrintController";
import {
  ItemDetails,
  orderTypesListPdf,
} from "../order-pdf-view/OrderPdfController";
import { useParams } from "react-router-dom";
import {
  formatDate,
  formatNumber,
  numberToWordsCurrency,
} from "../../common/SharedFunction";
import SafeHtml from "../../components/SafeHtml";

const OrderPrintViewV1 = () => {
  const [orderPrintById, setOrderPrintById] = useState<ItemDetails>();
  const { id, MobileToken, getID } = useParams();
  console.log("token", MobileToken, getID);


  const data = Array.from({ length: 100 }, (_, index) => {
    const srno = index + 1;
    let description = `FRP PIPE NB25 PN10 ${index}`;
    if ([19, 42, 41, 21, 46].includes(srno)) {
      description = `hello i am here where are you going\nplease don't go\nwhere are you go on\nshow that you can do 1\n1234567892\n1234567893\n123456789 4\n1234567895\n1234567896\n1234567897\n1234567898\n1234567899\n12345678910\n12345678911\n12345678912\n12345678913\n12345678914\n12345678915\n12345678916\n12345678917\n12345678918\n12345678919\n12345678920\n12345678921\n12345678922\n12345678923\n12345678924\n12345678925\n12345678926 better work\nyes i am here to work`;
    }

    return {
      srno,
      materialNumber: `L747918073401${index}`,
      description,
      quantity: `${(index % 5) + 1} Meter`, // Random quantity for demo
      unitPrice: (index + 1) * 27.62, // Random price for demo
      totalPrice: (index + 1) * 27.62 * 10, // Random total price for demo
    };
  });
  useEffect(() => {
    fetchOrderByForPrintIdApi(Number(id), setOrderPrintById, MobileToken, getID);
  }, [id, MobileToken, getID]);

  const grandTotalInWords = numberToWordsCurrency(
    orderPrintById?.cart?.grand_total ?? 0,
    "INR"
  );

  const symbolCurrency = "₹";
  return (
    <div className="print-table">
      <div className="content  " id="content">
        <table className="print-table">
          <thead>
            <tr>
              <td colSpan={10} style={{ padding: "0" }} className="text-center">
                {orderPrintById?.companyDetail.header_img !== "" ? (
                  <img
                    style={{
                      width: "100%",
                      
                    }}
                    src={orderPrintById?.companyDetail.header_img}
                    alt=""
                  />
                ) : (
                  ""
                )}
              </td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="main-colspan-class text-center" colSpan={9} style={{ backgroundColor: "#cfcfcf" }}>
                <p className="m-0">
                  <b>
                    {orderTypesListPdf?.find(
                      (option) =>
                        Number(option.id) === orderPrintById?.cart.type
                    )?.type || ""}
                  </b>
                </p>
              </td>
            </tr>
            <tr>
              <td
                className="main-colspan-class"
                style={{ padding: "0" }}
                colSpan={9}
              >
                <table
                  border={0}
                  ref={(el) => {
                    if (el) {
                      el.style.setProperty("width", "100%", "important");
                      el.style.setProperty("margin", "0", "important");
                      el.style.setProperty("border", "0px", "important");
                    }
                  }}
                >
                  <tr>
                    <td
                      style={{ verticalAlign: "top", width: "66mm" }}
                      ref={(el) => {
                        if (el) {
                          el.style.setProperty("border", "0px", "important");
                        }
                      }}
                    >
                      <span>
                        <b>FROM,</b>
                      </span>
                      <br />
                      <span
                        className="bolde-style"
                        style={{ textTransform: "uppercase" }}
                      >
                        <strong>
                          {orderPrintById?.companyDetail?.company_name
                            ? orderPrintById?.companyDetail?.company_name
                            : ""}
                        </strong>
                      </span>
                      <br />

                      <span className="bolde-style">
                        <b>Address :</b>
                      </span>
                      <br />
                      <span style={{ wordWrap: "break-word", width: " 50px" }}>
                        {orderPrintById?.companyDetail.address
                          ? orderPrintById?.companyDetail.address
                          : ""}
                      </span>
                      <br />
                      <span>
                        <strong>
                          GSTIN No. :
                          {orderPrintById?.companyDetail.gst_number
                            ? orderPrintById?.companyDetail.gst_number
                            : ""}
                        </strong>
                      </span>
                    </td>
                    <td
                      style={{
                        verticalAlign: " top",
                        width: "66mm",
                        borderTop: "0px",
                        borderBottom: "0px",
                      }}
                      className="without_price_check_customer"
                    >
                      <span>
                        <b>TO ,</b>
                      </span>
                      <br />
                      <span
                        className="bolde-style"
                        style={{ textTransform: "uppercase" }}
                      >
                        <strong>{orderPrintById?.cart.to_customer_name}</strong>
                      </span>
                      <br></br>
                      <span className="bolde-style">
                        <b>Billing Address:</b>
                      </span>
                      <br />
                      <span style={{ wordWrap: "break-word", width: "50px" }}>
                        {orderPrintById?.cart.Address}
                      </span>
                      <br />
                      <span className="bolde-style">
                        <b>Shipping Address:</b>
                      </span>
                      <br />
                      <span style={{ wordWrap: "break-word", width: "50px" }}>
                        {orderPrintById?.cart.shipping_address}
                      </span>
                      <br />
                      <br />
                      <span>
                        <strong>
                          GSTIN No. :
                          {orderPrintById?.cart.to_customer_gst_number}
                        </strong>
                      </span>
                      <br />
                    </td>
                    <td
                      style={{ verticalAlign: " top", width: "66mm" }}
                      ref={(el) => {
                        if (el) {
                          el.style.setProperty("border", "0px", "important");
                        }
                      }}
                    >
                      <span>
                        <b>{orderTypesListPdf?.find(
                          (option) =>
                            Number(option.id) === orderPrintById?.cart.type
                        )?.type || ""} No. : </b>&nbsp;
                        {orderPrintById?.cart.cart_number}
                      </span>
                      <br />
                      <span>
                        <b>{orderTypesListPdf?.find(
                          (option) =>
                            Number(option.id) === orderPrintById?.cart.type
                        )?.type || ""} Date :</b> &nbsp;
                        {orderPrintById?.cart.cart_date
                          ? formatDate(orderPrintById?.cart.cart_date)
                          : ""}
                      </span>
                      <br />

                      <span>
                        <b>Contact Person :</b>&nbsp;
                        {orderPrintById?.loginDetail?.username}
                      </span>
                      <br />
                      <br />
                      <br />
                      <br />
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr className="text-center" style={{ backgroundColor: "#cfcfcf" }}>
              <th className="text-center">No.</th>
              <th className="text-center"> Product Description</th>
              {/* <th className="text-center">HSN Code</th> */}
              <th className="without_price_check">Rate</th>
              <th className="text-center">Dis(%)</th>
              <th className="text-center"> GST(%)</th>
              <th className="without_price_check">Net Price</th>
              <th className="text-center">Qty/Unit</th>
              <th className="without_price_check">Total Amt</th>
            </tr>
            {orderPrintById?.items?.length &&
              orderPrintById.items.map((item, index) => (
                <React.Fragment key={index}>
                  <tr key={index}>
                    <td className="text-center srno">
                      <strong>{index + 1}</strong>
                    </td>
                    <td
                      className="model"
                      style={{ position: "relative", wordBreak: "break-word" }}
                    >
                      {item.item_product_name}

                      <br />
                      {item.item_product_description}
                    </td>

                    <td className="text-right">
                      {item.item_rate
                        ? `${symbolCurrency} ${formatNumber(item.item_rate, 2)}`
                        : ""}
                    </td>
                    <td className="text-right">
                      {item.item_discount_pct
                        ? formatNumber(item.item_discount_pct, 2)
                        : ""}
                    </td>
                    <td className="text-right without_price_check">
                      {item.item_gst ? formatNumber(item.item_gst, 2) : ""}
                    </td>
                    <td className="text-right without_price_check">
                      {item.item_net_rate
                        ? `${symbolCurrency} ${formatNumber(
                          item.item_net_rate,
                          2
                        )}`
                        : ""}
                    </td>
                    <td className="text-right without_price_check">
                      {item.item_qty} &nbsp;/&nbsp;
                      {item.item_unit_name}
                    </td>
                    <td className="text-right without_price_check">
                      {item.item_total
                        ? `${symbolCurrency} ${formatNumber(
                          item.item_total,
                          2
                        )}`
                        : ""}
                    </td>
                  </tr>
                </React.Fragment>
              ))}
            <tr style={{ backgroundColor: "lightgray" }}>
              <td></td>

              <td></td>

              <td className="without_price_check"></td>
              <td className="without_price_check"></td>
              <td className="without_price_check"></td>

              <td>
                <strong>Total Qty</strong>
              </td>
              <td className="text-right">{orderPrintById?.cart.total_qty}</td>
              <td className="without_price_check"></td>
            </tr>
            <tr className="font-size without_price_check">
              <td colSpan={5} style={{ verticalAlign: "top", width: "380px" }}>
              </td>
              <td
                colSpan={2}
                className="text-left font-13"
              >
                <strong>Sub Total</strong>
              </td>
              <td
                colSpan={3}
                className="text-right font-13"
              >
                <strong>
                  {orderPrintById?.cart.total_amt
                    ? `${symbolCurrency} ${formatNumber(
                      orderPrintById?.cart.total_amt,
                      2
                    )}`
                    : ""}
                </strong>
              </td>
            </tr>
            <tr>
              <td colSpan={9} style={{ padding: 0 }}>
                <table
                  style={{ padding: 0, margin: 0, width: "100%" }}
                  ref={(el) => {
                    if (el) {
                      el.style.setProperty("width", "100%", "important");
                      el.style.setProperty("margin", "0", "important");
                      el.style.setProperty("border", "0px", "important");
                    }
                  }}
                >
                  <tbody>
                    <tr>
                      <td
                        className="without_price_check"
                        rowSpan={8}
                        style={{ verticalAlign: "top", border: "0px" }}
                      >
                        <b>
                          <p>
                            {orderPrintById?.companyDetail.bank_detail ? (
                              <SafeHtml
                                htmlContent={
                                  orderPrintById?.companyDetail.bank_detail
                                }
                              />
                            ) : (
                              " "
                            )}
                          </p>
                        </b>
                        <span className="font-13">
                          <b>Terms & Condition : </b>
                        </span>
                        <p
                          className="font-13"
                        >
                          {orderPrintById?.cart.cart_terms_and_condition ? (
                            <SafeHtml
                              htmlContent={
                                orderPrintById?.cart.cart_terms_and_condition
                              }
                            />
                          ) : (
                            " "
                          )}
                        </p>
                        <br />
                        <span className="font-13">
                          <b>Note: </b>
                        </span>
                        <span className="font-13"></span>
                        <br />
                        <span style={{ color: "red" }}>
                          Contact Sales Person :
                          {`${orderPrintById?.loginDetail.username}  ${orderPrintById?.loginDetail.recovery_mobile}`}
                        </span>
                      </td>
                      <td
                        className="text-left without_price_check"
                        style={{ borderTop: "0px" }}
                      >
                        <strong>
                          Discount (
                          {orderPrintById?.cart.discount_pct
                            ? formatNumber(orderPrintById?.cart.discount_pct, 2)
                            : ""}
                          &nbsp;%)
                        </strong>
                      </td>
                      <td
                        className="text-right font-13 without_price_check"
                        style={{ border: "0px" }}
                      >
                        {orderPrintById?.cart.discount_pr
                          ? `${symbolCurrency} ${formatNumber(
                            orderPrintById?.cart.discount_pr,
                            2
                          )}`
                          : ""}
                      </td>
                    </tr>
                    <tr>
                      <td className="text-left without_price_check">
                        <b> Packing Forwarding charge</b>
                      </td>
                      <td
                        className="text-right font-13 without_price_check"
                        style={{ borderRight: "0px" }}
                      >
                        {orderPrintById?.cart.packing_forwarding_charge
                          ? `${symbolCurrency} ${formatNumber(
                            orderPrintById?.cart.packing_forwarding_charge,
                            2
                          )}`
                          : ""}
                      </td>
                    </tr>
                    <tr>
                      <td className="text-left font-13 without_price_check">
                        <strong> Transport charge </strong>
                      </td>
                      <td
                        className="text-right font-13 without_price_check"
                        style={{ borderRight: "0px" }}
                      >
                        {orderPrintById?.cart.transport_charge
                          ? `${symbolCurrency} ${formatNumber(
                            orderPrintById?.cart.transport_charge,
                            2
                          )}`
                          : ""}
                      </td>
                    </tr>
                    <tr>
                      <td className="text-left font-13 without_price_check">
                        <strong> Total Taxable Amount </strong>
                      </td>
                      <td
                        className="text-right font-13 without_price_check"
                        style={{ borderRight: "0px" }}
                      >
                        {orderPrintById?.cart.taxable_amt
                          ? `${symbolCurrency} ${formatNumber(
                            orderPrintById?.cart.taxable_amt,
                            2
                          )}`
                          : ""}
                      </td>
                    </tr>
                    <tr>
                      <td
                        className="text-left without_price_check"
                      >
                        <strong>GST</strong>
                      </td>
                      <td
                        className="text-right font-13 without_price_check"
                        style={{ borderRight: "0px" }}
                      >
                        {orderPrintById?.cart.gst_amt
                          ? `${symbolCurrency} ${formatNumber(
                            orderPrintById?.cart.gst_amt,
                            2
                          )}`
                          : ""}
                      </td>
                    </tr>
                    <tr>
                      <td className="text-left without_price_check">
                        <strong>TCS</strong>
                      </td>
                      <td
                        className="text-right without_price_check"
                        style={{ borderRight: "0px" }}
                      >
                        <strong>
                          {orderPrintById?.cart.tcs_amt
                            ? formatNumber(orderPrintById?.cart.tcs_amt, 2)
                            : ""}
                        </strong>
                      </td>
                    </tr>
                    <tr>
                      <td className="text-left without_price_check">
                      </td>
                      <td
                        className="text-right without_price_check"
                        style={{ borderRight: "0px" }}
                      >
                      </td>
                    </tr>
                    <tr>
                      <td className="without_price_check"></td>
                      <td
                        className="text-right without_price_check"
                        style={{ borderRight: "0px" }}
                      >
                        <strong></strong>
                      </td>
                    </tr>
                    <tr className="without_price_check">
                      <td rowSpan={1} style={{ borderLeft: "0px" }}>
                        <b>Grand Total In Words</b> : {grandTotalInWords}
                      </td>
                      <td>
                        <strong>Round Off</strong>
                      </td>
                      <td className="text-right" style={{ borderRight: "0px" }}>
                        {orderPrintById?.cart.round_off
                          ? `${symbolCurrency} ${formatNumber(orderPrintById?.cart.round_off, 2)}`
                          : ""}
                      </td>
                    </tr>
                    <tr className="without_price_check">
                      <td rowSpan={1} style={{ border: "0px" }}>
                        <b>
                          Note : KINDLY RELEASE PAYMENT FOR DISPATCH CLEARANCE
                        </b>
                      </td>
                      <td
                        style={{
                          backgroundColor: "#669B49",
                          fontSize: "16px",
                          borderBottom: "0px",
                        }}
                      >
                        <strong>Grand Total</strong>
                      </td>
                      <td
                        className="text-right"
                        style={{
                          backgroundColor: "#669B49",
                          fontSize: "15px",
                          borderBottom: "0px",
                          borderRight: "0px",
                        }}
                      >
                        <strong>
                          {orderPrintById?.cart.grand_total
                            ? `${symbolCurrency} ${formatNumber(orderPrintById?.cart.grand_total, 2)}`
                            : ""}
                        </strong>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
          <tfoot
          >
            <tr>
              <td
                colSpan={9}
                className="text-center p-0"
                style={{ padding: "0 !!important" }}
              >
                {orderPrintById?.companyDetail.footer_img ? (
                  <img
                    style={{
                      width: "100%",
                      padding: " 0px ",
                    }}
                    src={orderPrintById?.companyDetail.footer_img}
                    alt=""
                  />
                ) : (
                  ""
                )}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};

export default OrderPrintViewV1;
