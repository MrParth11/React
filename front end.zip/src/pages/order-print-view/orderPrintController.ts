import { toast } from "react-toastify";
import { DEFAULT_STATUS_CODE_SUCCESS, MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../helpers/AppConstants";
import { TReactSetState } from "../../helpers/AppType";
import {axiosInstance} from "../../services/axiosInstance";
import { ItemDetails } from "../order-pdf-view/OrderPdfController";


export const fetchOrderByForPrintIdApi = async (
    cartId: number |  undefined,
    setOrderPrintById: TReactSetState<ItemDetails | undefined>,
    MobileToken:any,
    getID:any
  ) => {
    console.log("token1111111", MobileToken);
    const getUUID = await localStorage.getItem("UUID");
    const token = localStorage.getItem("token");
    try {
      const { data } = await axiosInstance.post(
        "orderById",
        {
          cart_id: cartId,
          request_flag:2,
        },
        {
          headers: {
            Authorization: `${token ? token : MobileToken}`,
            "x-tenant-id":  getUUID ? Number(getUUID) : getID,

          },
        }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {

            setOrderPrintById(data.data.item);

        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };