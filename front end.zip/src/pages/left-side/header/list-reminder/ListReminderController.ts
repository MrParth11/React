import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../helpers/AppConstants";
import { TReactSetState } from "../../../../helpers/AppType";
import { axiosInstance } from "../../../../services/axiosInstance";

export interface IReminderList {
  id: number;
  reminder_data_time: string;
  remark: string;
  status: number;
  person_name: string;
  company_name: string;
  contact_message: string;
  completed_date_time: string;
  username: string;
  contact_masters_id: number;
  isDue: number;
  reference_id: number;
  reference_table: string;
  assigned_to_name:string;
  assigned_to:number;
}

export const fetchReminderApi = async (
  setReminderList: TReactSetState<IReminderList[]>,
  searchDate: string,
  setNoDataFound: TReactSetState<boolean>,
  setLoading: TReactSetState<boolean>,
  page:number,
  reminderCheckFlag: number | boolean
) => {
  const itemsPerPage = 12
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");
  const start: number = page * itemsPerPage;

  try {
    const { data } = await axiosInstance.post(
      "reminder",
      {
        a_application_login_id: Number(getUUID),
        searchDate: searchDate,
        ul: start, // Upper limit based on page number
        ll: itemsPerPage, // Lower limit based on page number
        reminderCheckFlag: reminderCheckFlag,
      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        if (page === 0) {
          setLoading(true);


          setReminderList(data.data.item);
          
        } else {
          setLoading(false);
          setReminderList((prevUsers) => [...prevUsers, ...data.data.item]);
        }
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
    setNoDataFound(data.data.item.length === 0);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};

export const createRescheduleReminder = async (
  reminderId: number | undefined,
  insertObj: any,
  setIsReminderConfirmation: TReactSetState<boolean>,
  setLoading: TReactSetState<boolean>,
  setReminderList: TReactSetState<IReminderList[]>,
  setNoDataFound: TReactSetState<boolean>
) => {
  const date = new Date(insertObj.dateTime);

  const formattedDateTime = `${date.getFullYear()}-${String(
    date.getMonth() + 1
  ).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(
    date.getHours()
  ).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(
    date.getSeconds()
  ).padStart(2, "0")}`;

  const requestData = {
    table: "reminder_messages",
    where: `{"id":"${reminderId}"}`,
    data: JSON.stringify({
      reminder_data_time: formattedDateTime,
      remark: insertObj.remark,
      status: "0",
    }),
  };
  const getUUID = localStorage.getItem("UUID")
  try {
    const data = await axiosInstance.post("commonUpdate", requestData ,
      
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }

    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setIsReminderConfirmation(false);
      fetchReminderApi(setReminderList, "", setNoDataFound, setLoading , 0,0);
    } else {
      toast.error(data.data.ack_msg);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createReminderForMy = async (
  insertObj: any,
  setIsReminderConfirmation: TReactSetState<boolean>,
  setLoading: TReactSetState<boolean>,
  setReminderList: TReactSetState<IReminderList[]>,
  setNoDataFound: TReactSetState<boolean>
) => {
  console.log("insertObj", insertObj.selectedCategory);

  const date = new Date(insertObj.dateTime);

  const formattedDateTime = `${date.getFullYear()}-${String(
    date.getMonth() + 1
  ).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(
    date.getHours()
  ).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(
    date.getSeconds()
  ).padStart(2, "0")}`;
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    table: "reminder_messages",
    data: JSON.stringify({
      reminder_data_time: formattedDateTime,
      remark: insertObj.remark,
      a_application_login_id: getUUID,
      assigned_to: insertObj?.selectedCategory?.value,
      assigned_to_name:insertObj.selectedCategory?.label,
      status: "0",
    }),
  };
  try {
    console.log("requestData", requestData.data);

    // setIsReminderConfirmation(false)
    const data = await axiosInstance.post("commonCreate", requestData ,
      
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setIsReminderConfirmation(false);
      fetchReminderApi(setReminderList, "", setNoDataFound, setLoading , 0,0);
    } else {
      toast.error(data.data.ack_msg);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateContactFormReminder = async (
  contactId: number | undefined
) => {
  const requestData = {
    table: "contact_message_histories",
    where: `{"id":${contactId}}`,
    data: `{"is_reminder":"0"}`,
  };
  const getUUID = localStorage.getItem("UUID")

  try {
    const data = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        return true;
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        return false;
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateOrderFormReminder = async (
  contactId: number | undefined
) => {
  const requestData = {
    table: "carts",
    where: `{"id":${contactId}}`,
    data: `{"is_reminder":"0"}`,
  };
  const getUUID = localStorage.getItem("UUID")

  try {
    const data = await axiosInstance.post("commonUpdate", requestData,{
      headers: {
        "x-tenant-id": getUUID,

      },
      });
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        return true;
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        return false;
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const updateInquiryFormReminder = async (
  contactId: number | undefined
) => {
  const requestData = {
    table: "inquiries",
    where: `{"id":${contactId}}`,
    data: `{"is_reminder":"0"}`,
  };
  try {
    const data = await axiosInstance.post("commonUpdate", requestData);
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        return true;
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        return false;
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const handleDeleteReminder = async (
  reminderId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setReminderList: TReactSetState<IReminderList[]>,
  setNoDataFound: TReactSetState<boolean>,
  setLoading: TReactSetState<boolean>,
  isReminderConfirmationStatusData: IReminderList | undefined
) => {
  const requestData = {
    table: "reminder_messages",
    where: `{"id":${reminderId}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID")
  try {
    const data = await axiosInstance.post("commonUpdate", requestData , 
      
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        
        if(isReminderConfirmationStatusData?.reference_table){
        switch (isReminderConfirmationStatusData?.reference_table) {
          case "contact_message_histories":
            await updateContactFormReminder(
              isReminderConfirmationStatusData.reference_id
            );
            break;
          case "cart_Quotation":
          case "cart_Order":
          case "cart_Invoice":
            console.log(
              "isReminderConfirmationStatusData?.reference_table",
              isReminderConfirmationStatusData?.reference_table
            );
            await updateOrderFormReminder(
              
              isReminderConfirmationStatusData.reference_id
            );
            break;
          case "inquiries":
            await updateInquiryFormReminder(
              isReminderConfirmationStatusData.reference_id
            );
            break;
          default:
            break;
        }
        await fetchReminderApi(setReminderList, "", setNoDataFound, setLoading , 0,0);
      }
       await fetchReminderApi(setReminderList, "", setNoDataFound, setLoading , 0,0);
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
