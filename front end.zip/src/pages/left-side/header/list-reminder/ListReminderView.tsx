import React, { useEffect, useRef, useState } from "react";
import {
  createReminderForMy,
  createRescheduleReminder,
  fetchReminderApi,
  handleDeleteReminder,
  IReminderList,
  updateContactFormReminder,
  updateInquiryFormReminder,
  updateOrderFormReminder,
} from "./ListReminderController";
import {
  formatDateAndTime,
  isCurrentDateTime,
} from "../../../../common/SharedFunction";
import { TOnChangeInput } from "../../../../helpers/AppType";
import SafeHtml from "../../../../components/SafeHtml";
import { axiosInstance } from "../../../../services/axiosInstance";
import {
  DEFAULT_MESSAGE_ERROR_PERMISSION,
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../helpers/AppConstants";
import { toast } from "react-toastify";
import ConfirmationModal from "../../../../components/model/ConfirmationModal";
import ReminderModal from "../../../../components/model/ReminderModal";
import { useTheme } from "../../../../components/ThemeContext";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import useCheckUserPermission from "../../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../../helpers/AppEnum";

interface IPropReminder {
  isReminderOpen: boolean;
  closeReminder: () => void;
}
const ListReminderView = ({ isReminderOpen, closeReminder }: IPropReminder) => {
  const listInnerRef = useRef<HTMLDivElement>(null);

  const [reminderList, setReminderList] = useState<IReminderList[]>([]);
  const [searchDate, setSearchDate] = useState<string>("");
  const [hasOneData, setHasOneData] = useState<number>();
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);

  const [labelDropdownOpen, setLabelDropdownOpen] = useState<any>(null);
  const [isReminderConfirmationStatus, setIsReminderConfirmationStatus] =
    useState(false);
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [isReminderConfirmation, setIsReminderConfirmation] = useState(false);
  const [isSetReminderConfirmation, setIsSetReminderConfirmation] =
    useState(false);
  const [reminderCheckFlag, setReminderCheckFlag] = useState<number>();

  const [reminderRescheduleData, setReminderRescheduleData] =
    useState<IReminderList>();
  const [
    isReminderConfirmationStatusData,
    setIsReminderConfirmationStatusData,
  ] = useState<IReminderList>();
  const { darkMode } = useTheme();
  const [noDataFound, setNoDataFound] = useState<boolean>(false);
  const dropdownContactRef = useRef<Record<number, HTMLUListElement | null>>(
    {}
  );
  const canView = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.VIEW
  );
  const canAdd = useCheckUserPermission(PAGE_ID.REMINDER, PERMISSION_TYPE.ADD);
  const canDelete = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.DELETE
  );
  const canEdit = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.EDIT
  );
  const canApprove = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.APPROVE
  );
  const itemsPerPage = 12;
  const handleDateChange = (event: TOnChangeInput) => {
    const search = event.target.value;
    setSearchDate(search);
    fetchReminderApi(setReminderList, search, setNoDataFound, setLoading, 0, 0);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (
        listInnerRef.current &&
        listInnerRef.current.scrollTop + listInnerRef.current.clientHeight ===
          listInnerRef.current.scrollHeight
      ) {
        if (reminderList.length < (currentPage + 1) * itemsPerPage + 1) {
          fetchReminderApi(
            setReminderList,
            searchDate,
            setNoDataFound,
            setLoading,
            0,
            currentPage + 1
          );
        }
        setCurrentPage((prevPage) => prevPage + 1);
      }
    };

    const listInnerElement = listInnerRef.current;

    if (listInnerElement) {
      listInnerElement.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (listInnerElement) {
        listInnerElement.removeEventListener("scroll", handleScroll);
      }
    };
  }, [currentPage, reminderList.length, searchDate]);
  useEffect(() => {
    if (canView) {
      fetchReminderApi(setReminderList, "", setNoDataFound, setLoading, 0, 0);
    }
  }, [isReminderConfirmationStatus, canView]);
  const handleDateClear = () => {
    setSearchDate("");
    fetchReminderApi(setReminderList, "", setNoDataFound, setLoading, 0, 0);
  };

  const handleGetAllRemainderData = () => {
    const newFlag = reminderCheckFlag === 1 ? 0 : 1;
    setReminderCheckFlag(newFlag); // Update the state
    fetchReminderApi(
      setReminderList,
      "",
      setNoDataFound,
      setLoading,
      0,
      newFlag
    );
  };

  const toggleDropdownLabel = (id: number) => {
    setHasOneData(id);
    setLabelDropdownOpen((prevId: any) => (prevId === id ? null : id));
  };
  const handleChangeReminderComplete = (messageData: IReminderList) => {
    // Get the current user's UUID
    const currentUserUUID = localStorage.getItem("UUID");

    // For debugging
    console.log("Current user:", currentUserUUID);
    console.log("Reminder data:", messageData);

    // Check if current user is the assigned user based on ID
    const isAssignedUser =
      messageData.assigned_to === parseInt(currentUserUUID || "0");

    if (canApprove || isAssignedUser) {
      setIsReminderConfirmationStatus(true);
      setIsReminderConfirmationStatusData(messageData);
    } else {
      setIsReminderConfirmationStatus(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handleChangeStatusOfReminder = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const date = new Date();
    console.log(
      "isReminderConfirmationStatusData?.reference_table",
      isReminderConfirmationStatusData?.reference_table
    );

    const formattedDateTime = `${date.getFullYear()}-${String(
      date.getMonth() + 1
    ).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(
      date.getHours()
    ).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(
      date.getSeconds()
    ).padStart(2, "0")}`;
    const requestData = {
      table: "reminder_messages",
      where: `{"id":"${isReminderConfirmationStatusData?.id}"}`,
      data: `{"status":"1" , "completed_date_time":"${formattedDateTime}" }`,
    };
    try {
      const { data } = await axiosInstance.post(
        "commonUpdate",
        requestData,

        {
          headers: {
            "x-tenant-id": getUUID,
          },
        }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          setIsReminderConfirmationStatus(false);
          switch (isReminderConfirmationStatusData?.reference_table) {
            case "contact_message_histories":
              await updateContactFormReminder(
                isReminderConfirmationStatusData.reference_id
              );
              break;
            case "cart_quotation":
            case "cart_order":
            case "cart_invoice":
            case "cart_purchase_order":
              await updateOrderFormReminder(
                isReminderConfirmationStatusData.reference_id
              );
              break;
            case "inquiries":
              await updateInquiryFormReminder(
                isReminderConfirmationStatusData.reference_id
              );
              break;
            default:
              return console.log("something want wrong");
          }
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };

  const handleClickOutside = (event: { target: any }) => {
    const clickedOutside = Object.values(dropdownContactRef.current).every(
      (ref) => ref && !ref.contains(event.target)
    );
    if (clickedOutside) {
      setLabelDropdownOpen(null);
    }
  };
  useEffect(() => {
    if (labelDropdownOpen !== null) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [labelDropdownOpen]);
  const handleReminder = async (data: {
    dateTime: string;
    remark: string;
    status: string;
  }) => {
    if (data.dateTime.trim() && data.remark.trim()) {
      createRescheduleReminder(
        reminderRescheduleData?.id,
        data,
        setIsReminderConfirmation,
        setLoading,
        setReminderList,
        setNoDataFound
      );
    } else {
      setIsReminderConfirmation(true);
    }
  };

  const handleSetReminder = async (data: {
    dateTime: string;
    remark: string;
    status: string;
    selectedCategory: any;
  }) => {
    console.log("selectedCategory", data.selectedCategory);

    if (
      data.dateTime.trim() &&
      data.remark.trim() &&
      data.selectedCategory !== null &&
      data.selectedCategory !== false
    ) {
      createReminderForMy(
        data,
        setIsSetReminderConfirmation,
        setLoading,
        setReminderList,
        setNoDataFound
      );
    } else {
      toast.error(
        "Please enter Select Team Member , Date and Time and Remark "
      );
      setIsSetReminderConfirmation(true);
    }
  };
  const handleChangeReminderReschedule = (messageData: IReminderList) => {
    if (canEdit) {
      setIsReminderConfirmation(true);
      setReminderRescheduleData(messageData);
    } else {
      setIsReminderConfirmation(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handelRefreshReminder = () => {
    if (canView) {
      fetchReminderApi(
        setReminderList,
        searchDate,
        setNoDataFound,
        setLoading,
        0,
        0
      );
    }
  };
  const handelChangeDelete = (messageData: IReminderList) => {
    if (canDelete) {
      setIsDeleteConfirmation(true);
      setIsReminderConfirmationStatusData(messageData);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  function addReminder() {
    if (canAdd) {
      setIsSetReminderConfirmation(true);
    } else {
      setIsSetReminderConfirmation(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }
  return (
    <>
      {isReminderOpen ? (
        <>
          <div
            className="leftSide  animate__animated animate__fadeInLeft"
            id="group"
          >
            {/* <!-- Header --> */}
            <div className="header-Chat">
              {/* <!-- Icons --> */}
              <div className="ICON">
                <button className="icons" onClick={closeReminder}>
                  <span className="text-white" title="Back">
                    <svg
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path
                        fill="currentColor"
                        d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                      ></path>
                    </svg>
                  </span>
                </button>
              </div>

              <div className="newText">
                <h2>Reminder & To Do List</h2>
              </div>
              <div
                className="text-end"
                style={{ marginBottom: "50px", marginLeft: "auto" }}
              >
                <button className="icons pP text-end" onClick={addReminder}>
                  <span className="text-white" title="Create Reminder">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="26px"
                      viewBox="0 -960 960 960"
                      width="26px"
                      fill="currentColor"
                      className="ml-2"
                    >
                      <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                    </svg>
                  </span>
                </button>
                <button
                  className="icons pP text-end"
                  onClick={handelRefreshReminder}
                >
                  <span className="text-white" title="Refresh">
                    <svg width="30" height="30" viewBox="0 0 50 50">
                      <path
                        fill="currentColor"
                        d="M25 38c-7.2 0-13-5.8-13-13 0-3.2 1.2-6.2 3.3-8.6l1.5 1.3C15 19.7 14 22.3 14 25c0 6.1 4.9 11 11 11 1.6 0 3.1-.3 4.6-1l.8 1.8c-1.7.8-3.5 1.2-5.4 1.2z"
                      />
                      <path
                        fill="currentColor"
                        d="M34.7 33.7l-1.5-1.3c1.8-2 2.8-4.6 2.8-7.3 0-6.1-4.9-11-11-11-1.6 0-3.1.3-4.6 1l-.8-1.8c1.7-.8 3.5-1.2 5.4-1.2 7.2 0 13 5.8 13 13 0 3.1-1.2 6.2-3.3 8.6z"
                      />
                      <path fill="currentColor" d="M18 24h-2v-6h-6v-2h8z" />
                      <path fill="currentColor" d="M40 34h-8v-8h2v6h6z" />
                    </svg>
                  </span>
                </button>
              </div>
            </div>
            {canView ? (
              <div className="col-12 d-flex">
                <div className="col-9  px-3">
                  <label className="">Filter Date :</label>
                  <input
                    type="date"
                    value={searchDate}
                    onChange={handleDateChange}
                    className="form-control font-size-15 rounded-1"
                  />
                </div>

                <div className="col-3">
                  <label className="w-100">All Status:</label>
                  <div className=" p-3">
                    <input
                      className="custom-checkbox "
                      type="checkbox"
                      onClick={handleGetAllRemainderData}
                      checked={reminderCheckFlag === 1}
                    />
                  </div>
                </div>
                <div className="col-2 d-flex align-items-center">
                  {searchDate ? (
                    <button
                      className="p-1 m-1 mt-2 d-flex "
                      onClick={handleDateClear}
                      title="Clear Filter"
                    >
                      <span role="button" className="p-1">
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="#5f6368"
                        >
                          <path d="M280-80q-83 0-141.5-58.5T80-280q0-83 58.5-141.5T280-480q83 0 141.5 58.5T480-280q0 83-58.5 141.5T280-80Zm544-40L568-376q-12-13-25.5-26.5T516-428q38-24 61-64t23-88q0-75-52.5-127.5T420-760q-75 0-127.5 52.5T240-580q0 6 .5 11.5T242-557q-18 2-39.5 8T164-535q-2-11-3-22t-1-23q0-109 75.5-184.5T420-840q109 0 184.5 75.5T680-580q0 43-13.5 81.5T629-428l251 252-56 56Zm-615-61 71-71 70 71 29-28-71-71 71-71-28-28-71 71-71-71-28 28 71 71-71 71 28 28Z" />
                        </svg>
                      </span>
                    </button>
                  ) : (
                    <span></span>
                  )}
                </div>
              </div>
            ) : (
              <span></span>
            )}
            {searchDate && noDataFound && (
              <p className="no_found">No data found</p>
            )}
            <div
              className="chats"
              style={{ height: "calc(90% - 112px)" }}
              ref={listInnerRef}
            >
              {canView ? (
                <>
                  {loading ? (
                    Array.from({ length: 12 }).map((_, index) => (
                      <div className="block chat-list" key={index}>
                        <div className="h-text">
                          <div className="col-12 d-flex">
                            <div className="col-10 text-start">
                              <span className="reminder_list_text">
                                <Skeleton
                                  width="50%"
                                  duration={5}
                                  style={{ opacity: darkMode ? "" : 0.5 }}
                                />
                                <span
                                  className="badge rounded-pill text-end"
                                  style={{
                                    float: "right",
                                  }}
                                ></span>
                              </span>

                              <span className="reminder_list_text">
                                <Skeleton
                                  width="50%"
                                  duration={5}
                                  style={{ opacity: darkMode ? "" : 0.5 }}
                                />
                              </span>

                              <span className="reminder_list_text">
                                <Skeleton
                                  width="50%"
                                  duration={5}
                                  style={{
                                    opacity: darkMode ? "" : 0.5,
                                  }}
                                />
                              </span>

                              <p className="time">
                                <Skeleton
                                  width="50%"
                                  duration={5}
                                  style={{
                                    marginLeft: "70%",
                                    opacity: darkMode ? "" : 0.5,
                                  }}
                                />
                              </p>
                            </div>
                            <div className="">
                              <button className="icon-more">
                                <Skeleton
                                  width={30}
                                  height={20}
                                  duration={5}
                                  circle={true}
                                  style={{ opacity: darkMode ? "" : 0.5 }}
                                />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <>
                      {reminderList &&
                        reminderList.map((item, index) => {
                          const isEven = index % 2 === 0;
                          let referenceText: string;

                          // Switch case logic to handle different reference_table values
                          switch (item.reference_table) {
                            case "cart_quotation":
                              referenceText = "For Quotation";
                              break;
                            case "cart_order":
                              referenceText = "For Order";
                              break;
                            case "cart_invoice":
                              referenceText = "For Invoice";
                              break;
                            case "inquiries":
                              referenceText = "For Inquiry";
                              break;
                            case "contact_message_histories":
                              referenceText = "For Message";
                              break;
                            case "cart_purchase_order":
                              referenceText = "For Purchase Invoice";
                              break;
                            default:
                              referenceText = "For General"; // Default if no match
                              break;
                          }
                          return (
                            <div key={index} className="">
                              <div>
                                <ul
                                  className={`labelDropLeft ${
                                    hasOneData === item.id && labelDropdownOpen
                                      ? "isVisible"
                                      : "isHidden"
                                  }`}
                                  ref={(el) =>
                                    (dropdownContactRef.current[item.id] = el)
                                  }
                                  style={{ marginTop: "8%" }}
                                >
                                  <li
                                    className="listItem"
                                    role="button"
                                    onClick={() => handelChangeDelete(item)}
                                  >
                                    Delete
                                  </li>
                                  <li
                                    className="listItem"
                                    role="button"
                                    onClick={() =>
                                      handleChangeReminderReschedule(item)
                                    }
                                  >
                                    Reschedule
                                  </li>
                                </ul>
                              </div>
                              <button
                                className={`${
                                  isEven ? "" : ""
                                } block chat-list`}
                              >
                                <div className="h-text">
                                  <div className="col-12 d-flex ">
                                    <div className="col-10 text-start">
                                      <span className="reminder_list_text">
                                        <div className="head">
                                          <div className=" d-flex align-items-center">
                                            <input
                                              className="custom-checkbox "
                                              type="checkbox"
                                              onClick={() =>
                                                handleChangeReminderComplete(
                                                  item
                                                )
                                              }
                                              checked={item.status === 1}
                                              disabled={item.status === 1}
                                            />
                                            <h4
                                              className="text-start"
                                              style={{
                                                fontSize: "16px",
                                                paddingRight: "10px",
                                              }}
                                            >
                                              <b className="ps-2">#{item.id}</b>
                                            </h4>
                                          </div>
                                        </div>
                                        <b>Remark : </b>
                                        {item.remark}
                                      </span>
                                      <br />
                                      {item.reference_table ===
                                      "contact_message_histories" ? (
                                        <>
                                          <span className="reminder_list_text">
                                            <b>Contact Name :</b>{" "}
                                            {item.person_name}
                                          </span>
                                          <br />
                                          <span className="">
                                            <span className="reminder_list_text">
                                              <b>Messages :</b>
                                            </span>
                                            <span className="reminder_list_text">
                                              <SafeHtml
                                                htmlContent={
                                                  item.contact_message
                                                }
                                              />
                                            </span>
                                          </span>
                                        </>
                                      ) : (
                                        <span></span>
                                      )}
                                    </div>

                                    <div className="col-2 text-end">
                                      <div>
                                        <button
                                          className="icon-more"
                                          onClick={() =>
                                            toggleDropdownLabel(item.id)
                                          }
                                        >
                                          <svg
                                            xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 19 20"
                                            width="19"
                                            height="20"
                                            className="hide animate__animated animate__fadeInUp"
                                          >
                                            <path
                                              fill="currentColor"
                                              d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                            ></path>
                                          </svg>
                                        </button>
                                      </div>
                                      <div className="text-end py-1">
                                        <span
                                          style={{
                                            backgroundColor:
                                              item.isDue === 1 ? "red" : " ", // Red for "Due", Green for "Completed"
                                            float: "right",
                                          }}
                                          className="badge rounded-pill text-end"
                                        >
                                          {item.isDue === 1 ? "Due" : " "}
                                        </span>
                                      </div>
                                    </div>
                                  </div>

                                  <div className="head">
                                    <h4 className=" time text-start">
                                      <span
                                        style={{
                                          backgroundColor: "#eeeeee ",
                                          border:
                                            "2px solid rgb(207, 207, 207)",
                                          color: "black",
                                        }}
                                        className="badge rounded-pill p-2"
                                      >
                                        {referenceText}
                                      </span>
                                    </h4>
                                    <p className="time text-end ">
                                      <b>Reminder Date :</b>
                                      <br />
                                      {item.reminder_data_time
                                        ? formatDateAndTime(
                                            item.reminder_data_time
                                          )
                                        : ""}
                                      <br />
                                      <i
                                        style={{
                                          wordWrap: "break-word",
                                          width: "50%",
                                        }}
                                      >
                                        {item.assigned_to_name}
                                      </i>
                                    </p>
                                  </div>
                                </div>
                              </button>
                            </div>
                          );
                        })}
                    </>
                  )}
                </>
              ) : (
                <p className="text-danger p-1">
                  {DEFAULT_MESSAGE_ERROR_PERMISSION}
                </p>
              )}
            </div>

            {/* <!-- Search Bar --> */}

            {/* <!-- Chats --> */}
          </div>
          {isReminderConfirmationStatus && (
            <ConfirmationModal
              show={isReminderConfirmationStatus}
              onHide={() => setIsReminderConfirmationStatus(false)}
              handleSubmit={handleChangeStatusOfReminder}
              title={"Are you sure you want to complete this Reminder?"}
              message={`Remark : ${
                isReminderConfirmationStatusData &&
                isReminderConfirmationStatusData.remark
              }`}
              btn1="CANCEL"
              btn2="Complete Reminder Now"
              message1={`Reminder Date : ${
                isReminderConfirmationStatusData &&
                formatDateAndTime(
                  isReminderConfirmationStatusData.reminder_data_time
                )
              }`}
            />
          )}
          {isDeleteConfirmation && (
            <ConfirmationModal
              show={isDeleteConfirmation}
              onHide={() => setIsDeleteConfirmation(false)}
              handleSubmit={() =>
                handleDeleteReminder(
                  isReminderConfirmationStatusData?.id,
                  setIsDeleteConfirmation,
                  setReminderList,
                  setNoDataFound,
                  setLoading,
                  isReminderConfirmationStatusData
                )
              }
              title={"Delete this Reminder"}
              message={"Are You Sure You Want To Delete This Reminder?"}
              btn1="CANCEL"
              btn2="DELETE"
            />
          )}
          {isReminderConfirmation && (
            <ReminderModal
              show={isReminderConfirmation}
              onHide={() => setIsReminderConfirmation(false)}
              handleSubmit={handleReminder}
              title={" Reminder Reschedule  "}
              message={"Are you sure you want delete is message? "}
              btn1="CANCEL"
              btn2="set Reminder"
              remarkMsg={reminderRescheduleData?.remark}
              request_flag="1"
            />
          )}
          {isSetReminderConfirmation && (
            <ReminderModal
              show={isSetReminderConfirmation}
              onHide={() => setIsSetReminderConfirmation(false)}
              handleSubmit={handleSetReminder}
              title={" Set Reminder of your"}
              message={"Are you sure you want delete is message? "}
              btn1="CANCEL"
              btn2="set Reminder"
              request_flag=""
            />
          )}
        </>
      ) : null}
    </>
  );
};

export default ListReminderView;
