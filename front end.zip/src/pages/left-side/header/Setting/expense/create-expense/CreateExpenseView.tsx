import React, { useEffect, useState } from "react";
import { Formik, Field, Form, ErrorMessage, useFormikContext } from "formik";
import {
  TOnChangeInput,
  TReactSetState,
} from "../../../../../../helpers/AppType";
import {
  createExpense,
  createProductInitialValues,
  createProductValidationSchema,
  fetchExpenseTypeApiForExpense,
  IExpenseCreate,
  IExpenseCreateStatus,
  IExpenseType,
  updateExpense,
  updateExpenseStatus,
} from "./CreateExpenseController";
import FormikCustomSearchDropdown from "../../../../../../components/FormikCustomSearchDropdown";
import { IExpenseView } from "../ExpenseController";
import { MINI_TEXT_LENGTH, TEXTAREA_TEXT_LENGTH } from "../../../../../../helpers/AppConstants";

interface IPropsCreateExpense {
  show: boolean;
  onHide: () => void;
  expenseToEdit: IExpenseView | undefined;
  headerName: string;
  setRefreshExpense: TReactSetState<boolean>;
  status?: string;
  createEditFlag?: string;
}
const CreateExpenseView = ({
  show,
  onHide,
  expenseToEdit,
  headerName,
  setRefreshExpense,
  status,
  createEditFlag,
}: IPropsCreateExpense) => {
  const [expenseTypesList, setExpenseTypeList] = useState<IExpenseType[]>([]);

  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);

  const handleSubmit = async (values: IExpenseCreate) => {
    if (expenseToEdit?.id) {
      values.expenseId = expenseToEdit.id;
      updateExpense(values, setRefreshExpense, expenseToEdit?.id, onHide);
    } else {
      createExpense(values, setRefreshExpense, onHide);
    }
    switch (status) {
      case "pass":
        updateExpenseStatus(values, setRefreshExpense, expenseToEdit?.id, onHide ,2);
        break;
       case "reject":
       updateExpenseStatus(values, setRefreshExpense, expenseToEdit?.id, onHide, 3);
       break;
      default:
        break;
    }
  };

  const handelClose = () => {
    onHide();
  };

  useEffect(() => {
    fetchExpenseTypeApiForExpense(setExpenseTypeList);
  }, [show]);

  const productTypesOptions = expenseTypesList.map((item) => ({
    value: item.id,
    label: item.expense_name,
  }));
  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1">
            <span className="close" onClick={handelClose}>
              &times;
            </span>
            <h2 className="modal-title1 form_header_text">{headerName}</h2>
            <p className="text-center " style={{ color: "#999" }}>
              Please Enter your Expense Detail.
            </p>
            <Formik
              enableReinitialize
              initialValues={createProductInitialValues(expenseToEdit)}
              validationSchema={createProductValidationSchema()}
              onSubmit={handleSubmit}
            >
              {({ errors, touched, setFieldValue, values }) => {
                return (
                  <Form>
                    <div className="mt-3 justify-content-center">
                      <div className="mb-3 py-4">
                        <div className="row  mx-0 px-2 gy-3  d-flex">
                          {createEditFlag === "createEdit" && (
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="expense_type_id"
                                  className="mb-1 form_label"
                                >
                                  Expense Types
                                  <span className="text-danger">*</span>
                                </label>
                                <FormikCustomSearchDropdown
                                  name="expense_type_id"
                                  options={productTypesOptions}
                                  className={`  ${
                                    errors.expense_type_id &&
                                    touched.expense_type_id &&
                                    "is-invalid input-box-error"
                                  }`}
                                />
                                <ErrorMessage
                                  name="expense_type_id"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                          )}
                          {createEditFlag === "createEdit" && (
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="amount"
                                  className="pb-2 form_label"
                                >
                                  Amount
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  type="text"
                                  name="amount"
                                  maxLength={MINI_TEXT_LENGTH}
                                  className={`form-control font-size-15 rounded-1   ${
                                    errors.amount &&
                                    touched.amount &&
                                    "is-invalid input-box-error"
                                  }`}
                                  onInput={(e: {
                                    target: { value: string };
                                  }) => {
                                    e.target.value = e.target.value.replace(
                                      /[^0-9.]/g,
                                      ""
                                    ); // Allow only numbers and dots
                                    if (
                                      (e.target.value.match(/\./g) || [])
                                        .length > 1
                                    ) {
                                      e.target.value = e.target.value.slice(
                                        0,
                                        -1
                                      ); // Remove extra dots
                                    }
                                  }}
                                />
                                <ErrorMessage
                                  name="amount"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                          )}
                          {createEditFlag === "createEdit" && (
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="remark"
                                className="pb-2 form_label"
                              >
                                Remark
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                as="textarea"
                                name="remark"
                                maxLength={TEXTAREA_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.remark &&
                                  touched.remark &&
                                  "is-invalid input-box-error"
                                }`}
                              />
                              <ErrorMessage
                                name="remark"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          )}
                          {status === "pass" && (
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="pass_amount"
                                  className="pb-2 form_label"
                                >
                                  Pass Amount
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  text="text"
                                  name="pass_amount"
                                  className={`form-control font-size-15 rounded-1   ${
                                    errors.pass_amount &&
                                    touched.pass_amount &&
                                    "is-invalid input-box-error"
                                  }`}
                                  onInput={(e: {
                                    target: { value: string };
                                  }) => {
                                    e.target.value = e.target.value.replace(
                                      /[^0-9.]/g,
                                      ""
                                    ); // Allow only numbers and dots
                                    if (
                                      (e.target.value.match(/\./g) || [])
                                        .length > 1
                                    ) {
                                      e.target.value = e.target.value.slice(
                                        0,
                                        -1
                                      ); // Remove extra dots
                                    }
                                  }}
                                />
                                <ErrorMessage
                                  name="pass_amount"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                          )}
                          {(status === "pass" || status === "reject") && (
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="status_remark"
                                className="pb-2 form_label"
                              >
                                Status Remark
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                as="textarea"
                                name="status_remark"
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.status_remark &&
                                  touched.status_remark &&
                                  "is-invalid input-box-error"
                                }`}
                              />
                              <ErrorMessage
                                name="status_remark"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                         )}      
                        </div>

                        <div className="col-12 col-12 pt-4 d-flex justify-content-center">
                          <button
                            className="border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label"
                            onClick={handelClose}
                          >
                            Close
                          </button>
                          <button
                            type="submit"
                            className="btn btn-primary px-4 py-2 ms-2  text-light form_label rounded-1"
                            style={{
                              backgroundColor: "#f58634",
                            }}
                          >
                            Save Expense
                          </button>
                        </div>
                      </div>
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default CreateExpenseView;
