import * as Yup from "yup";

import { toast } from "react-toastify";
import {
  axiosInstance,
  axiosInstanceFormData,
} from "../../../../../../services/axiosInstance";
import { TReactSetState } from "../../../../../../helpers/AppType";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../../helpers/AppConstants";

export interface IExpenseCreate {
  created_date_time?: string;
  amount: string;
  expense_type_id: string;
  remark : string;
  expenseId:number | string;  
  expense_status:number;
  status_remark: string;
  pass_amount:number
}

export interface IExpenseCreateStatus {
  expenseId:number | string;  
  expense_status:number;
  status_remark: string;
  pass_amount:number
}
export interface IExpenseType {
    id: string;
    expense_name: string;
}
export const createProductInitialValues = (
  ExpenseToEdit: IExpenseCreate | undefined
): IExpenseCreate => ({
  amount: ExpenseToEdit?.amount || "",
  expense_type_id: ExpenseToEdit?.expense_type_id || "",
  remark: ExpenseToEdit?.remark || "",
  expenseId: ExpenseToEdit?.expenseId || "",
  expense_status: ExpenseToEdit?.expense_status || 1,
  status_remark: ExpenseToEdit?.status_remark || "",
  pass_amount: ExpenseToEdit?.pass_amount || 0,
});

export const createProductValidationSchema = () =>
  Yup.object().shape({
    amount: Yup.string().required("Amount is Required"),
    expense_type_id: Yup.string().required("Expense Type is Required"),
  });

export const createExpense = async (
  values: IExpenseCreate,
  setRefreshExpense: TReactSetState<boolean>,
  onHide: () => void
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  if (!getUUID) {
    return;
  }
 
  const requestDataCreateExpense = {
    expense_type_id: values.expense_type_id,
    amount: values.amount,
    remark: values.remark,
    a_application_login_id:getUUID
  };
  try {
    const { data } = await axiosInstance.post(
      "create-expense",
      requestDataCreateExpense,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
          
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        toast.success(data.ack_msg);
        setRefreshExpense(true);

        onHide();
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateExpense = async (
  values: IExpenseCreate,
  setRefreshExpense: TReactSetState<boolean>,
  expenseId: number,
  onHide: () => void
) => {


  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");


  if (!getUUID) {
    return;
  }
  const requestDataUpdateExpense = {
    expense_id: expenseId,
    expense_type_id: values.expense_type_id,
    amount: values.amount,
    remark: values.remark,
    a_application_login_id:getUUID
  };
  console.log("requestDataUpdateExpense", requestDataUpdateExpense);

  try {
    const { data } = await axiosInstance.post(
      "update-expense",
      requestDataUpdateExpense,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        onHide();
        setRefreshExpense(true);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};



export const updateExpenseStatus = async (
  values: IExpenseCreateStatus,
  setRefreshExpense: TReactSetState<boolean>,
  expenseId: number | undefined,
  onHide: () => void,
  expenseStatus : number

) => {

  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");


  if (!getUUID) {
    return;
  }
  const requestDataUpdateExpense = {
    expense_id: expenseId,
    expense_status: expenseStatus,
    status_remark:values.status_remark,
    pass_amount:values.pass_amount,
  };
  console.log("requestDataUpdateExpense", requestDataUpdateExpense);

  try {
    const { data } = await axiosInstance.post(
      "update-expense",
      requestDataUpdateExpense,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        onHide();
        setRefreshExpense(true);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchExpenseTypeApiForExpense = async (
    setExpenseTypeList: TReactSetState<IExpenseType[]>
) => {
  const getUUID = localStorage.getItem("UUID")
  const requestData = {
    table: "expense_type_masters",
    columns: "id,expense_name",
    where: ["isDelete=0"],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const response = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
  );
    if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setExpenseTypeList(response.data.data); // Assuming API response is an array of countries
    } else {
        setExpenseTypeList([]); // Assuming API response is an array of countries
      toast.error(response.data.ack_msg);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);

    // Handle error (e.g., show error message, clear filtered list)
    setExpenseTypeList([]);
  }
};
