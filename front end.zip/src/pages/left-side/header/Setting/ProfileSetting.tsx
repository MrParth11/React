import React, { ChangeEvent, useEffect, useState } from "react";
import {
  axiosInstance,
  axiosInstanceFormData,
  axiosInstanceForWpWeb,
} from "../../../../services/axiosInstance";
import axios from "axios";
import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../helpers/AppConstants";
import OtpConfirmationModal from "../../../../components/model/OtpConfirmationModal";
import PersonalSettingView from "./personal-setting/PersonalSettingView";
interface IPropsProfileSetting {
  isProfileOpen: boolean;
  closeProfile: () => void;
  profileDetail: any;
}
const ProfileSetting = ({
  isProfileOpen,
  closeProfile,
  profileDetail,
}: IPropsProfileSetting) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [loginById, setLoginById] = useState<any>();
  const token = localStorage.getItem("token");
  const getUUID = localStorage.getItem("UUID");
  const [isUsernameEditMode, setIsUsernameEditMode] = useState(false);
  const [isWhatsappApiAppKeyEditMode, setIsWhatsappApiAppKeyEditMode] =
    useState(false);
  const [isWhatsappApiAuthEditMode, setIsWhatsappApiAuthEditMode] =
    useState(false);
  const [isEmailEditMode, setIsEmailEditMode] = useState(false);
  const [isLoginPinEditMode, setIsLoginPinEditMode] = useState(false);

  const [editedUsername, setEditedUsername] = useState(profileDetail.username);

  const [isPersonalSettingOpen, setIsPersonalSettingOpen] = useState(false);

  const [editedEmail, setEditedEmail] = useState(profileDetail.recovery_email);
  const [editedLoginPin, setEditedLoginPin] = useState(profileDetail.login_pin);
  const [emailError, setEmailError] = useState("");
  const [loginPinError, setLoginPinError] = useState("");

  const [isEmailValid, setIsEmailValid] = useState(false);
  const [isLoginPinValid, setIsLoginPinValid] = useState(false);

  const [isLoadApi, setIsLoadApi] = useState(false);
  const [selectedGender, setSelectedGender] = useState(profileDetail.gender);
  const [tempGender, setTempGender] = useState(profileDetail.gender);
  const [isGenderEditMode, setIsGenderEditMode] = useState(false);
  const [isCloseConfirmation, setIsCloseConfirmation] = useState(false);
  const [isMobileNumberConfirmation, setIsMobileNumberCloseConfirmation] =
    useState(false);
  const [isEmailVerifyConfirmation, setIsEmailVerifyCloseConfirmation] =
    useState(false);

  const handleGenderChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setTempGender(Number(event.target.value));
  };

  const handleConfirmClickGender = async () => {
    const newGender = tempGender;
    setSelectedGender(newGender);
    const requestData = {
      table: "a_application_logins",
      where: `{"id":"${profileDetail.id}"}`,
      data: `{"gender":"${newGender}"}`,
    };
    try {
      const { data } = await axiosInstance.post(
        "mainCommonUpdate",
        requestData
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          window.location.reload();
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
    setIsGenderEditMode(false);
  };

  const handleCancelClickGender = () => {
    setTempGender(selectedGender);
    setIsGenderEditMode(false);
  };

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files && event.target.files[0];
    if (file) {
      setSelectedFile(file);
      const validTypes = ["image/jpeg", "image/png", "image/jpg"];
      const maxSize = 1 * 1024 * 1024; // 1 MB in bytes
      if (!getUUID || !file) {
        return;
      }
      if (validTypes.includes(file.type)) {
        if (file.size <= maxSize) {
          const formData = new FormData();
          formData.append("image", file);
          formData.append("id", getUUID);

          try {
            const response = await axiosInstanceFormData.post(
              "changeProfile",
              formData,
              {
                headers: {
                  "Content-Type": "multipart/form-data", // Set content type for FormData
                  Authorization: token,
                },
              }
            );
            window.location.reload();

            if (response.data.code === 200) {
              // Handle success

              console.log("Profile image changed successfully", response.data);
              toast.success("Profile image changed successfully");
            } else {
              // Handle other status codes or errors
              console.error("Failed to change profile image");
              // toast.error("Failed to change profile image")
            }
          } catch (error: any) {
            // Handle network errors or other exceptions
            console.error("Error changing profile image:", error);
            toast.error(error || "Error changing profile image");
          }
        } else {
          toast.error(
            `File is too large. Please upload a file smaller than 1 MB.`
          );

          // Optionally, you can clear the input value to allow re-selection
          event.target.value = "";
        }
      } else {
        toast.error(`Invalid file format. Please upload a jpeg, jpg, png.`);
        event.target.value = "";
      }
    }
  };

  const handleUsernameEditClick = () => {
    setIsUsernameEditMode(true);
  };

  const handleEmailEditClick = () => {
    setIsEmailEditMode(true);
  };

  const handleLoginPinEditClick = () => {
    setIsLoginPinEditMode(true);
  };
  const handleUsernameSaveClick = async () => {
    // Perform save operation for username (e.g., API call)
    const requestData = {
      table: "a_application_logins",
      where: `{"id":"${profileDetail.id}"}`,
      data: `{"username":"${editedUsername}"}`,
    };

    try {
      const { data } = await axiosInstance.post(
        "mainCommonUpdate",
        requestData
      );

      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          // Reload the window to reflect changes
          window.location.reload();
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(
        error.response?.data?.message || MESSAGE_UNKNOWN_ERROR_OCCURRED
      );
    } finally {
      setIsUsernameEditMode(false);
    }
  };

  const handleEmailSaveClick = async () => {
    // Perform save operation for email (e.g., API call)
    const requestData = {
      table: "a_application_logins",
      where: `{"id":"${profileDetail.id}"}`,
      data: `{"recovery_email":"${editedEmail}", "is_email_verified":"0"}`,
    };
    try {
      const { data } = await axiosInstance.post(
        "mainCommonUpdate",
        requestData
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          window.location.reload();
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
    setIsEmailEditMode(false);
    // Update profile detail or perform necessary actions
  };

  const handleLoginPinSaveClick = async () => {
    // Perform save operation for email (e.g., API call)
    const requestData = {
      table: "a_application_logins",
      where: `{"id":"${profileDetail.id}"}`,
      data: `{"login_pin":"${editedLoginPin}"}`,
    };
    try {
      const { data } = await axiosInstance.post(
        "mainCommonUpdate",
        requestData
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          window.location.reload();
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
    setIsLoginPinEditMode(false);
    // Update profile detail or perform necessary actions
  };
  const handleCancelClick = () => {
    // Reset edited values and toggle off edit mode
    setEditedUsername(profileDetail.username);
    setIsUsernameEditMode(false);
  };

  const handleCancelWhatsappApiAuthKeyClick = () => {
    // Reset edited values and toggle off edit mode
    setEditedUsername(profileDetail.whatsapp_authkey);
    setIsWhatsappApiAuthEditMode(false);
  };

  const handleUsernameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEditedUsername(event.target.value);
  };

  const handleEmailChange = (e: any) => {
    const email = e.target.value;
    setEditedEmail(email);

    if (validateEmail(email)) {
      setEmailError("");
      setIsEmailValid(true);
    } else {
      setEmailError("Please enter a valid email address.");
      setIsEmailValid(false);
    }
  };
  const handleLoginPinChange = (e: any) => {
    const loginPin = e.target.value;
    setEditedLoginPin(loginPin);

    if (validateLoginPin(loginPin)) {
      setLoginPinError("");
      setIsLoginPinValid(true);
    } else {
      setLoginPinError("Please enter a 4 digit numeric only");
      setIsLoginPinValid(false);
    }
  };
  const validateLoginPin = (pin: any) => {
    // PIN validation regex for exactly 4 numeric digits only
    const pinRegex = /^\d{4}$/;
    return pinRegex.test(pin);
  };
  const validateEmail = (email: any) => {
    // Basic email validation regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const fetchGetByIdUser = async () => {
    const token = await localStorage.getItem("token");
    const localId = await localStorage.getItem("UUID");
    try {
      const { data } = await axiosInstance.post(
        "loginId",
        {
          loginId: localId,
        },
        {
          headers: {
            Authorization: `${token}`,
          },
        }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          setLoginById(data.data);
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };
  useEffect(() => {
    if (isLoadApi || isProfileOpen) {
      fetchGetByIdUser();
    }
  }, [isLoadApi, isProfileOpen]);
  const handleLogout = () => {
    console.log("handleLogout");

    window.location.reload();
    localStorage.clear();
    setIsCloseConfirmation(false);
  };

  const handelCloseChangeNumberOtp = () => {
    window.location.reload();
    setIsMobileNumberCloseConfirmation(false);
  };
  const handelSendOtpForEmailVerify = async () => {
    const token = await localStorage.getItem("token");

    try {
      const response = await axiosInstance.post(
        "otpSendEmailVerifyLogin",
        {
          loginId: profileDetail.id,
        },
        {
          headers: {
            Authorization: `${token}`,
          },
        }
      );
      if (response.data.code === 200) {
        if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          setIsEmailVerifyCloseConfirmation(true);
        } else {
          toast.error(response.data.ack_msg);
        }
      } else {
        toast.error(response.data.ack_msg);
      }
    } catch (error) {
      setIsEmailVerifyCloseConfirmation(false);

      toast.error("Failed to send OTP. Please try again.");
    }
  };

  const handleOpenPersonalSetting = async () => {
    setIsPersonalSettingOpen(true);
    const mobileNo = profileDetail?.recovery_mobile || 0;
    const response = await axiosInstanceForWpWeb.post("/show-qr", { mobileNo });
    console.log("Qr", response.data.data);
  };
  return (
    <>
      {isProfileOpen ? (
        <div
          className="profile animate__animated animate__fadeInLeft"
          id="profile"
        >
          {/* <!-- Header --> */}
          <div className="header-Chat">
            {/* <!-- Icons --> */}
            <div className="ICON">
              <div
                aria-disabled="false"
                role="button"
                className="icons"
                data-tab="2"
                title="New chat"
                aria-label="New chat"
                onClick={closeProfile}
              >
                <span data-testid="chat" data-icon="chat" className="">
                  <svg viewBox="0 0 24 24" width="24" height="24" className="">
                    <path
                      fill="currentColor"
                      d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                    ></path>
                  </svg>
                </span>
              </div>
            </div>

            <div className="newText">
              <h2>Profile</h2>
            </div>
          </div>
          {/* <!-- Chats --> */}
          <div className="chats-profile">
            {/* <!-- Profile --> */}
            <div className="top">
              <div className="imgBox">
                {profileDetail?.profile_pic || loginById?.profile_pic ? (
                  <img
                    src={
                      selectedFile
                        ? URL.createObjectURL(selectedFile)
                        : `${loginById?.profile_pic}`
                    }
                    alt=""
                    className="cover animate__animated animate__fadeIn"
                  />
                ) : (
                  <img
                    src={require("../../../../assets/images/no_image.jpeg")}
                    alt=""
                    className="cover animate__animated animate__fadeIn"
                  />
                )}
                <div className="middle">
                  <div
                    aria-disabled="false"
                    role="button"
                    className="icons-profile"
                    data-tab="2"
                    title="Camera"
                    aria-label="Camera"
                  >
                    <div className="form-group1">
                      <label htmlFor="input-files">
                        <span
                          data-testid="camera"
                          data-icon="camera"
                          className=""
                        >
                          <svg
                            viewBox="0 0 24 24"
                            width="24"
                            height="24"
                            className=""
                          >
                            <path
                              fill="currentColor"
                              d="M21.317 4.381H10.971L9.078 2.45c-.246-.251-.736-.457-1.089-.457H4.905c-.352 0-.837.211-1.078.468L1.201 5.272C.96 5.529.763 6.028.763 6.38v1.878l-.002.01v11.189a1.92 1.92 0 0 0 1.921 1.921h18.634a1.92 1.92 0 0 0 1.921-1.921V6.302a1.92 1.92 0 0 0-1.92-1.921zM12.076 18.51a5.577 5.577 0 1 1 0-11.154 5.577 5.577 0 0 1 0 11.154zm0-9.506a3.929 3.929 0 1 0 0 7.858 3.929 3.929 0 0 0 0-7.858z"
                            ></path>
                          </svg>
                        </span>
                      </label>
                      <input
                        type="file"
                        name="image"
                        id="input-files"
                        className="form-control-file border"
                        onChange={(e) => handleFileChange(e)}
                        style={{ display: "none" }}
                        accept=".png,.jpg,.jpeg,"
                      />
                    </div>
                  </div>
                  <div className="text">CHANGE PROFILE PHOTO</div>
                </div>
              </div>
            </div>

            {/* <!-- Chats 1 --> */}
            <div className="block">
              {/* <!-- Text --> */}
              <div className="h-text">
                <div className="titlePro">
                  <p>Your Name</p>
                </div>

                <div className="head">
                  {isUsernameEditMode ? (
                    <>
                      <div className="search-bar">
                        <div className="add-source-of-type-section">
                          <input
                            type="text"
                            value={editedUsername}
                            onChange={handleUsernameChange}
                          />
                        </div>
                      </div>
                      <div className="d-flex">
                        <button onClick={handleUsernameSaveClick}>
                          <span>
                            <svg
                              data-name="Layer 1"
                              height={24}
                              id="Layer_1"
                              viewBox="0 0 200 200"
                            >
                              <title />
                              <path
                                fill="currentColor"
                                d="M177.68,43.9c-4.5-3.5-10.5-3-14,1.5l-74,89.5-55-40c-4.5-3-10.5-2.5-14,2-3,4.5-2.5,10.5,2,14l62.5,45.5a.49.49,0,0,1,.5.5c.5,0,.5.5,1,.5s.5.5,1,.5.5,0,1,.5h6c.5,0,.5,0,1-.5.5,0,.5-.5,1-.5s.5-.5,1-.5.5-.5,1-.5a.49.49,0,0,0,.5-.5l.5-.5,80-97C182.18,53.9,181.68,47.4,177.68,43.9Z"
                              />
                            </svg>
                          </span>
                        </button>
                        <span className="m-1">|</span>
                        <button onClick={handleCancelClick}>
                          <svg
                            height="24px"
                            viewBox="0 -960 960 960"
                            width="24px"
                            fill="#5f6368"
                          >
                            <path d="m336-280 144-144 144 144 56-56-144-144 144-144-56-56-144 144-144-144-56 56 144 144-144 144 56 56ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z" />
                          </svg>
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      <h4>{editedUsername}</h4>
                      <div
                        aria-disabled="false"
                        role="button"
                        className="icons-prof"
                        data-tab="2"
                        title="Edit"
                        aria-label="Edit"
                        onClick={handleUsernameEditClick}
                      >
                        <span
                          data-testid="pencil"
                          data-icon="pencil"
                          className=""
                        >
                          <svg
                            viewBox="0 0 24 24"
                            width="24"
                            height="24"
                            className=""
                          >
                            <path
                              fill="currentColor"
                              d="M3.95 16.7v3.4h3.4l9.8-9.9-3.4-3.4-9.8 9.9zm15.8-9.1c.4-.4.4-.9 0-1.3l-2.1-2.1c-.4-.4-.9-.4-1.3 0l-1.6 1.6 3.4 3.4 1.6-1.6z"
                            ></path>
                          </svg>
                        </span>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="warning">
              <div className="warn-text">
                <h4>
                  This is not your username or pin. This name will be visible to
                  your small office crm contacts.
                </h4>
              </div>
            </div>

            <div className="block">
              {/* <!-- Text --> */}
              <div className="h-text d-flex justify-content-between">
                <div className="titlePro">
                  <p>Personal Settings</p>
                </div>

                <div className="head">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    height="24px"
                    viewBox="0 -960 960 960"
                    width="24px"
                    fill="#1f1f1f"
                    onClick={handleOpenPersonalSetting}
                  >
                    <path d="m370-80-16-128q-13-5-24.5-12T307-235l-119 50L78-375l103-78q-1-7-1-13.5v-27q0-6.5 1-13.5L78-585l110-190 119 50q11-8 23-15t24-12l16-128h220l16 128q13 5 24.5 12t22.5 15l119-50 110 190-103 78q1 7 1 13.5v27q0 6.5-2 13.5l103 78-110 190-118-50q-11 8-23 15t-24 12L590-80H370Zm70-80h79l14-106q31-8 57.5-23.5T639-327l99 41 39-68-86-65q5-14 7-29.5t2-31.5q0-16-2-31.5t-7-29.5l86-65-39-68-99 42q-22-23-48.5-38.5T533-694l-13-106h-79l-14 106q-31 8-57.5 23.5T321-633l-99-41-39 68 86 64q-5 15-7 30t-2 32q0 16 2 31t7 30l-86 65 39 68 99-42q22 23 48.5 38.5T427-266l13 106Zm42-180q58 0 99-41t41-99q0-58-41-99t-99-41q-59 0-99.5 41T342-480q0 58 40.5 99t99.5 41Zm-2-140Z" />
                  </svg>
                </div>
              </div>
            </div>

            {/* <!-- Chats 2 --> */}
            <div className="block">
              {/* <!-- Text --> */}
              <div className="h-text">
                <div className="titlePro">
                  <p>Gender</p>
                </div>

                {isGenderEditMode ? (
                  <div className="head">
                    <div className="d-flex gap-2">
                      <label>
                        <input
                          type="radio"
                          className="mx-1"
                          value="1"
                          checked={tempGender === 1}
                          onChange={handleGenderChange}
                        />
                        Male
                      </label>

                      <label>
                        <input
                          type="radio"
                          value="2"
                          className="mx-1"
                          checked={tempGender === 2}
                          onChange={handleGenderChange}
                        />
                        Female
                      </label>

                      <label>
                        <input
                          type="radio"
                          value="3"
                          className="mx-1"
                          checked={tempGender === 3}
                          onChange={handleGenderChange}
                        />
                        Other
                      </label>
                    </div>

                    {isGenderEditMode && (
                      <div className="d-flex">
                        <button onClick={handleConfirmClickGender}>
                          <span>
                            <svg
                              data-name="Layer 1"
                              height={24}
                              id="Layer_1"
                              viewBox="0 0 200 200"
                            >
                              <title />
                              <path
                                fill="currentColor"
                                d="M177.68,43.9c-4.5-3.5-10.5-3-14,1.5l-74,89.5-55-40c-4.5-3-10.5-2.5-14,2-3,4.5-2.5,10.5,2,14l62.5,45.5a.49.49,0,0,1,.5.5c.5,0,.5.5,1,.5s.5.5,1,.5.5,0,1,.5h6c.5,0,.5,0,1-.5.5,0,.5-.5,1-.5s.5-.5,1-.5.5-.5,1-.5a.49.49,0,0,0,.5-.5l.5-.5,80-97C182.18,53.9,181.68,47.4,177.68,43.9Z"
                              />
                            </svg>
                          </span>
                        </button>
                        <span className="m-1">|</span>
                        <button onClick={handleCancelClickGender}>
                          <svg
                            height="24px"
                            viewBox="0 -960 960 960"
                            width="24px"
                            fill="#5f6368"
                          >
                            <path d="m336-280 144-144 144 144 56-56-144-144 144-144-56-56-144 144-144-144-56 56 144 144-144 144 56 56ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z" />
                          </svg>
                        </button>
                      </div>
                    )}

                    {!isGenderEditMode && (
                      <button onClick={() => setIsGenderEditMode(true)}>
                        Edit Gender
                      </button>
                    )}
                  </div>
                ) : (
                  <>
                    <div className="d-flex justify-content-between">
                      <p>
                        {selectedGender === 1
                          ? "Male"
                          : selectedGender === 2
                          ? "Female"
                          : "Other"}
                      </p>
                      <div
                        aria-disabled="false"
                        role="button"
                        className="icons-prof"
                        data-tab="2"
                        title="Edit"
                        aria-label="Edit"
                        onClick={() => setIsGenderEditMode(true)}
                      >
                        <span
                          data-testid="pencil"
                          data-icon="pencil"
                          className=""
                        >
                          <svg
                            viewBox="0 0 24 24"
                            width="24"
                            height="24"
                            className=""
                          >
                            <path
                              fill="currentColor"
                              d="M3.95 16.7v3.4h3.4l9.8-9.9-3.4-3.4-9.8 9.9zm15.8-9.1c.4-.4.4-.9 0-1.3l-2.1-2.1c-.4-.4-.9-.4-1.3 0l-1.6 1.6 3.4 3.4 1.6-1.6z"
                            ></path>
                          </svg>
                        </span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
            <div className="block">
              {/* <!-- Text --> */}
              <div className="h-text">
                <div className="titlePro">
                  <p>Email</p>
                </div>

                <div className="head">
                  {isEmailEditMode ? (
                    <>
                      <div className="search-bar">
                        <div className="add-source-of-type-section">
                          <input
                            type="email"
                            value={editedEmail}
                            onChange={handleEmailChange}
                            className={emailError ? "error" : ""}
                          />
                        </div>
                      </div>

                      <div className="d-flex">
                        {isEmailValid && (
                          <button onClick={handleEmailSaveClick}>
                            <svg
                              data-name="Layer 1"
                              height={24}
                              id="Layer_1"
                              viewBox="0 0 200 200"
                            >
                              <title />
                              <path
                                fill="currentColor"
                                d="M177.68,43.9c-4.5-3.5-10.5-3-14,1.5l-74,89.5-55-40c-4.5-3-10.5-2.5-14,2-3,4.5-2.5,10.5,2,14l62.5,45.5a.49.49,0,0,1,.5.5c.5,0,.5.5,1,.5s.5.5,1,.5.5,0,1,.5h6c.5,0,.5,0,1-.5.5,0,.5-.5,1-.5s.5-.5,1-.5.5-.5,1-.5a.49.49,0,0,0,.5-.5l.5-.5,80-97C182.18,53.9,181.68,47.4,177.68,43.9Z"
                              />
                            </svg>
                          </button>
                        )}
                        <span className="m-1">|</span>
                        <button onClick={() => setIsEmailEditMode(false)}>
                          <svg
                            height="24px"
                            viewBox="0 -960 960 960"
                            width="24px"
                            fill="#5f6368"
                          >
                            <path d="m336-280 144-144 144 144 56-56-144-144 144-144-56-56-144 144-144-144-56 56 144 144-144 144 56 56ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z" />
                          </svg>
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      <h4>{editedEmail}</h4>

                      <div
                        aria-disabled="false"
                        role="button"
                        className="icons-prof"
                        data-tab="2"
                        title="Edit"
                        aria-label="Edit"
                        onClick={handleEmailEditClick}
                      >
                        <span
                          data-testid="pencil"
                          data-icon="pencil"
                          className=""
                        >
                          <svg
                            viewBox="0 0 24 24"
                            width="24"
                            height="24"
                            className=""
                          >
                            <path
                              fill="currentColor"
                              d="M3.95 16.7v3.4h3.4l9.8-9.9-3.4-3.4-9.8 9.9zm15.8-9.1c.4-.4.4-.9 0-1.3l-2.1-2.1c-.4-.4-.9-.4-1.3 0l-1.6 1.6 3.4 3.4 1.6-1.6z"
                            ></path>
                          </svg>
                        </span>
                      </div>
                    </>
                  )}
                </div>
                {!emailError && (
                  <div className="">
                    {profileDetail.is_email_verified === 1 ? (
                      <p style={{ color: `green` }}>
                        Your email verified successfully
                      </p>
                    ) : (
                      <p
                        onClick={handelSendOtpForEmailVerify}
                        style={{ color: `red` }}
                      >
                        verified your email
                      </p>
                    )}
                  </div>
                )}
                {emailError && (
                  <div className="error-message ">{emailError}</div>
                )}
              </div>
            </div>
            <div className="block">
              {/* <!-- Text --> */}
              <div className="h-text">
                <div className="titlePro">
                  <p>Set Login Pin</p>
                </div>

                <div className="head">
                  {isLoginPinEditMode ? (
                    <>
                      <div className="search-bar">
                        <div className="add-source-of-type-section">
                          <input
                            type="text"
                            value={editedLoginPin}
                            onChange={handleLoginPinChange}
                            className={loginPinError ? "error" : ""}
                          />
                        </div>
                      </div>

                      <div className="d-flex">
                        {isLoginPinValid && (
                          <button onClick={handleLoginPinSaveClick}>
                            <svg
                              data-name="Layer 1"
                              height={24}
                              id="Layer_1"
                              viewBox="0 0 200 200"
                            >
                              <title />
                              <path
                                fill="currentColor"
                                d="M177.68,43.9c-4.5-3.5-10.5-3-14,1.5l-74,89.5-55-40c-4.5-3-10.5-2.5-14,2-3,4.5-2.5,10.5,2,14l62.5,45.5a.49.49,0,0,1,.5.5c.5,0,.5.5,1,.5s.5.5,1,.5.5,0,1,.5h6c.5,0,.5,0,1-.5.5,0,.5-.5,1-.5s.5-.5,1-.5.5-.5,1-.5a.49.49,0,0,0,.5-.5l.5-.5,80-97C182.18,53.9,181.68,47.4,177.68,43.9Z"
                              />
                            </svg>
                          </button>
                        )}
                        <span className="m-1">|</span>
                        <button onClick={() => setIsLoginPinEditMode(false)}>
                          <svg
                            height="24px"
                            viewBox="0 -960 960 960"
                            width="24px"
                            fill="#5f6368"
                          >
                            <path d="m336-280 144-144 144 144 56-56-144-144 144-144-56-56-144 144-144-144-56 56 144 144-144 144 56 56ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z" />
                          </svg>
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      <h4>{editedLoginPin}</h4>

                      <div
                        aria-disabled="false"
                        role="button"
                        className="icons-prof"
                        data-tab="2"
                        title="Edit"
                        aria-label="Edit"
                        onClick={handleLoginPinEditClick}
                      >
                        <span
                          data-testid="pencil"
                          data-icon="pencil"
                          className=""
                        >
                          <svg
                            viewBox="0 0 24 24"
                            width="24"
                            height="24"
                            className=""
                          >
                            <path
                              fill="currentColor"
                              d="M3.95 16.7v3.4h3.4l9.8-9.9-3.4-3.4-9.8 9.9zm15.8-9.1c.4-.4.4-.9 0-1.3l-2.1-2.1c-.4-.4-.9-.4-1.3 0l-1.6 1.6 3.4 3.4 1.6-1.6z"
                            ></path>
                          </svg>
                        </span>
                      </div>
                    </>
                  )}
                </div>
                {loginPinError && (
                  <div className="error-message ">{loginPinError}</div>
                )}
              </div>
            </div>
            <div className="block">
              {/* <!-- Text --> */}
              <div className="h-text">
                <div className="titlePro">
                  <p>Account Delete</p>
                </div>
                <div className="head">
                  <button
                    className="btn btn-danger"
                    onClick={() => setIsCloseConfirmation(true)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
      <PersonalSettingView
        show={isPersonalSettingOpen}
        onHide={() => setIsPersonalSettingOpen(false)}
        companyToEdit={loginById}
        headerName="Save Personal Detail"
        setIsLoadApi={setIsLoadApi}
      />
      <OtpConfirmationModal
        show={isCloseConfirmation}
        onHide={() => setIsCloseConfirmation(false)}
        handleSubmit={handleLogout}
        title={`Delete this Account `}
        message={`Are you sure you want Delete this Account?`}
        btn1="CANCEL"
        btn2="Delete"
        mobileNumber={profileDetail?.recovery_mobile}
        emailId={profileDetail?.recovery_email}
        profileId={profileDetail.id}
        position={1}
      />

      <OtpConfirmationModal
        show={isMobileNumberConfirmation}
        onHide={() => setIsMobileNumberCloseConfirmation(false)}
        handleSubmit={handelCloseChangeNumberOtp}
        title={`Change this Mobile Number`}
        message={`Are you sure you want Change this Mobile Number?`}
        btn1="CANCEL"
        btn2="Change"
        mobileNumber={profileDetail?.recovery_mobile}
        emailId={profileDetail?.recovery_email}
        profileId={profileDetail.id}
        position={2}
      />
      <OtpConfirmationModal
        show={isEmailVerifyConfirmation}
        onHide={() => setIsEmailVerifyCloseConfirmation(false)}
        handleSubmit={() => setIsEmailVerifyCloseConfirmation(false)}
        title={`Verify Email`}
        message={`Are you sure you want  Verify  this ${profileDetail?.recovery_email} Email?`}
        btn1="CANCEL"
        btn2="verify"
        mobileNumber={profileDetail?.recovery_mobile}
        emailId={profileDetail?.recovery_email}
        profileId={profileDetail.id}
        position={3}
      />
    </>
  );
};

export default ProfileSetting;
