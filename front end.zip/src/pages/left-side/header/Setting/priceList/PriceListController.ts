import { toast } from "react-toastify";
import { TReactSetState } from "../../../../../helpers/AppType";
import {axiosInstance} from "../../../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import {
  checkDuplication,
  checkDuplicationUpdate,
} from "../../../../../common/SharedFunction";

export interface IPriceListView {
  price_list_name: string;
  id: number;
  effective_from: string;
  created_date_time?: string;
  country_id: string;
  state_id: string;
  city_id: string;
  city_name: string;
  state_name: string;
  country_name: string;
}
export interface IPriceListCreate {
  price_list_name: string;
  effective_from: string;
  created_date_time?: string;
  country_id: string;
  state_id: number;
  city_id: number;
}

export const handleDeletePriceList = async (
  priceListId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setPriceListList: TReactSetState<IPriceListView[]>,
  setLoading: TReactSetState<boolean>
) => {
  const requestData = {
    table: "pricelist_masters",
    where: `{"id":${priceListId}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID")

  try {
    const data = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        const requestDataPriceListMaster = {
          table: "price_lists",
          where: `{"pricelist_masters_id":${priceListId}}`,
          data: `{"isDelete":"1"}`,
        };

        const resultPriceListMaster = await axiosInstance.post(
          "commonUpdate",
          requestDataPriceListMaster , 
          {
            headers: {
              "x-tenant-id": getUUID,
    
            },
            }
        );
        if (resultPriceListMaster.data.code === 200) {
          if (resultPriceListMaster.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
            fetchPriceListApi(setPriceListList, setLoading);
          } else {
            toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
          }
        } else {
          toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createPriceList = async (
  priceListInput: IPriceListCreate,
  setPriceListList: TReactSetState<IPriceListView[]>,
  setLoading: TReactSetState<boolean>,
  clearForm: () => void
) => {
  if (
    !(await checkDuplication(
      priceListInput.price_list_name,
      "pricelist_masters",
      "price_list_name"
    ))
  ) {
    const date = new Date();

    const formattedDateTime = `${date.getFullYear()}-${String(
      date.getMonth() + 1
    ).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(
      date.getHours()
    ).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(
      date.getSeconds()
    ).padStart(2, "0")}`;
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "pricelist_masters",
      data: JSON.stringify({
        price_list_name: priceListInput.price_list_name,
        effective_from: priceListInput.effective_from,
        country_id: priceListInput.country_id, // Include the HTML content here
        state_id: priceListInput.state_id,
        city_id: priceListInput.city_id,
        created_date_time: formattedDateTime,
        a_application_login_id: Number(getUUID),
      }),
    };
    try {
      const { data } = await axiosInstance.post("commonCreate", requestData , 
        {
          headers: {
            "x-tenant-id": getUUID,
  
          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          fetchPriceListApi(setPriceListList, setLoading);
          clearForm();
          toast.success(data.ack_msg);
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("PriceList already available");
  }
};

export const fetchCountryApiForPriceList = async (setCountriesList: any) => {
  const requestData = {
    table: "a_countries",
    columns: "id,country_name,country_code",
    where: `{"isDelete": "0"}`,
  };
  const getUUID = localStorage.getItem("UUID")

  try {
    const response = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );

    setCountriesList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setCountriesList([]);
  }
};

export const fetchStateApiForPriceList = async (
  setStateList: any,
  selectedCountryId: any
) => {
  const requestData = {
    table: "a_states",
    columns: "id,state_name",
    where: `{"country_id": "${selectedCountryId}"}`,
  };
  const getUUID = localStorage.getItem("UUID")

  try {
    const response = await axiosInstance.post("commonGet", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );

    setStateList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setStateList([]);
  }
};
export const fetchCityApiForPriceList = async (
  setCityList: TReactSetState<any>,
  selectedStateId: any
) => {
  const requestData = {
    table: "a_cities",
    columns: "id,city_name",
    where: `{"state_id": ${selectedStateId}}`,
  };
  const getUUID = localStorage.getItem("UUID")

  try {
    const response = await axiosInstance.post("commonGet", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );

    setCityList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setCityList([]);
  }
};
export const fetchPriceListApi = async (
  setPriceListList: TReactSetState<IPriceListView[]>,
  setLoading: TReactSetState<boolean>
) => {
  const token = await localStorage.getItem("token");

  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    a_application_login_id: getUUID,
  };
  try {
    const data = await axiosInstance.post("priceListMaster", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,

      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false);
      setPriceListList([]);

      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
    setLoading(true);
    setPriceListList(data.data.data.item);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};

export const updatePriceList = async (
  priceListInput: IPriceListCreate,
  setPriceList: TReactSetState<IPriceListView[]>,
  editPriceListId: number | undefined,
  setLoading: TReactSetState<boolean>,
  clearForm: () => void
) => {
  if (
    !(await checkDuplicationUpdate(
      priceListInput.price_list_name,
      "pricelist_masters",
      "price_list_name",
      editPriceListId
    ))
  ) {
    const requestData = {
      table: "pricelist_masters",
      where: `{"id":"${editPriceListId}"}`,
      data: JSON.stringify({
        price_list_name: priceListInput.price_list_name,
        effective_from: priceListInput.effective_from,
        country_id: priceListInput.country_id, // Include the HTML content here
        state_id: priceListInput.state_id,
        city_id: priceListInput.city_id,
      }),
    };
    const getUUID = localStorage.getItem("UUID")

    try {
      const { data } = await axiosInstance.post("commonUpdate", requestData , 
        {
          headers: {
            "x-tenant-id": getUUID,
    
          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          setPriceList((prevList) =>
            prevList.map((category) =>
              category.id === editPriceListId ? data.data : category
            )
          );
          clearForm();
          fetchPriceListApi(setPriceList, setLoading);
          toast.success(data.ack_msg);
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("PriceList already available");
  }
};