import React, { useEffect, useState } from "react";

import {
  createPriceListItem,
  fetchPriceListItemApi,
  fetchProductApiForPriceListItem,
  handleDeletePriceListItem,
  IPriceListItemView,
  updatePriceListItem,
  // updateCompany,
} from "./PriceListItemController";

import { IPriceListView } from "./PriceListController";
import CustomSearchDropdown from "../../../../../components/CustomSearchDropdown";
import { SingleValue } from "react-select";
import { IOption } from "../../../../../helpers/AppInterface";
import { TOnChangeInput } from "../../../../../helpers/AppType";
import ConfirmationModal from "../../../../../components/model/ConfirmationModal";
import { toast } from "react-toastify";
import useCheckUserPermission from "../../../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../../../helpers/AppEnum";
import { DEFAULT_MESSAGE_ERROR_PERMISSION } from "../../../../../helpers/AppConstants";

const PriceListItemView = ({
  show,
  onHide,
  title,
  btn1 = "yes",
  btn2 = "no",
  passDataInAddItem,
}: {
  show: boolean;
  onHide: () => void;
  title: string;
  btn1: string;
  btn2: string;
  passDataInAddItem: IPriceListView | undefined;
}) => {
  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);

  const [productList, setProductList] = useState<any>([]);
  const [gstFromProduct, setGstFromProduct] = useState<any>();
  const [netRateFromProduct, setNetRateFromProduct] = useState<any>();
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [selectedProductId, setSelectProductId] = useState<any>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [rateInput, setRateInput] = useState<number>(0);
  const [discountInput, setDiscountInput] = useState<number>(0);
  const [netRateInput, setNetRateInput] = useState<number>(0);
  const [netRateInput1, setNetRateInput1] = useState<number>();
  const [priceListLists, setPriceListItem] = useState<IPriceListItemView[]>([]);
  const [productError, setproductError] = useState("");
  const [editPriceListItemId, setEditPriceListItemId] = useState<
    number | undefined
  >(undefined);
  const canViewProduct = useCheckUserPermission(
    PAGE_ID.PRODUCT,
    PERMISSION_TYPE.VIEW
  );
  const canAdd = useCheckUserPermission(
    PAGE_ID.PRICE_LIST_ITEM,
    PERMISSION_TYPE.ADD
  );

  const canEdit = useCheckUserPermission(
    PAGE_ID.PRICE_LIST_ITEM,
    PERMISSION_TYPE.EDIT
  );
  const canDelete = useCheckUserPermission(
    PAGE_ID.PRICE_LIST_ITEM,
    PERMISSION_TYPE.DELETE
  );
  const handleSubmit = async (values: any) => {
  };

  console.log("netRateFromProduct", netRateFromProduct, gstFromProduct);

  useEffect(() => {
    if(canViewProduct){
    fetchProductApiForPriceListItem(setProductList);
    }
    fetchPriceListItemApi(setPriceListItem, passDataInAddItem?.id);
    // }
  }, [passDataInAddItem?.id, canViewProduct]);
  const productOptions = productList.map((category: any) => ({
    value: category.id,
    label: category.product_name,
    netRate: category.rate,
    gst: category.GST,
  }));
  const calculateNetRate = (rate: number, discount: number, gst: number) => {
    // Step 2: DISCOUNT_AMOUNT = (rate * discount) / 100
    const discount_amount = (rate * discount) / 100;
    // Step 3: discounted_amount = rate - discount_amount
    const discounted_amount = rate - discount_amount;
    // Step 1: gst_amount = (gst * discounted_amount) / 100
    const gst_amount = (gst * discounted_amount) / 100;
    // Step 4: final = gst_amount + discounted_amount
    const final = gst_amount + discounted_amount;

    setNetRateInput(final | 0);
  };

  const handleProductChange = (selectedOption: SingleValue<any>) => {
    setSelectProductId(selectedOption);
    setproductError(selectedOption ? "" : "Product is required");
    setNetRateFromProduct(selectedOption?.netRate);
    const gst = selectedOption?.gst || 0; // Assuming `gst` is in percentage
    setGstFromProduct(gst);
    const netrate = selectedOption?.netRate || 0;
    setNetRateFromProduct(netrate);
    calculateNetRate(netrate, discountInput, gst);
  };

  const clearForm = () => {
    setRateInput(0);
    setDiscountInput(0);
    setNetRateInput(0);
    setGstFromProduct("");
    setNetRateFromProduct("");
    setIsEditing(false);
    setSelectProductId("");
  };
  const handelSubmit = () => {
    if (!selectedProductId) setproductError("Product is required");
    if (netRateFromProduct) {
      if (isEditing && editPriceListItemId !== null) {
        updatePriceListItem(
          {
            pricelist_masters_id: passDataInAddItem?.id,
            product_id: selectedProductId?.value,
            rate: netRateFromProduct,
            discount: discountInput,
            net_rate: netRateInput,
          },
          setPriceListItem,
          editPriceListItemId,
          passDataInAddItem?.id,
          clearForm
        );
      } else {
          if(!canAdd){
            toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)
            return
          }
        createPriceListItem(
          {
            pricelist_masters_id: passDataInAddItem?.id,
            product_id: selectedProductId?.value,
            rate: netRateFromProduct,
            discount: discountInput,
            net_rate: netRateInput,
          },
          setPriceListItem,
          passDataInAddItem?.id,
          clearForm
        );
      }
    }
  };

  const handelChangeRate = (event: React.ChangeEvent<HTMLInputElement>) => {
    const rate = parseFloat(event.target.value) || 0;
    setRateInput(rate);
    calculateNetRate(rate, discountInput, gstFromProduct);
  };

  const handelChangeDiscount = (event: React.ChangeEvent<HTMLInputElement>) => {
    const discount = parseFloat(event.target.value);
    if (Number(discount) < 100) {
      setDiscountInput(discount);
    } else {
          toast.error("You cant add Discount More Than Rate");
          setDiscountInput(0);
        }
    calculateNetRate(netRateFromProduct, discount, gstFromProduct);
  };

  const handelChangeNetRate = (event: TOnChangeInput) => {
    setNetRateInput(parseFloat(event.target.value));
  };
  const handleDeleteById = (id: number) => {
    if(canDelete){
    setNetRateInput1(id);
    setIsDeleteConfirmation(true);
    }else{
    setIsDeleteConfirmation(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)

    }
  };
  const handleEdit = (item: IPriceListItemView) => {
    if(canEdit){
    const selectedProductOption = productOptions.find(
      (option: { value: string }) => option.value === item.product_id
    );

    setDiscountInput(item.discount);
    setNetRateFromProduct(item.rate);
    setNetRateInput(item.net_rate);
    setGstFromProduct(item.gst_number);
    setSelectProductId(selectedProductOption);
    setIsEditing(true);
    setEditPriceListItemId(item.id);
  }else{
    toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)

  }
  };
  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1" style={{ maxHeight: "80%" }}>
            <span className="close" onClick={onHide}>
              &times;
            </span>
            <h2 className="modal-title1 form_header_text">
              Product List Name : {passDataInAddItem?.price_list_name}
            </h2>
            <p className="text-center " style={{ color: "#999" }}>
              Please Enter your Price List Item Detail.
            </p>
            <div
              className={`m-title-2 col-12 `}
            >
              <div className="head">
                <div className="source-of-type-list-grid-block">
                  <div className="source-of-type-list-grid-main">
                    <table className="table table-hover" border={0}>
                      <thead>
                        <th>
                          
                            Product<span className="text-danger">*</span>
                          
                        </th>
                        <th className="text-end">
                          Rate
                        </th>
                        <th className="text-end">
                          Discount (%)
                        </th>
                        <th className="text-center" style={{width :"10%"}}>
                          GST
                        </th>
                        <th className="text-end">
                          Net Rate
                        </th>
                      </thead>
                      <tbody className="">
                        <tr
                          className=""
                          style={
                            {
                            }
                          }
                        >
                          <td className="text-start" width={"22%"}>
                            <div className="w-100">
                              <CustomSearchDropdown
                                options={productOptions}
                                value={selectedProductId}
                                onChange={handleProductChange}
                                className="w-100"
                              />
                            </div>
                            {productError && (
                              <span className="text-danger">
                                {productError}
                              </span>
                            )}
                          </td>
                          <td className="text-start">
                            <div className="search-bar ">
                              <div className="add-source-of-type-section ">
                                <input
                                  type="text"
                                  title="Rate"
                                  placeholder="Rate"
                                  value={netRateFromProduct}
                                  readOnly
                                  style={{textAlign:"end"}}
                                />
                              </div>
                            </div>
                          </td>
                          <td className="text-start">
                            <div className="search-bar ">
                              <div className="add-source-of-type-section ">
                                <input
                                  type="number" // Changed to number to accept decimals
                                  title="Discount"
                                  placeholder="Discount"
                                  value={discountInput}
                                  onChange={(e) => handelChangeDiscount(e)}
                                  style={{ backgroundColor: "#f0f2f5" , textAlign:"end" }}
                                  step="0.01" // This allows decimal points
                                  min="0" // Optional: restricts negative values if needed
                                  
                                />
                              </div>
                            </div>
                          </td>
                          <td className="text-start">
                            <div className="search-bar mt-3">
                              <div className="  text-end">
                                {gstFromProduct ? gstFromProduct : ""} %
                              </div>
                            </div>
                          </td>
                          <td className="text-start">
                            <div className="search-bar ">
                              <div className="add-source-of-type-section ">
                                <input
                                  type="text"
                                  title="Net rate"
                                  placeholder="Net rate"
                                  value={netRateInput.toFixed(2)}
                                  readOnly
                                  style={{ backgroundColor: "#f0f2f5" , textAlign:"end" }}
                                />
                              </div>
                            </div>
                          </td>
                          <td>
                            <div className=" mt-2">
                              <button className="" onClick={handelSubmit}>
                                <span>
                                  {isEditing ? (
                                    <span>
                                      <svg
                                        data-name="Layer 1"
                                        height={24}
                                        id="Layer_1"
                                        viewBox="0 0 200 200"
                                      >
                                        <title />
                                        <path
                                          fill="currentColor"
                                          d="M177.68,43.9c-4.5-3.5-10.5-3-14,1.5l-74,89.5-55-40c-4.5-3-10.5-2.5-14,2-3,4.5-2.5,10.5,2,14l62.5,45.5a.49.49,0,0,1,.5.5c.5,0,.5.5,1,.5s.5.5,1,.5.5,0,1,.5h6c.5,0,.5,0,1-.5.5,0,.5-.5,1-.5s.5-.5,1-.5.5-.5,1-.5a.49.49,0,0,0,.5-.5l.5-.5,80-97C182.18,53.9,181.68,47.4,177.68,43.9Z"
                                        />
                                      </svg>
                                    </span>
                                  ) : (
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      height="26px"
                                      viewBox="0 -960 960 960"
                                      width="26px"
                                      fill="#5f6368"
                                    >
                                      <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                                    </svg>
                                  )}
                                </span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="source-of-type-list-grid-block">
                  <div className="source-of-type-list-grid-main">
                    <table className="table table-hover" border={0}>
                      <thead>
                        <th className="">
                          Product
                        </th>
                        <th className="text-end">
                          Rate
                        </th>
                        <th className="text-end">
                          Discount (%)
                        </th>
                        <th className="text-end">
                          GST (%)
                        </th>
                        <th className="text-end">
                          Net Rate
                        </th>
                        <th className="text-center">
                          Action
                        </th>
                      </thead>
                      <tbody className="text-center">
                        {priceListLists &&
                          priceListLists.map((item, index) => (
                            <tr
                              key={index}
                              className=""
                              style={
                                {
                                }
                              }
                            >
                              <td className="text-start">
                                <span>{item.product_name}</span>
                              </td>
                              <td className="text-end">
                                <span>{item.rate}</span>
                              </td>
                              <td className="text-end">
                                <span>{item.discount}</span>
                              </td>
                              <td className="text-end">
                                <span>
                                  {item.gst_number ? item.gst_number : ""}
                                </span>
                              </td>
                              <td className="text-end">
                                <span>{item.net_rate}</span>
                              </td>
                              <td className="text-center">
                                <span
                                  data-testid="pencil"
                                  data-icon="pencil"
                                  className=""
                                  style={{ cursor: "pointer" }}
                                  onClick={() => handleEdit(item)}
                                >
                                  <svg
                                    viewBox="0 0 24 24"
                                    width="24"
                                    height="24"
                                    className=""
                                  >
                                    <path
                                      fill="currentColor"
                                      d="M3.95 16.7v3.4h3.4l9.8-9.9-3.4-3.4-9.8 9.9zm15.8-9.1c.4-.4.4-.9 0-1.3l-2.1-2.1c-.4-.4-.9-.4-1.3 0l-1.6 1.6 3.4 3.4 1.6-1.6z"
                                    ></path>
                                  </svg>
                                </span>
                                |
                                <span
                                  style={{ cursor: "pointer" }}
                                  onClick={() => handleDeleteById(item.id)}
                                >
                                  <svg
                                    viewBox="0 -960 960 960"
                                    width="22px"
                                    fill="currentColor"
                                  >
                                    <path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" />
                                  </svg>
                                </span>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {isDeleteConfirmation && (
            <ConfirmationModal
              show={isDeleteConfirmation}
              onHide={() => setIsDeleteConfirmation(false)}
              handleSubmit={() =>
                handleDeletePriceListItem(
                  netRateInput1,
                  setIsDeleteConfirmation,
                  setPriceListItem,
                  passDataInAddItem?.id
                )
              }
              title={"Delete this PriceList"}
              message={"Are You Sure You Want To Delete This PriceList?"}
              btn1="CANCEL"
              btn2="DELETE"
            />
          )}
        </div>
      )}
    </React.Fragment>
  );
};

export default PriceListItemView;