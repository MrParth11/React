import React, { useEffect, useState } from "react";
import { Formik, Field, Form, ErrorMessage, useFormikContext } from "formik";
import {
  TOnChangeInput,
  TReactSetState,
} from "../../../../../../helpers/AppType";
import {
  createVisit,
  createProductInitialValues,
  createProductValidationSchema,
  fetchVisitTypeApiForVisit,
  IVisitCreate,
  IVisitCreateStatus,
  IVisitType,
  updateVisit,
  updateVisitStatus,
} from "./CreateVisitController";
import FormikCustomSearchDropdown from "../../../../../../components/FormikCustomSearchDropdown";
import { IVisitView } from "../VisitController";
import { TEXTAREA_TEXT_LENGTH } from "../../../../../../helpers/AppConstants";

interface IPropsCreateVisit {
  show: boolean;
  onHide: () => void;
  visitToEdit: IVisitView | undefined;
  headerName: string;
  setRefreshVisit: TReactSetState<boolean>;
  status?: string;
  createEditFlag?: string;
}
const CreateVisitView = ({
  show,
  onHide,
  visitToEdit,
  headerName,
  setRefreshVisit,
  status,
  createEditFlag,
}: IPropsCreateVisit) => {
  const [visitTypesList, setVisitTypeList] = useState<IVisitType[]>([]);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);

  const handleSubmit = async (values: IVisitCreate) => {
    const formData = new FormData();

    formData.append("visit_type_id", values.visit_type_id?.toString() || "");
    formData.append("remark", values.remark || "");
  ;
    formData.append("a_application_login_id", values.a_application_login_id?.toString() || "");
    if (values.visit_image instanceof File) {
      // Correct field name - must match backend expectation
      if (values.visit_image) {
        if (values.visit_image instanceof File) {

          formData.append("visit_image", values.visit_image.name);
        } 
      }
      console.log("Uploading file:", values.visit_image.name);
    }
    // For edit mode
    if (visitToEdit?.id) {
      formData.append("visit_id", visitToEdit.id.toString());
      await updateVisit(formData, values, setRefreshVisit, visitToEdit.id, onHide);
    } else {
      await createVisit(formData, values, setRefreshVisit, onHide);
    }

  };

  const handelClose = () => {
    onHide();
  };

  useEffect(() => {
    fetchVisitTypeApiForVisit(setVisitTypeList);
  }, [show]);

  const productTypesOptions = visitTypesList.map((item) => ({
    value: item.id,
    label: item.visit_type,
  }));
  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1">
            <span className="close" onClick={handelClose}>
              &times;
            </span>
            <h2 className="modal-title1 form_header_text">{headerName}</h2>
            <p className="text-center " style={{ color: "#999" }}>
              Please Enter your Visit Detail.
            </p>
            <Formik
              enableReinitialize
              initialValues={createProductInitialValues(visitToEdit)}
              validationSchema={createProductValidationSchema()}
              onSubmit={handleSubmit}
            >
              {({ errors, touched, setFieldValue, values }) => (
                <Form>
                  <div className="mt-3 justify-content-center">
                    <div className="mb-3 py-4">
                      <div className="row mx-0 px-2 gy-3 d-flex">
                        {/* Visit Type Field - Always shown in create/edit mode */}
                        {createEditFlag === "createEdit" && (
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label htmlFor="visit_type_id" className="mb-1 form_label">
                                Visit Types
                                <span className="text-danger">*</span>
                              </label>
                              <FormikCustomSearchDropdown
                                name="visit_type_id"
                                options={productTypesOptions}
                                className={`${errors.visit_type_id && touched.visit_type_id && "is-invalid input-box-error"
                                  }`}
                              />
                              <ErrorMessage
                                name="visit_type_id"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                        )}

                        {/* Image Upload Field - Only shown when editing an existing visit */}
                        {visitToEdit && (
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <Field name="visit_image">
                                {({ field, form }: { field: { value: any }; form: any }) => (
                                  <>
                                    <label htmlFor="visit_image" className="mb-1 form_label">
                                      Visit Image
                                    </label>
                                    <input
  type="file"
  id="visit_image"
  accept="image/*"
  onChange={(event) => {
    const file = event.currentTarget.files?.[0];
    if (file) {
      form.setFieldValue("visit_image", file); 
      setPreviewImage(URL.createObjectURL(file));
    }
  }}
/>

                                    <Field type="hidden" name="end_time" />
                                  </>
                                )}
                              </Field>
                              <ErrorMessage
                                name="visit_image"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                        )}

                        {/* Remark Field - Always shown in create/edit mode */}
                        {createEditFlag === "createEdit" && (
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label htmlFor="remark" className="pb-2 form_label">
                                Remark
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                as="textarea"
                                name="remark"
                                maxLength={TEXTAREA_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1 ${errors.remark && touched.remark && "is-invalid input-box-error"
                                  }`}
                              />
                              <ErrorMessage
                                name="remark"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Form Buttons */}
                      <div className="col-12 col-12 pt-4 d-flex justify-content-center">
                        <button
                          type="button"
                          className="border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label"
                          onClick={handelClose}
                        >
                          Close
                        </button>
                        <button
                          type="submit"
                          className="btn btn-primary px-4 py-2 ms-2 text-light form_label rounded-1"
                          style={{ backgroundColor: "#f58634" }}
                        >
                          {createEditFlag === "createEdit" ? "Save Visit" : "Update Visit"}
                        </button>
                      </div>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default CreateVisitView;
