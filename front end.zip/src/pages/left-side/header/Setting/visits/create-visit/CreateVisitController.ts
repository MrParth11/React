import * as Yup from "yup";

import { toast } from "react-toastify";
import {
  axiosInstance,
  axiosInstanceFormData,
} from "../../../../../../services/axiosInstance";
import { TReactSetState } from "../../../../../../helpers/AppType";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../../helpers/AppConstants";

export interface IVisitCreate {
  [x: string]: any;
  created_date_time?: string ;
  visit_type_id: string;
  remark : string;
  visitId:number | string;  
  visit_status:number;
  status_remark: string;
  visit_image?: File | string | null; 
  end_date ?:  string ; 
}

export interface IVisitCreateStatus {
  visitId:number | string;  
  visit_status:number;
  status_remark: string;

}
export interface IVisitType {
    id: string;
    visit_type: string;
   
}
export const createProductInitialValues = (
  VisitToEdit: IVisitCreate | undefined
): IVisitCreate => ({
  
  visit_image: VisitToEdit?.visit_image || "",
  visit_type_id: VisitToEdit?.visit_type_id || "",
  remark: VisitToEdit?.remark || "",
  visitId: VisitToEdit?.visitId || "",
  visit_status: VisitToEdit?.visit_status || 1,
  status_remark: VisitToEdit?.status_remark || "",

});

export const createProductValidationSchema = () =>
  Yup.object().shape({
    visit_type_id: Yup.string().required("Visit Type is Required"),
  });

export const createVisit = async (
  formData: FormData,
  values: IVisitCreate,
  setRefreshVisit: TReactSetState<boolean>,
  onHide: () => void
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  if (!getUUID) {
    return;
  }
 
  const requestDataCreateVisit = {
    visit_type_id: values.visit_type_id,
    remark: values.remark,
    visit_image: values.visit_image,
    a_application_login_id:getUUID
  };
  try {
    const { data } = await axiosInstance.post(
      "create-visit",
      requestDataCreateVisit,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
          
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        toast.success(data.ack_msg);
        setRefreshVisit(true);

        onHide();
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateVisit = async (
  formData: FormData,
  values: IVisitCreate,
  setRefreshVisit: TReactSetState<boolean>,
  visitId: number,
  onHide: () => void
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  if (!getUUID) {
    return;
  }

  try {
    // Create FormData for the request
    const requestFormData = new FormData();
    
    // Append all fields to FormData
    requestFormData.append('visit_id', visitId.toString());
    requestFormData.append('visit_type_id', values.visit_type_id.toString());
    requestFormData.append('remark', values.remark);
    requestFormData.append('a_application_login_id', getUUID);
    if (values.visit_image instanceof File) {
      requestFormData.append('visit_image', values.visit_image);
    }
    const { data } = await axiosInstance.post(
      "update-visit",
      requestFormData,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
          "Content-Type": "multipart/form-data",
        },
      }
    );

    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        onHide();
        setRefreshVisit(true);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    console.error("Update error:", error);
    toast.error(error.response?.data?.message || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};


export const updateVisitStatus = async (
  values: IVisitCreateStatus,
  setRefreshVisit: TReactSetState<boolean>,
  visitId: number | undefined,
  onHide: () => void,
  visitStatus : number

) => {

  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");


  if (!getUUID) {
    return;
  }
  const requestDataUpdateVisit = {
    visit_id: visitId,
    visit_status: visitStatus,
    status_remark:values.status_remark,
  };
  console.log("requestDataUpdateVisit", requestDataUpdateVisit);

  try {
    const { data } = await axiosInstance.post(
      "update-visit",
      requestDataUpdateVisit,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        onHide();
        setRefreshVisit(true);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchVisitTypeApiForVisit = async (
    setVisitTypeList: TReactSetState<IVisitType[]>
) => {
  const getUUID = localStorage.getItem("UUID")
  const requestData = {
    table: "visit_type_masters",
    columns: "id,visit_type",
    where: ["isDelete=0"],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const response = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
  );
    if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {

        setVisitTypeList(response.data.data); // Assuming API response is an array of countries
    } else {
        setVisitTypeList([]); // Assuming API response is an array of countries
      toast.error(response.data.ack_msg);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);

    // Handle error (e.g., show error message, clear filtered list)
    setVisitTypeList([]);
  }
};
