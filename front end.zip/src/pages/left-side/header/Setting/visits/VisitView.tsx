import React, { useEffect, useRef, useState } from "react";
import ConfirmationModal from "../../../../../components/model/ConfirmationModal";
import {
  fetchVisitApi,
  handleDeleteVisit,
  IVisitView,
} from "./VisitController";
import { toast } from "react-toastify";
import Skeleton from "react-loading-skeleton";
import { useTheme } from "../../../../../components/ThemeContext";
import "react-loading-skeleton/dist/skeleton.css";
import useCheckUserPermission from "../../../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../../../helpers/AppEnum";
import { BACKEND_OF_SMALL_OFFICE_CRM_END_POINT, DEFAULT_MESSAGE_ERROR_PERMISSION } from "../../../../../helpers/AppConstants";
import CreateVisitView from "./create-visit/CreateVisitView";
import { convertDateTimeFormat } from "../../../../../common/SharedFunction";

interface IPropsVisitView {
  isVisitView: boolean;
  closeVisitView: () => void;
}

const VisitView = ({ isVisitView, closeVisitView }: IPropsVisitView) => {
  const [visitLists, setVisitList] = useState<IVisitView[]>([]);
  const dropdownContactRef = useRef<Record<number, HTMLUListElement | null>>({});
  const inputRef = useRef<HTMLInputElement>(null);
  const [visitDropdown, setVisitDropdown] = useState<any>(null);
  const [hasIdAvail, setHasIdAvail] = useState<number>();
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [isOpenCreateModel, setIsCreateModel] = useState(false);
  const [isOpenEditModel, setIsOpenEditModel] = useState(false);
  const [isOpenStatusModel, setIsOpenStatusModel] = useState(false);
  const [editVisitStatusItem, setEditVisitStatusItem] = useState<IVisitView>();
  const [statusFlag, setStatusFlag] = useState<string>("");
  const [createEditStatusFlag, setCreateEditStatusFlag] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const { darkMode } = useTheme();
  const [editVisitItem, setEditVisitItem] = useState<IVisitView>();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const [refreshProduct, setRefreshProduct] = useState(false);
  const [imageViewerUrl, setImageViewerUrl] = useState<string | null>(null);

  const canView = useCheckUserPermission(PAGE_ID.VISIT, PERMISSION_TYPE.VIEW);
  const canAdd = useCheckUserPermission(PAGE_ID.VISIT, PERMISSION_TYPE.ADD);
  const canEdit = useCheckUserPermission(PAGE_ID.VISIT, PERMISSION_TYPE.EDIT);
  const canDelete = useCheckUserPermission(PAGE_ID.VISIT, PERMISSION_TYPE.DELETE);

  const toggleDropdownVisit = (visitId: number | undefined) => {
    console.log("button click");

    const checkedId = visitLists.find((abv) => abv.id === visitId);
    setHasIdAvail(checkedId?.id);
    setVisitDropdown(!visitDropdown);
  };

  const handleEdit = (item: IVisitView, addUpdateStatus: string) => {
    if (canEdit) {
      setEditVisitItem(item);
      setIsOpenEditModel(true);
      setVisitDropdown(null);
      setCreateEditStatusFlag(addUpdateStatus);
    } else {
      setVisitDropdown(null);
      setIsOpenEditModel(false);
      setCreateEditStatusFlag(addUpdateStatus);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  useEffect(() => {
    if (canView && isVisitView) {
      fetchVisitApi(setVisitList, setLoading, searchTerm);
    }
  }, [isVisitView, searchTerm, canView]);

  const handleClickOutside = (event: { target: any }) => {
    const clickedOutside = Object.values(dropdownContactRef.current).every(
      (ref) => ref && !ref.contains(event.target)
    );
    if (clickedOutside) {
      setVisitDropdown(null);
    }
  };

  useEffect(() => {
    if (visitDropdown !== null) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [visitDropdown]);

  const handelRefreshVisit = async () => {
    if (canView) {
      await fetchVisitApi(setVisitList, setLoading, "");
    }
  };

  function openSearch() {
    if (canView) {
      setSearchOpen(!searchOpen);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setSearchTerm(value);
    if (value.length >= 3 || value === "") {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
      setSearchTimeout(
        setTimeout(() => {
          fetchVisitApi(setVisitList, setLoading, value);
        }, 1000)
      );
    }
  };

  const handleSearchClear = () => {
    setSearchTerm("");
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }
    setSearchOpen(!searchOpen);
    setSearchTimeout(
      setTimeout(() => {
        fetchVisitApi(setVisitList, setLoading, "");
      }, 1000)
    );
  };

  function openDeleteModel() {
    if (canDelete) {
      setIsDeleteConfirmation(true);
    } else {
      setIsDeleteConfirmation(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }

  function openCreateProduct(addUpdateStatus: string) {
    if (canAdd) {
      setIsCreateModel(true);
      setCreateEditStatusFlag(addUpdateStatus);
    } else {
      setIsCreateModel(false);
      setCreateEditStatusFlag(addUpdateStatus);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }

  const handleStatusChange = (item: IVisitView, status: string) => {
    setIsOpenStatusModel(true);
    setEditVisitStatusItem(item);
    setStatusFlag(status);
  };

  useEffect(() => {
    if (refreshProduct) {
      fetchVisitApi(setVisitList, setLoading, searchTerm);
      setRefreshProduct(false);
    }
  }, [refreshProduct, searchTerm]);

  const handleChangeImgViewer = (imageUrl: string) => {
    setImageViewerUrl(imageUrl);
  };

  const handleCloseImageViewer = () => {
    setImageViewerUrl(null);
  };

  return (
    <>
      {isVisitView ? (
        <div className="leftSide animate__animated animate__fadeInLeft" id="notifications">
          {/* Header */}
          <div className="header-Chat">
            <div className="ICON">
              <div
                aria-disabled="false"
                role="button"
                className="icons text-light"
                data-tab="2"
                title="Back"
                aria-label="New chat"
                onClick={closeVisitView}
              >
                <span data-testid="chat" data-icon="chat" className="">
                  <svg viewBox="0 0 24 24" width="24" height="24" className="">
                    <path
                      fill="currentColor"
                      d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                    ></path>
                  </svg>
                </span>
              </div>
            </div>

            <div className="newText">
              <h2>Visit</h2>
            </div>

            <div className="col-8 text-end mb-2 ">
              <div className="ICON" style={{ position: "absolute", right: "1px" }}>
                <button
                  className="icons text-white"
                  onClick={() => openCreateProduct("createEdit")}
                >
                  <span title="Create Visit" className="text-white">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="26px"
                      viewBox="0 -960 960 960"
                      width="26px"
                      fill="currentColor"
                    >
                      <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                    </svg>
                  </span>
                </button>
                <button className="icons text-white" onClick={openSearch} title="Search">
                  <svg viewBox="0 0 24 24" width="24" height="24" className="">
                    <path
                      fill="currentColor"
                      d="M15.9 14.3H15l-.3-.3c1-1.1 1.6-2.7 1.6-4.3 0-3.7-3-6.7-6.7-6.7S3 6 3 9.7s3 6.7 6.7 6.7c1.6 0 3.2-.6 4.3-1.6l.3.3v.8l5.1 5.1 1.5-1.5-5-5.2zm-6.2 0c-2.6 0-4.6-2.1-4.6-4.6s2.1-4.6 4.6-4.6 4.6 2.1 4.6 4.6-2 4.6-4.6 4.6z"
                    ></path>
                  </svg>
                </button>

                <button
                  className="icons text-light"
                  onClick={handelRefreshVisit}
                  title="Refresh"
                >
                  <svg width="30" height="30" viewBox="0 0 50 50">
                    <path
                      fill="currentColor"
                      d="M25 38c-7.2 0-13-5.8-13-13 0-3.2 1.2-6.2 3.3-8.6l1.5 1.3C15 19.7 14 22.3 14 25c0 6.1 4.9 11 11 11 1.6 0 3.1-.3 4.6-1l.8 1.8c-1.7.8-3.5 1.2-5.4 1.2z"
                    />
                    <path
                      fill="currentColor"
                      d="M34.7 33.7l-1.5-1.3c1.8-2 2.8-4.6 2.8-7.3 0-6.1-4.9-11-11-11-1.6 0-3.1.3-4.6 1l-.8-1.8c1.7-.8 3.5-1.2 5.4-1.2 7.2 0 13 5.8 13 13 0 3.1-1.2 6.2-3.3 8.6z"
                    />
                    <path fill="currentColor" d="M18 24h-2v-6h-6v-2h8z" />
                    <path fill="currentColor" d="M40 34h-8v-8h2v6h6z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {searchOpen && (
            <div className="header-search" style={{ zIndex: "1" }}>
              <div className="search-bar">
                <div className=" d-flex justify-content-between">
                  <button className="search">
                    <span className="">
                      <svg viewBox="0 0 24 24" width="24" height="24" className="">
                        <path
                          fill="currentColor"
                          d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"
                        ></path>
                      </svg>
                    </span>
                  </button>

                  <span className="go-back">
                    <svg viewBox="0 0 24 24" width="24" height="24" className="">
                      <path
                        fill="currentColor"
                        d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                      ></path>
                    </svg>
                  </span>

                  <input
                    type="text"
                    title="Search "
                    aria-label="Search or start new chat"
                    placeholder="Search"
                    value={searchTerm}
                    onChange={handleSearchChange}
                    className="search-message-input"
                  />

                  <span role="button" className="p-1" onClick={handleSearchClear}>
                    <svg height="24px" viewBox="0 -960 960 960" width="24px" fill="#5f6368">
                      <path d="M280-80q-83 0-141.5-58.5T80-280q0-83 58.5-141.5T280-480q83 0 141.5 58.5T480-280q0 83-58.5 141.5T280-80Zm544-40L568-376q-12-13-25.5-26.5T516-428q38-24 61-64t23-88q0-75-52.5-127.5T420-760q-75 0-127.5 52.5T240-580q0 6 .5 11.5T242-557q-18 2-39.5 8T164-535q-2-11-3-22t-1-23q0-109 75.5-184.5T420-840q109 0 184.5 75.5T680-580q0 43-13.5 81.5T629-428l251 252-56 56Zm-615-61 71-71 70 71 29-28-71-71 71-71-28-28-71 71-71-71-28 28 71 71-71 71 28 28Z" />
                    </svg>
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Chats */}
          <div className="chats-notifications">
            {/* Chats 1 */}
            <div className="block p-0">
              {/* Text */}
              <div className="h-text">
                {canView ? (
                  <div>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, index) => (
                        <div className="chats" key={index}>
                          <button className="block chat-list">
                            <div>
                              <Skeleton
                                width="100%"
                                height="100%"
                                duration={5}
                                style={{ opacity: darkMode ? "" : 0.8 }}
                              />
                            </div>
                            <div className="h-text ps-2">
                              <Skeleton
                                width="100%"
                                height={15}
                                duration={5}
                                style={{ opacity: darkMode ? "" : 0.8 }}
                              />
                              <Skeleton
                                width="100%"
                                height={15}
                                duration={5}
                                style={{ opacity: darkMode ? "" : 0.8 }}
                              />
                              <Skeleton
                                width="100%"
                                height={15}
                                duration={5}
                                style={{ opacity: darkMode ? "" : 0.8 }}
                              />
                              <Skeleton
                                width="100%"
                                height={15}
                                duration={5}
                                style={{ opacity: darkMode ? "" : 0.8 }}
                              />
                              <Skeleton
                                width="100%"
                                height={15}
                                duration={5}
                                style={{ opacity: darkMode ? "" : 0.8 }}
                              />
                              <Skeleton
                                width="100%"
                                height={15}
                                duration={5}
                                style={{ opacity: darkMode ? "" : 0.8 }}
                              />
                            </div>
                          </button>
                        </div>
                      ))
                    ) : (
                      <>
                        <div className="chats">
                          <p className={`text-center mt-4 ${visitLists ? "" : " text-center pt-5"}`}>
                            {visitLists.length ? "" : "No Data Found"}
                          </p>
                          {visitLists &&
                            visitLists.map((item, index) => (
                              <div key={index} style={{ display: "flex", justifyContent: "center" }}>
                                <button className={`block chat-list`}>
                                  <div className="h-text ps-2" style={{ display: "flex", justifyContent: "space-between" }}>

                                    <div className="d-flex align-items-center">
                                      <div>
                                        <div className="d-flex align-items-center">
                                          <div style={{ paddingBottom: "2px", borderBottom: "unset" }}>
                                            <h4 className="inquiry-front">
                                              <b>Visit Name</b> :
                                            </h4>
                                          </div>
                                          <div style={{ paddingBottom: "2px", borderBottom: "unset", textAlign: "left" }}>
                                            <h4
                                              className="inquiry-front"
                                              style={{ wordWrap: "break-word", width: "100px" }}
                                            >
                                              {item.visit_type}
                                            </h4>
                                          </div>
                                        </div>

                                        <div className="d-flex">
                                          <div style={{ paddingBottom: "2px", borderBottom: "unset" }}>
                                            <h4 className="inquiry-front">
                                              <b>Remark</b> :
                                            </h4>
                                          </div>
                                          <div style={{ paddingBottom: "2px", borderBottom: "unset", textAlign: "left" }}>
                                            <h4
                                              className="inquiry-front"
                                              style={{ wordWrap: "break-word", width: "200px" }}
                                            >
                                              {item.remark ? item.remark : ""}
                                            </h4>
                                          </div>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="d-flex align-items-center justify-content-end">
                                      <div>
                                        {item.id === -1 ? (
                                          <span></span>
                                        ) : (
                                          <>
                                            <div style={{ display: "flex", gap: "8px", alignItems: "center", justifyContent: "flex-end" }}>
                                             

                                              {item.visit_image && (
                                                <button
                                                  className="icon-more"
                                                  onClick={() => handleChangeImgViewer(item.visit_image)}
                                                >
                                                  <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#1f1f1f">
                                                    <path d="M480-320q75 0 127.5-52.5T660-500q0-75-52.5-127.5T480-680q-75 0-127.5 52.5T300-500q0 75 52.5 127.5T480-320Zm0-72q-45 0-76.5-31.5T372-500q0-45 31.5-76.5T480-608q45 0 76.5 31.5T588-500q0 45-31.5 76.5T480-392Zm0 192q-146 0-266-81.5T40-500q54-137 174-218.5T480-800q146 0 266 81.5T920-500q-54 137-174 218.5T480-200Zm0-300Zm0 220q113 0 207.5-59.5T832-500q-50-101-144.5-160.5T480-720q-113 0-207.5 59.5T128-500q50 101 144.5 160.5T480-280Z" />
                                                  </svg>
                                                </button>
                                              )}

                                               <button
                                                className="icon-more"
                                                onClick={() => toggleDropdownVisit(item.id)}
                                              >
                                                <svg
                                                  xmlns="http://www.w3.org/2000/svg"
                                                  viewBox="0 0 19 20"
                                                  width="19"
                                                  height="20"
                                                  className="hide animate__animated animate__fadeInUp"
                                                >
                                                  <path
                                                    fill="currentColor"
                                                    d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                                  ></path>
                                                </svg>
                                              </button>
                                            </div>

                                            <div style={{ clear: "both" }}></div>

                                            <ul
                                              className={`labelDropLeft ${hasIdAvail === item.id && visitDropdown
                                                ? "isVisible"
                                                : "isHidden"
                                                }`}
                                              id="dropLeft"
                                              ref={(el) => (dropdownContactRef.current[item.id] = el)}
                                              style={{ width: "126px", marginLeft: "0%", marginTop: "0%" }}
                                            >
                                              <li
                                                className="listItem text-start"
                                                role="button"
                                                onClick={openDeleteModel}
                                              >
                                                Delete
                                              </li>
                                              {item.end_date == null && (
                                                <li
                                                  className="listItem text-start"
                                                  role="button"
                                                  onClick={() => handleEdit(item, "createEdit")}
                                                >
                                                  Stop Visit
                                                </li>
                                              )}
                                            </ul>

                                            <div className="text-end">
                                              <p className="contact-text">
                                                {item.created_date_time
                                                  ? convertDateTimeFormat(item.created_date_time).date
                                                  : ""}
                                              </p>
                                              <p className="contact-text">
                                                {item.created_date_time
                                                  ? convertDateTimeFormat(item.created_date_time).time
                                                  : ""}
                                              </p>
                                            </div>
                                          </>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </button>
                              </div>

                            ))}
                        </div>
                      </>
                    )}
                  </div>
                ) : (
                  <p className="text-danger p-1">{DEFAULT_MESSAGE_ERROR_PERMISSION}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {/* Image viewer modal */}
      {imageViewerUrl && (
        <div
          className="image-viewer-overlay"
          onClick={handleCloseImageViewer}
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            backgroundColor: "rgba(0, 0, 0, 0.8)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 9999,
          }}
        >
          <div
            style={{
              position: "relative",
              textAlign: "center",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={imageViewerUrl}
              alt="Full Preview"
              style={{
                width: "500px",

                borderRadius: "10px",
              }}
            />
            <div>
              <a
                href={imageViewerUrl}
                download
                className="btn btn-sm btn-light"
                style={{
                  marginTop: "10px",
                  display: "inline-block",
                }}
              >
                Download Image
              </a>
            </div>
          </div>
        </div>
      )}

      {isDeleteConfirmation && (
        <ConfirmationModal
          show={isDeleteConfirmation}
          onHide={() => setIsDeleteConfirmation(false)}
          handleSubmit={() =>
            handleDeleteVisit(
              hasIdAvail,
              setIsDeleteConfirmation,
              setLoading,
              setVisitList
            )
          }
          title={"Delete this Visit"}
          message={"Are You Sure You Want To Delete This Visit?"}
          btn1="CANCEL"
          btn2="DELETE"
        />
      )}

      {isOpenCreateModel && (
        <CreateVisitView
          show={isOpenCreateModel}
          createEditFlag={createEditStatusFlag}
          onHide={() => setIsCreateModel(false)}
          visitToEdit={undefined}
          headerName="Create Visit"
          setRefreshVisit={setRefreshProduct}
        />
      )}

      {isOpenEditModel && (
        <CreateVisitView
          show={isOpenEditModel}
          createEditFlag={createEditStatusFlag}
          onHide={() => setIsOpenEditModel(false)}
          visitToEdit={editVisitItem}
          headerName="Stop Visit"
          setRefreshVisit={setRefreshProduct}
        />
      )}

      {isOpenStatusModel && (
        <CreateVisitView
          show={isOpenStatusModel}
          onHide={() => setIsOpenStatusModel(false)}
          visitToEdit={editVisitStatusItem}
          headerName={`${statusFlag} Status`}
          setRefreshVisit={setRefreshProduct}
          status={statusFlag}
        />
      )}
    </>
  );
};

export default VisitView;