import { toast } from "react-toastify";
import { TReactSetState } from "../../../../../helpers/AppType";
import {axiosInstance, axiosInstanceFormData} from "../../../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import { checkDuplication } from "../../../../../common/SharedFunction";
import axios from "axios";

export interface IVisitView {
  visit_image: string;
  end_date: string;
  id: number;
  created_date_time?: string;
  visit_type_id: string;
  amount: string;
  visit_type:string;
  remark:string;

  visitId:number;
  visit_status:number;
  status_remark: string;
  pass_amount : number;
  a_application_login_id:string | number; 
  companyFlag:number;
}


export const handleDeleteVisit = async (
  visitId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setLoading: TReactSetState<boolean>,
  setVisitList: TReactSetState<IVisitView[]>
) => {
  const requestData = {
    table: "visits",
    where: `{"id":${visitId}}`, 
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID")
  try {
    const data = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        fetchVisitApi(setVisitList,setLoading , "");
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};


export const fetchVisitApi = async (
  setVisitList: TReactSetState<IVisitView[]>,
  setLoading: TReactSetState<boolean>,
  term:string
) => {
  const token = await localStorage.getItem("token");

  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    a_application_login_id: getUUID,
    searchTerm:term
  };
  try {
    const data = await axiosInstance.post("get-visit", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,

      },
    });
    if(data.status === 200){
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false)
      setVisitList([]);
    }
    setLoading(true)    
    setVisitList(data.data.data.item);
  }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};

export const fetchVisitTypeApiForVisits = async (
  setCategoryList: TReactSetState<[]>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "visit_type_masters",
    columns: "id,visit_name",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
    a_application_login_id:getUUID
  };
  try {
    const response = await axiosInstance.post("commonGet", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );

    setCategoryList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setCategoryList([]);
  }
};



