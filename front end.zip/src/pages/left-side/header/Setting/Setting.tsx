import React, { SetStateAction, useState } from "react";
import Security from "./Security";
import Wallpaper from "./Wallpaper";
import RequestAccountInfo from "./RequestAccountInfo";
import Help from "./Help";
import ConfirmationModal from "../../../../components/model/ConfirmationModal";
import ProfileSetting from "./ProfileSetting";
import Notifications from "./Notifications";
import Privacy from "./Privacy";
import { fetchCompanyKeyApi, ICompany, ILoginData } from "../../LeftSideController";
import SourceOfTypes from "./source-of-types/SourceOfTypes";
import LabelView from "./label/LabelView";
import CategoryView from "./category/CategoryView";
import ProductView from "./product/ProductView";
import PriceListView from "./priceList/PriceListView";
import StageStatusView from "./stage-status/StageStatusView";
import CustomInquiryFromView from "./custom-inquiry-from/CustomInquiryFromView";
import WorkFlowAutomationView from "./work-flow-automation/WorkFlowAutomationView";
import MainSettingsView from "./main-settings/MainSettingsView";
import TargetVsIncentiveView from "./target-vs-incentive/TargetVsIncentiveView";
import ExpenseTypeView from "./expense-type/ExpenseTypeView";
import ExpenseView from "./expense/ExpenseView";
import VisitTypeView from "./visit-type/VisitTypeView";
import VisitView from "./visits/VisitView";
import MachineManagement from "./machineManagement/Machine-managementView";
import DepartmentView from "./department/DepartmentView";
import { openInNewTab } from "../../../../common/SharedFunction";
import useCheckUserPermission from "../../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../../helpers/AppEnum";
import { toast } from "react-toastify";
import { DEFAULT_MESSAGE_ERROR_PERMISSION } from "../../../../helpers/AppConstants";
import ListCompanyView from "../../list-company/ListCompanyView";
import ListMyCompanyView from "../../list-company/MyCompanyList";
import ListInquiryView from "../../../right-side/list-inquiry/ListInquiryView";
import ListReminderView from "../list-reminder/ListReminderView";

interface IPropsSetting {
  isSettingOpen: boolean;
  closeSettings: () => void;
  profileDetail?: ILoginData;
}

const Setting = ({
  isSettingOpen,
  closeSettings,
  profileDetail,
}: IPropsSetting) => {
  const [optionConfirmation, setOptionConfirmation] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showopenNotification, setShownNotification] = useState(false);
  const [showPrivacy, setShownPrivacy] = useState(false);
  const [showSecurity, setShowSecurity] = useState(false);
  const [showWallpaper, setShowWallpaper] = useState(false);
  const [showRequest, setShowRequest] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showopenSourceOfType, setshowopenSourceOfType] = useState(false);
  const [label, setLabel] = useState(false);
  const [showCategory, setShowCategory] = useState(false);
  const [showProduct, setShowProduct] = useState(false);
  const [showPriceList, setShowPriceList] = useState(false);
  const [showopenStageStatus, setshowopenStageStatus] = useState(false);
  const [showOpenCustomInquiry, setShowOpenCustomInquiry] = useState(false);
  const [showOpenWorkFlow, setShowOpenWorkFlow] = useState(false);
  const [showOpenSetting, setShowOpenSetting] = useState(false);
  const [showTargetVsIncentive, setTargetVsIncentive] = useState(false);
  const [showExpenseType, setShowExpenseType] = useState(false);
  // const [showExpense, setShowExpense] = useState(false);
  const [showVisitType, setShowVisitType] = useState(false);
  // const [showVisit, setShowVisit] = useState(false);
  const [showMachineManagement, setShowMachineManagement] = useState(false);
  const [showDepartment, setShowDepartment] = useState(false);
  const [showListCompany, setShowListCompany] = useState(false);
  const [showListMyCompany, setShowListMyCompany] = useState(false);
  const [companyLists, setCompanyLists] = useState<ICompany>();
  const [showListAllInquiry, setShowListAllInquiry] = useState(false);
    const [showListAllReminder, setShowListAllReminder] = useState(false);
  
  const openMyCompanyList = async () => {
    try {
      await fetchCompanyKeyApi(setCompanyLists);
    } catch (error: any) { }
    setShowListMyCompany(true);
  };
  function openreminder() {
    setShowListAllReminder(true);
  };
  function openCompany() {
    setShowListCompany(true);
  };
  function openProfile() {
    setShowProfile(true);
  }
  function openNotifications() {
    setShownNotification(true);
  }
  function openPrivacy() {
    setShownPrivacy(true);
  }

  function openSecurity() {
    setShowSecurity(true);
  }

  function openWallpaper() {
    setShowWallpaper(true);
  }
  function openRequest() {
    setShowRequest(true);
  }
  function openHelp() {
    setShowHelp(true);
  }

  function openSourceOfType() {
    setshowopenSourceOfType(true);
  }
  function openLabel() {
    setLabel(true);
  }
  function openCategory() {
    setShowCategory(true);
  }

  function openProduct() {
    setShowProduct(true);
  }
  function openPriceList() {
    setShowPriceList(true);
  }
  function openStageStatus() {
    setshowopenStageStatus(true);
  }
  function openExpenseType() {
    setShowExpenseType(true);
  }
  // function openExpense() {
  //   setShowExpense(true);
  // }
  function openVisitType() {
    setShowVisitType(true);
  }
  // function openVisit() {
  //   setShowVisit(true);
  // }
  function openCustomInquiryForm() {
    setShowOpenCustomInquiry(true);
  }
  function openWorkFlowAutoMation() {
    if (canViewWorkflowAutomation) {
      setShowOpenWorkFlow(true);
    } else {
      setShowOpenWorkFlow(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }
  function machineManagement() {
    setShowMachineManagement(true);
  }
  function department() {
    setShowDepartment(true);
  }
  function openSetting() {
    setShowOpenSetting(true);
  }
  function openTargetVsIncentive() {
    setTargetVsIncentive(true);
  }

  const canViewWorkflowAutomation = useCheckUserPermission(
    PAGE_ID.WORKFLOW_AUTOMATION,
    PERMISSION_TYPE.VIEW
  );
  function setNoDataFound1(value: SetStateAction<boolean>): void {
    throw new Error("Function not implemented.");
  }

  return (
    <>
      {showProfile ||
       showListCompany ||
        showListMyCompany ||
        showListAllInquiry ||
        showListAllReminder||
        showopenNotification ||
        showPrivacy ||
        showSecurity ||
        showWallpaper ||
        showRequest ||
        showopenSourceOfType ||
        label ||
        showHelp ||
        showPriceList ||
        showopenStageStatus ||
        showCategory ||
        showOpenCustomInquiry ||
        showOpenWorkFlow ||
        showOpenSetting ||
        showProduct ||
        showTargetVsIncentive ||
        showMachineManagement ||
        showDepartment ||
        showExpenseType ||
        // showExpense ||
       
        showVisitType ? (
        <>
          <ProfileSetting
            isProfileOpen={showProfile}
            closeProfile={() => setShowProfile(false)}
            profileDetail={profileDetail}
          />
          <ListCompanyView
            isCompanyOpen={showListCompany}
            closeCompany={() => setShowListCompany(false)}
          />
             <ListMyCompanyView
            isCompanyOpen={showListMyCompany}
            closeCompany={() => setShowListMyCompany(false)}
            companyInfo={companyLists}
          />
          {showListAllInquiry&&
          <ListInquiryView
            isListInquiry={showListAllInquiry}
            closeListInquiry={() => setShowListAllInquiry(false)}
            isModelOpen={"InquiryAllList"}
            setNoDataFound1={setNoDataFound1}
          />
}
          <ListReminderView
                              isReminderOpen={showListAllReminder}
                              closeReminder={() => setShowListAllReminder(false)}
                            />
          <LabelView
            isLableView={label}
            closeLabelView={() => setLabel(false)}
          />
          <SourceOfTypes
            isSourceOfTypeOpen={showopenSourceOfType}
            closeSourceOfType={() => setshowopenSourceOfType(false)}
          />
          <Notifications
            isNotificationOpen={showopenNotification}
            closeNotifications={() => setShownNotification(false)}
          />
          <Privacy
            isPrivayOpen={showPrivacy}
            closePrivacy={() => setShownPrivacy(false)}
          />
          <Security
            isSecurityOpen={showSecurity}
            closeSecurity={() => setShowSecurity(false)}
          />
          <Wallpaper
            isWallpaperOpen={showWallpaper}
            closeWallpaper={() => setShowWallpaper(false)}
          />
          <RequestAccountInfo
            isRequestOpen={showRequest}
            closeRequest={() => setShowRequest(false)}
          />
          <Help isHelpOpen={showHelp} closeHelp={() => setShowHelp(false)} />
          <CategoryView
            isCategoryView={showCategory}
            closeCategoryView={() => setShowCategory(false)}
          />
          <MachineManagement
            isMachineView={showMachineManagement}
            closeMachineView={() => setShowMachineManagement(false)}
          />
          <DepartmentView
            isCategoryView={showDepartment}
            closeCategoryView={() => setShowDepartment(false)}
          />
          <ProductView
            isProductView={showProduct}
            closeProductView={() => setShowProduct(false)}
          />
          <TargetVsIncentiveView
            isTargetVsIncentiveView={showTargetVsIncentive}
            closeTargetVsIncentiveView={() => setTargetVsIncentive(false)}
          />
          <PriceListView
            isPriceListView={showPriceList}
            closePriceListView={() => setShowPriceList(false)}
          />
          <StageStatusView
            isStageStatusView={showopenStageStatus}
            closeStageStatusView={() => setshowopenStageStatus(false)}
          />
          <ExpenseTypeView
            isExpenseTypeView={showExpenseType}
            closeExpenseTypeView={() => setShowExpenseType(false)}
          />
          {/* <ExpenseView
            isExpenseView={showExpense}
            closeExpenseView={() => setShowExpense(false)}
          /> */}
          <VisitTypeView
            isVisitTypeView={showVisitType}
            closeVisitTypeView={() => setShowVisitType(false)}
          />
          {/* <VisitView
            isVisitView={showVisit}
            closeVisitView={() => setShowVisit(false)}
          /> */}
          <CustomInquiryFromView
            isCustomInquiryFromView={showOpenCustomInquiry}
            closeCustomInquiryFromView={() => setShowOpenCustomInquiry(false)}
          />
          <WorkFlowAutomationView
            isWorkFlowView={showOpenWorkFlow}
            closeWorkFlowView={() => setShowOpenWorkFlow(false)}
          />
          <MainSettingsView
            isMainSettingView={showOpenSetting}
            closeMainSettingView={() => setShowOpenSetting(false)}
          />
       
        </>
      ) : (
        <>
          {isSettingOpen ? (
            <div
              className="settings animate__animated animate__fadeInLeft"
              id="settings"
            >
              {/* <!-- Header --> */}
              <div className="header-Chat">
                {/* <!-- Icons --> */}
                <div className="ICON">
                  <button className="icons" onClick={closeSettings}>
                    <span className="" title="Back">
                      <svg
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        className=""
                      >
                        <path
                          fill="currentColor"
                          d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                        ></path>
                      </svg>
                    </span>
                  </button>
                </div>

                <div
                  className="newText d-flex justify-content-between"
                  style={{ width: "100%" }}
                >
                  <h2>Settings</h2>

                  <span>
                    <p
                      className="landing-page-text text-end"
                      style={{
                        cursor: "pointer",
                        color: "white",
                        float: "right",
                        fontSize: "13px",
                      }}
                      onClick={() => openInNewTab("/videoTutorial", 4)}
                    >
                      Learn More :{" "}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="24px"
                        fill="#FFFFFF"
                      >
                        <path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" />
                      </svg>
                    </p>
                  </span>
                  {/* <div style={{clear: "both"}}>
                  
                              </div> */}
                </div>
              </div>
              {/* <!-- Chats --> */}
              <div className="chats-settings">
                {/* <!-- Profile --> */}
                <div className="top" onClick={openProfile}>
                  {/* <!-- Img --> */}
                  <div className="imgBox">
                    {profileDetail?.profile_pic ? (
                      <img
                        src={`${profileDetail?.profile_pic}`}
                        alt=""
                        className="cover"
                      />
                    ) : (
                      <img
                        src={require("../../../../assets/images/no_image.jpeg")}
                        alt=""
                        className="cover"
                      />
                    )}
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4>{profileDetail?.username}</h4>
                    </div>
                    <div className="message">
                      <p>{profileDetail?.recovery_mobile}</p>
                    </div>
                  </div>
                </div>
                <div className="block" onClick={openCompany}>
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Product Category"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="m260-520 220-360 220 360H260ZM700-80q-75 0-127.5-52.5T520-260q0-75 52.5-127.5T700-440q75 0 127.5 52.5T880-260q0 75-52.5 127.5T700-80Zm-580-20v-320h320v320H120Zm580-60q42 0 71-29t29-71q0-42-29-71t-71-29q-42 0-71 29t-29 71q0 42 29 71t71 29Zm-500-20h160v-160H200v160Zm202-420h156l-78-126-78 126Zm78 0ZM360-340Zm340 80Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="My Company" aria-label="My Company">
                        My Company
                      </h4>
                    </div>
                  </div>
                </div>
                <div className="block" onClick={openMyCompanyList}>
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Product Category"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                 <path d="M0-240v-63q0-43 44-70t116-27q13 0 25 .5t23 2.5q-14 21-21 44t-7 48v65H0Zm240 0v-65q0-32 17.5-58.5T307-410q32-20 76.5-30t96.5-10q53 0 97.5 10t76.5 30q32 20 49 46.5t17 58.5v65H240Zm540 0v-65q0-26-6.5-49T754-397q11-2 22.5-2.5t23.5-.5q72 0 116 26.5t44 70.5v63H780Zm-455-80h311q-10-20-55.5-35T480-370q-55 0-100.5 15T325-320ZM160-440q-33 0-56.5-23.5T80-520q0-34 23.5-57t56.5-23q34 0 57 23t23 57q0 33-23 56.5T160-440Zm640 0q-33 0-56.5-23.5T720-520q0-34 23.5-57t56.5-23q34 0 57 23t23 57q0 33-23 56.5T800-440Zm-320-40q-50 0-85-35t-35-85q0-51 35-85.5t85-34.5q51 0 85.5 34.5T600-600q0 50-34.5 85T480-480Zm0-80q17 0 28.5-11.5T520-600q0-17-11.5-28.5T480-640q-17 0-28.5 11.5T440-600q0 17 11.5 28.5T480-560Zm1 240Zm-1-280Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="My Team" aria-label="My Team">
                        My Team
                      </h4>
                    </div>
                  </div>
                </div>
                <div className="block" onClick={() => setShowListAllInquiry(true)}>
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Product Category"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                         <path d="M280-600v-80h560v80H280Zm0 160v-80h560v80H280Zm0 160v-80h560v80H280ZM160-600q-17 0-28.5-11.5T120-640q0-17 11.5-28.5T160-680q17 0 28.5 11.5T200-640q0 17-11.5 28.5T160-600Zm0 160q-17 0-28.5-11.5T120-480q0-17 11.5-28.5T160-520q17 0 28.5 11.5T200-480q0 17-11.5 28.5T160-440Zm0 160q-17 0-28.5-11.5T120-320q0-17 11.5-28.5T160-360q17 0 28.5 11.5T200-320q0 17-11.5 28.5T160-280Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="All Inquiries" aria-label="All Inquiries">
                        All Inquiries
                      </h4>
                    </div>
                  </div>
                </div>
                {/* category */}
                <div className="block" onClick={openreminder}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                    <span title="Reminder">
                          <svg
                            height="24px"
                            viewBox="0 -960 960 960"
                            width="24px"
                            fill="currentColor"
                          >
                            <path d="m612-292 56-56-148-148v-184h-80v216l172 172ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 320q133 0 226.5-93.5T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160Z" />
                          </svg>
                        </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="All Reminders" aria-label="All Reminders">
                        All Reminders
                      </h4>
                    </div>
                  </div>
                </div>
                <div className="block" onClick={openCategory}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Product Category"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="m260-520 220-360 220 360H260ZM700-80q-75 0-127.5-52.5T520-260q0-75 52.5-127.5T700-440q75 0 127.5 52.5T880-260q0 75-52.5 127.5T700-80Zm-580-20v-320h320v320H120Zm580-60q42 0 71-29t29-71q0-42-29-71t-71-29q-42 0-71 29t-29 71q0 42 29 71t71 29Zm-500-20h160v-160H200v160Zm202-420h156l-78-126-78 126Zm78 0ZM360-340Zm340 80Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Category" aria-label="Category">
                        Product Category
                      </h4>
                    </div>
                  </div>
                </div>
                {/* category */}

                {/* Product */}
                <div className="block" onClick={openProduct}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Product"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M280-80q-33 0-56.5-23.5T200-160q0-33 23.5-56.5T280-240q33 0 56.5 23.5T360-160q0 33-23.5 56.5T280-80Zm400 0q-33 0-56.5-23.5T600-160q0-33 23.5-56.5T680-240q33 0 56.5 23.5T760-160q0 33-23.5 56.5T680-80ZM246-720l96 200h280l110-200H246Zm-38-80h590q23 0 35 20.5t1 41.5L692-482q-11 20-29.5 31T622-440H324l-44 80h480v80H280q-45 0-68-39.5t-2-78.5l54-98-144-304H40v-80h130l38 80Zm134 280h280-280Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Product" aria-label="Product">
                        Product
                      </h4>
                    </div>
                  </div>
                </div>
                {/* Product */}
                
                {/* Price List */}
                <div className="block" onClick={openPriceList}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Price List"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M240-80q-50 0-85-35t-35-85v-120h120v-560h600v680q0 50-35 85t-85 35H240Zm480-80q17 0 28.5-11.5T760-200v-600H320v480h360v120q0 17 11.5 28.5T720-160ZM360-600v-80h360v80H360Zm0 120v-80h360v80H360ZM240-160h360v-80H200v40q0 17 11.5 28.5T240-160Zm0 0h-40 400-360Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Price List" aria-label="Price List">
                        Price List
                      </h4>
                    </div>
                  </div>
                </div>
                {/* Price List */}
                {/* source of type */}
                <div className="block" onClick={openSourceOfType}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Source"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M480-120q-151 0-255.5-46.5T120-280v-400q0-66 105.5-113T480-840q149 0 254.5 47T840-680v400q0 67-104.5 113.5T480-120Zm0-479q89 0 179-25.5T760-679q-11-29-100.5-55T480-760q-91 0-178.5 25.5T200-679q14 30 101.5 55T480-599Zm0 199q42 0 81-4t74.5-11.5q35.5-7.5 67-18.5t57.5-25v-120q-26 14-57.5 25t-67 18.5Q600-528 561-524t-81 4q-42 0-82-4t-75.5-11.5Q287-543 256-554t-56-25v120q25 14 56 25t66.5 18.5Q358-408 398-404t82 4Zm0 200q46 0 93.5-7t87.5-18.5q40-11.5 67-26t32-29.5v-98q-26 14-57.5 25t-67 18.5Q600-328 561-324t-81 4q-42 0-82-4t-75.5-11.5Q287-343 256-354t-56-25v99q5 15 31.5 29t66.5 25.5q40 11.5 88 18.5t94 7Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Source of Type" aria-label="Source of Type">
                        Source
                      </h4>
                    </div>
                  </div>
                </div>
                {/* source of type */}
                {/* Label */}
                <div className="block" onClick={openLabel}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Label"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h440q19 0 36 8.5t28 23.5l216 288-216 288q-11 15-28 23.5t-36 8.5H160Zm0-80h440l180-240-180-240H160v480Zm220-240Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Label" aria-label="Label">
                        Label
                      </h4>
                    </div>
                  </div>
                </div>
                {/* Label */}

                {/* Stage Status List */}
                <div className="block" onClick={openStageStatus}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Status"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M160-120q-33 0-56.5-23.5T80-200v-560q0-33 23.5-56.5T160-840h640q33 0 56.5 23.5T880-760v560q0 33-23.5 56.5T800-120H160Zm0-80h640v-560H160v560Zm40-80h200v-80H200v80Zm382-80 198-198-57-57-141 142-57-57-56 57 113 113Zm-382-80h200v-80H200v80Zm0-160h200v-80H200v80Zm-40 400v-560 560Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Status" aria-label="Price List">
                        Status
                      </h4>
                    </div>
                  </div>
                </div>
                {/* expense type */}
                <div className="block" onClick={openExpenseType}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Expense Type"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v240H160v240h400v80H160Zm0-480h640v-80H160v80ZM760-80v-120H640v-80h120v-120h80v120h120v80H840v120h-80ZM160-240v-480 480Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="ExpenseType" aria-label="ExpenseType">
                        Expense Type
                      </h4>
                    </div>
                  </div>
                </div>
                {/* expense type */}
                {/* expense type */}
                {/* <div className="block" onClick={openExpense}>
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Expense"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M200-200v-560 560Zm0 80q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v100h-80v-100H200v560h560v-100h80v100q0 33-23.5 56.5T760-120H200Zm320-160q-33 0-56.5-23.5T440-360v-240q0-33 23.5-56.5T520-680h280q33 0 56.5 23.5T880-600v240q0 33-23.5 56.5T800-280H520Zm280-80v-240H520v240h280Zm-160-60q25 0 42.5-17.5T700-480q0-25-17.5-42.5T640-540q-25 0-42.5 17.5T580-480q0 25 17.5 42.5T640-420Z" />
                        </svg>
                      </span>
                    </button>
                  </div>

                  <div className="h-text">
                    <div className="head">
                      <h4 title="Expense" aria-label="Expense">
                        Expense
                      </h4>
                    </div>
                  </div>
                </div> */}
                <div className="block" onClick={openVisitType}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Visit Type"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M519-82v-80q42-6 81.5-23t74.5-43l58 58q-47 37-101 59.5T519-82Zm270-146-56-56q26-33 42-72.5t22-83.5h82q-8 62-30.5 115.5T789-228Zm8-292q-6-45-22-84.5T733-676l56-56q38 44 61.5 98T879-520h-82ZM439-82q-153-18-255.5-131T81-480q0-155 102.5-268T439-878v80q-120 17-199 107t-79 211q0 121 79 210.5T439-162v80Zm238-650q-36-27-76-44t-82-22v-80q59 5 113 27.5T733-790l-56 58ZM480-280q-58-49-109-105t-51-131q0-68 46.5-116T480-680q67 0 113.5 48T640-516q0 75-51 131T480-280Zm0-200q18 0 30.5-12.5T523-523q0-17-12.5-30T480-566q-18 0-30.5 13T437-523q0 18 12.5 30.5T480-480Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="VisitType" aria-label="VisitType">
                        Visit Type
                      </h4>
                    </div>
                  </div>
                </div>
                {/* Target Vs incentive */}
                <div className="block" onClick={openTargetVsIncentive}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Target Vs incentive"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-80q-100 0-170-70t-70-170q0-100 70-170t170-70q100 0 170 70t70 170q0 100-70 170t-170 70Zm0-80q66 0 113-47t47-113q0-66-47-113t-113-47q-66 0-113 47t-47 113q0 66 47 113t113 47Zm0-80q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4
                        title="Target Vs incentive"
                        aria-label="Target Vs incentive"
                      >
                        Target Vs incentive
                      </h4>
                    </div>
                  </div>
                </div>
                {/* Target Vs incentive */}
                {/* <div className="block" onClick={openVisit}>
                  
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Visits"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M400-400h160v-80H400v80Zm0-120h320v-80H400v80Zm0-120h320v-80H400v80Zm-80 400q-33 0-56.5-23.5T240-320v-480q0-33 23.5-56.5T320-880h480q33 0 56.5 23.5T880-800v480q0 33-23.5 56.5T800-240H320Zm0-80h480v-480H320v480ZM160-80q-33 0-56.5-23.5T80-160v-560h80v560h560v80H160Zm160-720v480-480Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                 
                  <div className="h-text">
                    <div className="head">
                      <h4 title="ExpenseType" aria-label="ExpenseType">
                        Visits
                      </h4>
                    </div>
                  </div>
                </div> */}
                {/* expense */}
                {/* custom Field Form */}
                 {/* Department */}
                <div className="block" onClick={department}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Department"
                      >
                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="m260-520 220-360 220 360H260ZM700-80q-75 0-127.5-52.5T520-260q0-75 52.5-127.5T700-440q75 0 127.5 52.5T880-260q0 75-52.5 127.5T700-80Zm-580-20v-320h320v320H120Zm580-60q42 0 71-29t29-71q0-42-29-71t-71-29q-42 0-71 29t-29 71q0 42 29 71t71 29Zm-500-20h160v-160H200v160Zm202-420h156l-78-126-78 126Zm78 0ZM360-340Zm340 80Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Department" aria-label="Department">
                        Department
                      </h4>
                    </div>
                  </div>
                </div>
                <div className="block" onClick={openCustomInquiryForm}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="custom Field Form"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="M200-520q-33 0-56.5-23.5T120-600v-160q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v160q0 33-23.5 56.5T760-520H200Zm0-80h560v-160H200v160Zm0 480q-33 0-56.5-23.5T120-200v-160q0-33 23.5-56.5T200-440h560q33 0 56.5 23.5T840-360v160q0 33-23.5 56.5T760-120H200Zm0-80h560v-160H200v160Zm0-560v160-160Zm0 400v160-160Z" />
                        </svg>
                      </span>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Custom Field Form">Custom Field Form</h4>
                    </div>
                  </div>
                </div>
                {/* Work Flow Automation */}

                <div className="block" onClick={openWorkFlowAutoMation}>
                  {/* <!-- Img --> */}
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="24px"
                        fill="currentColor"
                      >
                        <path d="M296-270q-42 35-87.5 32T129-269q-34-28-46.5-73.5T99-436l75-124q-25-22-39.5-53T120-680q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47q-9 0-18-1t-17-3l-77 130q-11 18-7 35.5t17 28.5q13 11 31 12.5t35-12.5l420-361q42-35 88-31.5t80 31.5q34 28 46 73.5T861-524l-75 124q25 22 39.5 53t14.5 67q0 66-47 113t-113 47q-66 0-113-47t-47-113q0-66 47-113t113-47q9 0 17.5 1t16.5 3l78-130q11-18 7-35.5T782-630q-13-11-31-12.5T716-630L296-270Zm-16-330q33 0 56.5-23.5T360-680q0-33-23.5-56.5T280-760q-33 0-56.5 23.5T200-680q0 33 23.5 56.5T280-600Zm400 400q33 0 56.5-23.5T760-280q0-33-23.5-56.5T680-360q-33 0-56.5 23.5T600-280q0 33 23.5 56.5T680-200ZM280-680Zm400 400Z" />
                      </svg>
                    </button>
                  </div>
                  {/* <!-- Text --> */}
                  <div className="h-text">
                    <div className="head">
                      <h4 title="Work Flow Automation">Work Flow Automation</h4>
                    </div>
                  </div>
                </div>
                {/* Machine Management */}
                {/* <div className="block" onClick={machineManagement}>

                  <div className="icon-Box">
                    <button className="icons-setings">
                      <span
                        data-icon="settings-notifications"
                        className=""
                        title="Machine Management"
                      >

                        <svg
                          height="24px"
                          viewBox="0 -960 960 960"
                          width="24px"
                          fill="currentColor"
                        >
                          <path d="m260-520 220-360 220 360H260ZM700-80q-75 0-127.5-52.5T520-260q0-75 52.5-127.5T700-440q75 0 127.5 52.5T880-260q0 75-52.5 127.5T700-80Zm-580-20v-320h320v320H120Zm580-60q42 0 71-29t29-71q0-42-29-71t-71-29q-42 0-71 29t-29 71q0 42 29 71t71 29Zm-500-20h160v-160H200v160Zm202-420h156l-78-126-78 126Zm78 0ZM360-340Zm340 80Z" />
                        </svg>
                      </span>
                    </button>
                  </div>

                  <div className="h-text">
                    <div className="head">
                      <h4
                        title="Machine Management"
                        aria-label="Machine Management"
                      >
                        Machine Management
                      </h4>
                    </div>
                  </div>
                </div> */}
                {/* Machine Management */}
               
                <div className="block" onClick={openSetting}>
                  <div className="icon-Box">
                    <button className="icons-setings">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="24px"
                        fill="currentColor"
                      >
                        <path d="m370-80-16-128q-13-5-24.5-12T307-235l-119 50L78-375l103-78q-1-7-1-13.5v-27q0-6.5 1-13.5L78-585l110-190 119 50q11-8 23-15t24-12l16-128h220l16 128q13 5 24.5 12t22.5 15l119-50 110 190-103 78q1 7 1 13.5v27q0 6.5-2 13.5l103 78-110 190-118-50q-11 8-23 15t-24 12L590-80H370Zm70-80h79l14-106q31-8 57.5-23.5T639-327l99 41 39-68-86-65q5-14 7-29.5t2-31.5q0-16-2-31.5t-7-29.5l86-65-39-68-99 42q-22-23-48.5-38.5T533-694l-13-106h-79l-14 106q-31 8-57.5 23.5T321-633l-99-41-39 68 86 64q-5 15-7 30t-2 32q0 16 2 31t7 30l-86 65 39 68 99-42q22 23 48.5 38.5T427-266l13 106Zm42-180q58 0 99-41t41-99q0-58-41-99t-99-41q-59 0-99.5 41T342-480q0 58 40.5 99t99.5 41Zm-2-140Z" />
                      </svg>
                    </button>
                  </div>

                  <div className="h-text">
                    <div className="head">
                      <h4 title="Settings">Notification-Settings</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            ""
          )}
        </>
      )}
      {optionConfirmation && (
        <ConfirmationModal
          show={optionConfirmation}
          onHide={() => setOptionConfirmation(false)}
          handleSubmit={() => "jhj"}
          title={"Choose theme"}
          btn1="CANCEL"
          btn2="OK"
          isoption={true}
          opt1={"Light"}
          opt2={"Dark"}
          opt3={"System default"}
        />
      )}
    </>
  );
};

export default Setting;
function setCompanyLists(value: SetStateAction<ICompany | undefined>): void {
  throw new Error("Function not implemented.");
}

