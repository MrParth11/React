import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import {axiosInstance} from "../../../../../services/axiosInstance";
import { TReactSetState } from "../../../../../helpers/AppType";
import { checkDuplication, checkDuplicationUpdate } from "../../../../../common/SharedFunction";

export interface ILabelView {
  lable_name: string;
  id: number;
  color: string | undefined | null;
}
export interface ILabelCreate {
  lable_name: string;
  color: string | undefined | null;
}

interface IAddLabelObj {
  lable_name: string;
  color: string | undefined | null;
}
export const handleDeleteLabel = async (
  labelId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setLabelList: TReactSetState<ILabelView[]>,
  setLoading: TReactSetState<boolean>,
) => {
  const requestData = {
    table: "lable_masters",
    where: `{"id":${labelId}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID")

  try {
    const data = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        fetchLabelApi(setLabelList,setLoading);
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createLabel = async (
  labelInput: IAddLabelObj,
  setLabelList: TReactSetState<ILabelView[]>,
  setLoading: TReactSetState<boolean>,
  clearFormCallback: () => void //
) => {
  if (
    !(await checkDuplication(
      labelInput.lable_name,
      "lable_masters",
      "lable_name"
    ))
  ) {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "lable_masters",
      data: `{"lable_name":"${labelInput.lable_name}","color":"${
        labelInput.color
      }","a_application_login_id":${Number(getUUID)}}`,
    };
    try {
      const { data } = await axiosInstance.post("commonCreate", requestData , 
        {
          headers: {
            "x-tenant-id": getUUID,

          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          fetchLabelApi(setLabelList,setLoading);
          toast.success(data.ack_msg);
          clearFormCallback()
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("Label already available");
  }
};

export const fetchLabelApi = async (
  setLabelList: TReactSetState<ILabelView[]>,
  setLoading: TReactSetState<boolean>,
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "lable_masters",
    columns: "id,lable_name,color",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false);
      setLabelList([]);
    }
    setLoading(true);
    setLabelList(data.data.data);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};

export const updateLabel = async (
  categoryInput: ILabelCreate,
  setCategoryList: TReactSetState<ILabelView[]>,
  setLoading: TReactSetState<boolean>,
  editLabelId: number | undefined,
  clearFormCallback: () => void //

) => {
  if (
    !(await checkDuplicationUpdate(
      categoryInput.lable_name,
      "lable_masters",
      "lable_name",
      editLabelId
    ))
  ) {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "lable_masters",
    where: `{"id":"${editLabelId}"}`,
    data: `{"lable_name":"${categoryInput.lable_name}","color":"${
      categoryInput.color
    }","a_application_login_id":${Number(getUUID)}}`,
  };
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setCategoryList((prevList) =>
          prevList.map((category) =>
            category.id === editLabelId ? data.data : category
          )
        );
        clearFormCallback()
        fetchLabelApi(setCategoryList,setLoading);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
} else {
  toast.error("Label already available");
}
};
