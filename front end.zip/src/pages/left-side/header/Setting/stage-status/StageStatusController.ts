import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import {axiosInstance} from "../../../../../services/axiosInstance";
import { TReactSetState } from "../../../../../helpers/AppType";
import {
  checkDuplication,
  checkDuplicationTwoColum,
  checkDuplicationUpdate,
  checkDuplicationUpdateTwoColum,
} from "../../../../../common/SharedFunction";

export interface IStageStatusView {
  order_type: number;
  name: string;
  id: number;
  color: string | undefined | null;
  display_order_type: number;
}

export interface IStageStatusCreate {
  name: string;
  color: string | undefined | null;
  order_type: number;
}
export interface IDisplayOrderCreate {
  display_order_type: number | string;
}
interface IAddStageStatusObj {
  name: string;
  color: string | undefined | null;
  order_type: number;
}

export const orderTypesStageList = [
  { id: "1", order_type_display: "Contact" },
  { id: "2", order_type_display: "Inquiry" },
  { id: "3", order_type_display: "Quotation" },
  { id: "4", order_type_display: "Order" },
  { id: "5", order_type_display: "Invoice" },
  { id: "6", order_type_display: "Purchase" },

];

export const handleDeleteStageStatus = async (
  stagestatusId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setStageStatusList: TReactSetState<IStageStatusView[]>,
  setLoading: TReactSetState<boolean>
) => {
  const requestData = {
    table: "stage_status_masters",
    where: `{"id":${stagestatusId}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID")
  try {
    const data = await axiosInstance.post("commonUpdate", requestData ,     {
      headers: {
        "x-tenant-id": getUUID,

      },
      });
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        fetchStageStatusApi(setStageStatusList, setLoading);
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createStageStatus = async (
  stagestatusInput: IAddStageStatusObj,
  setStageStatusList: TReactSetState<IStageStatusView[]>,
  setLoading: TReactSetState<boolean>,
  clearFormCallback: () => void //
) => {
  if (
    !(await checkDuplicationTwoColum(
      stagestatusInput.name,
      "stage_status_masters",
      "name",
      "order_type",
      stagestatusInput.order_type
    ))
  ) {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "stage_status_masters",
      data: `{"name":"${stagestatusInput.name}","color":"${
        stagestatusInput.color
      }","order_type":"${
        stagestatusInput.order_type
      }","a_application_login_id":${Number(getUUID)}}`,
    };

    try {
      const { data } = await axiosInstance.post("commonCreate", requestData , 
        {
          headers: {
            "x-tenant-id": getUUID,

          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          fetchStageStatusApi(setStageStatusList, setLoading);
          toast.success(data.ack_msg);
          clearFormCallback();
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("Stage and Status already available");
  }
};

export const fetchStageStatusApi = async (
  setStageStatusList: TReactSetState<IStageStatusView[]>,
  setLoading: TReactSetState<boolean>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "stage_status_masters",
    columns: "id,name,color,order_type,display_order_type",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false);
      setStageStatusList([]);
    }
    setLoading(true);
    setStageStatusList(data.data.data);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};

export const updateStageStatus = async (
  stagestatusInput: IStageStatusCreate,
  setStageStatusList: TReactSetState<IStageStatusView[]>,
  setLoading: TReactSetState<boolean>,
  editStageStatusId: number | undefined,
  clearForm: () => void
) => {
  if (
    !(await checkDuplicationUpdateTwoColum(
      stagestatusInput.name,
      "stage_status_masters",
      "name",
      "order_type",
      Number(stagestatusInput.order_type),
      editStageStatusId
    ))
  ) {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "stage_status_masters",
      where: `{"id":"${editStageStatusId}"}`,
      data: `{"name":"${stagestatusInput.name}","color":"${
        stagestatusInput.color
      }","order_type":"${
        stagestatusInput.order_type
      }","a_application_login_id":${Number(getUUID)}}`,
    };
    try {
      const { data } = await axiosInstance.post("commonUpdate", requestData , 
        {
          headers: {
            "x-tenant-id": getUUID,

          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          setStageStatusList((prevList) =>
            prevList.map((stagestatus) =>
              stagestatus.id === editStageStatusId ? data.data : stagestatus
            )
          );
          clearForm()
          fetchStageStatusApi(setStageStatusList, setLoading);
          toast.success(data.ack_msg);
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("Stage and Status already available");
  }
};

export const updateDisplayOrder = async (
  displayOrderInput: IDisplayOrderCreate,
  editStageStatusId: number | undefined
) => {
  const requestData = {
    table: "stage_status_masters",
    where: `{"id":"${editStageStatusId}"}`,
    data: `{"display_order_type":"${displayOrderInput.display_order_type}" }`,
  };
  const getUUID = localStorage.getItem("UUID")
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
