import { toast } from "react-toastify";
import { TReactSetState } from "../../../../../helpers/AppType";
import {axiosInstance} from "../../../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import { checkDuplication, checkDuplicationUpdate } from "../../../../../common/SharedFunction";

export interface IExpenseTypeView {
  expense_name: string;
  id: number;
  color: string | undefined | null;
  created_date_time?: string;
}

export interface IExpenseTypeCreate {
  expense_name: string;
  color: string | undefined | null;
  created_date_time?: string;
}

export const handleDeleteExpenseType = async (
  ExpenseTypeId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setExpenseTypeList: TReactSetState<IExpenseTypeView[]>,
  setLoading:TReactSetState<boolean>,
) => {
  const getUUID = localStorage.getItem("UUID")
  const requestData = {
    table: "expense_type_masters",
    where: `{"id":${ExpenseTypeId}}`,
    data: `{"isDelete":"1"}`,
    a_application_login_id:getUUID

  };
  try {
    const data = await axiosInstance.post("commonUpdate", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,
        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {

        setIsDeleteConfirmation(false);
        fetchExpenseTypeApi(setExpenseTypeList,setLoading);
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createExpenseType = async (
  expenseTypeInput: IExpenseTypeCreate,
  setExpenseTypeList: TReactSetState<IExpenseTypeView[]>,
  setLoading:TReactSetState<boolean>,
  clearFormCallback: () => void //
) => {
  if (
    !(await checkDuplication(
      expenseTypeInput.expense_name,
      "expense_type_masters",
      "expense_name"
    ))
  ) {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "expense_type_masters",
      data: `{"expense_name":"${expenseTypeInput.expense_name}","color":"${
        expenseTypeInput.color
      }","a_application_login_id":${Number(getUUID)}}`,
      a_application_login_id:getUUID

    };
    try {
      const { data } = await axiosInstance.post("commonCreate", requestData ,
        {
          headers: {
            "x-tenant-id": getUUID,
          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          fetchExpenseTypeApi(setExpenseTypeList,setLoading);
          toast.success(data.ack_msg);
          clearFormCallback();
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("Expense Type already available");
  }
};

export const updateExpenseType = async (
  expenseTypeInput: IExpenseTypeCreate,
  setExpenseTypeList: TReactSetState<IExpenseTypeView[]>,
  editExpenseTypeId: number | undefined,
  setLoading:TReactSetState<boolean>,
  clearFormCallback: () => void //

) => {
  if (
    !(await checkDuplicationUpdate(
      expenseTypeInput.expense_name,
      "expense_type_masters",
      "expense_name",
      editExpenseTypeId
    ))
  ) {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "expense_type_masters",
    where: `{"id":"${editExpenseTypeId}"}`,
    data: `{"expense_name":"${expenseTypeInput.expense_name}","color":"${
      expenseTypeInput.color
    }","a_application_login_id":${Number(getUUID)}}`,
    a_application_login_id:getUUID

  };
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,
        },
        }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          clearFormCallback()
        setExpenseTypeList((prevList) =>
          prevList.map((ExpenseType) =>
            ExpenseType.id === editExpenseTypeId ? data.data : ExpenseType
          )
        );
        fetchExpenseTypeApi(setExpenseTypeList,setLoading);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
} else {
  toast.error("Expense Type already available");
}
};

export const fetchExpenseTypeApi = async (
  setExpenseTypeList: TReactSetState<IExpenseTypeView[]>,
  setLoading: TReactSetState<boolean>,
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "expense_type_masters",
    columns: "id,expense_name,color",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
    a_application_login_id:getUUID
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,
        },
        }
    );
    console.log("data", data);
    if(data.status === 200){
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false)
      setExpenseTypeList([]);

    }
    setLoading(true)
    setExpenseTypeList(data.data.data);
  }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};
