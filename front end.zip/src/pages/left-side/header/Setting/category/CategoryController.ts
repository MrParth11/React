import { toast } from "react-toastify";
import { TReactSetState } from "../../../../../helpers/AppType";
import {axiosInstance} from "../../../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import { checkDuplication, checkDuplicationUpdate } from "../../../../../common/SharedFunction";

export interface ICategoryView {
  category_name: string;
  id: number;
  color: string | undefined | null;
  created_date_time?: string;
}

export interface ICategoryCreate {
  category_name: string;
  color: string | undefined | null;
  created_date_time?: string;
}

export const handleDeleteCategory = async (
  categoryId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setCategoryList: TReactSetState<ICategoryView[]>,
  setLoading:TReactSetState<boolean>,
) => {
  const getUUID = localStorage.getItem("UUID")
  const requestData = {
    table: "categories",
    where: `{"id":${categoryId}}`,
    data: `{"isDelete":"1"}`,
    a_application_login_id:getUUID

  };
  try {
    const data = await axiosInstance.post("commonUpdate", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {

        setIsDeleteConfirmation(false);
        fetchCategoryApi(setCategoryList,setLoading);
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createCategory = async (
  categoryInput: ICategoryCreate,
  setCategoryList: TReactSetState<ICategoryView[]>,
  setLoading:TReactSetState<boolean>,
  clearFormCallback: () => void //
) => {
  if (
    !(await checkDuplication(
      categoryInput.category_name,
      "categories",
      "category_name"
    ))
  ) {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "categories",
      data: `{"category_name":"${categoryInput.category_name}","color":"${
        categoryInput.color
      }","a_application_login_id":${Number(getUUID)}}`,
      a_application_login_id:getUUID

    };
    try {
      const { data } = await axiosInstance.post("commonCreate", requestData ,
        {
          headers: {
            "x-tenant-id": getUUID,
  
          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          fetchCategoryApi(setCategoryList,setLoading);
          toast.success(data.ack_msg);
          clearFormCallback();
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("Category already available");
  }
};

export const updateCategory = async (
  categoryInput: ICategoryCreate,
  setCategoryList: TReactSetState<ICategoryView[]>,
  editCategoryId: number | undefined,
  setLoading:TReactSetState<boolean>,
  clearFormCallback: () => void //

) => {
  if (
    !(await checkDuplicationUpdate(
      categoryInput.category_name,
      "categories",
      "category_name",
      editCategoryId
    ))
  ) {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "categories",
    where: `{"id":"${editCategoryId}"}`,
    data: `{"category_name":"${categoryInput.category_name}","color":"${
      categoryInput.color
    }","a_application_login_id":${Number(getUUID)}}`,
    a_application_login_id:getUUID

  };
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          clearFormCallback()
        setCategoryList((prevList) =>
          prevList.map((category) =>
            category.id === editCategoryId ? data.data : category
          )
        );
        fetchCategoryApi(setCategoryList,setLoading);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
} else {
  toast.error("Category already available");
}
};

export const fetchCategoryApi = async (
  setCategoryList: TReactSetState<ICategoryView[]>,
  setLoading: TReactSetState<boolean>,
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "categories",
    columns: "id,category_name,color",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
    a_application_login_id:getUUID
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    console.log("data", data);
    if(data.status === 200){
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false)
      setCategoryList([]);
    }
    setLoading(true)
    setCategoryList(data.data.data);
  }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};
