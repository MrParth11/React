import * as Yup from "yup";
import { axiosInstance } from "../../../../../services/axiosInstance";
import { DEFAULT_STATUS_CODE_SUCCESS, MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../../../../helpers/AppConstants";
import { toast } from "react-toastify";
import { TReactSetState } from "../../../../../helpers/AppType";



export interface IPersonalSettingCreate {
    id?:number;
    whatsapp_authkey: string;
    whatsapp_appkey: string;
    port_mail_setup: string;
    mail_id_setup: string;
    password_mail_setup: string;
    pop3_host:string
    incoming_port:string
    host_out_going_mail:string
  }



  export const createPersonalSettingInitialValues = (
    companyToEdit: IPersonalSettingCreate | undefined,
  ): IPersonalSettingCreate => ({

    whatsapp_authkey: companyToEdit?.whatsapp_authkey || "",
    whatsapp_appkey: companyToEdit?.whatsapp_appkey || "",
    port_mail_setup: companyToEdit?.port_mail_setup || "",
    mail_id_setup: companyToEdit?.mail_id_setup || "",
    password_mail_setup: companyToEdit?.password_mail_setup || "",
    incoming_port:companyToEdit?.incoming_port || "",
    pop3_host:companyToEdit?.pop3_host || "",
    host_out_going_mail:companyToEdit?.host_out_going_mail || ""
  });
  

  export const createPersonalSettingValidationSchema = () =>
    Yup.object().shape({
   
    });

    export const handleSaveData = async (
        values:IPersonalSettingCreate,
        profileId:number,
    onHide:() => void,
    setIsLoadApi:TReactSetState<boolean>
    ) => {
        // Perform save operation for username (e.g., API call)
        const requestData = {
          table: "a_application_logins",
          where: `{"id":"${profileId}"}`,
          data: JSON.stringify({
            whatsapp_authkey:values.whatsapp_authkey,
            whatsapp_appkey:values.whatsapp_appkey,
            port_mail_setup:values.port_mail_setup,
            mail_id_setup:values.mail_id_setup,
            password_mail_setup:values.password_mail_setup,
            incoming_port:values.incoming_port,
            pop3_host:values.pop3_host,
            host_out_going_mail:values.host_out_going_mail
          })
        };
    
        try {
          const { data } = await axiosInstance.post("mainCommonUpdate", requestData);
    
          if (data.code === 200) {
            if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
                setIsLoadApi(true)
    window.location.reload();

                onHide()
            } else {
              toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
            }
          }
        } catch (error: any) {
          toast.error(
            error.response?.data?.message || MESSAGE_UNKNOWN_ERROR_OCCURRED
          );
        }
     
      };