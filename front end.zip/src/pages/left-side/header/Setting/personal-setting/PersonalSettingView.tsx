import { ErrorMessage, Field, Form, Formik } from "formik";
import React, { useEffect, useRef, useState } from "react";
import {
  createPersonalSettingInitialValues,
  createPersonalSettingValidationSchema,
  handleSaveData,
} from "./PersonalSettingController";
import { TReactSetState } from "../../../../../helpers/AppType";
import { axiosInstanceForWpWeb } from "../../../../../services/axiosInstance";
import { openInNewTab } from "../../../../../common/SharedFunction";

interface IPropsPersonalSetting {
  show: boolean;
  onHide: () => void;
  companyToEdit: any;
  headerName: string;
  setIsLoadApi: TReactSetState<boolean>;
}
const PersonalSettingView = ({
  show,
  onHide,
  companyToEdit,
  headerName,
  setIsLoadApi,
}: IPropsPersonalSetting) => {
  const [isOpenThirdParty, setIsOpenThirdParty] = useState(false);

  const handleSubmit = async (values: any) => {
    handleSaveData(values, companyToEdit.id, onHide, setIsLoadApi);
  };
  const [showQr, setShowQr] = useState("");
  const intervalRef = useRef<NodeJS.Timeout | null>(null); // Store interval reference
  const [statusMessages, setStatusMessages] = useState<{
    type: string;
    message: string;
  }>(); // Store status messages

  const fetchQr = async () => {
    const mobileNo = companyToEdit?.recovery_mobile || 0;
    const response = await axiosInstanceForWpWeb.get("/show-qr");
    console.log("Qr", response.data.data);
    setShowQr(response.data.data.qr);
    const latestStatus = response?.data?.data?.latestStatusMessage;
    if (Array.isArray(latestStatus) && latestStatus.length > 0) {
      setStatusMessages(latestStatus[0]); // Ensure it's a valid object
    } else {
      setStatusMessages({ type: "", message: "" }); // Default empty object
    }
  };

  const handleClose = () => {
    onHide();
    setIsOpenThirdParty(false);
  };
  useEffect(() => {
    if (isOpenThirdParty) {
      fetchQr(); // Fetch QR code when modal opens

      // Start auto-refresh every 1 minute
      intervalRef.current = setInterval(fetchQr, 10000);
      setStatusMessages({ type: "", message: "" });
    } else {
      // Stop API calls when modal is closed
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isOpenThirdParty]);

  return (
    <div>
      {show && (
        <div className="modal1">
          <div className="modal-content1">
            <span>
              <p
                className="landing-page-text text-end"
                style={{
                  cursor: "pointer",
                  color: "blue",
                  float: "right",
                  fontSize: "13px",
                }}
                onClick={() => openInNewTab("/videoTutorial", 5)}
              >
                Learn More :{" "}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="24px"
                  viewBox="0 -960 960 960"
                  width="24px"
                  fill="#0000FF"
                >
                  <path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" />
                </svg>
              </p>
            </span>
            <div style={{ clear: "both" }}></div>
            <span className="close" onClick={handleClose}>
              &times;
            </span>
            <h2 className="modal-title1 form_header_text">{headerName}</h2>
            <p className="text-center " style={{ color: "#999" }}>
              Please Enter your Personal Detail.
            </p>
            <Formik
              enableReinitialize
              initialValues={createPersonalSettingInitialValues(companyToEdit)}
              validationSchema={createPersonalSettingValidationSchema()}
              onSubmit={handleSubmit}
            >
              {({ errors, touched, setFieldValue, values }) => (
                <Form>
                  <div className="  mt-3    d-flex justify-content-center">
                    <div className="mb-3 py-4  ">
                      <div className="row  mx-0 px-2 gy-3  d-flex justify-content-center">
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="whatsapp_authkey"
                              className="pb-2 form_label"
                            >
                              Whatsapp Api authkey
                            </label>
                            <Field
                              as="textarea"
                              name="whatsapp_authkey"
                              className={`form-control font-size-15 rounded-1   ${
                                errors.whatsapp_authkey &&
                                touched.whatsapp_authkey &&
                                "is-invalid input-box-error"
                              }`}
                              rows={1}
                            />
                            <ErrorMessage
                              name="whatsapp_authkey"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="whatsapp_appkey"
                              className="pb-2 form_label"
                            >
                              Whatsapp Api AppKey
                            </label>
                            <Field
                              as="textarea"
                              name="whatsapp_appkey"
                              className={`form-control font-size-15 rounded-1   ${
                                errors.whatsapp_appkey &&
                                touched.whatsapp_appkey &&
                                "is-invalid input-box-error"
                              }`}
                              rows={1}
                            />
                            <ErrorMessage
                              name="whatsapp_appkey"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>

                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="company_name"
                              className="pb-2 form_label"
                            >
                              SMTP HOST
                            </label>
                            <Field
                              type="text"
                              name="host_out_going_mail"
                              className={`form-control font-size-15 rounded-1   ${
                                errors.host_out_going_mail &&
                                touched.host_out_going_mail &&
                                "is-invalid input-box-error"
                              }`}
                            />
                            <ErrorMessage
                              name="host_out_going_mail"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="port_mail_setup"
                              className="pb-2 form_label"
                            >
                              Email OutGoing Port
                            </label>
                            <Field
                              type="text"
                              name="port_mail_setup"
                              className={`form-control font-size-15 rounded-1   ${
                                errors.port_mail_setup &&
                                touched.port_mail_setup &&
                                "is-invalid input-box-error"
                              }`}
                            />
                            <ErrorMessage
                              name="port_mail_setup"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="mail_id_setup"
                              className="pb-2 form_label"
                            >
                              Email Address
                            </label>
                            <Field
                              type="email"
                              name="mail_id_setup"
                              className={`form-control font-size-15 rounded-1   ${
                                errors.mail_id_setup &&
                                touched.mail_id_setup &&
                                "is-invalid input-box-error"
                              }`}
                            />
                            <ErrorMessage
                              name="mail_id_setup"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="password_mail_setup"
                              className="pb-2 form_label"
                            >
                              Password
                            </label>
                            <Field
                              type="password"
                              name="password_mail_setup"
                              className={`form-control font-size-15 rounded-1   ${
                                errors.password_mail_setup &&
                                touched.password_mail_setup &&
                                "is-invalid input-box-error"
                              }`}
                            />
                            <ErrorMessage
                              name="password_mail_setup"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="pop3_host"
                              className="pb-2 form_label"
                            >
                              POP3 Host
                            </label>
                            <Field
                              type="text"
                              name="pop3_host"
                              className={`form-control font-size-15 rounded-1   ${
                                errors.pop3_host &&
                                touched.pop3_host &&
                                "is-invalid input-box-error"
                              }`}
                            />
                            <ErrorMessage
                              name="pop3_host"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="incoming_port"
                              className="pb-2 form_label"
                            >
                              Incoming Port
                            </label>
                            <Field
                              type="text"
                              name="incoming_port"
                              className={`form-control font-size-15 rounded-1   ${
                                errors.incoming_port &&
                                touched.incoming_port &&
                                "is-invalid input-box-error"
                              }`}
                            />
                            <ErrorMessage
                              name="incoming_port"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 border rounded bg-secondary">
                          <b
                            className="cursor-pointer"
                            onClick={() => setIsOpenThirdParty(true)}
                            style={{
                              cursor: "pointer",
                              display: "block",
                              color: "#ffff",
                            }}
                          >
                            Show Qr
                            <span className="ms-2">
                              {isOpenThirdParty ? "▲" : "▼"}
                            </span>
                          </b>
                        </div>
                        {isOpenThirdParty && (
                          <>
                            <div className="col-12 ">
                              <div className="form-group">
                                <label
                                  htmlFor="india_mart_api_key"
                                  className="pb-2 form_label"
                                >
                                  QR
                                </label>

                                {showQr && (
                                  <img
                                    src={showQr}
                                    style={{ height: "600px", width: "600px" }}
                                    alt=""
                                  />
                                )}
                                {statusMessages && (
                                  <p>{statusMessages.message}</p>
                                )}
                              </div>
                            </div>
                          </>
                        )}
                        <div className="col-12 col-12 pt-4 d-flex justify-content-center">
                          <button
                            className="border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label"
                            onClick={handleClose}
                          >
                            Close
                          </button>
                          <button
                            type="submit"
                            className="btn btn-primary px-4 py-2 ms-2  text-light form_label rounded-1"
                            style={{
                              backgroundColor: "#f58634",
                            }}
                          >
                            save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      )}
    </div>
  );
};

export default PersonalSettingView;
