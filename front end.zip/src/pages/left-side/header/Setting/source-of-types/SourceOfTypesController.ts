import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import {axiosInstance} from "../../../../../services/axiosInstance";
import { TReactSetState } from "../../../../../helpers/AppType";
import { checkDuplication, checkDuplicationUpdate } from "../../../../../common/SharedFunction";

export interface ISourceOfTypes {
  source_name: string;
  id: number;
  color: string | undefined | null;
}

export interface ISourceOfTypesCreate {
  source_name: string;
  color: string | undefined | null;
}
interface IAddSourceOfTypesObj {
  source_name: string;
  color: string | undefined | null;
}
export const handleDeleteSourceType = async (
  sourceOfId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setSourceOfTypesLists: TReactSetState<ISourceOfTypes[]>,
  setLoading: TReactSetState<boolean>,
) => {
  const requestData = {
    table: "source_types",
    where: `{"id":${sourceOfId}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = await localStorage.getItem("UUID");

  try {
    const data = await axiosInstance.post("commonUpdate", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        fetchSourceOfTypesApi(setSourceOfTypesLists,setLoading);
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createSourceOfType = async (
  sourceOfTypeInput: IAddSourceOfTypesObj,
  setSourceOfTypesLists: TReactSetState<ISourceOfTypes[]>,
  setLoading: TReactSetState<boolean>,
  clearFormCallback: () => void //
) => {
  if (
    !(await checkDuplication(
      sourceOfTypeInput.source_name,
      "source_types",
      "source_name"
    ))
  ) {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "source_types",
      data: `{"source_name":"${sourceOfTypeInput.source_name}","color":"${
        sourceOfTypeInput.color
      }","a_application_login_id":${Number(getUUID)}}`,
    };
    try {
      const { data } = await axiosInstance.post("commonCreate", requestData , 
        {
          headers: {
            "x-tenant-id": getUUID,

          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          fetchSourceOfTypesApi(setSourceOfTypesLists,setLoading);
          toast.success(data.ack_msg);
          clearFormCallback()
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("Source Type already available");
  }
};

export const fetchSourceOfTypesApi = async (
  setSourceOfTypesLists: TReactSetState<ISourceOfTypes[]>,
  setLoading: TReactSetState<boolean>,
) => {
  
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token")
  const requestData = {
    a_application_login_id:getUUID
  };
  try {
    const data = await axiosInstance.post("sourceOfTypes", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false)
      setSourceOfTypesLists([]);
    }
    setLoading(true)
    setSourceOfTypesLists(data.data.data.item);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};

export const updateSourceOfTypes = async (
  sourceOfTypeInput: ISourceOfTypesCreate,
  setSourceOfTypesLists: TReactSetState<ISourceOfTypes[]>,
  setLoading: TReactSetState<boolean>,
  editSourceTypeId: number | undefined,
  clearFormCallback: () => void //

) => {
  if (
    !(await checkDuplicationUpdate(
      sourceOfTypeInput.source_name,
      "source_types",
      "source_name",
      editSourceTypeId
    ))
  ) {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "source_types",
    where: `{"id":"${editSourceTypeId}"}`,
    data: `{"source_name":"${sourceOfTypeInput.source_name}","color":"${
      sourceOfTypeInput.color
    }","a_application_login_id":${Number(getUUID)}}`,
  };
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        clearFormCallback()
        setSourceOfTypesLists((prevList) =>
          prevList.map((category) =>
            category.id === editSourceTypeId ? data.data : category
          )
        );
        
        fetchSourceOfTypesApi(setSourceOfTypesLists,setLoading);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
} else {
  toast.error("Source Type already available");
}
};
