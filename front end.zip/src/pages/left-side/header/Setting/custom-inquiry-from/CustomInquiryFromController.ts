import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import { TReactSetState } from "../../../../../helpers/AppType";
import { axiosInstance } from "../../../../../services/axiosInstance";

export const orderTypesCustomInquiryList = [
  { id: "1", order_type_display: "Number" },
  { id: "2", order_type_display: "Text" },
  { id: "3", order_type_display: "TextArea" },
  { id: "4", order_type_display: "Date" },
  { id: "5", order_type_display: "DateAndTime" },
  { id: "6", order_type_display: "Time" },
  { id: "7", order_type_display: "Switch" },
  { id: "8", order_type_display: "Decimal" },
  { id: "9", order_type_display: "DropDown" },
  { id: "10", order_type_display: "Radio" },
];
export const reqTypesCustomInquiryList = [
  { id: "1", order_type_display: "Yes" },
  { id: "2", order_type_display: "No" },

];

export const pageTypesCustomFieldList = [
  { id: "1", order_type_display: "contact" },
  { id: "2", order_type_display: "Inquiry" },
];
export interface ICustomInquiryFromList {
  id: number;
  title: string;
  data_type: number;
  display_order: number;
  required_or_not: number;
  data_sorce:string
  form_type:number
}
interface IAddCustomInquiryFromObj {
  title: string;
  data_type: number;
  display_order: number;
  required_or_not: number;
  form_type:number
}
export const fetchCustomInquiryFromApi = async (
  setCustomInquiryFromList: TReactSetState<ICustomInquiryFromList[]>,
  setLoading: TReactSetState<boolean>,
  pageType:number
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "custom_field_form_masters",
    columns: "id,title,data_type,display_order,required_or_not,data_sorce",
    where: ["isDelete=0", `form_type=${pageType}`, `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false);
      setCustomInquiryFromList([]);
    }
    setLoading(true);
    setCustomInquiryFromList(data.data.data);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};
export const createCustomInquiryFrom = async (
  customInquiryFromInput: IAddCustomInquiryFromObj,
  setCustomInquiryFromList: TReactSetState<ICustomInquiryFromList[]>,
  setLoading: TReactSetState<boolean>,
  clearFormCallback: () => void, //,
  pageType:number
) => {

  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  const requestData = {
      title: customInquiryFromInput.title,
      data_type: customInquiryFromInput.data_type,
      display_order: 0, // Include the HTML content here
      required_or_not: customInquiryFromInput.required_or_not,
      a_application_login_id: Number(getUUID),
      form_type:customInquiryFromInput.form_type
  };
  
  try {
    const { data } = await axiosInstance.post(
      "createCustomFieldFrom",
      requestData,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    )
    console.log("daaaaaaaaaaaaa",data);
    
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        fetchCustomInquiryFromApi(setCustomInquiryFromList, setLoading , pageType);
        clearFormCallback();
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateCustomInqFrom = async (
  customInquiryFromInput: IAddCustomInquiryFromObj,
  setCustomInquiryFromList: TReactSetState<ICustomInquiryFromList[]>,
  setLoading: TReactSetState<boolean>,
  editCustomInqFromId: number | undefined,
  clearForm: () => void,
  pageType:number
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "custom_field_form_masters",
    where: `{"id":"${editCustomInqFromId}"}`,
    data: JSON.stringify({
      title: customInquiryFromInput.title,
      data_type: customInquiryFromInput.data_type,
      display_order: customInquiryFromInput.display_order, // Include the HTML content here
      required_or_not: customInquiryFromInput.required_or_not,
      form_type:customInquiryFromInput.form_type

    }),
  };
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setCustomInquiryFromList((prevList) =>
          prevList.map((stagestatus) =>
            stagestatus.id === editCustomInqFromId ? data.data : stagestatus
          )
        );
        fetchCustomInquiryFromApi(setCustomInquiryFromList, setLoading ,pageType);

        clearForm();
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const handleDeleteCustomInquiryFrom = async (
  customInquiryFromId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setCustomInquiryFromList: TReactSetState<ICustomInquiryFromList[]>,
  setLoading: TReactSetState<boolean>,
  pageType:number
) => {
  const requestData = {
    table: "custom_field_form_masters",
    where: `{"id":${customInquiryFromId}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID")
  try {
    const data = await axiosInstance.post("commonUpdate", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        fetchCustomInquiryFromApi(setCustomInquiryFromList, setLoading , pageType);
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export interface IDisplayOrderCreate {
  display_order: number | string;
}
export const updateDisplayOrderCustomInqFrom = async (
  displayOrderInput: IDisplayOrderCreate,
  editStageStatusId: number | undefined
) => {
  const requestData = {
    table: "custom_field_form_masters",
    where: `{"id":"${editStageStatusId}"}`,
    data: `{"display_order":"${displayOrderInput.display_order}" }`,
  };
  const getUUID = localStorage.getItem("UUID")
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};