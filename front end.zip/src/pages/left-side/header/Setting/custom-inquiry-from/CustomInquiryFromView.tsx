import React, { useEffect, useRef, useState } from "react";
import CustomSearchDropdown from "../../../../../components/CustomSearchDropdown";
import {
  createCustomInquiryFrom,
  fetchCustomInquiryFromApi,
  handleDeleteCustomInquiryFrom,
  ICustomInquiryFromList,
  orderTypesCustomInquiryList,
  pageTypesCustomFieldList,
  reqTypesCustomInquiryList,
  updateCustomInqFrom,
  updateDisplayOrderCustomInqFrom,
} from "./CustomInquiryFromController";
import { SingleValue } from "react-select";
import { IOption } from "../../../../../helpers/AppInterface";
import { TOnChangeInput } from "../../../../../helpers/AppType";
import Skeleton from "react-loading-skeleton";
import ConfirmationModal from "../../../../../components/model/ConfirmationModal";
import CustomInquiryAddDataSource from "./CustomInquiryAddDataSource";
import {
  BIG_TEXT_LENGTH,
  DEFAULT_MESSAGE_ERROR_PERMISSION,
} from "../../../../../helpers/AppConstants";
import useCheckUserPermission from "../../../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../../../helpers/AppEnum";
import { toast } from "react-toastify";

interface IPropsCustomInquiryFrom {
  isCustomInquiryFromView: boolean;
  closeCustomInquiryFromView: () => void;
}
const CustomInquiryFromView = ({
  isCustomInquiryFromView,
  closeCustomInquiryFromView,
}: IPropsCustomInquiryFrom) => {
  const [selectedOrderList, setSelectedOrderList] =
    useState<SingleValue<IOption> | null>(null);
  const [selectedReqList, setSelectedReqList] =
    useState<SingleValue<IOption> | null>(null);
  const [selectedPageType, setSelectedPageType] =
    useState<SingleValue<IOption> | null>(null);
  const [titleInput, setTitleInput] = useState("");
  const [displayOrderInput, setDisplayOrderInput] = useState(0);
  const [hasIdAvail, setHasIdAvail] = useState<number>();
  const customInqFromRefDropdown = useRef<HTMLButtonElement>(null);

  const [requiredSwitch, setRequiredSwitch] = useState(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [customInquiryFromList, setCustomInquiryFromList] = useState<
    ICustomInquiryFromList[]
  >([]);
  const [loading, setLoading] = useState(false);
  const [customInqFromDropdown, setCustomInqFromDropdown] = useState<any>(null);
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [isAddDataSource, setIsAddDataSource] = useState(false);

  const [dataTypeError, setDataTypeError] = useState("");
  const [pageTypeError, setPageTypeError] = useState("");

  const [titleError, setTitleListError] = useState("");
  const [displayOrders, setDisplayOrders] = useState<{ [key: number]: number }>(
    {}
  );

  const [editCustomInqFromId, setEditCustomInqFromId] = useState<
    number | undefined
  >(undefined);
  const [addDataSourceItem, setAddDataSourceItem] =
    useState<ICustomInquiryFromList>();
  const orderDisplayOptions =
    orderTypesCustomInquiryList &&
    orderTypesCustomInquiryList.map((option) => ({
      value: option.id,
      label: option.order_type_display,
    }));

  const requiredDisplayOptions =
    reqTypesCustomInquiryList &&
    reqTypesCustomInquiryList.map((option) => ({
      value: option.id,
      label: option.order_type_display,
    }));
  const pageTypeDisplayOptions =
    pageTypesCustomFieldList &&
    pageTypesCustomFieldList.map((option) => ({
      value: option.id,
      label: option.order_type_display,
    }));
  const clearForm = () => {
    setTitleInput("");
    setDisplayOrderInput(0);
    setRequiredSwitch(false);
    setIsEditing(false);
    setSelectedOrderList(false || null);
    setSelectedReqList(null);
    setSelectedPageType(selectedPageType);
  };
  const canViewCustomInquiry = useCheckUserPermission(
    PAGE_ID.CUSTOM_FORM_FIELD,
    PERMISSION_TYPE.VIEW
  );

  const canAddCustomInquiry = useCheckUserPermission(
    PAGE_ID.CUSTOM_FORM_FIELD,
    PERMISSION_TYPE.ADD
  );

  const canUpdateCustomInquiry = useCheckUserPermission(
    PAGE_ID.CUSTOM_FORM_FIELD,
    PERMISSION_TYPE.EDIT
  );

  const canDeleteCustomInquiry = useCheckUserPermission(
    PAGE_ID.CUSTOM_FORM_FIELD,
    PERMISSION_TYPE.DELETE
  );

  const handleOrderDisplayChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedOrderList(selectedOption);
    setDataTypeError(selectedOption ? "" : "Data type is required");
  };
  const handleReqDisplayChange = (selectedOption: SingleValue<IOption>) => {
    setSelectedReqList(selectedOption);
  };
  const handlePageTypeDisplayChange = (
    selectedOption: SingleValue<IOption>
  ) => {
    console.log("selectedOption", selectedOption);

    setSelectedPageType(selectedOption);
    setPageTypeError(selectedOption ? "" : "Type is required");
  };
  const handelChangeTitle = (event: TOnChangeInput) => {
    const value = event.target.value;
    setTitleInput(value);
    setTitleListError(value ? "" : "Title name is required");
  };
  const handelChangeDisplayOrder = (event: TOnChangeInput) => {
    const value = event.target.value;
    if (/^\d*$/.test(value)) {
      // Only allows digits (no letters or special characters)
      setDisplayOrderInput(Number(value));
    } else {
      setDisplayOrderInput(0);
    }
  };

  const handelSubmit = () => {
    if (!selectedOrderList) setDataTypeError("Data Type is required");
    if (!selectedPageType) setPageTypeError("Type is required");

    if (titleInput.trim() === "") {
      setTitleListError("Title name is required");
      return;
    }
    if (isEditing) {
      if (canUpdateCustomInquiry) {
        updateCustomInqFrom(
          {
            title: titleInput,
            data_type: Number(selectedOrderList?.value),
            display_order: displayOrderInput,
            required_or_not: Number(selectedReqList?.value)
              ? Number(selectedReqList?.value)
              : 0,
            form_type: Number(selectedPageType?.value),
          },
          setCustomInquiryFromList,
          setLoading,
          editCustomInqFromId,
          clearForm,
          Number(selectedPageType?.value)
        );
      } else {
        toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
      }
    } else {
      if (canAddCustomInquiry) {
        createCustomInquiryFrom(
          {
            title: titleInput,
            data_type: Number(selectedOrderList?.value),
            display_order: displayOrderInput,
            required_or_not: Number(selectedReqList?.value)
              ? Number(selectedReqList?.value)
              : 0,
            form_type: Number(selectedPageType?.value),
          },
          setCustomInquiryFromList,
          setLoading,
          clearForm,
          Number(selectedPageType?.value)
        );
      } else {
        toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
      }
    }
  };

  useEffect(() => {
    if (canViewCustomInquiry) {
      fetchCustomInquiryFromApi(
        setCustomInquiryFromList,
        setLoading,
        Number(selectedPageType?.value)
      );
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }, [isCustomInquiryFromView, isAddDataSource, selectedPageType?.value]);

  const toggleDropdownCustomInqFrom = (customId: number | undefined) => {
    setHasIdAvail(customId);
    setCustomInqFromDropdown(!customInqFromDropdown);
  };
  const handleEdit = (item: ICustomInquiryFromList) => {
    setCustomInqFromDropdown(null);
    setTitleInput(item.title);
    setDisplayOrderInput(item.display_order);
    setIsEditing(true);
    setEditCustomInqFromId(item.id);
    const selectedOption =
      orderDisplayOptions.find(
        (option: { value: string }) => option.value === String(item.data_type)
      ) || null;
    const reqSelectedOption =
      requiredDisplayOptions.find(
        (option: { value: string }) =>
          option.value === String(item.required_or_not)
      ) || null;
    setSelectedOrderList(selectedOption);
    setSelectedReqList(reqSelectedOption);
  };
  const dataSource = (item: ICustomInquiryFromList) => {
    setIsAddDataSource(true);
    setAddDataSourceItem(item);
  };
  const handleDelete = (id: number) => {
    setCustomInqFromDropdown(null);
    setIsDeleteConfirmation(true);
    setHasIdAvail(id);
  };
  const handleDisplayOrderChange = async (
    id: number,
    value: number | string
  ) => {
    setDisplayOrders((prev: any) => ({
      ...prev,
      [id]: value, // Update the display order in local state
    }));

    console.log("value", value);
    console.log("id", id);
    if (value !== 0) {
      updateDisplayOrderCustomInqFrom(
        {
          display_order: Number(value),
        },
        id
      );
    }
  };

  const handleDeleteCustomFrom = () => {
    if (canDeleteCustomInquiry) {
      handleDeleteCustomInquiryFrom(
        hasIdAvail,
        setIsDeleteConfirmation,
        setCustomInquiryFromList,
        setLoading,
        Number(selectedPageType?.value)
      );
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleRefreshStageStatus = async () => {
    await fetchCustomInquiryFromApi(
      setCustomInquiryFromList,
      setLoading,
      Number(selectedPageType?.value)
    );
  };
  return (
    <>
      {isCustomInquiryFromView ? (
        <>
          <div
            className="notifications animate__animated animate__fadeInLeft"
            id="notifications"
          >
            {/* <!-- Header --> */}
            <div className="header-Chat">
              {/* <!-- Icons --> */}
              <div className="ICON">
                <div
                  aria-disabled="false"
                  role="button"
                  className="icons"
                  data-tab="2"
                  title="Back"
                  aria-label="New chat"
                  onClick={closeCustomInquiryFromView}
                >
                  <span data-testid="chat" data-icon="chat" className="">
                    <svg
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path
                        fill="currentColor"
                        d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                      ></path>
                    </svg>
                  </span>
                </div>
              </div>

              <div className=" col-8 newText">
                <h2>Custom Field Form</h2>
              </div>
              <div className="col-3 text-end mb-2">
                <div className="ICON">
                  <button
                    className="icons"
                    onClick={handleRefreshStageStatus}
                    title="Refresh"
                  >
                    <svg width="30" height="30" viewBox="0 0 50 50">
                      <path
                        fill="currentColor"
                        d="M25 38c-7.2 0-13-5.8-13-13 0-3.2 1.2-6.2 3.3-8.6l1.5 1.3C15 19.7 14 22.3 14 25c0 6.1 4.9 11 11 11 1.6 0 3.1-.3 4.6-1l.8 1.8c-1.7.8-3.5 1.2-5.4 1.2z"
                      />
                      <path
                        fill="currentColor"
                        d="M34.7 33.7l-1.5-1.3c1.8-2 2.8-4.6 2.8-7.3 0-6.1-4.9-11-11-11-1.6 0-3.1.3-4.6 1l-.8-1.8c1.7-.8 3.5-1.2 5.4-1.2 7.2 0 13 5.8 13 13 0 3.1-1.2 6.2-3.3 8.6z"
                      />
                      <path fill="currentColor" d="M18 24h-2v-6h-6v-2h8z" />
                      <path fill="currentColor" d="M40 34h-8v-8h2v6h6z" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
            {/* <!-- Chats --> */}
            <div className="chats-notifications">
              {/* <!-- Chats 1 --> */}
              <div className="block">
                {/* <!-- Text --> */}
                <div className="h-text">
                  <div className="head" style={{ display: "block" }}>
                    <div className="row">
                      <div className="col-6 mt-1">
                        <label
                          className="form-check-label"
                          htmlFor="flexCheckDefault"
                        >
                          <h4>
                            From Type
                            <span className="text-danger">*</span>
                          </h4>
                        </label>
                        <div className="">
                          <div className="add-source-of-type-section ">
                            <CustomSearchDropdown
                              options={pageTypeDisplayOptions}
                              value={selectedPageType}
                              onChange={handlePageTypeDisplayChange}
                              className="w-100"
                              isDisabled={isEditing ? "disabled" : false}
                            />
                          </div>
                        </div>
                        {pageTypeError && (
                          <span className="text-danger">{pageTypeError}</span>
                        )}
                      </div>
                      <div className="col-6 mt-1">
                        <label
                          className="form-check-label"
                          htmlFor="flexCheckDefault"
                        >
                          <h4>
                            Data Type
                            <span className="text-danger">*</span>
                          </h4>
                        </label>
                        <div className="">
                          <div className="add-source-of-type-section ">
                            <CustomSearchDropdown
                              options={orderDisplayOptions}
                              value={selectedOrderList}
                              onChange={handleOrderDisplayChange}
                              className="w-100"
                              isDisabled={isEditing ? "disabled" : false}
                            />
                          </div>
                        </div>
                        {dataTypeError && (
                          <span className="text-danger">{dataTypeError}</span>
                        )}
                      </div>
                    </div>
                    <div className="row mt-1">
                      <div className="col-6">
                        <label
                          className="form-check-label"
                          htmlFor="flexCheckDefault"
                        >
                          <h4>
                            Enter Title
                            <span className="text-danger">*</span>
                          </h4>
                        </label>
                        <div className="search-bar ">
                          <div className="add-source-of-type-section ">
                            <input
                              type="text"
                              title="Add Title Name"
                              placeholder="Add Title Name"
                              value={titleInput}
                              maxLength={BIG_TEXT_LENGTH}
                              onChange={(e) => handelChangeTitle(e)}
                            />
                          </div>
                        </div>
                        {titleError && (
                          <span className="text-danger">{titleError}</span>
                        )}
                      </div>
                      <div className="col-5">
                        <label
                          className="form-check-label"
                          htmlFor="flexCheckDefault"
                        >
                          <h4>Required?</h4>
                        </label>
                        <div className="">
                          <div className="add-source-of-type-section ">
                            <CustomSearchDropdown
                              options={requiredDisplayOptions}
                              value={selectedReqList}
                              onChange={handleReqDisplayChange}
                              className="w-100"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="col-1 mt-4 p-0">
                        <button className="" onClick={handelSubmit}>
                          <span>
                            {isEditing ? (
                              <span>
                                <svg
                                  data-name="Layer 1"
                                  height={24}
                                  id="Layer_1"
                                  viewBox="0 0 200 200"
                                >
                                  <title />
                                  <path
                                    fill="currentColor"
                                    d="M177.68,43.9c-4.5-3.5-10.5-3-14,1.5l-74,89.5-55-40c-4.5-3-10.5-2.5-14,2-3,4.5-2.5,10.5,2,14l62.5,45.5a.49.49,0,0,1,.5.5c.5,0,.5.5,1,.5s.5.5,1,.5.5,0,1,.5h6c.5,0,.5,0,1-.5.5,0,.5-.5,1-.5s.5-.5,1-.5.5-.5,1-.5a.49.49,0,0,0,.5-.5l.5-.5,80-97C182.18,53.9,181.68,47.4,177.68,43.9Z"
                                  />
                                </svg>
                              </span>
                            ) : (
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                height="26px"
                                viewBox="0 -960 960 960"
                                width="26px"
                                fill="#5f6368"
                              >
                                <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                              </svg>
                            )}
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                  <div>
                    {loading ? (
                      Array.from({ length: 12 }).map((_, index) => (
                        <div
                          className="source-of-type-list-grid-main"
                          key={index}
                        >
                          <div className="source-of-type-list-grid-list">
                            <div
                              style={{
                                display: "inline-block",
                                marginLeft: "8px",
                              }}
                            >
                              <Skeleton
                                width="100px"
                                height="25px"
                                duration={5}
                                borderRadius={50}
                              />
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <>
                        <div className="source-of-type-list-grid-block">
                          <div className="source-of-type-list-grid-main">
                            <table className="table table-bordered table-sm">
                              <thead>
                                <tr>
                                  <th style={{ width: "100px" }}>Sr.no</th>
                                  <th>Data Type</th>
                                  <th>Title</th>
                                  <th style={{ width: "10px" }}></th>
                                </tr>
                              </thead>
                              <tbody>
                                <p
                                  className={`${
                                    customInquiryFromList.length > 0
                                      ? ""
                                      : " text-center pt-5"
                                  }`}
                                >
                                  {customInquiryFromList.length > 0
                                    ? ""
                                    : "No Data Found"}
                                </p>
                                {customInquiryFromList &&
                                  customInquiryFromList.map((item, index) => (
                                    <tr key={index}>
                                      <td className="">
                                        <input
                                          type="text"
                                          className="w-100"
                                          style={{ textAlign: "right" }}
                                          title="Display Order"
                                          value={
                                            displayOrders[item.id] !== undefined
                                              ? displayOrders[item.id]
                                              : item.display_order || 0
                                          }
                                          onChange={(e) => {
                                            const newValue = e.target.value;

                                            // Allow empty, "-", or valid numeric inputs
                                            if (/^-?$|^-?\d+$/.test(newValue)) {
                                              handleDisplayOrderChange(
                                                item.id,
                                                newValue
                                              );
                                            }
                                          }}
                                        />
                                      </td>
                                      <td>
                                        {orderTypesCustomInquiryList.find(
                                          (option) =>
                                            Number(option.id) === item.data_type
                                        )?.order_type_display || ""}{" "}
                                        <br />
                                        {item.required_or_not === 1 ? (
                                          <span className="text-danger">
                                            *Req
                                          </span>
                                        ) : (
                                          "No"
                                        )}
                                      </td>
                                      <td>
                                        <p
                                          style={{
                                            width: "100px",
                                            wordBreak: "break-word",
                                          }}
                                        >
                                          {item.title}
                                        </p>
                                      </td>

                                      <td className="">
                                        {item.id === -1 ? (
                                          <span></span>
                                        ) : (
                                          <>
                                            <button
                                              className="source-of-type-list-grid-options"
                                              id="source-of-types-options-id"
                                              onClick={() =>
                                                toggleDropdownCustomInqFrom(
                                                  item?.id
                                                )
                                              }
                                              ref={customInqFromRefDropdown}
                                            >
                                              <span>
                                                <svg
                                                  viewBox="0 0 24 24"
                                                  width="24"
                                                  height="24"
                                                >
                                                  <path
                                                    fill="currentColor"
                                                    d="M12 7a2 2 0 1 0-.001-4.001A2 2 0 0 0 12 7zm0 2a2 2 0 1 0-.001 3.999A2 2 0 0 0 12 9zm0 6a2 2 0 1 0-.001 3.999A2 2 0 0 0 12 15z"
                                                  ></path>
                                                </svg>
                                              </span>
                                            </button>
                                            <ul
                                              className={`source-of-types-options source-of-types-options-custom-form ${
                                                hasIdAvail === item.id &&
                                                customInqFromDropdown
                                                  ? "isVisible"
                                                  : "isHidden"
                                              }`}
                                              id="dropLeft"
                                              style={{
                                                width: "120px",
                                              }}
                                            >
                                              <li
                                                className="listItem"
                                                role="button"
                                                onClick={() =>
                                                  handleDelete(item.id)
                                                }
                                              >
                                                Delete
                                              </li>
                                              <li
                                                className="listItem"
                                                role="button"
                                                onClick={() => handleEdit(item)}
                                              >
                                                Edit
                                              </li>
                                              {item.data_type === 9 ||
                                              item.data_type === 10 ? (
                                                <li
                                                  className="listItem"
                                                  role="button"
                                                  onClick={() =>
                                                    dataSource(item)
                                                  }
                                                >
                                                  Add Data source
                                                </li>
                                              ) : (
                                                <span></span>
                                              )}
                                            </ul>
                                          </>
                                        )}
                                      </td>
                                    </tr>
                                  ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
            {isDeleteConfirmation && (
              <ConfirmationModal
                show={isDeleteConfirmation}
                onHide={() => setIsDeleteConfirmation(false)}
                handleSubmit={handleDeleteCustomFrom}
                title={"Delete this Custom Field Form"}
                message={
                  "Are you sure you want delete This Custom Field Form? "
                }
                btn1="CANCEL"
                btn2="DELETE"
              />
            )}
          </div>
          {isAddDataSource && (
            <CustomInquiryAddDataSource
              show={isAddDataSource}
              onHide={() => setIsAddDataSource(false)}
              passDataInAddItem={addDataSourceItem}
            />
          )}
        </>
      ) : null}
    </>
  );
};

export default CustomInquiryFromView;
