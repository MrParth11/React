import React, { useEffect, useState } from "react";

import CustomSearchDropdown from "../../../../../components/CustomSearchDropdown";
import { SingleValue } from "react-select";
import { TOnChangeInput } from "../../../../../helpers/AppType";
import ConfirmationModal from "../../../../../components/model/ConfirmationModal";
import { toast } from "react-toastify";
import { axiosInstance } from "../../../../../services/axiosInstance";
import { ICustomInquiryFromList } from "./CustomInquiryFromController";

const CustomInquiryAddDataSource = ({
  show,
  onHide,
  passDataInAddItem,
}: {
  show: boolean;
  onHide: () => void;
  passDataInAddItem: ICustomInquiryFromList | undefined;
}) => {
  const getUUID = localStorage.getItem("UUID");
  
  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);

  const [dataSource, setDataSource] = useState<string>("");
  const [sources, setSources] = useState<string[]>([
    passDataInAddItem?.data_sorce ?? "",
  ]);

  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (dataSource.trim() === "") return; // Prevent empty input

    const cleanedSources = sources
      .flatMap((s) => s.split(",").map((item) => item.trim()))
      .filter((item) => item !== ""); // Remove empty strings


    const requestData = {
      table: "custom_field_form_masters",
      where: `{"id":"${passDataInAddItem?.id}"}`,
      data: JSON.stringify({
        data_sorce: cleanedSources.join(","),
      }),
    };



      console.log("tenatid",getUUID);
    const updateData = async () => {
      try {
        setLoading(true); // Show loading state
        const response = await axiosInstance.post("commonUpdate", requestData,
          {
            headers: {
              "x-tenant-id": getUUID,
    
            },
            }
        );

        if (response.status === 200) {

          setDataSource(""); // Clear input after success
        } else {
          console.error("Failed to add source");
        }
      } catch (error) {
        console.error("Error adding source:", error);
      } finally {
        setLoading(false); // Stop loading state
      }
    };

    updateData(); // Call the async function

  }, [sources]); // Runs whenever `sources` changes

  const handleAddSource = async () => {
    if (dataSource.trim() === "") return; // Prevent empty input

    setSources((prev) => [
      ...prev.flatMap((s) => s.split(",").map((item) => item.trim())), // Split existing entries
      ...dataSource.split(",").map((item) => item.trim()), // Split new input
    ]);

    const cleanedSources = sources;

    const requestData = {
      table: "custom_field_form_mastersw",
      where: `{"id":"${passDataInAddItem?.id}"}`,
      data: JSON.stringify({
        data_sorce: cleanedSources.join(", "),
      }),
    };
  };

  const handleChangeInput = (e: any) => {
    setDataSource(e.target.value);
  };

  const handleDeleteById = async (itemToDelete: string) => {
    let updatedSources: string[];

    if (
      sources.length === 1 &&
      typeof sources[0] === "string" &&
      sources[0].includes(",")
    ) {
      updatedSources = sources[0]
        .split(",")
        .map((item) => item.trim())
        .filter((item) => item !== itemToDelete);
    } else {
      updatedSources = sources.filter((item) => item !== itemToDelete);
    }

    const cleanedSources = updatedSources
      .flatMap((s) => s.split(",").map((item) => item.trim()))
      .filter((item) => item !== ""); // Remove empty strings


    const requestData = {
      table: "custom_field_form_masters",
      where: `{"id":"${passDataInAddItem?.id}"}`,
      data: JSON.stringify({
      data_sorce: cleanedSources.join(","),
      }),
    };
   
      
    try {
      setLoading(true); // Show loading state
      const response = await axiosInstance.post("commonUpdate", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,
  
          },
          }
      );

      if (response.status === 200) {
        setSources(updatedSources);
      } else {
        console.error("Failed to add source");
      }
    } catch (error) {
      console.error("Error adding source:", error);
    } finally {
      setLoading(false); // Stop loading state
    }
  };

  const formattedSources = Array.isArray(sources)
    ? sources.length === 1 &&
      typeof sources[0] === "string" &&
      sources[0].includes(",")
      ? sources[0]
          .split(",")
          .map((item) => item.trim())
          .filter((item) => item !== "") // Split, trim, and remove empty values
      : sources.filter((item) => item !== "") // Filter out empty values if it's an array
    : [];

  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1" style={{ maxHeight: "80%" }}>
            <span className="close" onClick={onHide}>
              &times;
            </span>
            <h2 className="modal-title1 form_header_text">
              Add Source : {passDataInAddItem?.title}
            </h2>
            <p className="text-center " style={{ color: "#999" }}>
              Please Enter your Source.
            </p>
            <div
              className={`m-title-2 col-12 `}
            >
              <div className="head">
                <div className="search-bar ">
                  <div className="add-source-of-type-section ">
                    <input
                      type="text"
                      title="Source"
                      placeholder="Source"
                      value={dataSource}
                      onChange={(e) => setDataSource(e.target.value)}
                    />
                  </div>
                  <div
                    onClick={handleAddSource}
                    style={{ cursor: "pointer" }}
                    className="px-3"
                  >
                    {loading ? (
                      "Adding..."
                    ) : (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="26px"
                        viewBox="0 -960 960 960"
                        width="26px"
                        fill="#5f6368"
                      >
                        <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                      </svg>
                    )}
                  </div>
                </div>
                <div
                  className="source-of-type-list-grid-block"
                  style={{ overflowX: "scroll", maxHeight: "350px" }}
                >
                  <div className="source-of-type-list-grid-main">
                    <table className="table table-hover" border={0}>
                      <thead>
                        <th className="">Data Sources</th>
                        <th className="text-center">Action</th>
                      </thead>
                      <tbody className="text-center">
                        {formattedSources.map((item, index) => (
                          <tr key={index}>
                            <td className="text-start">
                              <span>{item.trim()}</span>
                            </td>
                            <td className="text-center">
                              <span
                                style={{ cursor: "pointer" }}
                                onClick={() => handleDeleteById(item)}
                              >
                                <svg
                                  viewBox="0 -960 960 960"
                                  width="22px"
                                  fill="currentColor"
                                >
                                  <path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" />
                                </svg>
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default CustomInquiryAddDataSource;
