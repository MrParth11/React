import { toast } from "react-toastify";
import { TReactSetState } from "../../../../../helpers/AppType";
import {axiosInstance} from "../../../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import { checkDuplication, checkDuplicationUpdate } from "../../../../../common/SharedFunction";

export interface IVisitTypeView {
  visit_type: string;
  id: number;
  color: string | undefined | null;
  created_date_time?: string;
}

export interface IVisitTypeCreate {
  visit_type: string;
  color: string | undefined | null;
  created_date_time?: string;
}

export const handleDeleteVisitType = async (
  VisitTypeId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setVisitTypeList: TReactSetState<IVisitTypeView[]>,
  setLoading:TReactSetState<boolean>,
) => {
  const getUUID = localStorage.getItem("UUID")
  const requestData = {
    table: "visit_type_masters",
    where: `{"id":${VisitTypeId}}`,
    data: `{"isDelete":"1"}`,
    a_application_login_id:getUUID

  };
  try {
    const data = await axiosInstance.post("commonUpdate", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {

        setIsDeleteConfirmation(false);
        fetchVisitTypeApi(setVisitTypeList,setLoading);
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createVisitType = async (
  visitTypeInput: IVisitTypeCreate,
  setVisitTypeList: TReactSetState<IVisitTypeView[]>,
  setLoading:TReactSetState<boolean>,
  clearFormCallback: () => void //
) => {
  if (
    !(await checkDuplication(
      visitTypeInput.visit_type,
      "visit_type_masters",
      "visit_type"
    ))
  ) {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "visit_type_masters",
      data: `{"visit_type":"${visitTypeInput.visit_type}","color":"${
        visitTypeInput.color
      }","a_application_login_id":${Number(getUUID)}}`,
      a_application_login_id:getUUID

    };
    try {
      const { data } = await axiosInstance.post("commonCreate", requestData ,
        {
          headers: {
            "x-tenant-id": getUUID,
  
          },
          }
      );
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          // setLoading(true)
          fetchVisitTypeApi(setVisitTypeList,setLoading);
          toast.success(data.ack_msg);
          clearFormCallback();
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } else {
    toast.error("Visit Type already available");
  }
};

export const updateVisitType = async (
  visitTypeInput: IVisitTypeCreate,
  setVisitTypeList: TReactSetState<IVisitTypeView[]>,
  editVisitTypeId: number | undefined,
  setLoading:TReactSetState<boolean>,
  clearFormCallback: () => void //

) => {
  if (
    !(await checkDuplicationUpdate(
      visitTypeInput.visit_type,
      "visit_type_masters",
      "visit_type",
      editVisitTypeId
    ))
  ) {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "visit_type_masters",
    where: `{"id":"${editVisitTypeId}"}`,
    data: `{"visit_type":"${visitTypeInput.visit_type}","color":"${
      visitTypeInput.color
    }","a_application_login_id":${Number(getUUID)}}`,
    a_application_login_id:getUUID

  };
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          clearFormCallback()
        setVisitTypeList((prevList) =>
          prevList.map((VisitType) =>
            VisitType.id === editVisitTypeId ? data.data : VisitType
          )
        );
        fetchVisitTypeApi(setVisitTypeList,setLoading);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
} else {
  toast.error("Visit Type already available");
}
};

export const fetchVisitTypeApi = async (
  setVisitTypeList: TReactSetState<IVisitTypeView[]>,
  setLoading: TReactSetState<boolean>,
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "visit_type_masters",
    columns: "id,visit_type,color",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
    a_application_login_id:getUUID
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );
    console.log("data", data);
    if(data.status === 200){
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setLoading(false)
      setVisitTypeList([]);
    }
    setLoading(true)
    setVisitTypeList(data.data.data);
  }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};
