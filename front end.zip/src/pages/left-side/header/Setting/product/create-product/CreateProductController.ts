import * as Yup from "yup";

import { toast } from "react-toastify";
import {
  axiosInstance,
  axiosInstanceFormData,
} from "../../../../../../services/axiosInstance";
import { TReactSetState } from "../../../../../../helpers/AppType";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../../helpers/AppConstants";

export interface IProductCreate {
  product_name: string;
  product_alias: string;
  product_code: string;
  created_date_time?: string;
  category_id: string;
  unit: string;
  category_name?: string;
  rate: string;
  net_rate: string;
  GST: string;
  weight_or_size: string;
  min_stock_quantity:string,
  max_stock_quantity:string,
  product_img: string;
  product_types: string;
}

export const createProductInitialValues = (
  productToEdit: IProductCreate | undefined
): IProductCreate => ({
  product_name: productToEdit?.product_name || "",
  product_alias: productToEdit?.product_alias || "",
  product_code: productToEdit?.product_code || "",
  category_id: productToEdit?.category_id || "",
  unit: productToEdit?.unit || "",
  rate: productToEdit?.rate || "",
  net_rate: productToEdit?.net_rate || "",
  GST: productToEdit?.GST || "18",
  weight_or_size: productToEdit?.weight_or_size || "",
  min_stock_quantity: productToEdit?.min_stock_quantity || "",
  max_stock_quantity: productToEdit?.max_stock_quantity || "",
  product_img: productToEdit?.product_img || "",
  product_types: productToEdit?.product_types || "",
});

export const createProductValidationSchema = () =>
  Yup.object().shape({
    category_id: Yup.string().required("Product Category Name is Required"),
    product_name: Yup.string().required("Product Name is Required"),
    unit: Yup.string().required("Unit is Required"),

    GST: Yup.string().required("GST is Required"),
    rate: Yup.string().required("Rate is Required"),
  });

export const createProduct = async (
  values: IProductCreate,
  setRefreshProduct: TReactSetState<boolean>,
  onHide: () => void
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  if (!getUUID) {
    return;
  }
  const formData = new FormData();

  formData.append("product_img", values.product_img);
  formData.append("product_types", values.product_types);

  formData.append("product_name", values.product_name);
  formData.append("product_alias", values.product_alias);
  formData.append("product_code", values.product_code);
  formData.append("unit", values.unit);
  formData.append("category_id", values.category_id);
  formData.append("rate", values.rate);
  formData.append("GST", values.GST);
  formData.append("net_rate", values.net_rate);
  formData.append("weight_or_size", values.weight_or_size);
  formData.append("min_stock_quantity", values.min_stock_quantity);
  formData.append("max_stock_quantity", values.max_stock_quantity);
  formData.append("a_application_login_id", getUUID);
  console.log("formData",values.product_types)
  try {
    const { data } = await axiosInstanceFormData.post(
      "create-product",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
          
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        toast.success(data.ack_msg);
        setRefreshProduct(true);

        onHide();
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateProduct = async (
  values: IProductCreate,
  setRefreshProduct: TReactSetState<boolean>,
  productId: any,
  onHide: () => void
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const formData = new FormData();

  if (!getUUID) {
    return;
  }

  if (productId !== undefined) {
    formData.append("product_id", productId.toString());
  } else {
    console.error("editCategoryId is undefined");
  }
  if (values.product_img) {
    formData.append("product_img", values.product_img);
  }
  formData.append("product_types", values.product_types);

  formData.append("product_name", values.product_name);
  formData.append("product_alias", values.product_alias);
  formData.append("product_code", values.product_code);
  formData.append("unit", values.unit);
  formData.append("category_id", values.category_id);
  formData.append("rate", values.rate);
  formData.append("GST", values.GST);
  formData.append("net_rate", values.net_rate);
  formData.append("weight_or_size", values.weight_or_size);
  formData.append("min_stock_quantity", values.min_stock_quantity);
  formData.append("max_stock_quantity", values.max_stock_quantity);
  formData.append("a_application_login_id", getUUID);

  try {
    const { data } = await axiosInstanceFormData.post(
      "update-product",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `${token}`,
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        onHide();
        setRefreshProduct(true);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const fetchCategoryApiForProduct = async (
  setCategoryList: TReactSetState<[]>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "categories",
    columns: "id,category_name",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
    a_application_login_id:Number(getUUID)
  };
  try {
    const response = await axiosInstance.post("commonGet", requestData ,           {
      headers: {
        "x-tenant-id": getUUID,

      },
      });
    if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setCategoryList(response.data.data); // Assuming API response is an array of countries
    } else {
      toast.error(response.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);

    // Handle error (e.g., show error message, clear filtered list)
    setCategoryList([]);
  }
};

export const fetchProductTypeApiForProduct = async (
  setProductTypeList: TReactSetState<[]>
) => {
  const getUUID = localStorage.getItem("UUID")
  const requestData = {
    table: "product_types",
    columns: "id,name",
    where: ["isDelete=0"],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const response = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
  );
    if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setProductTypeList(response.data.data); // Assuming API response is an array of countries
    } else {
      setProductTypeList([]); // Assuming API response is an array of countries
      toast.error(response.data.ack_msg);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);

    // Handle error (e.g., show error message, clear filtered list)
    setProductTypeList([]);
  }
};
