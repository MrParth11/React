import React, { useEffect, useState } from "react";
import { Formik, Field, Form, ErrorMessage, useFormikContext } from "formik";
import { TOnChangeInput, TReactSetState } from "../../../../../../helpers/AppType";
import { toast } from "react-toastify";
import {
  createProduct,
  createProductInitialValues,
  createProductValidationSchema,
  fetchCategoryApiForProduct,
  fetchProductTypeApiForProduct,
  updateProduct,
} from "./CreateProductController";
import FormikCustomSearchDropdown from "../../../../../../components/FormikCustomSearchDropdown";
import { IProductCreate, IProductView } from "../ProductController";
import { BIG_TEXT_LENGTH, MINI_TEXT_LENGTH, SMALL_TEXT_LENGTH } from "../../../../../../helpers/AppConstants";
import { openInNewTab } from "../../../../../../common/SharedFunction";


const UpdateNetRate = () => {
  const { values, setFieldValue } = useFormikContext<any>(); // Access Formik context

  useEffect(() => {
    const rate = parseFloat(values.rate) || 0;
    const GST = parseFloat(values.GST) || 0;
    const netRate = rate * (1 + GST / 100);
    setFieldValue("net_rate", netRate.toFixed(2)); // Set Net Rate
  }, [values.rate, values.GST, setFieldValue]);

  return null; // This component doesn't render anything
};

interface IPropsCreateProduct {
  show: boolean;
  onHide: () => void;
  productToEdit: IProductView | undefined;
  headerName: string;
  setRefreshProduct:TReactSetState<boolean>
}
const CreateProductView = ({
  show,
  onHide,
  productToEdit,
  headerName,
  setRefreshProduct
}: IPropsCreateProduct) => {


  const [productPreview, setProductPreview] = useState<string | null>(null);
  const [categoryList, setCategoryList] = useState<any>([]);
  const [productTypesList, setProductList] = useState<any>([]);



  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);

  const handleSubmit = async (values1: any) => {
    
    if (productToEdit?.id) {
      updateProduct(values1, setRefreshProduct, productToEdit?.id, onHide  );
    } else {
      createProduct(values1, setRefreshProduct, onHide );
    }
  };

  const handelClose = () => {
    setProductPreview("");
    onHide();
  };

  const handleFileChange = (
    event: TOnChangeInput,
    fieldName: string,
    setFieldValue: (field: string, value: File | undefined) => void,
    setPreview: (url: string) => void
  ) => {
    const file = event.currentTarget.files?.[0];

    if (file) {
      // Check if the file size is greater than 1MB
      if (file.size > 1024 * 1024) {
        toast.error("File size must be less than 1MB");
        return;
      }

      // Check if the file type is JPG, JPEG, or PNG
      const validTypes = ["image/jpeg", "image/png", "image/jpg"];
      if (!validTypes.includes(file.type)) {
        toast.error("Only JPG, JPEG, and PNG files are allowed");
        return;
      }

      // Set the field value and preview image
      setFieldValue(fieldName, file);
      setPreview(URL.createObjectURL(file));
    }
  };

  useEffect(() => {
    fetchCategoryApiForProduct(setCategoryList);
    fetchProductTypeApiForProduct(setProductList);
  }, [show]);

  const categoryOptions = categoryList.map((category: any) => ({
    value: category.id,
    label: category.category_name,
  }));
  const productTypesOptions = productTypesList.map((item: any) => ({
    value: item.id,
    label: item.name,
  }));
  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1">
            <p
              className="landing-page-text "
              style={{
                cursor: "pointer",
                color: "blue",
                fontSize: "13px",
                display: "flex",
                justifyContent: "end",
                alignItems: "center",
                marginTop: "10px",
                marginBottom: "10px",
                gap: "10px",
              }}
              onClick={() => openInNewTab("/videoTutorial", 9)}
            >
              Learn More :
              <svg
                xmlns="http://www.w3.org/2000/svg"
                height="24px"
                viewBox="0 -960 960 960"
                width="24px"
                fill="#0000FF"
              >
                <path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" />
              </svg>
                 <span className="close" onClick={handelClose}>
              &times;
            </span>
            </p>
         
            <h2 className="modal-title1 form_header_text">{headerName}</h2>
            <p className="text-center " style={{ color: "#999" }}>
              Please Enter your Product Detail.
            </p>
            <Formik
              enableReinitialize
              initialValues={createProductInitialValues(productToEdit)}
              validationSchema={createProductValidationSchema()}
              onSubmit={handleSubmit}
            >
              {({ errors, touched, setFieldValue, values }) => {
                return (
                  <Form>
                    <div className="  mt-3    d-flex justify-content-center">
                      <div className="mb-3 py-4  ">
                        <div className="row  mx-0 px-2 gy-3  d-flex justify-content-center">
                          <div className="col-6 ">
                            <div className="form-group">
                              <label
                                htmlFor="product_types"
                                className="mb-1 form_label"
                              >
                                Product Types
                                <span className="text-danger">*</span>
                              </label>
                              <FormikCustomSearchDropdown
                                name="product_types"
                                options={productTypesOptions}
                                className={`  ${
                                  errors.product_types &&
                                  touched.product_types &&
                                  "is-invalid input-box-error"
                                }`}
                              />
                              <ErrorMessage
                                name="product_types"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-6 ">
                            <div className="add-source-of-type-section">
                              <p>
                                Product Image
                                <small className="text-danger ps-2">
                                  Best Size(521 X 419px)
                                </small>
                              </p>
                            </div>
                            <div className="imgBox-product">
                              <label htmlFor="input-files-product">
                                {productPreview ? (
                                  <img
                                    src={productPreview}
                                    alt=""
                                    className="imgBox-product-cover animate__animated animate__fadeIn"
                                  />
                                ) : values.product_img ? (
                                  <img
                                    src={values.product_img}
                                    alt=""
                                    className="imgBox-product-cover animate__animated animate__fadeIn"
                                  />
                                ) : (
                                  <img
                                    src={require("../../../../../../assets/images/no_image.jpeg")}
                                    alt=""
                                    className="imgBox-product-cover animate__animated animate__fadeIn"
                                  />
                                )}

                                <div>
                                  <div className="form-group1">
                                    <input
                                      type="file"
                                      name="image"
                                      id="input-files-product"
                                      className="form-control-file border"
                                      onChange={(event) =>
                                        handleFileChange(
                                          event,
                                          "product_img", // The field name you want to set
                                          setFieldValue, // Function to update the field value
                                          setProductPreview // Function to set the image preview
                                        )
                                      }
                                      style={{ display: "none" }}
                                      accept=".png,.jpg,.jpeg"
                                    />
                                  </div>
                                </div>
                              </label>
                            </div>
                          </div>

                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="category_id_b2b"
                                className="mb-1 form_label"
                              >
                                Product Category
                                <span className="text-danger">*</span>
                              </label>
                              <FormikCustomSearchDropdown
                                name="category_id"
                                options={categoryOptions}
                                className={`  ${
                                  errors.category_id &&
                                  touched.category_id &&
                                  "is-invalid input-box-error"
                                }`}
                              />
                              <ErrorMessage
                                name="category_id"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="product_name"
                                className="mb-1 form_label"
                              >
                                Product Name
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                type="text"
                                name="product_name"
                                maxLength={BIG_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.product_name &&
                                  touched.product_name &&
                                  "is-invalid input-box-error"
                                }`}
                              />
                              <ErrorMessage
                                name="product_name"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="product_alias"
                                className="mb-1 form_label"
                              >
                                Product Alias
                              </label>
                              <Field
                                type="text"
                                name="product_alias"
                                maxLength={BIG_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1 `}
                              />
                              <ErrorMessage
                                name="product_alias"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="product_code"
                                className="mb-1 form_label"
                              >
                                Product Code
                              </label>
                              <Field
                                type="text"
                                name="product_code"
                                maxLength={BIG_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1`}
                              />
                              <ErrorMessage
                                name="product_code"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-12 col-md-6 ">
                            <div className="form-group">
                              <label htmlFor="unit" className="pb-2 form_label">
                                Unit Name
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                type="unit"
                                name="unit"
                                maxLength={BIG_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.unit &&
                                  touched.unit &&
                                  "is-invalid input-box-error"
                                }`}
                              />
                              <ErrorMessage
                                name="unit"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>

                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="weight_or_size"
                                className="pb-2 form_label"
                              >
                                Weight/Size
                              </label>
                              <Field
                                type="text"
                                name="weight_or_size"
                                maxLength={SMALL_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.weight_or_size &&
                                  touched.weight_or_size &&
                                  "is-invalid input-box-error"
                                }`}
                                onInput={(e: { target: { value: string } }) => {
                                  e.target.value = e.target.value.replace(
                                    /[^0-9.]/g,
                                    ""
                                  ); // Allow only numbers and dots
                                  if (
                                    (e.target.value.match(/\./g) || []).length >
                                    1
                                  ) {
                                    e.target.value = e.target.value.slice(
                                      0,
                                      -1
                                    ); // Remove extra dots
                                  }
                                }}
                              />
                              <ErrorMessage
                                name="weight_or_size"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="min_stock_quantity"
                                className="pb-2 form_label"
                              >
                                Min Stock Quantity
                              </label>
                              <Field
                                type="text"
                                name="min_stock_quantity"
                                maxLength={SMALL_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.min_stock_quantity &&
                                  touched.min_stock_quantity &&
                                  "is-invalid input-box-error"
                                }`}
                                onInput={(e: { target: { value: string } }) => {
                                  e.target.value = e.target.value.replace(
                                    /[^0-9.]/g,
                                    ""
                                  ); // Allow only numbers and dots
                                  if (
                                    (e.target.value.match(/\./g) || []).length >
                                    1
                                  ) {
                                    e.target.value = e.target.value.slice(
                                      0,
                                      -1
                                    ); // Remove extra dots
                                  }
                                }}
                              />
                              <ErrorMessage
                                name="min_stock_quantity"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="max_stock_quantity"
                                className="pb-2 form_label"
                              >
                                Max Stock Quantity
                              </label>
                              <Field
                                type="text"
                                name="max_stock_quantity"
                                maxLength={SMALL_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.max_stock_quantity &&
                                  touched.max_stock_quantity &&
                                  "is-invalid input-box-error"
                                }`}
                                onInput={(e: { target: { value: string } }) => {
                                  e.target.value = e.target.value.replace(
                                    /[^0-9.]/g,
                                    ""
                                  ); // Allow only numbers and dots
                                  if (
                                    (e.target.value.match(/\./g) || []).length >
                                    1
                                  ) {
                                    e.target.value = e.target.value.slice(
                                      0,
                                      -1
                                    ); // Remove extra dots
                                  }
                                }}
                              />
                              <ErrorMessage
                                name="max_stock_quantity"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-4 col-md-4">
                            <div className="form-group">
                              <label htmlFor="rate" className="pb-2 form_label">
                                Rate
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                type="text"
                                name="rate"
                                maxLength={SMALL_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.rate &&
                                  touched.rate &&
                                  "is-invalid input-box-error"
                                }`}
                                onInput={(e: { target: { value: string } }) => {
                                  e.target.value = e.target.value.replace(
                                    /[^0-9.]/g,
                                    ""
                                  ); // Allow only numbers and dots
                                  if (
                                    (e.target.value.match(/\./g) || []).length >
                                    1
                                  ) {
                                    e.target.value = e.target.value.slice(
                                      0,
                                      -1
                                    ); // Remove extra dots
                                  }
                                }}
                              />
                              <ErrorMessage
                                name="rate"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-4 col-md-4">
                            <div className="form-group">
                              <label htmlFor="GST" className="pb-2 form_label">
                                GST (%)
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                type="text"
                                name="GST"
                                maxLength={MINI_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.GST &&
                                  touched.GST &&
                                  "is-invalid input-box-error"
                                }`}
                                onInput={(e: { target: { value: string } }) => {
                                  e.target.value = e.target.value.replace(
                                    /[^0-9.]/g,
                                    ""
                                  ); // Allow only numbers and dots
                                  if (
                                    (e.target.value.match(/\./g) || []).length >
                                    1
                                  ) {
                                    e.target.value = e.target.value.slice(
                                      0,
                                      -1
                                    ); // Remove extra dots
                                  }
                                }}
                              />
                              <ErrorMessage
                                name="GST"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                          <div className="col-4 col-md-4">
                            <div className="form-group">
                              <label
                                htmlFor="net_rate"
                                className="pb-2 form_label"
                              >
                                Net Rate
                              </label>
                              <Field
                                type="text"
                                name="net_rate"
                                className={`form-control font-size-15 rounded-1   ${
                                  errors.net_rate &&
                                  touched.net_rate &&
                                  "is-invalid input-box-error"
                                }`}
                                disabled={true}
                              />
                              <ErrorMessage
                                name="net_rate"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="col-12 col-12 pt-4 d-flex justify-content-center">
                          <button
                            className="border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label"
                            onClick={handelClose}
                          >
                            Close
                          </button>
                          <button
                            type="submit"
                            className="btn btn-primary px-4 py-2 ms-2  text-light form_label rounded-1"
                            style={{
                              backgroundColor: "#f58634",
                            }}
                          >
                            Save Product
                          </button>
                        </div>
                      </div>
                    </div>
                    <UpdateNetRate />
                  </Form>
                );
              }}
            </Formik>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default CreateProductView;
