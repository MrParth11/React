import { toast } from "react-toastify";
import { TReactSetState } from "../../../../../helpers/AppType";
import {
  axiosInstance,
  axiosInstanceFormData,
} from "../../../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import { checkDuplication } from "../../../../../common/SharedFunction";
import axios from "axios";

export interface IProductView {
  product_name: string;
  product_alias: string;
  product_code: string;
  id: number;
  created_date_time?: string;
  category_id: string;
  unit: string;
  category_name?: string;
  rate: string;
  net_rate: string;
  GST: string;
  product_img: string;
  weight_or_size: string;
  min_stock_quantity: string;
  max_stock_quantity: string;
  product_types: string;
}

export interface IProductStockMovement {
  id: number;
  cart_date: string;
  cart_type: number;
  item_qty: number;
  cart_number: string;
  item_total: number;
  closing_qty: number;
}
export interface IProductCreate {
  product_name: string;
  product_alias: string;
  product_code: string;
  created_date_time?: string;
  category_id: string;
  unit: string;
  category_name?: string;
  rate: string;
  net_rate: string;
  GST: string;
  weight_or_size: string;
}

export const productProductTypesList = [
  { id: "1", order_type: "Quotation" },
  { id: "2", order_type: "Sales Order" },
  { id: "3", order_type: "Sales Invoice" },
  { id: "4", order_type: "Purchase Invoice" },
];
export const handleDeleteProduct = async (
  productId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setLoading: TReactSetState<boolean>,
  setProductList: TReactSetState<IProductView[]>
) => {
  const requestData = {
    table: "products",
    where: `{"id":${productId}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID");
  try {
    const data = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        fetchProductApi(setProductList, setLoading, "");
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createProduct = async (
  productInput: IProductCreate,
  setProductList: TReactSetState<IProductView[]>,
  selectedFile: File | null,
  setLoading: TReactSetState<boolean>,
  clearFormCallback: () => void //
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  const requestData = {
    table: "products",
    data: `{"product_name":"${productInput.product_name}",
      "product_alias":"${productInput.product_alias}",
      "product_code":"${productInput.product_code}",
      "unit":"${productInput.unit}",
      "category_id":"${productInput.category_id}",
      "rate":"${productInput.rate}",
      "GST":"${productInput.GST}",
      "net_rate":"${productInput.net_rate}",
      "a_application_login_id":${Number(getUUID)}}`,
  };
  if (!getUUID) {
    return;
  }
  const formData = new FormData();
  if (selectedFile) {
    console.log("createProduct", selectedFile);

    formData.append("product_img", selectedFile);
  }

  formData.append("product_name", productInput.product_name);
  formData.append("product_alias", productInput.product_alias);
  formData.append("product_code", productInput.product_code);
  formData.append("unit", productInput.unit);
  formData.append("category_id", productInput.category_id);
  formData.append("rate", productInput.rate);
  formData.append("GST", productInput.GST);
  formData.append("net_rate", productInput.net_rate);
  formData.append("weight_or_size", productInput.weight_or_size);
  formData.append("a_application_login_id", getUUID);

  try {
    const { data } = await axiosInstanceFormData.post(
      "create-product",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        fetchProductApi(setProductList, setLoading, "");
        toast.success(data.ack_msg);
        clearFormCallback();
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchCategoryApiForProduct = async (
  setCategoryList: TReactSetState<[]>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "categories",
    columns: "id,category_name",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
    a_application_login_id: getUUID,
  };
  try {
    const response = await axiosInstance.post("commonGet", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });

    setCategoryList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setCategoryList([]);
  }
};

export const fetchProductApi = async (
  setProductList: TReactSetState<IProductView[]>,
  setLoading: TReactSetState<boolean>,
  term: string
) => {
  const token = await localStorage.getItem("token");

  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    a_application_login_id: getUUID,
    searchTerm: term,
  };
  try {
    const data = await axiosInstance.post("product", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });
    if (data.status === 200) {
      if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
        setLoading(false);
        setProductList([]);
      }
      setLoading(true);
      setProductList(data.data.data.item);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000); // 1000 milliseconds (1 seconds)
  }
};

export const updateProduct = async (
  productInput: IProductCreate,
  setProductList: TReactSetState<IProductView[]>,
  editCategoryId: number | undefined,
  setLoading: TReactSetState<boolean>,
  selectedFile: File | null,
  clearForm: () => void
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");
  console.log("productInput", productInput);

  const requestData = {
    table: "products",
    where: `{"id":"${editCategoryId}"}`,
    data: `{"product_name":"${productInput.product_name}",
    "product_alias":"${productInput.product_alias}",
    "product_code":"${productInput.product_code}",
    "unit":"${productInput.unit}","category_id":"${
      productInput.category_id
    }","rate":"${productInput.rate}","GST":"${productInput.GST}","net_rate":"${
      productInput.net_rate
    }","a_application_login_id":${Number(getUUID)}}`,
  };
  const formData = new FormData();
  if (!getUUID) {
    return;
  }
  if (selectedFile) {
    console.log("selectedFile", selectedFile);

    formData.append("product_img", selectedFile);
  }
  if (editCategoryId !== undefined) {
    formData.append("product_id", editCategoryId.toString());
  } else {
    console.error("editCategoryId is undefined");
  }
  formData.append("product_name", productInput.product_name);
  formData.append("product_alias", productInput.product_alias);
  formData.append("product_code", productInput.product_code);
  formData.append("unit", productInput.unit);
  formData.append("category_id", productInput.category_id);
  formData.append("rate", productInput.rate);
  formData.append("GST", productInput.GST);
  formData.append("net_rate", productInput.net_rate);
  formData.append("weight_or_size", productInput.weight_or_size);

  formData.append("a_application_login_id", getUUID);

  try {
    const { data } = await axiosInstanceFormData.post(
      "update-product",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `${token}`,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setProductList((prevList) =>
          prevList.map((category) =>
            category.id === editCategoryId ? data.data : category
          )
        );
        clearForm();
        fetchProductApi(setProductList, setLoading, "");
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchApiProductStockMovement = async (
  setProductStockMovement: TReactSetState<IProductStockMovement[]>,
  productId: number | undefined,
  selectedDates: Date[] | undefined,
  setClosingQty: TReactSetState<number>,
  setOpenQty: TReactSetState<number>
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const requestData: any = {
    a_application_login_id: getUUID,
    productId: productId,
  };

  if (selectedDates && selectedDates.length > 0) {
    requestData.selectedDates = selectedDates;
  }

  try {
    const data = await axiosInstance.post(
      "get-product-stock-movement",
      requestData,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      console.log("datata", data.data.data.item);

      setProductStockMovement(data.data.data.item);
      setClosingQty(data.data.data.closing_qty);
      setOpenQty(data.data.data.open_qty);
    } else {
      setProductStockMovement([]);
      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    setProductStockMovement([]);

    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
