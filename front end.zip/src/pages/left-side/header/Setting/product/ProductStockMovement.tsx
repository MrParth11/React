import React, { useEffect, useState } from "react";
import DateTimeRangePicker from "../../../../../components/DateTimeRangePicker";
import {
  fetchApiProductStockMovement,
  IProductStockMovement,
  IProductView,
  productProductTypesList,
} from "./ProductController";
import { formatDate } from "../../../../../common/SharedFunction";

const ProductStockMovement = ({
  show,
  onHide,
  passDataInAddItem,
}: {
  show: boolean;
  onHide: () => void;

  passDataInAddItem: IProductView | undefined;
}) => {
  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);
  const [productStockMovement, setProductStockMovement] = useState<
    IProductStockMovement[]
  >([]);
  const [closingQty, setClosingQty] = useState(0);
  const [openQty, setOpenQty] = useState(0);

  const getCurrentMonthRange = (): Date[] => {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1); // First day of the month
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0); // Last day of the month
    return [startOfMonth, endOfMonth];
  };
  const [selectDate, setSelectDate] = useState<Date[]>(getCurrentMonthRange);
  useEffect(() => {
    fetchApiProductStockMovement(
      setProductStockMovement,
      passDataInAddItem?.id,
      selectDate,
      setClosingQty,
      setOpenQty
    );
  }, [passDataInAddItem?.id]);

  const handelSearchDateChange = (selectedDates: Date[] | undefined) => {
    console.log("handelSearchChange", selectedDates);

    setSelectDate(selectedDates || []);
    fetchApiProductStockMovement(
      setProductStockMovement,
      passDataInAddItem?.id,
      selectedDates,
      setClosingQty,
      setOpenQty
    );
  };

  console.log("stock", productStockMovement);

  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1" style={{ maxHeight: "80%" }}>
            <span className="close" onClick={onHide}>
              &times;
            </span>
            <h2 className="modal-title1 form_header_text">
              Product Stock Summary of <br />
              {passDataInAddItem?.product_name}
            </h2>
            <div
              className={`m-title-2 col-12 `}
            >
              <div className="head">
                <div>
                  <div>
                    <DateTimeRangePicker
                      value={selectDate}
                      onChange={handelSearchDateChange}
                      showTime={false} // Disable time selection
                      numberOfMonthsShow={1}
                    />
                    <span className="p-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="22px"
                        viewBox="0 -960 960 960"
                        width="22px"
                        fill="#5f6368"
                      >
                        <path d="M200-80q-33 0-56.5-23.5T120-160v-560q0-33 23.5-56.5T200-800h40v-80h80v80h320v-80h80v80h40q33 0 56.5 23.5T840-720v560q0 33-23.5 56.5T760-80H200Zm0-80h560v-400H200v400Zm0-480h560v-80H200v80Zm0 0v-80 80Zm280 240q-17 0-28.5-11.5T440-440q0-17 11.5-28.5T480-480q17 0 28.5 11.5T520-440q0 17-11.5 28.5T480-400Zm-160 0q-17 0-28.5-11.5T280-440q0-17 11.5-28.5T320-480q17 0 28.5 11.5T360-440q0 17-11.5 28.5T320-400Zm320 0q-17 0-28.5-11.5T600-440q0-17 11.5-28.5T640-480q17 0 28.5 11.5T680-440q0 17-11.5 28.5T640-400ZM480-240q-17 0-28.5-11.5T440-280q0-17 11.5-28.5T480-320q17 0 28.5 11.5T520-280q0 17-11.5 28.5T480-240Zm-160 0q-17 0-28.5-11.5T280-280q0-17 11.5-28.5T320-320q17 0 28.5 11.5T360-280q0 17-11.5 28.5T320-240Zm320 0q-17 0-28.5-11.5T600-280q0-17 11.5-28.5T640-320q17 0 28.5 11.5T680-280q0 17-11.5 28.5T640-240Z" />
                      </svg>
                    </span>
                  </div>
                </div>
                <div className="source-of-type-list-grid-block">
                  <div
                    className="source-of-type-list-grid-main"
                    style={{ maxHeight: "55vh", overflowX: "scroll" }}
                  >
                    <table className="table table-hover" border={0}>
                      <thead
                        style={{
                          position: "sticky",
                          top: 0,
                          zIndex: 1000,
                          backgroundColor: "white",
                        }}
                      >
                        <tr style={{ backgroundColor: "#dee2e6" }}>
                          <th></th>
                          <th></th>

                          <th>Opening Quantity : </th>
                          <th>{openQty}</th>
                          <th></th>
                          <th></th>
                        </tr>
                        <tr>
                          <th className="">Date</th>
                          <th>Type</th>
                          <th>Reference</th>
                          <th className="text-end">Qty</th>
                          <th className="text-center">Status</th>
                          <th className="text-end">Value</th>
                        </tr>
                      </thead>
                      <tbody className="text-center">
                        {productStockMovement.length !== 0 ? (
                          <>
                            {productStockMovement &&
                              productStockMovement.map((item, index) => (
                                <tr key={index}>
                                  <td className="text-start">
                                    <span>
                                      {item.cart_date
                                        ? formatDate(item.cart_date)
                                        : ""}
                                    </span>
                                  </td>
                                  <td className="text-start">
                                    <span>
                                      {
                                        productProductTypesList.find(
                                          (OrdItem) =>
                                            Number(OrdItem.id) ===
                                            Number(item.cart_type)
                                        )?.order_type
                                      }
                                    </span>
                                  </td>
                                  <td className="text-start">
                                    {item.cart_number}
                                  </td>
                                  <td className="text-end">
                                    <span>
                                      {item.item_qty ? item.item_qty : ""}
                                    </span>
                                  </td>
                                  <td className="text-center">
                                    <span>
                                      {item.cart_type === 4 ? "In" : "Out"}
                                    </span>
                                  </td>
                                  <td className="text-end">
                                    <span>{item.item_total.toFixed(2)}</span>
                                  </td>
                                </tr>
                              ))}
                          </>
                        ) : (
                          <p className="text-center">No Records Found.</p>
                        )}
                      </tbody>

                      <tfoot
                        style={{
                          position: "sticky",
                          bottom: 0,
                          backgroundColor: "#fff",
                          zIndex: 10,
                        }}
                      >
                        <tr style={{ backgroundColor: "#dee2e6" }}>
                          <td></td>
                          <td></td>
                          <td>
                            <b>Closing Quantity :</b>
                          </td>
                          <td>
                            <b>{closingQty}</b>
                          </td>
                          <td></td>
                          <td></td>

                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default ProductStockMovement;
