import { toast } from "react-toastify";
import { TReactSetState } from "../../../../../helpers/AppType";
import { axiosInstance } from "../../../../../services/axiosInstance";
import {
    DEFAULT_STATUS_CODE_SUCCESS,
    MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../../../helpers/AppConstants";
import { checkDuplication, checkDuplicationUpdate } from "../../../../../common/SharedFunction";

export interface IDepartmentView {
    department_name: string;
    id: number;
    color: string | undefined | null;
    created_date_time?: string;
}

export interface IDepartmentCreate {
    department_name: string;
    color: string | undefined | null;
    created_date_time?: string;
}

export const handleDeleteDepartment = async (
    departmentId: number | undefined,
    setIsDeleteConfirmation: TReactSetState<boolean>,
    setDepartmentList: TReactSetState<IDepartmentView[]>,
    setLoading: TReactSetState<boolean>,
) => {
    const getUUID = localStorage.getItem("UUID")
    const requestData = {
        table: "departments",
        where: `{"id":${departmentId}}`,
        data: `{"isDelete":"1"}`,
        a_application_login_id: getUUID

    };
    try {
        const data = await axiosInstance.post("commonUpdate", requestData,
            {
                headers: {
                    "x-tenant-id": getUUID,

                },
            }
        );
        if (data.data.code === 200) {
            if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {

                setIsDeleteConfirmation(false);
                fetchDepartmentApi(setDepartmentList, setLoading);
            } else {
                toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
            }
        }
    } catch (error: any) {
        toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
};

export const createDepartment = async (
    departmentInput: IDepartmentCreate,
    setDepartmentList: TReactSetState<IDepartmentView[]>,
    setLoading: TReactSetState<boolean>,
    clearFormCallback: () => void //
) => {
    // if (
    //     !(await checkDuplication(
    //         departmentInput.department_name,
    //         "categories",
    //         "category_name"
    //     ))
    // ) {
        const getUUID = await localStorage.getItem("UUID");
        const requestData = {
            table: "departments",
            data: `{"department_name":"${departmentInput.department_name}","color":"${departmentInput.color
                }","a_application_login_id":${Number(getUUID)}}`,
            a_application_login_id: getUUID

        };
        try {
            const { data } = await axiosInstance.post("commonCreate", requestData,
                {
                    headers: {
                        "x-tenant-id": getUUID,

                    },
                }
            );
            if (data.code === 200) {
                if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
                    fetchDepartmentApi(setDepartmentList, setLoading);
                    toast.success(data.ack_msg);
                    clearFormCallback();
                } else {
                    toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
                }
            }
        } catch (error: any) {
            toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
    // } else {
    //     toast.error("Department already available");
    // }
};

export const updateDepartment = async (
    departmentInput: IDepartmentCreate,
    setDepartmentList: TReactSetState<IDepartmentView[]>,
    editCategoryId: number | undefined,
    setLoading: TReactSetState<boolean>,
    clearFormCallback: () => void //

) => {
    // if (
    //     !(await checkDuplicationUpdate(
    //         departmentInput.department_name,
    //         "categories",
    //         "category_name",
    //         editCategoryId
    //     ))
    // ) {
        const getUUID = await localStorage.getItem("UUID");
        const requestData = {
            table: "departments",
            where: `{"id":"${editCategoryId}"}`,
            data: `{"department_name":"${departmentInput.department_name}","color":"${departmentInput.color
                }","a_application_login_id":${Number(getUUID)}}`,
            a_application_login_id: getUUID

        };
        try {
            const { data } = await axiosInstance.post("commonUpdate", requestData,
                {
                    headers: {
                        "x-tenant-id": getUUID,

                    },
                }
            );
            if (data.code === 200) {
                if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
                    clearFormCallback()
                    setDepartmentList((prevList) =>
                        prevList.map((department) =>
                            department.id === editCategoryId ? data.data : department
                        )
                    );
                    fetchDepartmentApi(setDepartmentList, setLoading);
                    toast.success(data.ack_msg);
                } else {
                    toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
                }
            }
        } catch (error: any) {
            toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
    // } else {
    //     toast.error("Department already available");
    // }
};

export const fetchDepartmentApi = async (
    setDepartmentList: TReactSetState<IDepartmentView[]>,
    setLoading: TReactSetState<boolean>,
) => {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
        table: "departments",
        columns: "id,department_name,color",
        where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
        request_flag: 0,
        order: `{"id":"DESC"}`,
        a_application_login_id: getUUID
    };
    try {
        const data = await axiosInstance.post("commonGet", requestData,
            {
                headers: {
                    "x-tenant-id": getUUID,

                },
            }
        );
        console.log("data", data);
        if (data.status === 200) {
            if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
                setLoading(false)
                setDepartmentList([]);
            }
            setLoading(true)
            setDepartmentList(data.data.data);
        }
    } catch (error: any) {
        toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    } finally {
        setTimeout(() => {
            setLoading(false); // Set loading to false after minimum time
        }, 1000); // 1000 milliseconds (1 seconds)
    }
};
