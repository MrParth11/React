import React, { useContext, useEffect, useState } from "react";
import {
  Formik,
  Field,
  Form,
  ErrorMessage,
  FormikErrors,
  FormikTouched,
} from "formik";
import {
  createContact,
  createCustomerInitialValues,
  createCustomerValidationSchema,
  fetchCategoryApiForContact,
  fetchCustomInqFromApiForContact,
  fetchPriceListApiForContact,
  fetchProductApiForContact,
  requirementTypesListForContact,
  updateContact,
} from "./CreateContactController";
import { axiosInstance } from "../../../services/axiosInstance";
import FormikCustomSearchDropdown from "../../../components/FormikCustomSearchDropdown";
import { SingleValue } from "react-select";
import { IOption } from "../../../helpers/AppInterface";
import { AppContext } from "../../../common/AppContext";
import useCheckUserPermission from "../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../helpers/AppEnum";
import {
  ICreateInquiry,
  ICustomFromList,
} from "../../right-side/create-inquiry/CreateInquiryController";
import { BIG_TEXT_LENGTH, MINI_TEXT_LENGTH, SMALL_TEXT_LENGTH } from "../../../helpers/AppConstants";
import { openInNewTab } from "../../../common/SharedFunction";

const CreateContactView = ({
  show,
  onHide,
  setContact,
  contactData,
  headerName,
  setIsCreateContact1,
  closeChatAbout,
}: any) => {
  const { isEditContact, showRightSide, setShowRightSide } =
    useContext(AppContext)!;
  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);

  const [countriesList, setCountriesList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [selectedCountryId, setSelectedCountryId] = useState();
  const [selectedStateId, setSelectedStateId] = useState<number>();
  const [selectedCityId, setSelectedCityId] = useState<number>();
  const [sourceOfTypesList, setSourceOfTypesList] = useState([]);
  const [priceList, setPriceList] = useState<any>([]);
  const [categoryList, setCategoryList] = useState<any>([]);
  const [productList, setProductList] = useState<any>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number>();
  const [customFormList, setCustomFromList] = useState<ICustomFromList[]>([]);

  const [areaList, setAreaList] = useState([]);

  const handleSubmit = async (values: any) => {
    // Handle form submission logic here
    if (contactData?.id) {
      updateContact(
        values,
        setContact,
        contactData?.id,
        setIsCreateContact1,
        closeChatAbout,
        onHide
      );
    } else {
      createContact(values, setContact, onHide);
    }
  };

  const handleCountriesChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("country", selectedOption.value);
      setSelectedStateId(selectedOption.value as number);
    } else {
      setFieldValue("country", "");
      setSelectedStateId(undefined);
    }
  };
  const handleSateChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("state", selectedOption.value);
      setSelectedStateId(selectedOption.value as number);
    } else {
      setFieldValue("state", "");
      setSelectedStateId(undefined);
    }
  };

  const canViewProduct = useCheckUserPermission(
    PAGE_ID.PRODUCT,
    PERMISSION_TYPE.VIEW
  );
  const canViewCategroy = useCheckUserPermission(
    PAGE_ID.CATEGORY,
    PERMISSION_TYPE.VIEW
  );
  const canViewSource = useCheckUserPermission(
    PAGE_ID.SOURCE,
    PERMISSION_TYPE.VIEW
  );
  const canViewPriceList = useCheckUserPermission(
    PAGE_ID.PRICE_LIST,
    PERMISSION_TYPE.VIEW
  );

  const handleCityChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("city", selectedOption.value);
      setSelectedCityId(selectedOption.value as number);
    } else {
      setFieldValue("city", "");
      setSelectedCityId(undefined);
      setAreaList([]);
    }
  };

  const handleSourceTypeChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    setFieldValue("source_type_id", selectedOption?.value);
  };

  const handlePriceListChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    setFieldValue("assinged_to_price_list", selectedOption?.value);
  };
  const handleAreaChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("area", selectedOption.value);
    } else {
      setFieldValue("area", "");
    }
  };

  const fetchcontryapi = async () => {
    const requestData = {
      table: "a_countries",
      columns: "id,country_name,country_code",
      where: `{"isDelete": "0"}`,
    };
    const getUUID = localStorage.getItem("UUID")
    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,

          },
        }
      );

      setCountriesList(response.data.data); // Assuming API response is an array of countries
    } catch (error) {
      console.error("Error fetching countries:", error);
      // Handle error (e.g., show error message, clear filtered list)
      setCountriesList([]);
    }
  };

  const fetchStateapi = async () => {
    const requestData = {
      table: "a_states",
      columns: "id,state_name",
      where: `{"country_id": "${selectedCountryId || 101}"}`,
    };
    const getUUID = localStorage.getItem("UUID")
    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,

          },
        }

      );

      setStateList(response.data.data); // Assuming API response is an array of countries
    } catch (error) {
      console.error("Error fetching countries:", error);
      // Handle error (e.g., show error message, clear filtered list)
      setStateList([]);
    }
  };

  const fetchCityApi = async () => {
    const requestData = {
      table: "a_cities",
      columns: "id,city_name",
      where: `{"state_id": ${selectedStateId}}`,
    };
    const getUUID = localStorage.getItem("UUID")

    try {
      const response = await axiosInstance.post("commonGet", requestData, {
        headers: {
          "x-tenant-id": getUUID,

        },
      }
      );

      setCityList(response.data.data); // Assuming API response is an array of countries
    } catch (error) {
      console.error("Error fetching countries:", error);
      // Handle error (e.g., show error message, clear filtered list)
      setCityList([]);
    }
  };
  const fetchAreaApi = async () => {
    const requestData = {
      table: "a_areas",
      columns: "id,area_name",
      where: `{"city_id": ${selectedCityId}}`,
    };
    const getUUID = localStorage.getItem("UUID")

    try {
      const response = await axiosInstance.post("commonGet", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,

          },
        }
      );

      setAreaList(response.data.data); // Assuming API response is an array of countries
    } catch (error) {
      console.error("Error fetching countries:", error);
      // Handle error (e.g., show error message, clear filtered list)
      setAreaList([]);
    }
  };
  const fetchSourceTypeApi = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const token = await localStorage.getItem("token");
    const requestData = {
      a_application_login_id: getUUID,
    };
    if (canViewSource) {
      try {
        const response = await axiosInstance.post(
          "sourceOfTypes",
          requestData,
          {
            headers: {
              Authorization: `${token}`,
              "x-tenant-id": getUUID,
            },
          }
        );

        setSourceOfTypesList(response.data.data.item); // Assuming API response is an array of countries
      } catch (error) {
        console.error("Error fetching countries:", error);
        // Handle error (e.g., show error message, clear filtered list)
        setSourceOfTypesList([]);
      }
    }
  };
  const handleCategoryChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("category_id", selectedOption.value);
      setSelectedCategoryId(selectedOption.value as number);
    } else {
      setFieldValue("category_id", "");
      setSelectedCategoryId(undefined);
      setProductList([]);
    }
  };
  const updateData = async () => {
    await fetchStateapi();
    await fetchSourceTypeApi();
    if (canViewPriceList) {
      await fetchPriceListApiForContact(setPriceList);
    }
    if (selectedCountryId && !selectedStateId) {
      await fetchStateapi();
      setCityList([]);
      setAreaList([]);
      setSelectedStateId(contactData?.state || undefined);
      setSelectedCityId(undefined);
    } else if (selectedStateId && !selectedCityId) {
      await fetchCityApi();
      setAreaList([]);
      setSelectedCityId(contactData?.city || undefined);
    } else if (selectedCityId) {
      await fetchAreaApi();
    } else {
      if (contactData?.country) {
        await fetchcontryapi();
        setSelectedCountryId(contactData.country);
      } else {
        await fetchcontryapi();
      }
    }
  };
  useEffect(() => {
    updateData();
  }, [selectedCountryId, selectedStateId, selectedCityId, show]);
  useEffect(() => {
    fetchCustomInqFromApiForContact(setCustomFromList);
  }, [show]);
  useEffect(() => {
    if (canViewCategroy) {
      fetchCategoryApiForContact(setCategoryList);
    }
    if (canViewProduct) {
      fetchProductApiForContact(setProductList, selectedCategoryId);
    }
  }, [canViewCategroy, canViewProduct, selectedCategoryId]);
  const stateOptions = stateList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.state_name,
  }));
  const countriesOptions = countriesList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.country_name,
  }));
  const cityOptions = cityList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.city_name,
  }));
  const areaOptions = areaList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.area_name,
  }));
  const sourcTypeOptions = sourceOfTypesList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.source_name,
  }));
  const priceListOptions =
    priceList &&
    priceList.map((itemState: any) => ({
      value: itemState.id,
      label: itemState.price_list_name,
    }));
  const categoryOptions = categoryList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.category_name,
  }));
  const productOptions = productList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.product_name,
  }));
  const requirementTypesOptions = requirementTypesListForContact.map(
    (itemState) => ({
      value: itemState.id,
      label: itemState.requirement_name,
    })
  );

  const renderInputField = (
    item: {
      data_type: number;
      display_order: number;
      required_or_not: number;
      data_sorce: string;
      form_type: number
    },
    name: string,
    fieldName: string,
    setFieldValue: any,
    error: FormikErrors<ICreateInquiry>,
    touched: FormikTouched<ICreateInquiry>
  ) => {
    switch (item.data_type) {
      case 1:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>
              <Field
                type="text"
                name={fieldName}
                className={`form-control`}
                onInput={(e: React.ChangeEvent<HTMLInputElement>) => {
                  e.target.value = e.target.value.replace(/[^0-9]/g, ""); // Allows only numbers
                }}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 2:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>
              <Field
                type="text"
                name={fieldName}
                className={`form-control font-size-15 rounded-1  `}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 3:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                as="textarea"
                name={fieldName}
                className={`form-control`}
                rows={1}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 4:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                type="date"
                name={fieldName}
                className={`form-control font-size-15 rounded-1`}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 5:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                type="datetime-local"
                name={fieldName}
                className={`form-control font-size-15 rounded-1`}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 6:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                type="time"
                name={fieldName}
                className={`form-control font-size-15 rounded-1`}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 7:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>
              <Field name={fieldName}>
                {({ field, form }: any) => (
                  <div className="form-check form-switch">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="descriptionSwitch"
                      {...field}
                      checked={field.value === true} // Ensure the checked state is correctly set
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        // Manually update the value as a boolean
                        form.setFieldValue(fieldName, e.target.checked);
                      }}
                    />
                    <ErrorMessage
                      name={fieldName}
                      component="div"
                      className="field-error text-danger"
                    />
                  </div>
                )}
              </Field>
            </div>
          </div>
        );
      case 8:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                type="text"
                name={fieldName}
                className={`form-control`}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  let value = e.target.value;

                  // Allow only numbers and a single decimal point
                  if (!/^\d*\.?\d*$/.test(value)) {
                    value = value.replace(/[^0-9.]/g, ""); // Remove non-numeric & extra dots
                  }

                  // Ensure only one decimal point exists
                  const decimalCount = (value.match(/\./g) || []).length;
                  if (decimalCount > 1) {
                    value = value.slice(0, -1); // Remove extra decimal point
                  }

                  setFieldValue(fieldName, value);
                }}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 9:
        const getDataSourceForDropDown = item.data_sorce
          ?.split(",")
          .map((item: any) => item.replace(/"/g, ""));

        const dropDownOptions =
          getDataSourceForDropDown &&
          getDataSourceForDropDown.map((item) => ({
            value: item,
            label: item,
          }));
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <FormikCustomSearchDropdown
                name={fieldName}
                options={dropDownOptions}
                className={` `}
              // onChange={handleDropChange}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 10:
        const getDataSourceForRadio = item.data_sorce
          ?.split(",")
          .map((item: any) => item.replace(/"/g, ""));

        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>
              <div className="mt-1">
                <div>
                  {getDataSourceForRadio &&
                    getDataSourceForRadio.map((option, index) => (
                      <label key={index} className="p-1">
                        <Field type="radio" name={fieldName} value={option} />
                        {option}
                      </label>
                    ))}
                </div>
              </div>

              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      default:
        return "No More filed Add";
    }
  };
  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1">

            <div className="d-flex align-items-center justify-content-end">
              <span>
                <p
                  className="landing-page-text text-end"
                  style={{ cursor: "pointer", color: "blue", float: "right", fontSize: "13px" }}
                  onClick={() => openInNewTab("/videoTutorial", 2)}
                >
                  Learn More : <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#0000FF"><path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" /></svg>
                </p>
              </span>

              <span
                className="close ms-3 pb-3"
                 onClick={onHide}
              >
                &times;
              </span>
            </div>
           
            <h2 className="modal-title1 form_header_text">{headerName}</h2>
            <p className="text-center " style={{ color: "#999" }}>
              Please Enter your Contact Detail.
            </p>
            <Formik
              enableReinitialize
              initialValues={createCustomerInitialValues(contactData)}
              validationSchema={createCustomerValidationSchema(customFormList)}
              onSubmit={handleSubmit}
            >
              {({
                errors,
                touched,
                isSubmitting,
                setFieldValue,
                values,
                setFieldError,
                setFieldTouched,
              }) => (
                <Form>
                  <div className="  mt-3    d-flex justify-content-center">
                    <div className="mb-3 py-4  ">
                      <div className="row  mx-0 px-2 gy-3  d-flex justify-content-center"
                        style={{ maxHeight: "600px", overflowX: "scroll" }}
                      >
                        <div className="col-6 col-md-6 ">
                          <div className="form-group">
                            <label htmlFor="name " className="pb-2 form_label">
                              Contact Name
                              <span className="text-danger">*</span>
                            </label>
                            <Field
                              type="text"
                              name="person_name"
                              maxLength={SMALL_TEXT_LENGTH}
                              className={`form-control font-size-15 rounded-1   ${errors.person_name &&
                                touched.person_name &&
                                "is-invalid input-box-error"
                                }`}
                            />

                            <ErrorMessage
                              name="person_name"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="mobile_number"
                              className="pb-2 form_label"
                            >
                              Mobile Number
                             
                            </label>
                            <Field
                              type="text"
                              name="mobile_number"
                              maxLength={MINI_TEXT_LENGTH}
                              className={`form-control font-size-15 rounded-1   ${errors.mobile_number &&
                                touched.mobile_number &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="mobile_number"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6">
                          <div className="form-group">
                            <label
                              htmlFor="country"
                              className="mb-1 form_label"
                            >
                              Country
                            </label>
                            <FormikCustomSearchDropdown
                              name="country"
                              options={countriesOptions}
                              className={`  ${errors.country &&
                                touched.country &&
                                "is-invalid input-box-error"
                                }`}
                              onChange={handleCountriesChange}
                            />
                            <ErrorMessage
                              name="country"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="email_id"
                              className="pb-2 form_label"
                            >
                              Email
                            </label>
                            <Field
                              type="email_id"
                              name="email_id"
                              maxLength={BIG_TEXT_LENGTH}
                              className={`form-control font-size-15 rounded-1   ${errors.email_id &&
                                touched.email_id &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="email_id"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>

                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label htmlFor="state" className="mb-1 form_label">
                              State
                            </label>
                            <FormikCustomSearchDropdown
                              name="state"
                              options={stateOptions}
                              className={`  ${errors.state &&
                                touched.state &&
                                "is-invalid input-box-error"
                                }`}
                              onChange={handleSateChange}
                            />
                            <ErrorMessage
                              name="state"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>

                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label htmlFor="city" className="mb-1 form_label">
                              City
                            </label>
                            <FormikCustomSearchDropdown
                              name="city"
                              options={cityOptions}
                              className={`  ${errors.city &&
                                touched.city &&
                                "is-invalid input-box-error"
                                }`}
                              onChange={handleCityChange}
                            />
                            <ErrorMessage
                              name="city"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6" >

                          <div className="form-group">
                            <label htmlFor="area" className="mb-1 form_label">
                              Area
                            </label>
                            <FormikCustomSearchDropdown
                              name="area"
                              options={areaOptions}
                              className={`  ${errors.area &&
                                touched.area &&
                                "is-invalid input-box-error"
                                }`}
                              onChange={handleAreaChange}

                            />
                            <ErrorMessage
                              name="area"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="pincode"
                              className="pb-2 form_label"
                            >
                              PinCode
                            </label>
                            <Field
                              type="text"
                              name="pincode"
                              className={`form-control font-size-15 rounded-1   ${errors.pincode &&
                                touched.pincode &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="pincode"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label htmlFor="name " className="pb-2 form_label">
                              Address
                            </label>
                            <Field
                              type="text"
                              name="address"
                              className={`form-control font-size-15 rounded-1   ${errors.address &&
                                touched.address &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="address"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label htmlFor="city" className="mb-1 form_label">
                              Source Type
                            </label>
                            <FormikCustomSearchDropdown
                              name="source_type_id"
                              options={sourcTypeOptions}
                              className={`  ${errors.source_type_id &&
                                touched.source_type_id &&
                                "is-invalid input-box-error"
                                }`}
                              onChange={handleSourceTypeChange}
                            />
                            <ErrorMessage
                              name="city"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="assinged_to_price_list"
                              className="mb-1 form_label"
                            >
                              Price List
                            </label>
                            <FormikCustomSearchDropdown
                              name="assinged_to_price_list"
                              options={priceListOptions}
                              className={`  ${errors.assinged_to_price_list &&
                                touched.assinged_to_price_list &&
                                "is-invalid input-box-error"
                                }`}
                              onChange={handlePriceListChange}
                            />
                            <ErrorMessage
                              name="assinged_to_price_list"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="shipping_address"
                              className="pb-2 form_label"
                            >
                              Shipping Address
                            </label>
                            <Field
                              type="text"
                              name="shipping_address"
                              maxLength={BIG_TEXT_LENGTH}
                              className={`form-control font-size-15 rounded-1   ${errors.shipping_address &&
                                touched.shipping_address &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="shipping_address"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="gst_number"
                              className="pb-2 form_label"
                            >
                              GST Number
                            </label>
                            <Field
                              type="text"
                              name="gst_number"
                              maxLength={SMALL_TEXT_LENGTH}
                              className={`form-control font-size-15 rounded-1   ${errors.gst_number &&
                                touched.gst_number &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="gst_number"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6"></div>
                        <hr className="p-0 m-0" />
                        {customFormList.length > 0 &&
                          <div className="col-12 border rounded bg-secondary m-0 mt-1 ">
                            <b
                              style={{
                                cursor: "pointer",
                                display: "block",
                                color: "#ffff",
                              }}
                            >

                              <span className="ms-2">
                                More Contact Information
                              </span>
                            </b>
                          </div>
                        }
                        <div className="row mt-2">
                          {customFormList &&
                            customFormList.map((item) => {

                              return (
                                <React.Fragment
                                  key={item.reference_column_name}
                                >
                                  {item.form_type === 1 ?
                                    <>
                                      {renderInputField(
                                        item,
                                        item.title,
                                        item.reference_column_name,
                                        setFieldValue,
                                        errors,
                                        touched
                                      )}
                                    </>
                                    : ""}
                                </React.Fragment>
                              )
                            })}
                        </div>
                        {/* create inquiry */}
                        {contactData ? (
                          <span></span>
                        ) : (
                          <>
                            <div className="col-12">
                              <p className="text-center form_header_text">
                                Create Inquiry
                              </p>
                            </div>
                            <div className="col-6 col-md-6 ">
                              <div className="form-group">
                                <label
                                  htmlFor="category_id"
                                  className="pb-2 mb-1 form_label"
                                >
                                  Product Category Name
                                </label>
                                <FormikCustomSearchDropdown
                                  name="category_id"
                                  options={categoryOptions}
                                  className={`  ${errors.category_id &&
                                    touched.category_id &&
                                    "is-invalid input-box-error"
                                    }`}
                                  onChange={handleCategoryChange}
                                />

                                <ErrorMessage
                                  name="category_id"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="name "
                                  className="pb-2 form_label"
                                >
                                  Product Name
                                </label>
                                <FormikCustomSearchDropdown
                                  name="product_id"
                                  options={productOptions}
                                  className={`  ${errors.product_id &&
                                    touched.product_id &&
                                    "is-invalid input-box-error"
                                    }`}
                                />
                                <ErrorMessage
                                  name="product_id"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="name "
                                  className="pb-2 form_label"
                                >
                                  Required Quantity
                                </label>
                                <Field
                                  type="text"
                                  name="qty"
                                  className={`form-control font-size-15 rounded-1   ${errors.qty &&
                                    touched.qty &&
                                    "is-invalid input-box-error"
                                    }`}
                                />
                                <ErrorMessage
                                  name="qty"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="static"
                                  className="mb-1 form_label"
                                >
                                  Requirement Type
                                </label>
                                <FormikCustomSearchDropdown
                                  name="static"
                                  options={requirementTypesOptions}
                                  className={`  ${errors.static &&
                                    touched.static &&
                                    "is-invalid input-box-error"
                                    }`}
                                />
                                <ErrorMessage
                                  name="static"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="description"
                                  className="pb-2 form_label"
                                >
                                  Description
                                </label>
                                <Field
                                  as="textarea"
                                  name="description"
                                  maxLength={BIG_TEXT_LENGTH}
                                  className={`form-control ${errors.description && touched.description
                                      ? "is-invalid input-box-error"
                                      : ""
                                    }`}
                                  rows={1}
                                />
                                <ErrorMessage
                                  name="description"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-6"></div>
                            {customFormList.length > 0 &&
                              <div className="col-12 border rounded bg-secondary">
                                <b
                                  style={{
                                    cursor: "pointer",
                                    display: "block",
                                    color: "#ffff",
                                  }}
                                >

                                  <span className="ms-2">
                                    More Inquiry Information
                                  </span>
                                </b>
                              </div>
                            }
                            <div className="row mt-2">
                              {customFormList &&
                                customFormList.map((item) => {

                                  return (
                                    <React.Fragment
                                      key={item.reference_column_name}
                                    >
                                      {item.form_type === 2 ?
                                        <>
                                          {renderInputField(
                                            item,
                                            item.title,
                                            item.reference_column_name,
                                            setFieldValue,
                                            errors,
                                            touched
                                          )}
                                        </>
                                        : ""}
                                    </React.Fragment>
                                  )
                                })}
                            </div>
                          </>
                        )}


                      </div>
                      <div className="col-12 col-12 pt-4 d-flex justify-content-center">
                        <button
                          className="border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label"
                          onClick={onHide}
                        >
                          Close
                        </button>
                        {/* px-4 py-2 ms-2 */}
                        <button
                          type="submit"
                          className="btn btn-primary px-4 py-2 ms-2  text-light form_label rounded-1"
                          style={{
                            backgroundColor: "#f58634",
                          }}
                        >
                          Save Contact
                        </button>
                      </div>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default CreateContactView;
