import * as Yup from "yup";
import { axiosInstance } from "../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";
import { toast } from "react-toastify";
import { TReactSetState } from "../../../helpers/AppType";
import { checkDuplication } from "../../../common/SharedFunction";
import { IPriceListView } from "../header/Setting/priceList/PriceListController";
import { ICustomFromList } from "../../right-side/create-inquiry/CreateInquiryController";

export interface ICreateCustomer {
  email_id: string;
  person_name: string;
  mobile_number: number | string;
  country: string;
  state: string;
  district: string;
  city: string;
  area: string;
  pincode: number | string;
  address: string;
  source_type_id: string;
  assinged_to_price_list: number;
  shipping_address: string;
  gst_number: string;
  qty: string;
  description: string;
  category_id: number;
  product_id: number;
  static: number;
  cntc_column_number_1: number | string;
  cntc_column_number_2: number | string;
  cntc_column_number_3: number | string;
  cntc_column_number_4: number | string;
  cntc_column_number_5: number | string;
  cntc_column_text_1: string;
  cntc_column_text_2: string;
  cntc_column_text_3: string;
  cntc_column_text_4: string;
  cntc_column_text_5: string;
  cntc_column_text_area_1: string;
  cntc_column_text_area_2: string;
  cntc_column_text_area_3: string;
  cntc_column_text_area_4: string;
  cntc_column_text_area_5: string;
  cntc_column_date_1: string;
  cntc_column_date_2: string;
  cntc_column_date_3: string;
  cntc_column_date_4: string;
  cntc_column_date_5: string;
  cntc_column_date_and_time_1: string;
  cntc_column_date_and_time_2: string;
  cntc_column_date_and_time_3: string;
  cntc_column_date_and_time_4: string;
  cntc_column_date_and_time_5: string;
  cntc_column_time_1: string;
  cntc_column_time_2: string;
  cntc_column_time_3: string;
  cntc_column_time_4: string;
  cntc_column_time_5: string;
  cntc_column_switch_1: number | boolean;
  cntc_column_switch_2: number | boolean;
  cntc_column_switch_3: number | boolean;
  cntc_column_switch_4: number | boolean;
  cntc_column_switch_5: number | boolean;
  cntc_column_decimal_1: number | string;
  cntc_column_decimal_2: number | string;
  cntc_column_decimal_3: number | string;
  cntc_column_decimal_4: number | string;
  cntc_column_decimal_5: number | string;
  cntc_column_dropdown_1: string;
  cntc_column_dropdown_2: string;
  cntc_column_dropdown_3: string;
  cntc_column_dropdown_4: string;
  cntc_column_dropdown_5: string;
  cntc_column_radio_1: string;
  cntc_column_radio_2: string;
  cntc_column_radio_3: string;
  cntc_column_radio_4: string;
  cntc_column_radio_5: string;
  column_number_1: number | string;
  column_number_2: number | string;
  column_number_3: number | string;
  column_number_4: number | string;
  column_number_5: number | string;
  column_text_1: string;
  column_text_2: string;
  column_text_3: string;
  column_text_4: string;
  column_text_5: string;
  column_text_area_1: string;
  column_text_area_2: string;
  column_text_area_3: string;
  column_text_area_4: string;
  column_text_area_5: string;
  column_date_1: string;
  column_date_2: string;
  column_date_3: string;
  column_date_4: string;
  column_date_5: string;
  column_date_and_time_1: string;
  column_date_and_time_2: string;
  column_date_and_time_3: string;
  column_date_and_time_4: string;
  column_date_and_time_5: string;
  column_time_1: string;
  column_time_2: string;
  column_time_3: string;
  column_time_4: string;
  column_time_5: string;
  column_switch_1: number | boolean;
  column_switch_2: number | boolean;
  column_switch_3: number | boolean;
  column_switch_4: number | boolean;
  column_switch_5: number | boolean;
  column_decimal_1: number | string;
  column_decimal_2: number | string;
  column_decimal_3: number | string;
  column_decimal_4: number | string;
  column_decimal_5: number | string;
  column_dropdown_1: string;
  column_dropdown_2: string;
  column_dropdown_3: string;
  column_dropdown_4: string;
  column_dropdown_5: string;
  column_radio_1: string;
  column_radio_2: string;
  column_radio_3: string;
  column_radio_4: string;
  column_radio_5: string;
}
export interface ICreateInquiryFromContact {
  qty: string;
}

const ContactNumberRegex = /^[0-9]+$/;

export const requirementTypesListForContact = [
  { id: "0", requirement_name: "One time" },
  { id: "1", requirement_name: "Recurring" },
];
const formatDateForDateTimeLocal = (dateString: string) => {
  if (!dateString) return "";

  // Create a Date object from the UTC time (avoiding automatic timezone conversion)
  const date = new Date(dateString);

  // Extract year, month, date, hours, and minutes
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0"); // Ensure 2 digits
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");

  return `${year}-${month}-${day}T${hours}:${minutes}`;
};
export const createCustomerInitialValues = (
  contactData: ICreateCustomer | undefined
): ICreateCustomer => ({
  person_name: contactData?.person_name || "",
  //   last_name: "",
  email_id: contactData?.email_id || "",
  mobile_number: contactData?.mobile_number || "",
  country: contactData?.country || "",
  state: contactData?.state || "",
  district: contactData?.district || "",
  city: contactData?.city || "",
  area: contactData?.area || "",
  pincode: contactData?.pincode || "",
  address: contactData?.address || "",
  source_type_id: contactData?.source_type_id || "",
  assinged_to_price_list: contactData?.assinged_to_price_list || 0,
  shipping_address: contactData?.shipping_address || "",
  gst_number: contactData?.gst_number || "",
  qty: "",
  description: "",
  category_id: 0,
  product_id: 0,
  static: 0,
  column_number_1: "",
  column_number_2: "",
  column_number_3: "",
  column_number_4: "",
  column_number_5: "",
  column_text_1: "",
  column_text_2: "",
  column_text_3: "",
  column_text_4: "",
  column_text_5: "",
  column_text_area_1: "",
  column_text_area_2: "",
  column_text_area_3: "",
  column_text_area_4: "",
  column_text_area_5: "",
  column_date_1: "",
  column_date_2: "",
  column_date_3: "",
  column_date_4: "",
  column_date_5: "",
  column_date_and_time_1: "",
  column_date_and_time_2: "",
  column_date_and_time_3: "",
  column_date_and_time_4: "",
  column_date_and_time_5: "",
  column_time_1: "00:00 AM",
  column_time_2: "00:00 AM",
  column_time_3: "00:00 AM",
  column_time_4: "00:00 AM",
  column_time_5: "00:00 AM",
  column_switch_1: contactData?.column_switch_1 === 1 ? true : false,
  column_switch_2: contactData?.column_switch_2 === 1 ? true : false,
  column_switch_3: contactData?.column_switch_3 === 1 ? true : false,
  column_switch_4: contactData?.column_switch_4 === 1 ? true : false,
  column_switch_5: contactData?.column_switch_5 === 1 ? true : false,
  column_decimal_1: "",
  column_decimal_2: "",
  column_decimal_3: "",
  column_decimal_4: "",
  column_decimal_5: "",
  column_dropdown_1: "",
  column_dropdown_2: "",
  column_dropdown_3: "",
  column_dropdown_4: "",
  column_dropdown_5: "",
  column_radio_1: "",
  column_radio_2: "",
  column_radio_3: "",
  column_radio_4: "",
  column_radio_5: "",
  cntc_column_number_1: contactData?.cntc_column_number_1 || "",
  cntc_column_number_2: contactData?.cntc_column_number_2 || "",
  cntc_column_number_3: contactData?.cntc_column_number_3 || "",
  cntc_column_number_4: contactData?.cntc_column_number_4 || "",
  cntc_column_number_5: contactData?.cntc_column_number_5 || "",
  cntc_column_text_1: contactData?.cntc_column_text_1 || "",
  cntc_column_text_2: contactData?.cntc_column_text_2 || "",
  cntc_column_text_3: contactData?.cntc_column_text_3 || "",
  cntc_column_text_4: contactData?.cntc_column_text_4 || "",
  cntc_column_text_5: contactData?.cntc_column_text_5 || "",
  cntc_column_text_area_1: contactData?.cntc_column_text_area_1 || "",
  cntc_column_text_area_2: contactData?.cntc_column_text_area_2 || "",
  cntc_column_text_area_3: contactData?.cntc_column_text_area_3 || "",
  cntc_column_text_area_4: contactData?.cntc_column_text_area_4 || "",
  cntc_column_text_area_5: contactData?.cntc_column_text_area_5 || "",
  cntc_column_date_1: contactData?.cntc_column_date_1 || "",
  cntc_column_date_2: contactData?.cntc_column_date_2 || "",
  cntc_column_date_3: contactData?.cntc_column_date_3 || "",
  cntc_column_date_4: contactData?.cntc_column_date_4 || "",
  cntc_column_date_5: contactData?.cntc_column_date_5 || "",
  cntc_column_date_and_time_1: contactData?.cntc_column_date_and_time_1
    ? formatDateForDateTimeLocal(contactData?.cntc_column_date_and_time_1)
    : "",
  cntc_column_date_and_time_2: contactData?.cntc_column_date_and_time_2
    ? formatDateForDateTimeLocal(contactData?.cntc_column_date_and_time_2)
    : "",
  cntc_column_date_and_time_3: contactData?.cntc_column_date_and_time_3
    ? formatDateForDateTimeLocal(contactData?.cntc_column_date_and_time_3)
    : "",
  cntc_column_date_and_time_4: contactData?.cntc_column_date_and_time_4
    ? formatDateForDateTimeLocal(contactData?.cntc_column_date_and_time_4)
    : "",
  cntc_column_date_and_time_5: contactData?.cntc_column_date_and_time_5
    ? formatDateForDateTimeLocal(contactData?.cntc_column_date_and_time_5)
    : "",
  cntc_column_time_1: contactData?.cntc_column_time_1 || "00:00 AM",
  cntc_column_time_2: contactData?.cntc_column_time_2 || "00:00 AM",
  cntc_column_time_3: contactData?.cntc_column_time_3 || "00:00 AM",
  cntc_column_time_4: contactData?.cntc_column_time_4 || "00:00 AM",
  cntc_column_time_5: contactData?.cntc_column_time_5 || "00:00 AM",
  cntc_column_switch_1: contactData?.cntc_column_switch_1 === 1 ? true : false,
  cntc_column_switch_2: contactData?.cntc_column_switch_2 === 1 ? true : false,
  cntc_column_switch_3: contactData?.cntc_column_switch_3 === 1 ? true : false,
  cntc_column_switch_4: contactData?.cntc_column_switch_4 === 1 ? true : false,
  cntc_column_switch_5: contactData?.cntc_column_switch_5 === 1 ? true : false,
  cntc_column_decimal_1: contactData?.cntc_column_decimal_1 || "",
  cntc_column_decimal_2: contactData?.cntc_column_decimal_2 || "",
  cntc_column_decimal_3: contactData?.cntc_column_decimal_3 || "",
  cntc_column_decimal_4: contactData?.cntc_column_decimal_4 || "",
  cntc_column_decimal_5: contactData?.cntc_column_decimal_5 || "",
  cntc_column_dropdown_1: contactData?.cntc_column_dropdown_1 || "",
  cntc_column_dropdown_2: contactData?.cntc_column_dropdown_2 || "",
  cntc_column_dropdown_3: contactData?.cntc_column_dropdown_3 || "",
  cntc_column_dropdown_4: contactData?.cntc_column_dropdown_4 || "",
  cntc_column_dropdown_5: contactData?.cntc_column_dropdown_5 || "",
  cntc_column_radio_1: contactData?.cntc_column_radio_1 || "",
  cntc_column_radio_2: contactData?.cntc_column_radio_2 || "",
  cntc_column_radio_3: contactData?.cntc_column_radio_3 || "",
  cntc_column_radio_4: contactData?.cntc_column_radio_4 || "",
  cntc_column_radio_5: contactData?.cntc_column_radio_5 || "",
});

export const createCustomerValidationSchema = (
  customFormList: ICustomFromList[]
) => {
  const validationSchema: any = {};
  // '1=>Number,2=>Text,3=>TextArea,4=>Date,5=>DateAndTme,6=>Time,7=>switch8=>decimal';
  customFormList &&
    customFormList.forEach((item) => {
      if (item.required_or_not === 1 && item.form_type === 1) {
        switch (item.data_type) {
          case 1: // Number
            validationSchema[item.reference_column_name] = Yup.number()
              .typeError("Must be a number")
              .required("This field is required");

            break;
          case 2: // Text
            validationSchema[item.reference_column_name] =
              Yup.string().required("This field is required");

            break;
          case 3: // Text Area
            validationSchema[item.reference_column_name] = Yup.string()
              .trim()
              .required("This field is required");

            break;
          case 4: // Date
            validationSchema[item.reference_column_name] =
              Yup.string().required("This field is required");
            break;
          case 5: // DateandTime
            validationSchema[item.reference_column_name] =
              Yup.string().required("This field is required");
            break;
          case 6: // Time
            validationSchema[item.reference_column_name] =
              Yup.string().required("This field is required");
            break;
          case 7: // Checkbox
            validationSchema[item.reference_column_name] = Yup.boolean().oneOf(
              [true],
              "This field is required"
            );

            break;
          case 8: // decimal
            validationSchema[item.reference_column_name] =
              Yup.string().required("This field is required");

            break;
          case 9: // decimal
            validationSchema[item.reference_column_name] =
              Yup.string().required("This field is required");

            break;
          case 10: // decimal
            validationSchema[item.reference_column_name] =
              Yup.string().required("This field is required");

            break;
          default:
            break;
        }
      }
    });

  return Yup.object().shape({
    person_name: Yup.string()
      .required("Name is Required"),
    mobile_number: Yup.string()
      .matches(ContactNumberRegex, "Only Numbers are Allowed")
      .max(15, "Max mobile number 15")
      .min(10, "Min mobile number 10"),
    email_id: Yup.string().email("Please write proper email "),
    pincode: Yup.string().matches(
      /^[a-zA-Z0-9]*$/,
      "PinCode should not contain special characters"
    ),
    gst_number: Yup.string()
      .max(15, "Max GST number 15")
      .min(15, "Min GST number 15"),
    ...validationSchema,
  });
};
export const createContact = async (
  values: ICreateCustomer,
  setContact: any,
  onHide: () => void
) => {
  console.log("value", values);

  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  const requestDataCreateContact = {
    person_name: values.person_name,
    mobile_number: values.mobile_number,
    email_id: values.email_id,
    country: values.country,
    state: values.state,
    district: values.district,
    city: values.city,
    area: values.area,
    pincode: values.pincode,
    address: values.address,
    source_type_id: values.source_type_id,
    assinged_to_price_list: values.assinged_to_price_list,
    shipping_address: values.shipping_address,
    gst_number: values.gst_number,
    a_application_login_id: getUUID,
    qty: values.qty,
    description: values.description,
    category_id: values.category_id,
    product_id: values.product_id,
    static: values.static,
    is_unread: 0,
    column_number_1: values.column_number_1,
    column_number_2: values.column_number_2,
    column_number_3: values.column_number_3,
    column_number_4: values.column_number_4,
    column_number_5: values.column_number_5,
    column_text_1: values.column_text_1,
    column_text_2: values.column_text_2,
    column_text_3: values.column_text_3,
    column_text_4: values.column_text_4,
    column_text_5: values.column_text_5,
    column_text_area_1: values.column_text_area_1,
    column_text_area_2: values.column_text_area_2,
    column_text_area_3: values.column_text_area_3,
    column_text_area_4: values.column_text_area_4,
    column_text_area_5: values.column_text_area_5,
    column_date_1: values.column_date_1,
    column_date_2: values.column_date_2,
    column_date_3: values.column_date_3,
    column_date_4: values.column_date_4,
    column_date_5: values.column_date_5,
    column_date_and_time_1: values.column_date_and_time_1,
    column_date_and_time_2: values.column_date_and_time_2,
    column_date_and_time_3: values.column_date_and_time_3,
    column_date_and_time_4: values.column_date_and_time_4,
    column_date_and_time_5: values.column_date_and_time_5,
    column_time_1: values.column_time_1,
    column_time_2: values.column_time_2,
    column_time_3: values.column_time_3,
    column_time_4: values.column_time_4,
    column_time_5: values.column_time_5,
    column_switch_1: values.column_switch_1,
    column_switch_2: values.column_switch_2,
    column_switch_3: values.column_switch_3,
    column_switch_4: values.column_switch_4,
    column_switch_5: values.column_switch_5,
    column_decimal_1: values.column_decimal_1,
    column_decimal_2: values.column_decimal_2,
    column_decimal_3: values.column_decimal_3,
    column_decimal_4: values.column_decimal_4,
    column_decimal_5: values.column_decimal_5,
    column_dropdown_1: values.column_dropdown_1,
    column_dropdown_2: values.column_dropdown_2,
    column_dropdown_3: values.column_dropdown_3,
    column_dropdown_4: values.column_dropdown_4,
    column_dropdown_5: values.column_dropdown_5,
    column_radio_1: values.column_radio_1,
    column_radio_2: values.column_radio_2,
    column_radio_3: values.column_radio_3,
    column_radio_4: values.column_radio_4,
    column_radio_5: values.column_radio_5,
    cntc_column_number_1: values.cntc_column_number_1,
    cntc_column_number_2: values.cntc_column_number_2,
    cntc_column_number_3: values.cntc_column_number_3,
    cntc_column_number_4: values.cntc_column_number_4,
    cntc_column_number_5: values.cntc_column_number_5,
    cntc_column_text_1: values.cntc_column_text_1,
    cntc_column_text_2: values.cntc_column_text_2,
    cntc_column_text_3: values.cntc_column_text_3,
    cntc_column_text_4: values.cntc_column_text_4,
    cntc_column_text_5: values.cntc_column_text_5,
    cntc_column_text_area_1: values.cntc_column_text_area_1,
    cntc_column_text_area_2: values.cntc_column_text_area_2,
    cntc_column_text_area_3: values.cntc_column_text_area_3,
    cntc_column_text_area_4: values.cntc_column_text_area_4,
    cntc_column_text_area_5: values.cntc_column_text_area_5,
    cntc_column_date_1: values.cntc_column_date_1,
    cntc_column_date_2: values.cntc_column_date_2,
    cntc_column_date_3: values.cntc_column_date_3,
    cntc_column_date_4: values.cntc_column_date_4,
    cntc_column_date_5: values.cntc_column_date_5,
    cntc_column_date_and_time_1: values.cntc_column_date_and_time_1,
    cntc_column_date_and_time_2: values.cntc_column_date_and_time_2,
    cntc_column_date_and_time_3: values.cntc_column_date_and_time_3,
    cntc_column_date_and_time_4: values.cntc_column_date_and_time_4,
    cntc_column_date_and_time_5: values.cntc_column_date_and_time_5,
    cntc_column_time_1: values.cntc_column_time_1,
    cntc_column_time_2: values.cntc_column_time_2,
    cntc_column_time_3: values.cntc_column_time_3,
    cntc_column_time_4: values.cntc_column_time_4,
    cntc_column_time_5: values.cntc_column_time_5,
    cntc_column_switch_1: values.cntc_column_switch_1,
    cntc_column_switch_2: values.cntc_column_switch_2,
    cntc_column_switch_3: values.cntc_column_switch_3,
    cntc_column_switch_4: values.cntc_column_switch_4,
    cntc_column_switch_5: values.cntc_column_switch_5,
    cntc_column_decimal_1: values.cntc_column_decimal_1,
    cntc_column_decimal_2: values.cntc_column_decimal_2,
    cntc_column_decimal_3: values.cntc_column_decimal_3,
    cntc_column_decimal_4: values.cntc_column_decimal_4,
    cntc_column_decimal_5: values.cntc_column_decimal_5,
    cntc_column_dropdown_1: values.cntc_column_dropdown_1,
    cntc_column_dropdown_2: values.cntc_column_dropdown_2,
    cntc_column_dropdown_3: values.cntc_column_dropdown_3,
    cntc_column_dropdown_4: values.cntc_column_dropdown_4,
    cntc_column_dropdown_5: values.cntc_column_dropdown_5,
    cntc_column_radio_1: values.cntc_column_radio_1,
    cntc_column_radio_2: values.cntc_column_radio_2,
    cntc_column_radio_3: values.cntc_column_radio_3,
    cntc_column_radio_4: values.cntc_column_radio_4,
    cntc_column_radio_5: values.cntc_column_radio_5,
  };
  const requestDataCreateContactToInquiry = {
    qty: values.qty,
    description: values.description,
    a_application_login_id: getUUID,
  };
  try {
    setContact(false);

    const { data } = await axiosInstance.post(
      "createContact",
      requestDataCreateContact,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        toast.success(data.ack_msg);
        console.log(data.ack_msg);
        
        onHide();
        setContact(true);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      setContact(false);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateContact = async (
  values: ICreateCustomer,
  setContact: any,
  contactId: number | string | undefined,
  setIsCreateContact1: TReactSetState<boolean>,
  closeChatAbout: any,
  onHide: () => void
) => {
  setIsCreateContact1(false);
  console.log("value", values);
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    table: "contact_masters",
    where: `{"id":${contactId}}`,
    data: JSON.stringify({
      person_name: values.person_name,
      mobile_number: values.mobile_number,
      email_id: values.email_id,
      country: values.country,
      state: values.state,
      district: values.district,
      city: values.city,
      area: values.area,
      pincode: values.pincode,
      address: values.address,
      source_type_id: values.source_type_id,
      assinged_to_price_list: values.assinged_to_price_list,
      shipping_address: values.shipping_address,
      gst_number: values.gst_number,
      cntc_column_number_1: values.cntc_column_number_1,
      cntc_column_number_2: values.cntc_column_number_2,
      cntc_column_number_3: values.cntc_column_number_3,
      cntc_column_number_4: values.cntc_column_number_4,
      cntc_column_number_5: values.cntc_column_number_5,
      cntc_column_text_1: values.cntc_column_text_1,
      cntc_column_text_2: values.cntc_column_text_2,
      cntc_column_text_3: values.cntc_column_text_3,
      cntc_column_text_4: values.cntc_column_text_4,
      cntc_column_text_5: values.cntc_column_text_5,
      cntc_column_text_area_1: values.cntc_column_text_area_1,
      cntc_column_text_area_2: values.cntc_column_text_area_2,
      cntc_column_text_area_3: values.cntc_column_text_area_3,
      cntc_column_text_area_4: values.cntc_column_text_area_4,
      cntc_column_text_area_5: values.cntc_column_text_area_5,
      cntc_column_date_1: values.cntc_column_date_1,
      cntc_column_date_2: values.cntc_column_date_2,
      cntc_column_date_3: values.cntc_column_date_3,
      cntc_column_date_4: values.cntc_column_date_4,
      cntc_column_date_5: values.cntc_column_date_5,
      cntc_column_date_and_time_1: values.cntc_column_date_and_time_1,
      cntc_column_date_and_time_2: values.cntc_column_date_and_time_2,
      cntc_column_date_and_time_3: values.cntc_column_date_and_time_3,
      cntc_column_date_and_time_4: values.cntc_column_date_and_time_4,
      cntc_column_date_and_time_5: values.cntc_column_date_and_time_5,
      cntc_column_time_1: values.cntc_column_time_1,
      cntc_column_time_2: values.cntc_column_time_2,
      cntc_column_time_3: values.cntc_column_time_3,
      cntc_column_time_4: values.cntc_column_time_4,
      cntc_column_time_5: values.cntc_column_time_5,
      cntc_column_switch_1: values.cntc_column_switch_1,
      cntc_column_switch_2: values.cntc_column_switch_2,
      cntc_column_switch_3: values.cntc_column_switch_3,
      cntc_column_switch_4: values.cntc_column_switch_4,
      cntc_column_switch_5: values.cntc_column_switch_5,
      cntc_column_decimal_1: values.cntc_column_decimal_1,
      cntc_column_decimal_2: values.cntc_column_decimal_2,
      cntc_column_decimal_3: values.cntc_column_decimal_3,
      cntc_column_decimal_4: values.cntc_column_decimal_4,
      cntc_column_decimal_5: values.cntc_column_decimal_5,
      cntc_column_dropdown_1: values.cntc_column_dropdown_1,
      cntc_column_dropdown_2: values.cntc_column_dropdown_2,
      cntc_column_dropdown_3: values.cntc_column_dropdown_3,
      cntc_column_dropdown_4: values.cntc_column_dropdown_4,
      cntc_column_dropdown_5: values.cntc_column_dropdown_5,
      cntc_column_radio_1: values.cntc_column_radio_1,
      cntc_column_radio_2: values.cntc_column_radio_2,
      cntc_column_radio_3: values.cntc_column_radio_3,
      cntc_column_radio_4: values.cntc_column_radio_4,
      cntc_column_radio_5: values.cntc_column_radio_5,
    }),
  };
  try {
    const data = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });

    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      toast.success(data.data.ack_msg);
      
      onHide();
      setContact(true);
      setIsCreateContact1(true);
      closeChatAbout();
    } else {
      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchPriceListApiForContact = async (
  setPriceListList: TReactSetState<IPriceListView[]>
) => {
  const token = await localStorage.getItem("token");

  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    a_application_login_id: getUUID,
  };
  try {
    const data = await axiosInstance.post("priceListMaster", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setPriceListList([]);
    }
    setPriceListList(data.data.data.item);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchCategoryApiForContact = async (
  setCategoryList: TReactSetState<any>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "categories",
    columns: "id,category_name",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const response = await axiosInstance.post("commonGet", requestData ,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );

    setCategoryList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setCategoryList([]);
  }
};
export const fetchProductApiForContact = async (
  setProductList: TReactSetState<any>,
  selectedCategoryId: any
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "products",
    columns: "id,product_name",
    where: [
      "isDelete=0",
      `category_id=${selectedCategoryId}`,
      `a_application_login_id=${getUUID}||0`,
    ],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const response = await axiosInstance.post("commonGet", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }
    );

    setProductList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setProductList([]);
  }
};

export const fetchCustomInqFromApiForContact = async (
  setCustomFromList: TReactSetState<ICustomFromList[]>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  try {
    const data = await axiosInstance.post(
      "getCustomFieldFrom",
      {
        a_application_login_id: Number(getUUID),
      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setCustomFromList([]);

      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
    setCustomFromList(data.data.data.item);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
