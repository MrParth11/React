import React, { useEffect, useState } from "react";
import { ICompanyTeam } from "./ListCompanyController";

import "../../../components/model/ConfirmationModal.css";
import { axiosInstance } from "../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";
import { toast } from "react-toastify";
import { openInNewTab } from "../../../common/SharedFunction";

interface ITeamRights {
  id: number;
  page_name: string;
  a_page_id_rights_jason: any;
  page_id: number;
}
type PermissionKeys =
  | "view"
  | "add"
  | "edit"
  | "delete"
  | "approve"
  | "import"
  | "print"
  | "share"
  | "all_data"
  | "personal";

const TeamRightsView = ({
  show,
  onHide,
  companyTeamInfo,
}: {
  show: boolean;
  onHide: () => void;
  companyTeamInfo: ICompanyTeam | undefined;
}) => {
  const [teamRightList, setTeamRightList] = useState<ITeamRights[]>([]);
  const [savePermissions, setSavePermissions] = useState<
    Record<
      number,
      { page_name: string; permissions: Record<PermissionKeys, boolean> }
    >
  >({});
  const [updatedPermissions, setUpdatedPermissions] = useState<{
    [key: number]: any;
  }>({});
  console.log("teamRightList", teamRightList);

  const [allToggled, setAllToggled] = useState(false);
  const fetchApiTeamRight = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const token = await localStorage.getItem("token");
    const requestData = {
      a_application_login_id: companyTeamInfo?.id,
    };
    try {
      const data = await axiosInstance.post("getTeamRights", requestData, {
        headers: {
          Authorization: `${token}`,
        },
      });
      if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
        setTeamRightList([]);
      }
      setTeamRightList(data.data.data.item);
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };
  useEffect(() => {
    fetchApiTeamRight();
  }, [show]);
  const handleToggle = (
    id: number,
    field: PermissionKeys,
    page_name: string
  ) => {
    setUpdatedPermissions((prevPermissions) => {
      // Get the existing permissions or fallback to initial state
      const prevRights =
        prevPermissions[id] ||
        (teamRightList.find((item) => item.id === id)?.a_page_id_rights_jason
          ? JSON.parse(
              teamRightList.find((item) => item.id === id)!
                .a_page_id_rights_jason
            )
          : {
              view: 0,
              add: 0,
              edit: 0,
              delete: 0,
              approve: 0,
              import: 0,
              print: 0,
              share: 0,
              all_data: 0,
              personal: 0,
            });

      return {
        ...prevPermissions,
        [id]: {
          ...prevRights,
          // page_name, // ✅ Include page_name
          [field]: prevRights[field] === 1 ? 0 : 1, // ✅ Toggle value properly
        },
      };
    });
  };

  const handleSave = async () => {
    // Send this JSON to API if needed
    const token = await localStorage.getItem("token");

    const finalData = teamRightList.map((item) => {
      // Parse existing rights, ensuring default { view: 0, add: 0 }
      const existingRights = item.a_page_id_rights_jason
        ? JSON.parse(item.a_page_id_rights_jason)
        : {
            view: 0,
            add: 0,
            edit: 0,
            delete: 0,
            approve: 0,
            import: 0,
            print: 0,
            share: 0,
            all_data: 0,
            personal: 0,
          };

      // Merge with updatedPermissions (if toggled)
      const mergedPermissions = updatedPermissions[item.id] || existingRights;

      return {
        page_id: item.page_id ? item.page_id : item.id,
        page_name: item.page_name,
        a_page_id_rights_jason: mergedPermissions,
      };
    });

    console.log("Final Data:", finalData);

    const requestData = {
      permissionsData: finalData,
      a_application_login_id: companyTeamInfo?.id,
    };
    try {
      const response = await axiosInstance.post(
        "createAppLoginRights",
        requestData,
        {
          headers: {
            Authorization: `${token}`,
          },
        }
      );
      console.log("response", response.data);

      if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        toast.success(response.data.ack_msg);
        onHide();
      } else {
        toast.error(response.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } catch (error: any) {
      console.error("Error fetching :", error);
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      // Handle error (e.g., show error message, clear filtered list)
    }
  };
  const handleClose = () => {
    onHide();
    setUpdatedPermissions([]);
  };
  return (
    <React.Fragment>
      {show && (
        <div className="modal1">
          <div
            className="modal-content1"
            style={{
              maxHeight: "90%",
              maxWidth: "100%",
              width: "85vw",
              height: "90vh",
            }}
          >
            <div className="d-flex align-items-center justify-content-between">
              <div className="d-flex justify-content-center align-items-center col-10">
                <h2
                  className="modal-title1 form_header_text"
                  style={{ paddingLeft: "20%" }}
                >
                  You are Granted the Rights of a: {companyTeamInfo?.username}
                </h2>
              </div>

              <div className="d-flex align-items-center justify-content-end col-2">
                <p
                  className="landing-page-text"
                  style={{ cursor: "pointer", color: "blue", fontSize: "13px" }}
                  onClick={() => openInNewTab("/videoTutorial", 26)}
                >
                  Learn More :
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    height="24px"
                    viewBox="0 -960 960 960"
                    width="24px"
                    fill="#0000FF"
                  >
                    <path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" />
                  </svg>
                </p>

                <span
                  className="close ms-3 pb-3"
                  onClick={onHide}
                  style={{ cursor: "pointer" }}
                >
                  &times;
                </span>
              </div>
            </div>
            <p className="text-center " style={{ color: "#999" }}>
              Please Enter your Team Rights
            </p>
            <div className={`m-title-2 col-12 `}>
              <div className="head">
                <div className="source-of-type-list-grid-block">
                  <div
                    className="source-of-type-list-grid-main table-responsive"
                    style={{ maxHeight: "52vh", overflowX: "scroll" }}
                  >
                    <table className="table table-hover" border={0}>
                      <thead
                        style={{
                          position: "sticky",
                          top: 0,
                          zIndex: 1000,
                          backgroundColor: "white",
                        }}
                      >
                        <th className="">No.</th>
                        <th className="text-start">Module Name</th>
                        <th className="text-center">View</th>
                        <th className="text-center">Add</th>
                        <th className="text-center">Edit</th>
                        <th className="text-center">Delete</th>
                        <th className="text-center">Approve</th>
                        <th className="text-center">Import</th>
                        <th className="text-center">Print</th>
                        <th className="text-center">Share</th>
                        <th className="text-center">All Data</th>
                        <th className="text-center">Personal</th>
                        <th className="text-center">Limit</th>
                      </thead>
                      <tbody className="text-center">
                        {teamRightList &&
                          teamRightList.map((item, index) => {
                            const rights = item.a_page_id_rights_jason
                              ? JSON.parse(item.a_page_id_rights_jason)
                              : {
                                  view: 0,
                                  add: 0,
                                  edit: 0,
                                  delete: 0,
                                  approve: 0,
                                  import: 0,
                                  print: 0,
                                  share: 0,
                                  all_data: 0,
                                  personal: 0,
                                };
                            const updatedRights =
                              updatedPermissions[item.id] || rights;

                            return (
                              <tr key={index} className="">
                                <td>{index + 1}</td>
                                <td className="text-start">{item.page_name}</td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.view === 1} // ✅ Ensure default value
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "view",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.add === 1} // ✅ Ensure default value
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "add",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.edit === 1} // ✅ Ensure default value
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "edit",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.delete === 1}
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "delete",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.approve === 1}
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "approve",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.import === 1}
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "import",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.print === 1}
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "print",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.share === 1}
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "share",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.all_data === 1}
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "all_data",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="form-check form-switch  d-flex justify-content-center align-items-center">
                                    <input
                                      className="form-check-input "
                                      type="checkbox"
                                      role="switch"
                                      id="successSwitch"
                                      checked={updatedRights.personal === 1}
                                      onChange={() =>
                                        handleToggle(
                                          item.id,
                                          "personal",
                                          item.page_name
                                        )
                                      }
                                    />
                                  </div>
                                </td>
                                <td
                                  className="text-center"
                                  style={{ width: "8vw" }}
                                >
                                  <div className="search-bar ">
                                    <div className="add-source-of-type-section ">
                                      <input
                                        type="text"
                                        title="Limit"
                                        placeholder="Limit"
                                        value={rights.limit || "Unlimited"}
                                        readOnly
                                        style={{
                                          backgroundColor: "#f0f2f5",
                                          textAlign: "end",
                                        }}
                                      />
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-buttons">
              <button className="modal-button1" onClick={handleClose}>
                Close
              </button>
              <button className="modal-button2" onClick={handleSave}>
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default TeamRightsView;
