import React, { useEffect, useRef, useState } from "react";
import Skeleton from "react-loading-skeleton";
import {
  convertDateTimeFormat,
  formatDateAndTime,
} from "../../../common/SharedFunction";
import {
  companyTeamListRemove,
  fetchCompanyTeamApi,
  ICompanyTeam,
} from "./ListCompanyController";
import ConfirmationModal from "../../../components/model/ConfirmationModal";
import TeamRightsView from "./TeamRightsView";
import ProductStockMovement from "../header/Setting/product/ProductStockMovement";
import AttendanceHistory from "./AttendanceHistory";
import TrackView from "./TrackView";
import {
  BIG_TEXT_LENGTH,
  DEFAULT_MESSAGE_ERROR_PERMISSION,
} from "../../../helpers/AppConstants";
import ExpenseView from "../header/Setting/expense/ExpenseView";
import VisitView from "../header/Setting/visits/VisitView";
import useCheckUserPermission from "../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../helpers/AppEnum";
import { toast } from "react-toastify";
import EditTeamMemberView from "./EditTeam";
import { ITeamMember } from "./EditTeamMemberController";

interface IPropsCompany {
  isCompanyOpen: boolean;
  closeCompany: () => void;
  companyInfo: any;
}

const MyCompanyList = ({
  isCompanyOpen,
  closeCompany,
  companyInfo,
}: IPropsCompany) => {
  const dropdownCompanyListRef = useRef<
    Record<number, HTMLUListElement | null>
  >({});
  const [companyTeamLists, setCompanyTeamLists] = useState<ICompanyTeam[]>([]);
  const [companyTeamListDropdownOpen, setCompanyTeamListDropdownOpen] =
    useState<any>(null);
  const [hasOneData, setHasOneData] = useState<number>();
  const [
    isRemoveCompanyTeamListConfirmation,
    setIsRemoveCompanyTeamListConfirmation,
  ] = useState(false);
  const [isTeamRightsOpen, setIsTeamRightsOpen] = useState(false);
  const [isOpenTracking, setIsOpenTracking] = useState(false);
  const [companyTeamInfo, setCompanyTeamInfo] = useState<ICompanyTeam>();

  const [companyTeamListId, setCompanyTeamListId] = useState<number>();
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [isOpenAttendanceHistory, setIsOpenAttendanceHistory] = useState(false);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(
    null
  );
  const [showExpense, setShowExpense] = useState(false);
  const [showVisit, setShowVisit] = useState(false);
  const [isTeamMemberFormOpen, setIsTeamMemberFormOpen] = useState(false);
  const [selectedTeamMember, setSelectedTeamMember] = useState<any>(null);
  const canViewAttendance = useCheckUserPermission(
    PAGE_ID.ATTENDANCE,
    PERMISSION_TYPE.VIEW
  );

  useEffect(() => {
    fetchCompanyTeamApi(setCompanyTeamLists, companyInfo?.id, "");
  }, [companyInfo?.id]);

  const toggleDropdownCompanyList = (id: number) => {
    setHasOneData(id);
    setCompanyTeamListDropdownOpen((prevId: any) =>
      prevId === id ? null : id
    );
  };

  const handleClickOutside = (event: { target: any }) => {
    const clickedOutside = Object.values(dropdownCompanyListRef.current).every(
      (ref) => ref && !ref.contains(event.target)
    );
    if (clickedOutside) {
      setCompanyTeamListDropdownOpen(null);
    }
  };

  useEffect(() => {
    if (companyTeamListDropdownOpen !== null) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [companyTeamListDropdownOpen]);

  const handelRemoveCompanyTeamList = (id: number) => {
    setCompanyTeamListId(id);
    setIsRemoveCompanyTeamListConfirmation(true);
  };

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (searchTerm.length >= 3 || searchTerm === "") {
        fetchCompanyTeamApi(setCompanyTeamLists, companyInfo?.id, searchTerm);
      }
    }, 1000); // 500ms debounce

    return () => clearTimeout(delayDebounceFn); // Cleanup the timeout on each render
  }, [companyInfo?.id, searchTerm]);

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setSearchTerm(value);
  };

  const handleChange = (item: ICompanyTeam) => {
    setIsTeamRightsOpen(true);
    setCompanyTeamInfo(item);
  };

  const handleTracking = (item: ICompanyTeam) => {
    setIsOpenTracking(true);
    setCompanyTeamInfo(item);
  };

  const handleAttendanceHistory = (item: ICompanyTeam) => {
    if (canViewAttendance) {
      setIsOpenAttendanceHistory(true);
      setCompanyTeamInfo(item);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  function openExpense() {
    setShowExpense(true);
  }

  function openVisit() {
    setShowVisit(true);
  }

  const openEditTeamMemberForm = (item: ICompanyTeam) => {
    setSelectedTeamMember(item);
    setIsTeamMemberFormOpen(true);
  };

  const handleTeamUpdate = (updatedValues: ITeamMember) => {
    // Update companyTeamLists with the new values
    setCompanyTeamLists((prevLists) =>
      prevLists.map((team) =>
        team.id === updatedValues.id
          ? {
              ...team,
              daily_in_time: updatedValues.daily_in_time,
              daily_out_time: updatedValues.daily_out_time,
              per_hour_salary: updatedValues.per_hour_salary,
              reporting_employee: updatedValues.reporting_employee,
              department: updatedValues.department,
            }
          : team
      )
    );

    // Also update companyTeamInfo if it's the same team member
    if (companyTeamInfo?.id === updatedValues.id) {
      setCompanyTeamInfo((prevInfo) =>
        prevInfo
          ? {
              ...prevInfo,
              daily_in_time: updatedValues.daily_in_time,
              daily_out_time: updatedValues.daily_out_time,
              per_hour_salary: updatedValues.per_hour_salary,
              reporting_employee: updatedValues.reporting_employee,
              department: updatedValues.department,
            }
          : prevInfo
      );
    }
  };

  return (
    <>
      {showVisit ? (
        <VisitView
          isVisitView={showVisit}
          closeVisitView={() => setShowVisit(false)}
        />
      ) : showExpense ? (
        <ExpenseView
          isExpenseView={showExpense}
          closeExpenseView={() => setShowExpense(false)}
        />
      ) : isCompanyOpen ? (
        <>
          <div
            className="notifications animate__animated animate__fadeInLeft"
            id="notifications"
          >
            {/* <!-- Header --> */}
            <div className="header-Chat justify-content-between">
              {/* <!-- Icons --> */}
              <div className="d-flex ">
                <div className="ICON">
                  <div
                    aria-disabled="false"
                    role="button"
                    className="icons"
                    data-tab="2"
                    title="Back"
                    aria-label="New chat"
                    onClick={closeCompany}
                  >
                    <span data-testid="chat" data-icon="chat" className="">
                      <svg
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        className=""
                      >
                        <path
                          fill="currentColor"
                          d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                        ></path>
                      </svg>
                    </span>
                  </div>
                </div>

                <div className="newText">
                  <h2>
                    {companyInfo.company_name} Team List
                    <p style={{ fontSize: "14px", fontWeight: "300" }}>
                      Invitation key : {companyInfo.invitation_key}
                    </p>
                  </h2>
                </div>
              </div>
              <div></div>
            </div>

            <div className="h-text">
              <div className="head">
                <div className="search-bar ">
                  <div className="add-source-of-type-section ">
                    <input
                      type="text"
                      title="Add Source Of Type"
                      placeholder="Search company List"
                      maxLength={BIG_TEXT_LENGTH}
                      value={searchTerm}
                      onChange={handleSearchChange}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="chats" style={{ overflowY: "unset" }}>
              <>
                {companyTeamLists &&
                  companyTeamLists.map((item, index) => (
                    <>
                      <div>
                        <ul
                          className={`labelDropLeft-myteam labelDropLeft ${
                            hasOneData === item.id &&
                            companyTeamListDropdownOpen
                              ? "isVisible"
                              : "isHidden"
                          } `}
                          ref={(el) =>
                            (dropdownCompanyListRef.current[item.id] = el)
                          }
                         
                        >
                          {companyInfo.company_flag === 1 &&
                          item.company_flag !== 1 ? ( 
                          <li
                            className="listItem"
                            role="button"
                            onClick={() => openEditTeamMemberForm(item)}
                          >
                            Edit
                          </li>
                            ) : (
                            ""
                          )} 
                          {companyInfo.company_flag === 1 &&
                          item.company_flag !== 1 ? (
                            <li
                              className="listItem"
                              role="button"
                              onClick={() =>
                                handelRemoveCompanyTeamList(item.id)
                              }
                            >
                              Remove
                            </li>
                          ) : (
                            ""
                          )}
                          {companyInfo.company_flag === 1 &&
                          item.company_flag !== 1 ? (
                            <li
                              className="listItem"
                              role="button"
                              onClick={() => handleChange(item)}
                            >
                              Team Rights
                            </li>
                          ) : (
                            ""
                          )}
                          {companyInfo.company_flag !== 2 ||
                          item.company_flag !== 1 ? (
                            <li
                              className="listItem"
                              role="button"
                              onClick={() => handleTracking(item)}
                            >
                              Location Tracking
                            </li>
                          ) : (
                            ""
                          )}
                          {companyInfo.company_flag !== 2 ||
                          item.company_flag !== 1 ? (
                            <li
                              className="listItem"
                              role="button"
                              onClick={() => handleAttendanceHistory(item)}
                              style={{
                                paddingRight: "10%",
                              }}
                            >
                              Attendance History
                            </li>
                          ) : (
                            ""
                          )}
                          {companyInfo.company_flag !== 2 ||
                          item.company_flag === 2 ? (
                            <li
                              className="listItem"
                              role="button"
                              onClick={openVisit}
                            >
                              Visits
                            </li>
                          ) : (
                            ""
                          )}
                          {companyInfo.company_flag !== 2 ||
                          item.company_flag !== 1 ? (
                            <li
                              className="listItem"
                              role="button"
                              onClick={openExpense}
                            >
                              Expenses
                            </li>
                          ) : (
                            ""
                          )}
                        </ul>
                      </div>
                      <button className="block chat-list">
                        <div className="imgBox">
                          <div
                            className="userImg"
                            style={{ marginLeft: "3px" }}
                          >
                            {item?.profile_pic ? (
                              <img
                                src={`${item?.profile_pic}`}
                                alt="Avatar"
                                className="cover"
                              />
                            ) : (
                              <img
                                src={require("../../../assets/images/no_image.jpeg")}
                                alt="Avatar"
                                className="cover"
                              />
                            )}
                          </div>
                        </div>
                        <div className="h-text">
                          <div className="head">
                            <h4>{item.username}</h4>
                            {item.company_flag === 1 && (
                              <span
                                style={{
                                  backgroundColor: "#808080",
                                }}
                                className="badge rounded-pill"
                              >
                                Company Owner
                              </span>
                            )}
                            <button
                              className="icon-more"
                              onClick={() => toggleDropdownCompanyList(item.id)}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 19 20"
                                width="19"
                                height="20"
                                className="hide animate__animated animate__fadeInUp"
                              >
                                <path
                                  fill="currentColor"
                                  d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                ></path>
                              </svg>
                            </button>
                          </div>
                          <div className="message-chat">
                            {/* EMAIL,CONTARY,STATE,CITY,NUMBER */}
                            <div className="chat-text-icon">
                              {/* <div className="d-flex"> */}
                              <span className="thanks">
                                {item.recovery_mobile}
                                {item.recovery_mobile ? "," : ""}
                              </span>
                              <span className="thanks">
                                {item.recovery_email}
                                {item.recovery_email ? "," : ""}
                              </span>
                              {/* </div> */}
                            </div>
                            <div className="text-end col-3">
                              <p className="contact-text">
                                {item.created_date_time
                                  ? convertDateTimeFormat(
                                      item.created_date_time
                                    ).date
                                  : ""}
                              </p>
                              <p className="contact-text">
                                {item.created_date_time
                                  ? convertDateTimeFormat(
                                      item.created_date_time
                                    ).time
                                  : ""}
                              </p>
                            </div>
                          </div>
                        </div>
                      </button>
                    </>
                  ))}
              </>
            </div>
          </div>

          {isRemoveCompanyTeamListConfirmation && (
            <ConfirmationModal
              show={isRemoveCompanyTeamListConfirmation}
              onHide={() => setIsRemoveCompanyTeamListConfirmation(false)}
              handleSubmit={() =>
                companyTeamListRemove(
                  companyTeamListId,
                  setIsRemoveCompanyTeamListConfirmation,
                  setCompanyTeamLists,
                  companyInfo.id
                )
              }
              title={"Remove this Team member"}
              message={"Are You Sure You Want To Remove This Team member?"}
              btn1="CANCEL"
              btn2="Remove"
            />
          )}

          <TeamRightsView
            show={isTeamRightsOpen}
            onHide={() => setIsTeamRightsOpen(false)}
            companyTeamInfo={companyTeamInfo}
          />
        </>
      ) : null}

      {isOpenAttendanceHistory && (
        <AttendanceHistory
          show={isOpenAttendanceHistory}
          onHide={() => setIsOpenAttendanceHistory(false)}
          companyTeamInfo={companyTeamInfo}
        />
      )}

      {isOpenTracking ? (
        <TrackView
          show={isOpenTracking}
          onHide={() => setIsOpenTracking(false)}
          DateAndId=""
          companyTeamInfo={companyTeamInfo}
        />
      ) : null}

      <EditTeamMemberView
        show={isTeamMemberFormOpen}
        onHide={() => {
          setIsTeamMemberFormOpen(false);
          setSelectedTeamMember(null);
          fetchCompanyTeamApi(setCompanyTeamLists, companyInfo?.id, searchTerm);
        }}
        companyTeamInfo={selectedTeamMember}
        onUpdate={handleTeamUpdate}
      />
    </>
  );
};

export default MyCompanyList;