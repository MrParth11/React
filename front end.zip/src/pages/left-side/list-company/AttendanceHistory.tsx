import React, { useEffect, useState } from "react";
import DateTimeRangePicker from "../../../components/DateTimeRangePicker";
import {
  fetchAttendanceHistory,
  IAttendanceHistory,
} from "./ListCompanyController";
import {
  formatDate,
  formatTime,
  formatTimeToAmPm,
  openInNewTab,
} from "../../../common/SharedFunction";
import { ICompanyTeam } from "../LeftSideController";
import { toast } from "react-toastify";

interface IAttendanceHistoryProps {
  show: boolean;
  onHide: () => void;
  companyTeamInfo: ICompanyTeam | undefined;
}

const getCurrentMonthRange = (): Date[] => {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  return [startOfMonth, endOfMonth];
};

const AttendanceHistory = ({
  show,
  onHide,
  companyTeamInfo,
}: IAttendanceHistoryProps) => {
  const [selectDate, setSelectDate] = useState<Date[]>(getCurrentMonthRange);
  const [attendanceHistory, setAttendanceHistory] = useState<IAttendanceHistory[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!companyTeamInfo?.id || !selectDate?.length) {
      setAttendanceHistory([]);
      return;
    }
    setError(null);
    fetchAttendanceHistory(setAttendanceHistory, selectDate, companyTeamInfo.id).catch(() => {
      setError("Failed to fetch attendance history");
      toast.error("Failed to fetch attendance history");
    });
  }, [selectDate, companyTeamInfo?.id]);

  const handleSearchDateChange = (selectedDates: Date[] | undefined) => {
    console.log("handleSearchDateChange", selectedDates);
    setSelectDate(selectedDates || []);
    if (!companyTeamInfo?.id || !selectedDates?.length) {
      setAttendanceHistory([]);
      return;
    }
    fetchAttendanceHistory(setAttendanceHistory, selectedDates, companyTeamInfo.id).catch(() => {
      setError("Failed to fetch attendance history");
      toast.error("Failed to fetch attendance history");
    });
  };

  function formatTime(totalSeconds: number) {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }

  const calculateTotalWorkingHours = () => {
    let totalSeconds = 0;
    attendanceHistory.forEach((item) => {
      item.messages.forEach((e) => {
        const timeStr = e.total_working_hour;
        if (timeStr && typeof timeStr === "string") {
          const [hours, minutes, seconds] = timeStr.split(":").map(Number);
          if (!isNaN(hours) && !isNaN(minutes) && !isNaN(seconds)) {
            totalSeconds += hours * 3600 + minutes * 60 + seconds;
          }
        }
      });
    });
    return formatTime(totalSeconds);
  };

  const calculateSalary = (totalSeconds: number, perHourSalary: string | number) => {
    const totalMinutes = totalSeconds / 60; // Convert seconds to minutes
    const salaryPerHour = typeof perHourSalary === "string" ? parseFloat(perHourSalary) : perHourSalary;
    if (isNaN(salaryPerHour) || salaryPerHour === 0) return "Not Set";
    const salary = (totalMinutes / 60) * salaryPerHour; // Convert minutes to hours and multiply by hourly rate
    return `₹ ${salary.toFixed(2)}`;
  };

  const calculateTotalSalary = () => {
    let totalSeconds = 0;
    attendanceHistory.forEach((item) => {
      item.messages.forEach((e) => {
        const timeStr = e.total_working_hour;
        if (timeStr && typeof timeStr === "string") {
          const [hours, minutes, seconds] = timeStr.split(":").map(Number);
          if (!isNaN(hours) && !isNaN(minutes) && !isNaN(seconds)) {
            totalSeconds += hours * 3600 + minutes * 60 + seconds;
          }
        }
      });
    });
    const totalMinutes = totalSeconds / 60; // Convert seconds to minutes
    const salaryPerHour = typeof per_hour_salary === "string" ? parseFloat(per_hour_salary) : per_hour_salary;
    if (isNaN(salaryPerHour) || salaryPerHour === 0) return "Not Set";
    const totalSalary = (totalMinutes / 60) * salaryPerHour; // Convert minutes to hours and multiply by hourly rate
    return `₹ ${totalSalary.toFixed(2)}`;
  };

  const getAttendanceStatus = (
    actualTime: string,
    expectedTime: string,
    type: "in" | "out"
  ) => {
    if (!actualTime || !expectedTime || expectedTime === "Not Set") return "";
    const normalizeTime = (time: string) => {
      const parts = time.split(":");
      return parts.length === 3 ? parts.slice(0, 2).join(":") : time;
    };
    const normalizedActualTime = normalizeTime(actualTime);
    const normalizedExpectedTime = normalizeTime(expectedTime);
    const actual = new Date(`1970-01-01T${normalizedActualTime}:00`);
    const expected = new Date(`1970-01-01T${normalizedExpectedTime}:00`);
    if (type === "in") {
      return actual > expected ? "Late IN" : "On Time";
    } else {
      return actual < expected ? "Early Out" : "On Time";
    }
  };

  const dailyInTime = companyTeamInfo?.daily_in_time ?? "Not Set";
  const dailyOutTime = companyTeamInfo?.daily_out_time ?? "Not Set";
  const per_hour_salary = companyTeamInfo?.per_hour_salary ?? "Not Set";

  return (
    <div>
      {show && (
        <div className="modal1" style={{ overflowX: "hidden" }}>
          <div
            className="modal-content1"
            style={{ maxHeight: "90%", width: "60%" }}
          >
            <div className="d-flex align-items-center justify-content-between">
              <div className="d-flex justify-content-start align-items-center col-9">
                <h2 className="modal-title1 form_header_text">
                  Attendance History of {companyTeamInfo?.username}
                  <br />
                </h2>
              </div>
              <div className="d-flex align-items-center justify-content-end col-3">
                <p
                  className="landing-page-text"
                  style={{ cursor: "pointer", color: "blue", fontSize: "13px" }}
                  onClick={() => openInNewTab("/videoTutorial", 8)}
                >
                  Learn More :
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    height="24px"
                    viewBox="0 -960 960 960"
                    width="24px"
                    fill="#0000FF"
                  >
                    <path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" />
                  </svg>
                </p>
                <span
                  className="close ms-3 pb-3"
                  onClick={onHide}
                  style={{ cursor: "pointer" }}
                >
                  ×
                </span>
              </div>
            </div>
            <div className="m-title-2 col-12">
              <div className="head">
                <div>
                  <div>
                    <DateTimeRangePicker
                      value={selectDate}
                      onChange={handleSearchDateChange}
                      showTime={false}
                      numberOfMonthsShow={1}
                    />
                    <span className="p-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="22px"
                        viewBox="0 -960 960 960"
                        width="22px"
                        fill="#5f6368"
                      >
                        <path d="M200-80q-33 0-56.5-23.5T120-160v-560q0-33 23.5-56.5T200-800h40v-80h80v80h320v-80h80v80h40q33 0 56.5 23.5T840-720v560q0 33-23.5 56.5T760-80H200Zm0-80h560v-400H200v400Zm0-480h560v-80H200v80Zm0 0v-80 80Zm280 240q-17 0-28.5-11.5T440-440q0-17 11.5-28.5T480-480q17 0 28.5 11.5T520-440q0 17-11.5 28.5T480-400Zm-160 0q-17 0-28.5-11.5T280-440q0-17 11.5-28.5T320-480q17 0 28.5 11.5T360-440q0 17-11.5 28.5T320-400Zm320 0q-17 0-28.5-11.5T600-440q0-17 11.5-28.5T640-480q17 0 28.5 11.5T680-440q0 17-11.5 28.5T640-400ZM480-240q-17 0-28.5-11.5T440-280q0-17 11.5-28.5T480-320q17 0 28.5 11.5T520-280q0 17-11.5 28.5T480-240Zm-160 0q-17 0-28.5-11.5T280-280q0-17 11.5-28.5T320-320q17 0 28.5 11.5T360-280q0 17-11.5 28.5T320-240Zm320 0q-17 0-28.5-11.5T600-280q0-17 11.5-28.5T640-320q17 0 28.5 11.5T680-280q0 17-11.5 28.5T640-240Z" />
                      </svg>
                    </span>
                  </div>
                </div>
                {error && <p className="text-danger">{error}</p>}
                <div className="source-of-type-list-grid-block">
                  <div
                    className="source-of-type-list-grid-main"
                    style={{ maxHeight: "70vh", overflowX: "scroll" }}
                  >
                    <table className="table table-hover" border={0} aria-label="Attendance History">
                      <thead
                        className="text-center"
                        style={{
                          position: "sticky",
                          top: 0,
                          zIndex: 1000,
                          backgroundColor: "white",
                        }}
                      >
                        <tr style={{ backgroundColor: "#dee2e6" }}>
                          <th scope="col">Date</th>
                          <th scope="col">Time (Expected vs Actual)</th>
                          <th scope="col">Status</th>
                          <th scope="col">Total Working Hours</th>
                          <th scope="col">Day ways Salary</th>
                        </tr>
                      </thead>
                      <tbody className="text-center">
                        {attendanceHistory.length !== 0 ? (
                          attendanceHistory.map((item, index) => {
                            const inMessage = item.messages.find(
                              (e) => e.attendance_status === 1
                            );
                            const outMessage = item.messages.find(
                              (e) => e.attendance_status === 2
                            );
                            const inStatus = inMessage
                              ? getAttendanceStatus(
                                  inMessage.attendanceTime,
                                  dailyInTime,
                                  "in"
                                )
                              : "";
                            const outStatus = outMessage
                              ? getAttendanceStatus(
                                  outMessage.attendanceTime,
                                  dailyOutTime,
                                  "out"
                                )
                              : "";
                            let dateTotalSeconds = 0;
                            item.messages.forEach((e) => {
                              const timeStr = e.total_working_hour;
                              if (timeStr && typeof timeStr === "string") {
                                const [hours, minutes, seconds] = timeStr.split(":").map(Number);
                                if (!isNaN(hours) && !isNaN(minutes) && !isNaN(seconds)) {
                                  dateTotalSeconds += hours * 3600 + minutes * 60 + seconds;
                                }
                              }
                            });
                            return (
                              <tr key={index}>
                                <td>{item.date ? formatDate(item.date) : ""}</td>
                             <td>
                                  {item.messages &&
                                    item.messages.map((e, i) => {
                                      if (e.attendance_status === 1) {
                                        return (
                                          <span
                                            style={{
                                              color: "green",
                                              margin: 0,
                                            }}
                                          >
                                            {e.attendanceTime}
                                          </span>
                                        );
                                      } else if (e.attendance_status === 2) {
                                        return (
                                          <>
                                            <span
                                              style={{
                                                color: "red",
                                                marginLeft: "10px",
                                              }}
                                            >
                                              {e.attendanceTime}
                                            </span>
                                            <br />
                                          </>
                                        );
                                      } else {
                                        return (
                                          <>
                                            <span key={i}>
                                              ---------------------------
                                            </span>
                                            <br />
                                          </>
                                        );
                                      }
                                    })}
                                </td>
                                <td>
                                  {inStatus && (
                                    <div
                                      style={{
                                        color: inStatus === "Late IN" ? "orange" : "green",
                                        marginBottom: "5px",
                                      }}
                                    >
                                      {inStatus}
                                    </div>
                                  )}
                                  {outStatus && (
                                    <div
                                      style={{
                                        color: outStatus === "Early Out" ? "orange" : "green",
                                      }}
                                    >
                                      {outStatus}
                                    </div>
                                  )}
                                </td>
                                <td>{formatTime(dateTotalSeconds)}</td>
                                <td>{calculateSalary(dateTotalSeconds, per_hour_salary)}</td>
                              </tr>
                            );
                          })
                        ) : (
                          <tr>
                            <td colSpan={5}>No record found</td>
                          </tr>
                        )}
                      </tbody>
                      <tfoot
                        style={{
                          position: "sticky",
                          bottom: 0,
                          backgroundColor: "#fff",
                          zIndex: 10,
                        }}
                      >
                        <tr>
                          <td colSpan={2} style={{ textAlign: "right" }}>
                            <strong>Total Working Hours :</strong>
                          </td>
                          <td>
                            <strong>{calculateTotalWorkingHours()}</strong>
                          </td>
                           <td colSpan={1} style={{ textAlign: "right" }}>
                            <strong>Total Salary :</strong>
                          </td>
                          <td>
                            <strong>{calculateTotalSalary()}</strong>
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceHistory;