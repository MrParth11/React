import { toast } from "react-toastify";
import { TReactSetState } from "../../../helpers/AppType";
import {axiosInstance} from "../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";

export interface ICompany {
  id: number;
  company_name: string;
  company_email: string;
  company_contact: string;
  created_date_time: string;
  invitation_key: string;
  company_flag: number;
  plan_id:number;
  plan_date:string;
  plan_expiry_date:string
  plan_expiry_flag:number
  trade_india_user_id: string;
  trade_india_profile_id: string;
  trade_india_key: string;
  india_mart_api_key: string;
  whatsapp_authkey: string;
  whatsapp_appkey: string;
  google_lead_sheet_for_faceBook_1: string;
  google_lead_sheet_for_faceBook_2: string;
  google_sheet_key_3: string;
  google_sheet_key_4: string;
}
export type TCountData = {
  teamMembers: number;
  contacts: number;
  inquiries: number;
  totalEmails: number;
  totalSalesOrders: number;
  totalProducts: number;
  totalQuotations: number;
  totalPurchaseInvoices: number;
  totalSalesInvoices: number;
  totalSalesB2bPortalInquiries: number;
   planContactDataLimit:number | string;
    planTeamMembersDataLimit:number | string;
    PlanInquiriesDataLimit:number | string;
    PlanEmailDataLimit:number | string;
    PlanSalesOrdersDataLimit:number | string;
    PlanProductsDataLimit:number | string;
    PlanQuotationsDataLimit:number | string;
    PlanPurchaseInvoicesDataLimit:number | string;
    PlanSalesInvoicesDataLimit:number | string;
    PlanSalesB2bPortalInquiriesDataLimit:number | string;
};

export const planTypesList = [
  { id: "1", order_type_display: "Free" },
  { id: "2", order_type_display: "Started Pack" },
  { id: "3", order_type_display: "Business Pack" },
];

export interface ICompanyTeam {
  id: number;
  username: string;
  recovery_email: string;
  recovery_mobile: string;
  created_date_time: string;
  company_flag:number
  profile_pic:string
}


export interface IAttendanceHistory {
  // attendanceDate: string,
  date: string,
  messages: [
    {
      id: number,
    attendance_status: number,
    a_application_login_id: number,
    check_in_out_date_time: string,
    total_working_hour: string,
    created_date_time: string,
    s_timestemp: string,
    isDelete: number,
    isActive: number,
    company_masters_id: number,
    attendanceDate: string,
    attendanceTime: string
    }
  ]
}

export const fetchCompanyApi = async (
  setCompanyLists: TReactSetState<ICompany[]>,
  term: string,
  setNoDataFound: TReactSetState<any>,
  setCompanyJoinOrCreate: TReactSetState<any>
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    a_application_login_id: getUUID,
    searchTerm: term,
  };
  try {
    const data = await axiosInstance.post("company", requestData, {
      headers: {
        Authorization: `${token}`,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setCompanyLists([]);
    }
    
    setCompanyLists(data.data.data.item);
    setNoDataFound(data.data.data.item.length === 0);
    setCompanyJoinOrCreate(data.data.data.item.length === 0);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchCompanyTeamApi = async (
  setCompanyTeamLists: TReactSetState<ICompanyTeam[]>,
  companyMastersId: number,
  searchTerm:string
) => {
  const token = await localStorage.getItem("token");

  const requestData = {
    company_masters_id: companyMastersId,
    searchTerm:searchTerm
  };
  try {
    const data = await axiosInstance.post(
      "my-team",
      requestData,
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setCompanyTeamLists([]);
    }
    setCompanyTeamLists(data.data.data.item);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const createVaiLink = async (
  data: string,
  setIsJoinConfirmation: TReactSetState<boolean>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  const requestData = {
    a_application_login_id: getUUID,
    invitation_key: data,
    company_flag: 2,
  };
  try {
    const { data } = await axiosInstance.post("invitation_key", requestData, {
      headers: {
        Authorization: `${token}`,
      },
    });
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsJoinConfirmation(false);
        toast.success(data.ack_msg);
      }
    } else {
      setIsJoinConfirmation(true);
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const companyTeamListRemove = async (
  companyTeamId: number | undefined,
  setIsRemoveCompanyTeamListConfirmation: TReactSetState<boolean>,
  setCompanyTeamLists: TReactSetState<ICompanyTeam[]>,
  companyMastersId: number
) => {
  const token = await localStorage.getItem("token");
  try {
    const data = await axiosInstance.post(
      "my-team-remove",
      {
        id: companyTeamId,
        company_masters_id: companyMastersId,
        isDelete: 1,
      },
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );
    if (data.data.code === 200) {
      if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsRemoveCompanyTeamListConfirmation(false);
        fetchCompanyTeamApi(setCompanyTeamLists, companyMastersId ,"");
      } else {
        toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const companyLeave = async (companyIdLeave: number) => {
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    table: "company_vs_application_logins",
    where: `{"company_masters_id":"${companyIdLeave}","a_application_login_id":"${getUUID}"}`,
    data: `{"isDelete":"1"}`,
  };
  try {
    const data = await axiosInstance.post("commonUpdate", requestData);

    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      localStorage.removeItem("token")
      localStorage.removeItem("UUID")
      window.location.reload();
      return true;
    } else {
      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    return false;
  }
};

export const companyDelete = async () => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  try {
    const data = await axiosInstance.post(
      "companyDelete",
      {
        a_application_login_id: getUUID,
        isDelete:1
      },
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );

    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      localStorage.removeItem("token")
      localStorage.removeItem("UUID")
      window.location.reload(); 
      return true;
    } else {
      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    return false;
  }
};

// export const fetchPlanStatisticsCounts = async (setCountData:TReactSetState<TCountData>) => {
//   const getUUID = await localStorage.getItem("UUID");
//   const token = await localStorage.getItem("token");
//   try {
//     const response = await axiosInstance.post("get-plan-statistics",   {
//       a_application_login_id: getUUID,
//       plan_id : token
//     },
//     {
//       headers: {
//         Authorization: `${token}`,
//         "x-tenant-id": getUUID,

//       },
//     }); // Replace with actual API URL
//     if(response.data.ack === 1){
//     setCountData(response.data.data.item);

//     }else{
//       toast.error(response.data.ack_msg)
//     }
//   } catch (error : any) {
//     toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
//   }
// };

export const fetchPlanStatisticsCounts = async (
  setCountData: TReactSetState<TCountData>,
  planId: string | number // Add planId parameter
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");
  try {
    const response = await axiosInstance.post("get-plan-statistics", {
      a_application_login_id: getUUID,
      plan_id: planId // Use the passed planId instead of token
    }, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });
    
    if (response.data.ack === 1) {
      setCountData(response.data.data.item);
    } else {
      toast.error(response.data.ack_msg)
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchAttendanceHistory = async (
  setAttendanceHistory: TReactSetState<IAttendanceHistory[]>,
  selectedDates:Date[] |  undefined,
  companyMasterId: number | undefined
)=>{

  
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");
 
  const requestedData = {
    request_flag: 2,
    a_application_login_id: companyMasterId,
    selectedDates: selectedDates
  }
  console.log("requested Data",requestedData);
  try{
    const data = await axiosInstance.post("view-attendance", requestedData, {
      headers:{
        "x-tenant-id": getUUID,
        Authorization: `${token}`,
      }
    })
    console.log("data",data);
    
    if(data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS){
      return console.log("Error");
    }

    console.log("Data");
    setAttendanceHistory(data.data.data.item);
  }catch(error : any){
    
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);

  }
}