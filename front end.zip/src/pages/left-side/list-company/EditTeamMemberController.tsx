import * as Yup from "yup";
import { axiosInstance } from "../../../services/axiosInstance";
import { toast } from "react-toastify";
import {
  SMALL_TEXT_LENGTH,
  BIG_TEXT_LENGTH,
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";

// Interfaces
export interface ITeamMember {
  id: number;
  name: string;
  email: string;
  mobile_number: string;
  daily_in_time: string;
  daily_out_time: string;
  per_hour_salary: string;
  reporting_employee: number | "";
  department: number | "";
  username?: string;
}

// Initial values
export const teamMemberInitialValues = (companyTeamInfo: any): ITeamMember => ({
  id: companyTeamInfo?.id,
  name: companyTeamInfo?.name || companyTeamInfo?.username || "Unknown User",
  email: companyTeamInfo?.email || companyTeamInfo?.recovery_email || "",
  mobile_number: companyTeamInfo?.mobile_number || companyTeamInfo?.recovery_mobile || "",
  daily_in_time: companyTeamInfo?.daily_in_time || "",
  daily_out_time: companyTeamInfo?.daily_out_time || "",
  per_hour_salary: companyTeamInfo?.per_hour_salary || "",
  reporting_employee: companyTeamInfo?.reporting_employee || "",
  department: companyTeamInfo?.department || "",
  username: companyTeamInfo?.username || "",
});

// Yup validation schema
export const teamMemberValidationSchema = Yup.object({
  name: Yup.string()
    .required("Name is required")
    .max(SMALL_TEXT_LENGTH, `Must be ${SMALL_TEXT_LENGTH} characters or less`),
  email: Yup.string()
    .email("Invalid email format")
    .required("Email is required")
    .max(BIG_TEXT_LENGTH, `Must be ${BIG_TEXT_LENGTH} characters or less`),
  mobile_number: Yup.string()
    .required("Mobile Number is required")
    .matches(/^\d+$/, "Must be a valid number")
    .max(SMALL_TEXT_LENGTH, `Must be ${SMALL_TEXT_LENGTH} characters or less`),
  daily_in_time: Yup.string()
    .required("Daily In Time is required")
    .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format (HH:MM)"),
  daily_out_time: Yup.string()
    .required("Daily Out Time is required")
    .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format (HH:MM)"),
  per_hour_salary: Yup.string()
    .required("Per Hour Salary is required")
    .matches(/^\d*\.?\d*$/, "Must be a valid number")
    .max(SMALL_TEXT_LENGTH, `Must be ${SMALL_TEXT_LENGTH} characters or less`),
  reporting_employee: Yup.number().required("Reporting Employee is required"),
  department: Yup.number().required("Department is required"),
});

// API: Fetch Reporting Employees
export const fetchReportingEmployeesApi = async (setReportingEmployees: (data: any[]) => void) => {
  const token = localStorage.getItem("token");
  const tenantId = localStorage.getItem("UUID");

  try {
    const response = await axiosInstance.post(
      "my-team",
      { a_application_login_id: tenantId },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": tenantId!,
        },
      }
    );

    const result = response.data;
    if (result.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setReportingEmployees([]);
      return;
    }

    const normalizedData = result.data.item.map((user: any) => ({
      ...user,
      name: user.name || user.username || "Unknown User",
    }));

    setReportingEmployees(normalizedData);
  } catch (error) {
    console.error("Error fetching reporting employees:", error);
    toast.error(MESSAGE_UNKNOWN_ERROR_OCCURRED);
    setReportingEmployees([]);
  }
};

// API: Fetch Departments
export const fetchDepartmentsApi = async (setDepartments: (data: any[]) => void) => {
  const tenantId = localStorage.getItem("UUID");

  const requestData = {
    table: "departments",
    columns: "id,department_name,color",
    where: ["isDelete=0", `a_application_login_id=${tenantId}||0`],
    request_flag: 0,
    order: `{"id":"DESC"}`,
    a_application_login_id: tenantId,
  };

  try {
    const response = await axiosInstance.post("commonGet", requestData, {
      headers: { "x-tenant-id": tenantId! },
    });

    const result = response.data;
    if (result.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setDepartments([]);
      return;
    }

    setDepartments(result.data);
  } catch (error) {
    console.error("Error fetching departments:", error);
    toast.error(MESSAGE_UNKNOWN_ERROR_OCCURRED);
    setDepartments([]);
  }
};

// API: Update Team Member
export const updateTeamMember = async (
  values: ITeamMember,
  callback: (updatedValues: ITeamMember) => void, // Updated callback signature
  employeeId: number,
  onHide: () => void
) => {
  const tenantId = localStorage.getItem("UUID");

  if (!tenantId) {
    toast.error("Missing UUID in localStorage");
    return;
  }

  const requestData = {
    table: "a_application_logins",
    where: JSON.stringify({ id: employeeId }),
    data: JSON.stringify({
      daily_in_time: values.daily_in_time,
      daily_out_time: values.daily_out_time,
      per_hour_salary: values.per_hour_salary,
      reporting_member: values.reporting_employee,
      department: values.department,
    }),
  };

  console.log("▶ Update Team Member Payload:", requestData);

  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": tenantId,
      },
    });

    if (data.code !== 200) {
      toast.error("Unexpected server response.");
      return;
    }

    if (data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      toast.error(data.ack_msg || "No records were updated.");
      return;
    }

    toast.success("Team member updated successfully.");
    callback(values); // Pass the updated values to the callback
    onHide();
  } catch (error: any) {
    console.error("❌ Error updating team member:", error);
    toast.error(error?.message || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};