import React, { useContext, useEffect, useState } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import FormikCustomSearchDropdown from "../../../components/FormikCustomSearchDropdown";
import { SingleValue } from "react-select";
import { AppContext } from "../../../common/AppContext";
import { IOption } from "../../../helpers/AppInterface";
import { toast } from "react-toastify";
import * as Yup from "yup";
import {
  ITeamMember,
  teamMemberInitialValues,
  fetchReportingEmployeesApi,
  fetchDepartmentsApi,
  updateTeamMember,
} from "./EditTeamMemberController";
import { BIG_TEXT_LENGTH, SMALL_TEXT_LENGTH } from "../../../helpers/AppConstants";

interface EditTeamMemberViewProps {
  show: boolean;
  onHide: () => void;
  companyTeamInfo: any;
  onUpdate?: (updatedValues: ITeamMember) => void; // Callback to update parent state
}

const teamMemberValidationSchema = Yup.object({
  name: Yup.string()
    .max(SMALL_TEXT_LENGTH, `Name must be less than ${SMALL_TEXT_LENGTH} characters`)
    .required("Name is required"),
  email: Yup.string()
    .email("Invalid email address")
    .max(BIG_TEXT_LENGTH, `Email must be less than ${BIG_TEXT_LENGTH} characters`)
    .required("Email is required"),
  mobile_number: Yup.string()
    .matches(/^[0-9]{10}$/, "Mobile number must be exactly 10 digits")
    .required("Mobile number is required"),
  daily_in_time: Yup.string()
    .matches(
      /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])(:[0-5][0-9])?$/,
      "Invalid time format (HH:MM or HH:MM:SS)"
    )
    .required("Daily in time is required"),
  daily_out_time: Yup.string()
    .matches(
      /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])(:[0-5][0-9])?$/,
      "Invalid time format (HH:MM or HH:MM:SS)"
    )
    .required("Daily out time is required")
    .test("is-after-in-time", "Daily out time must be after daily in time", function (value) {
      const { daily_in_time } = this.parent;
      if (!daily_in_time || !value) return true;

      const normalizeTime = (time: string) => time.split(":").slice(0, 2).join(":");
      const normalizedInTime = normalizeTime(daily_in_time);
      const normalizedOutTime = normalizeTime(value);

      const inTime = new Date(`1970-01-01T${normalizedInTime}:00`);
      const outTime = new Date(`1970-01-01T${normalizedOutTime}:00`);
      return outTime > inTime;
    }),
  per_hour_salary: Yup.number()
    .typeError("Per hour salary must be a number")
    .positive("Per hour salary must be a positive number")
    .required("Per hour salary is required"),
  reporting_employee: Yup.string().required("Reporting employee is required"),
  department: Yup.string().required("Department is required"),
});

const EditTeamMemberView = ({ show, onHide, companyTeamInfo, onUpdate }: EditTeamMemberViewProps) => {
  const { showRightSide, setShowRightSide } = useContext(AppContext)!;
  const [reportingEmployees, setReportingEmployees] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);

  useEffect(() => {
    console.log("EditTeamMemberView companyTeamInfo:", companyTeamInfo);
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault();
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
      fetchReportingEmployeesApi(setReportingEmployees);
      fetchDepartmentsApi(setDepartments);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show, companyTeamInfo]);

  const handleSubmit = async (values: ITeamMember) => {

      try {
        await updateTeamMember(
          values,
          (updatedValues) => {
            if (onUpdate) {
              onUpdate(updatedValues); // Notify parent of updated values
            }
          },
          companyTeamInfo?.id,
          onHide
        );
      } catch (error: any) {
        toast.error(error.response?.data?.message || "Failed to update team member");
      }
  };

  const handleReportingEmployeeChange = (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    setFieldValue("reporting_employee", selectedOption?.value || "", true);
  };

  const handleDepartmentChange = (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    setFieldValue("department", selectedOption?.value || "", true);
  };

  const filteredReportingEmployees = companyTeamInfo?.id
    ? reportingEmployees.filter((employee) => employee.id !== companyTeamInfo.id)
    : reportingEmployees;

  const reportingEmployeeOptions = filteredReportingEmployees.map((employee) => ({
    value: employee.id,
    label: employee.name || employee.username || "Unknown",
  }));

  const departmentOptions = departments.map((dept) => ({
    value: dept.id,
    label: dept.department_name,
  }));

  if (!show || !companyTeamInfo) {
    return null;
  }

  return (
    <React.Fragment>
      <div className="modal1">
        <div className="modal-content1">
          <div className="d-flex align-items-center justify-content-end">
            <span className="close ms-3 pb-3" onClick={onHide}>
              ×
            </span>
          </div>
          <h2 className="modal-title1 form_header_text">Edit Team Member</h2>
          <p className="text-center" style={{ color: "#999" }}>
            Please Update Team Member Details
          </p>
          <Formik
            enableReinitialize
            initialValues={teamMemberInitialValues(companyTeamInfo)}
            validationSchema={teamMemberValidationSchema}
            onSubmit={handleSubmit}
          >
            {({ errors, touched, isSubmitting, setFieldValue, values }) => (
              <Form>
                <div className="mt-3 d-flex justify-content-center">
                  <div className="mb-3 py-4">
                    <div
                      className="row mx-0 px-2 gy-3 d-flex justify-content-center"
                      style={{ maxHeight: "600px", overflowX: "scroll" }}
                    >
                      <div className="col-6">
                        <div className="form-group">
                          <label htmlFor="name" className="pb-2 form_label">
                            Name <span className="text-danger">*</span>
                          </label>
                          <Field
                            type="text"
                            name="name"
                            maxLength={SMALL_TEXT_LENGTH}
                            className={`form-control font-size-15 rounded-1 ${
                              errors.name && touched.name ? "is-invalid input-box-error" : ""
                            }`}
                            disabled
                          />
                          <ErrorMessage
                            name="name"
                            component="div"
                            className="field-error text-danger"
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="form-group">
                          <label htmlFor="email" className="pb-2 form_label">
                            Email <span className="text-danger">*</span>
                          </label>
                          <Field
                            type="email"
                            name="email"
                            maxLength={BIG_TEXT_LENGTH}
                            className={`form-control font-size-15 rounded-1 ${
                              errors.email && touched.email ? "is-invalid input-box-error" : ""
                            }`}
                            disabled
                          />
                          <ErrorMessage
                            name="email"
                            component="div"
                            className="field-error text-danger"
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="form-group">
                          <label htmlFor="mobile_number" className="pb-2 form_label">
                            Mobile Number <span className="text-danger">*</span>
                          </label>
                          <Field
                            type="text"
                            name="mobile_number"
                            maxLength={SMALL_TEXT_LENGTH}
                            className={`form-control font-size-15 rounded-1 ${
                              errors.mobile_number && touched.mobile_number
                                ? "is-invalid input-box-error"
                                : ""
                            }`}
                            disabled
                          />
                          <ErrorMessage
                            name="mobile_number"
                            component="div"
                            className="field-error text-danger"
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="form-group">
                          <label htmlFor="daily_in_time" className="pb-2 form_label">
                            Daily In Time <span className="text-danger">*</span>
                          </label>
                          <Field
                            type="time"
                            name="daily_in_time"
                            className={`form-control font-size-15 rounded-1 ${
                              errors.daily_in_time && touched.daily_in_time
                                ? "is-invalid input-box-error"
                                : ""
                            }`}
                          />
                          <ErrorMessage
                            name="daily_in_time"
                            component="div"
                            className="field-error text-danger"
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="form-group">
                          <label htmlFor="daily_out_time" className="pb-2 form_label">
                            Daily Out Time <span className="text-danger">*</span>
                          </label>
                          <Field
                            type="time"
                            name="daily_out_time"
                            className={`form-control font-size-15 rounded-1 ${
                              errors.daily_out_time && touched.daily_out_time
                                ? "is-invalid input-box-error"
                                : ""
                            }`}
                          />
                          <ErrorMessage
                            name="daily_out_time"
                            component="div"
                            className="field-error text-danger"
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="form-group">
                          <label htmlFor="per_hour_salary" className="pb-2 form_label">
                            Per Hour Salary <span className="text-danger">*</span>
                          </label>
                          <Field
                            type="text"
                            name="per_hour_salary"
                            maxLength={SMALL_TEXT_LENGTH}
                            className={`form-control font-size-15 rounded-1 ${
                              errors.per_hour_salary && touched.per_hour_salary
                                ? "is-invalid input-box-error"
                                : ""
                            }`}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                              let value = e.target.value;
                              if (!/^\d*\.?\d*$/.test(value)) {
                                value = value.replace(/[^0-9.]/g, "");
                                const decimalCount = (value.match(/\./g) || []).length;
                                if (decimalCount > 1) {
                                  value = value.slice(0, -1);
                                }
                              }
                              setFieldValue("per_hour_salary", value);
                            }}
                          />
                          <ErrorMessage
                            name="per_hour_salary"
                            component="div"
                            className="field-error text-danger"
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="form-group">
                          <label htmlFor="reporting_employee" className="pb-2 form_label">
                            Reporting Employee <span className="text-danger">*</span>
                          </label>
                          <FormikCustomSearchDropdown
                            name="reporting_employee"
                            options={reportingEmployeeOptions}
                            value={reportingEmployeeOptions.find(
                              (option) => option.value === values.reporting_employee
                            )}
                            className={`${
                              errors.reporting_employee && touched.reporting_employee
                                ? "is-invalid input-box-error"
                                : ""
                            }`}
                            onChange={(selectedOption: SingleValue<IOption>) =>
                              handleReportingEmployeeChange(selectedOption, setFieldValue)
                            }
                          />
                          <ErrorMessage
                            name="reporting_employee"
                            component="div"
                            className="field-error text-danger"
                          />
                        </div>
                      </div>
                      <div className="col-6">
                        <div className="form-group">
                          <label htmlFor="department" className="pb-2 form_label">
                            Department <span className="text-danger">*</span>
                          </label>
                          <FormikCustomSearchDropdown
                            name="department"
                            options={departmentOptions}
                            value={departmentOptions.find(
                              (option) => option.value === values.department
                            )}
                            className={`${
                              errors.department && touched.department
                                ? "is-invalid input-box-error"
                                : ""
                            }`}
                            onChange={(selectedOption: SingleValue<IOption>) =>
                              handleDepartmentChange(selectedOption, setFieldValue)
                            }
                          />
                          <ErrorMessage
                            name="department"
                            component="div"
                            className="field-error text-danger"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="col-12 pt-4 d-flex justify-content-center">
                      <button
                        className="border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label"
                        onClick={onHide}
                        type="button"
                      >
                        Close
                      </button>
                      <button
                        type="submit"
                        className="btn btn-primary px-4 py-2 ms-2 text-light form_label rounded-1"
                        style={{ backgroundColor: "#f58634" }}
                        disabled={isSubmitting}
                      >
                        Save Team Member
                      </button>
                    </div>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </React.Fragment>
  );
};

export default EditTeamMemberView;