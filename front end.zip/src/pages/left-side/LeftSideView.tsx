import React, { useEffect, useState, useRef, useContext } from "react";
import { useTheme } from "../../components/ThemeContext";
import ConfirmationModal from "../../components/model/ConfirmationModal";
import Group from "./header/Group";
import Starred from "./header/Starred";
import Setting from "./header/Setting/Setting";
import NewChat from "./header/NewChat";
import RightView from "../right-side/RightView";
import Status from "./header/Status";
import {
  ILoginData,
  IUserList,
  deleteContactApi,
  fetchAllCompanyApi,
  fetchDataIndiaMart,
  fetchDataUser,
  fetchGetByIdUser,
  fetchGoogleSheetForFacebook,
  fetchStageStatusApi,
  fetchWhatsAppApiWebhook,
  logOutApi,
  pinContactApi,
  upateCheckBox,
  updateIsUnRead,
  updateStageStatusRadioButton,
  updateUserCheckBox,
  fetchCompanyKeyApi,
  ICompany,
} from "./LeftSideController";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import LoginView from "../public/login/LoginView";
import CreateContactView from "./create-contact/CreateContactView";
import CheckBoxModal from "../../components/model/CheckBoxModal";
import { fetchLabelApi } from "./header/Setting/label/LabelController";
import CheckBoxFilterModal from "../../components/model/CheckBoxFilterModal";
import {
  convertDateTimeFormat,
  formatDateAndTime,
} from "../../common/SharedFunction";
import ListInquiryView from "../right-side/list-inquiry/ListInquiryView";
import ListCompanyView from "./list-company/ListCompanyView";
import ListMyCompanyView from "./list-company/MyCompanyList";
import ListReminderView from "./header/list-reminder/ListReminderView";
import { AppContext } from "../../common/AppContext";
import DashboardView from "../dashboard/DashboardView";
import ImportExcelForContactModal from "../../components/model/ImportExcelForContactModal";
import { IUserInfo } from "../public/otp-verification/OTPVerificationController";
import RadioButtonModal from "../../components/model/RadioButtonModal";
import ExcelExport from "../../components/ExcelExport";
import OrderCreateModal from "../../components/model/OrderCreateModal";
import ListNoteView from "./Personal-Notes/NoteView";
import { clearConfig } from "dompurify";
import useCheckUserPermission from "../../hooks/useCheckUserPermission";
import { toast } from "react-toastify";
import { PAGE_ID, PERMISSION_TYPE, SHORT_KEY } from "../../helpers/AppEnum";
import {
  DEFAULT_MESSAGE_ERROR_PERMISSION,
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
  MINI_TEXT_LENGTH,
} from "../../helpers/AppConstants";
import { axiosInstance } from "../../services/axiosInstance";

import {
  registerServiceWorker,
  requestFirebaseToken,
  setupForegroundMessageHandler,
} from "../../FirebaseConfig";
import IntroductionVideo from "../../components/IntroductionVideo";

interface IPropsLeftView {
  isVisible: boolean;
  userInfo?: IUserInfo;
}
// console.log("userInfo",userInfo);

const LeftSideView = ({ isVisible, userInfo }: IPropsLeftView) => {
  const {
    isEditContact,
    showRightSide,
    setShowRightSide,
    setCheckToken,
    setPermissions,
  } = useContext(AppContext)!;

  const token = localStorage.getItem("token");
  const localId = localStorage.getItem("UUID");

  const [hasInitializedFirebase, setHasInitializedFirebase] = useState(false);

  useEffect(() => {
    const initializeFirebase = async () => {
      if (hasInitializedFirebase) return;

      try {
        // Register the service worker
        await registerServiceWorker();

        // Request Firebase token
        const tokenNotification = await requestFirebaseToken();

        if (tokenNotification) {
          console.log("FCM Token:", tokenNotification);

          // Update the notification token in the backend
          const updateNotificationTokenInContact = async (
            tokenNotification: string
          ): Promise<boolean> => {
            const requestData = {
              table: "a_application_logins",
              where: `{"id":${localId}}`,
              data: `{"web_refresh_token":"${tokenNotification}"}`,
            };

            try {
              const response = await axiosInstance.post(
                "commonUpdate",
                requestData,
                {
                  headers: {
                    "x-tenant-id": localId,
                  },
                }
              );

              if (response.data.code === 200) {
                if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
                  return true;
                } else {
                  toast.error(
                    response.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED
                  );
                  return false;
                }
              } else {
                toast.error(MESSAGE_UNKNOWN_ERROR_OCCURRED);
                return false;
              }
            } catch (error: any) {
              toast.error(error.message || MESSAGE_UNKNOWN_ERROR_OCCURRED);
              return false;
            }
          };

          // Call the function to update the token
          await updateNotificationTokenInContact(tokenNotification);
        }

        setHasInitializedFirebase(true); // Mark as initialized
      } catch (error) {
        console.error("Firebase initialization error:", error);
        toast.error("Failed to initialize Firebase messaging");
      }
    };

    initializeFirebase();
    setupForegroundMessageHandler((message) => {
      // console.log('Received foreground message:', message);
      toast.success(message.notification?.body);
    });
  }, [hasInitializedFirebase]);

  useEffect(() => {
    // Update timestamp every second using setTimeout

    const LoginSubmit = async () => {
      const getUUID = await localStorage.getItem("UUID");

      try {
        const response = await axiosInstance.post(
          "onLoad",
          {
            a_application_login_id: getUUID, // This is the payload you want to send
          },
          {
            headers: token ? { Authorization: `${token}` } : {}, // Optional headers
          }
        );

        if (response.data.ack === 1) {
          setPermissions(response.data.data.resultRights);
        } else {
        }
      } catch (error: any) {
        if (error.response && error.response.status === 401) {
        } else {
          toast.error(error?.response?.data?.ack_msg);
        }
      }
    };
    LoginSubmit();
  }, [setPermissions, token]);

  const listInnerRef = useRef<HTMLDivElement>(null);
  const { darkMode } = useTheme();
  const dropdownRef = useRef<HTMLButtonElement>(null);
  const dropdownContactRef = useRef<Record<number, HTMLUListElement | null>>(
    {}
  );

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [labelDropdownOpen, setLabelDropdownOpen] = useState<any>(null);
  const [showListInquiry, setShowListInquiry] = useState(false);
  const [isCloseConfirmation, setIsCloseConfirmation] = useState(false);
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [issetShareId, setShareId] = useState(false);
  const [isPinConfirmation, setIsPinConfirmation] = useState<{
    show: boolean;
    type: "pin" | "unpin" | null;
  }>({
    show: false,
    type: null,
  });
  const [isNotes, setIsNotes] = useState(false);
  const [isCreateContact, setIsCreateContact] = useState(false);
  const [showGroup, setShowGroup] = useState(false);
  const [showStarred, setshowStarred] = useState(false);
  const [showSetting, setshowSetting] = useState(false);
  const [showNewChat, setshowNewChat] = useState(false);
  const [showDashBoard, setshowDashBoard] = useState(false);
  const [showAichat, setshowAichat] = useState(false);
  const [showStatus, setShowStatus] = useState(false);
  const [user, setUsers] = useState<IUserList[]>([]);
  const [user1, setUsers1] = useState(false);

  const [contInfo, setcontInfo] = useState<IUserList>();
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [noDataFound, setNoDataFound] = useState(false);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(
    null
  ); // State to hold the timeout
  const [noDataFound1, setNoDataFound1] = useState(false);
  const [loginById, setLoginById] = useState<ILoginData>();
  const [isLoadContact, setIsLoadContact] = useState(true);
  const [isRefers, setIsRefers] = useState(true);

  const [hasOneData, setHasOneData] = useState<number>();
  const [contactId, setContactId] = useState<number>();

  const [userAssignContactId, setUserAssignContactId] = useState<number>();
  const [statusAssignContactId, setStatusAssignContactId] = useState<number>();

  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const [isModalAssignStatusVisible, setIsModalAssignStatusVisible] =
    useState<boolean>(false);
  const [contInfoEdit, setcontInfoEdit] = useState<IUserList>();

  const [isModalEditContactVisible, setIsModalEditContactVisible] =
    useState<boolean>(false);

  const [isModalAssignUserVisible, setIsModalAssignUserVisible] =
    useState<boolean>(false);

  const [isModalExcelVisible, setIsModalExcelVisible] =
    useState<boolean>(false);

  const [isModalFilterVisible, setIsModalFilterVisible] =
    useState<boolean>(false);
  const [options, setOptions] = useState<any[]>([]);
  const [optionJoinCompany, setOptionJoinCompany] = useState<any[]>([]);
  const [optionRadioButtonStatus, setOptionRadioButtonStatus] = useState<any[]>(
    []
  );

  const [contactSelections, setContactSelections] = useState<
    Record<number, any[]>
  >({});
  const [showListAllInquiry, setShowListAllInquiry] = useState(false);
  const [showListAllReminder, setShowListAllReminder] = useState(false);

  const [showListCompany, setShowListCompany] = useState(false);
  const [showListMyCompany, setShowListMyCompany] = useState(false);
  const [showListnote, setShowListNote] = useState(false);
  const [selectedLabelIds, setSelectedLabelIds] = useState<string | undefined>(
    ""
  );
  const [hasData, setHasData] = useState<boolean>(false);
  const [editorContentToEdit, setEditorContentToEdit] = useState<string>("");
  const [isOrderCreateFromContactShow, setIsOrderCreateFromContactShow] =
    useState(false);
  const [isOrderShowFromContactType, setIsOrderShowFromContactType] =
    useState(0);
  const [contactInfoOrder, setContactInfoOrder] = useState<IUserList>();
  const [companyLists, setCompanyLists] = useState<ICompany>();
  const [showQr, setShowQr] = useState(false);
  const [showCreateContact, setShowCreateContact] = useState(false);
  const [createContactTrigger, setCreateContactTrigger] = useState(0);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const [filterParams, setFilterParams] = useState({
    filterData: null,
    checkedOptions: null,
    checkedSourceTypes: null,
    startSearchDate: "",
    endSearchDate: "",
    checkedOptionsStageStatus: null,
    checkedOptionsUser: null,
  });
  const canEdit = useCheckUserPermission(PAGE_ID.CONTACT, PERMISSION_TYPE.EDIT);

  const canView = useCheckUserPermission(PAGE_ID.CONTACT, PERMISSION_TYPE.VIEW);

  const canAdd = useCheckUserPermission(PAGE_ID.CONTACT, PERMISSION_TYPE.ADD);

  const canDelete = useCheckUserPermission(
    PAGE_ID.CONTACT,
    PERMISSION_TYPE.DELETE
  );

  const canExport = useCheckUserPermission(
    PAGE_ID.CONTACT,
    PERMISSION_TYPE.SHARE
  );

  const canImport = useCheckUserPermission(
    PAGE_ID.CONTACT,
    PERMISSION_TYPE.IMPORT
  );
  const canViewLabel = useCheckUserPermission(
    PAGE_ID.LABEL,
    PERMISSION_TYPE.VIEW
  );
  const canViewStatus = useCheckUserPermission(
    PAGE_ID.STATUS,
    PERMISSION_TYPE.VIEW
  );
  const canAddQuo = useCheckUserPermission(
    PAGE_ID.QUOTATION,
    PERMISSION_TYPE.ADD
  );
  const canAddOrder = useCheckUserPermission(
    PAGE_ID.ORDER,
    PERMISSION_TYPE.ADD
  );
  const canAddInv = useCheckUserPermission(
    PAGE_ID.INVOICE,
    PERMISSION_TYPE.ADD
  );
  const canAddPurchase = useCheckUserPermission(
    PAGE_ID.PURCHASE,
    PERMISSION_TYPE.ADD
  );
  const canViewInq = useCheckUserPermission(
    PAGE_ID.INQUIRY,
    PERMISSION_TYPE.VIEW
  );
  const canViewDash = useCheckUserPermission(
    PAGE_ID.INSIGHT,
    PERMISSION_TYPE.VIEW
  );
  const canViewMsg = useCheckUserPermission(
    PAGE_ID.CONTACT_MESSAGE_HISTORY,
    PERMISSION_TYPE.VIEW
  );
  const canAddAssignTeamMember = useCheckUserPermission(
    PAGE_ID.ASSIGN_TO_TEAM_MEMBER,
    PERMISSION_TYPE.ADD
  );
  const canViewThirdPArtyLeadGeneration = useCheckUserPermission(
    PAGE_ID.THIRD_PARTY_LEAD_GENERATION,
    PERMISSION_TYPE.ADD
  );
  const canViewSmartFilter = useCheckUserPermission(
    PAGE_ID.SMART_SEARCH_AND_FILTER,
    PERMISSION_TYPE.VIEW
  );

  const handleLogout = () => {
    logOutApi(setIsCloseConfirmation);
  };
  const openGrp = () => {
    setShowGroup(true);
  };
  const openCompany = () => {
    setShowListCompany(true);
  };
  const openRightSide = (singleData: IUserList) => {
    if (canViewMsg) {
      setshowDashBoard(false);
      setShowRightSide(true);
      setshowAichat(false);
      setcontInfo(singleData);

      setEditorContentToEdit(""); // Clear editor content on contact change
      if (singleData.is_unread === 0) {
        updateIsUnRead(singleData.id, setIsRefers);
      }
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const toggleDropdownLabel = (id: number) => {
    setHasOneData(id);
    setLabelDropdownOpen((prevId: any) => (prevId === id ? null : id));
  };
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener("click", handleOutsideClick);

    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, []);

  const openSettings = () => {
    setshowSetting(true);
  };

  function openStatus() {
    setShowStatus(true);
  }

  function SystemReload() {
    window.location.reload();
  }

  const openForm = () => {
    setshowNewChat(true);
  };
  const openNotes = () => {
    setShowListNote(true);
  };
  const openMyCompany = async () => {
    try {
      await fetchCompanyKeyApi(setCompanyLists);
    } catch (error: any) {}
    setShowListMyCompany(true);
  };
  const itemsPerPage: number = 12;

  const handelRefreshContacts = async () => {
    try {
      // Call fetchWhatsAppApiWebhook first
      await fetchWhatsAppApiWebhook(setLoading);

      // Call fetchDataIndiaMart second
      if (canViewThirdPArtyLeadGeneration) {
        await fetchDataIndiaMart(setLoading);

        // Call fetchGoogleSheetForFacebook third
        await fetchGoogleSheetForFacebook(setLoading);
      }

      // Call fetchDataUser fourth
      await fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setCheckToken
      );
    } catch (error) {
      console.error("Error refreshing contacts:", error);
    }
  };
  useEffect(() => {
    if (canView) {
      setTimeout(() => {
        fetchDataUser(
          0,
          "",
          setUsers,
          itemsPerPage,
          setNoDataFound,
          setLoading,
          token,
          localId,
          setContactId,
          setSelectedLabelIds,
          setCheckToken
        );
        setCurrentPage(0); // Reset page to 0 when search term changes
      }, 100);
    }
    fetchGetByIdUser(localId, setLoginById);
  }, [
    canView,
    localId,
    setCheckToken,
    token,
    isModalEditContactVisible,
    isCreateContact,
    isEditContact,
  ]);
  useEffect(() => {
    if (canView) {
      if (isRefers) {
        setTimeout(() => {
          fetchDataUser(
            0,
            "",
            setUsers,
            itemsPerPage,
            setNoDataFound,
            setLoading,
            token,
            localId,
            setContactId,
            setSelectedLabelIds,
            setCheckToken
          );
          setCurrentPage(0); // Reset page to 0 when search term changes
        }, 100);
      }
    }
  }, [isRefers, canView]);
  useEffect(() => {
    if (noDataFound1) {
      handleLogout();
    }
    if (isModalVisible) {
      fetchLabelApi(setOptions, setLoading);
    }
    if (isModalAssignUserVisible) {
      fetchAllCompanyApi(setOptionJoinCompany);
    }
    if (isModalAssignStatusVisible) {
      fetchStageStatusApi(setOptionRadioButtonStatus);
    }
  }, [
    noDataFound1,
    isModalVisible,
    isModalAssignUserVisible,
    isModalAssignStatusVisible,
  ]);
  useEffect(() => {
    const handleScroll = () => {
      if (
        listInnerRef.current &&
        listInnerRef.current.scrollTop + listInnerRef.current.clientHeight ===
          listInnerRef.current.scrollHeight
      ) {
        if (user.length < (currentPage + 1) * itemsPerPage + 1) {
          fetchDataUser(
            currentPage + 1,
            searchTerm,
            setUsers,
            itemsPerPage,
            setNoDataFound,
            setLoading,
            token,
            localId,
            setContactId,
            setSelectedLabelIds,
            setCheckToken,
            filterParams.filterData,
            filterParams.checkedOptions,
            filterParams.checkedSourceTypes,
            filterParams.startSearchDate,
            filterParams.endSearchDate,
            filterParams.checkedOptionsStageStatus,
            filterParams.checkedOptionsUser
          );
        }
        setCurrentPage((prevPage) => prevPage + 1);
      }
    };

    const listInnerElement = listInnerRef.current;

    if (listInnerElement) {
      listInnerElement.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (listInnerElement) {
        listInnerElement.removeEventListener("scroll", handleScroll);
      }
    };
  }, [
    user.length,
    showSetting,
    showListAllInquiry,
    showListCompany,
    showListMyCompany,
    showListnote,
  ]);

  // Handler for search input change
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setSearchTerm(value);
    if (value.length >= 3 || value === "") {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }

      // Set new timeout to trigger API call after 5 seconds
      setSearchTimeout(
        setTimeout(() => {
          fetchDataUser(
            0,
            value,
            setUsers,
            itemsPerPage,
            setNoDataFound,
            setLoading,
            token,
            localId,
            setContactId,
            setSelectedLabelIds,
            setCheckToken
          );
          setCurrentPage(0); // Reset page to 0 when search term changes
        }, 1000)
      );
    }
  };

  const handleModalOpen = (id: number | undefined) => {
    if (canViewLabel) {
      setContactId(id);
      setIsModalVisible(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handleModalOpenUserAssign = (id: number | undefined) => {
    if (canAddAssignTeamMember) {
      setUserAssignContactId(id);
      setIsModalAssignUserVisible(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handleModalOpenStatusAssign = (id: number | undefined) => {
    if (canViewStatus) {
      setStatusAssignContactId(id);
      setIsModalAssignStatusVisible(true);
    } else {
      setIsModalAssignStatusVisible(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleModalClose = () => {
    if (isModalVisible) {
      setIsModalVisible(false);
    } else {
      setIsModalFilterVisible(false);
    }
  };
  const handleConfirm = async (
    contactId: number | undefined,
    checkedOptions: any[]
  ) => {
    if (contactId === undefined) return;

    await upateCheckBox(contactId, checkedOptions, setLoading);
    setTimeout(() => {
      fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setNoDataFound1
      );
      setCurrentPage(0); // Reset page to 0 when search term changes
    }, 100);
    setContactSelections((prev) => ({
      ...prev,
      [contactId]: checkedOptions,
    }));
    setIsModalVisible(false);
  };
  const handleConfirmRadioButton = async (checkedOptions: any[]) => {
    if (statusAssignContactId === undefined) return;

    await updateStageStatusRadioButton(
      statusAssignContactId,
      checkedOptions,
      setLoading
    );
    setTimeout(() => {
      fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setNoDataFound1
      );
      setCurrentPage(0); // Reset page to 0 when search term changes
    }, 100);
    setContactSelections((prev) => ({
      ...prev,
      [statusAssignContactId]: checkedOptions,
    }));
    setIsModalAssignStatusVisible(false);
  };
  const handleConfirmAssignUser = async (
    contactId: number | undefined,
    checkedOptions: any[]
  ) => {
    if (userAssignContactId === undefined) return;

    await updateUserCheckBox(userAssignContactId, checkedOptions, setLoading);
    setTimeout(() => {
      fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setNoDataFound1
      );
      setCurrentPage(0); // Reset page to 0 when search term changes
    }, 100);
    setContactSelections((prev) => ({
      ...prev,
      [userAssignContactId]: checkedOptions,
    }));
    setIsModalAssignUserVisible(false);
  };
  const handleConfirmFilter = async (
    filterData: any,
    checkedOptions: any,
    checkedSourceTypes: any,
    startSearchDate: string,
    endSearchDate: string,
    checkedOptionsStageStatus: any,
    checkedOptionsUser: any
  ) => {
    setFilterParams({
      filterData,
      checkedOptions,
      checkedSourceTypes,
      startSearchDate,
      endSearchDate,
      checkedOptionsStageStatus,
      checkedOptionsUser,
    });
    setHasData(
      checkedOptions?.length > 0 ||
        checkedSourceTypes?.length > 0 ||
        filterData?.country !== undefined ||
        filterData?.state !== undefined ||
        filterData?.city !== undefined ||
        filterData?.area !== undefined ||
        startSearchDate !== "" ||
        endSearchDate !== "" ||
        checkedOptionsStageStatus?.length > 0 ||
        checkedOptionsUser?.length > 0
    );
    setTimeout(() => {
      fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setCheckToken,
        filterData,
        checkedOptions,
        checkedSourceTypes,
        startSearchDate,
        endSearchDate,
        checkedOptionsStageStatus,
        checkedOptionsUser
      );
      setCurrentPage(0); // Reset page to 0 when search term changes
    }, 100);

    setIsModalFilterVisible(false);
  };

  const getSelectedOptionsForContact = (contactId: number | undefined) => {
    return contactId ? contactSelections[contactId] || [] : [];
  };
  const getSelectedOptionsForContactFilter = (
    contactId: number | undefined
  ) => {
    return contactId ? contactSelections[contactId] || [] : [];
  };
  const handleClickOutside = (event: { target: any }) => {
    const clickedOutside = Object.values(dropdownContactRef.current).every(
      (ref) => ref && !ref.contains(event.target)
    );
    if (clickedOutside) {
      setLabelDropdownOpen(null);
    }
  };

  useEffect(() => {
    if (labelDropdownOpen !== null) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [labelDropdownOpen]);
  const handleConfirmImportExcel = async () => {
    setIsModalExcelVisible(false);
    await fetchDataUser(
      0,
      "",
      setUsers,
      itemsPerPage,
      setNoDataFound,
      setLoading,
      token,
      localId,
      setContactId,
      setSelectedLabelIds,
      setNoDataFound1
    );
  };
  const handelChangeShowModelQuotation = (item: IUserList) => {
    if (canAddQuo) {
      setContactInfoOrder(item);
      setIsOrderShowFromContactType(1);
      setIsOrderCreateFromContactShow(true);
    } else {
      setIsOrderCreateFromContactShow(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelChangeShowModelOrder = (item: IUserList) => {
    if (canAddOrder) {
      setContactInfoOrder(item);
      setIsOrderShowFromContactType(2);
      setIsOrderCreateFromContactShow(true);
    } else {
      setIsOrderCreateFromContactShow(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelChangeShowModelInvoice = (item: IUserList) => {
    if (canAddInv) {
      setContactInfoOrder(item);
      setIsOrderShowFromContactType(3);
      setIsOrderCreateFromContactShow(true);
    } else {
      setIsOrderCreateFromContactShow(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelChangeShowModelPurchase = (item: IUserList) => {
    if (canAddPurchase) {
      setContactInfoOrder(item);
      setIsOrderShowFromContactType(4);
      setIsOrderCreateFromContactShow(true);
    } else {
      setIsOrderCreateFromContactShow(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const columns = [
    "ID",
    "Contact Person",
    "Email Id",
    "Mobile Number",
    "Country Name",
    "State Name",
    "City Name",
    "Area Name",
    "Address",
    "Shipping Address",
    "GST Number",
    "Source Name",
    "Status/Stage",
    "Label Name",
    "Create Date Time",
  ];

  // Prepare the data for export
  const prepareExportData = user.map((item) => ({
    ID: item.id,
    "Contact Person": item.person_name || "",
    "Email Id": item.email_id || "",
    "Mobile Number": item.mobile_number || "",
    "Country Name": item.country_name || "",
    "State Name": item.state_name || "",
    "City Name": item.city_name || "",
    "Area Name": item.area_name || "",
    Address: item.address || "",
    "Shipping Address": item.shipping_address || "",
    "GST Number": item.gst_number || "",
    "Source Name": item.source_name || "",
    "Status/Stage": item.stage_status_name || "",
    "Label Name": item.label_name || "",
    "Create Date Time": item.created_date_time || "",
  }));

  const handleExportClick = () => {
    ExcelExport({
      data: prepareExportData,
      columns: columns,
      fileName: "contact_",
    });
    setShareId(false);
  };
  const openExport = () => {
    if (canExport) {
      setShareId(true);
    } else {
      setShareId(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const openFilterLabel = () => {
    if (canViewSmartFilter) {
      setIsModalFilterVisible(true);
    } else {
      setIsModalFilterVisible(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleChangeAddContact = () => {
    if (canAdd) {
      setIsCreateContact(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
      setIsCreateContact(false);
    }
  };
  const handleModalOpenEditContact = (singleData: IUserList) => {
    // setShowRightSide(true);
    if (canEdit) {
      setcontInfoEdit(singleData);
      setIsModalEditContactVisible(true);
    } else {
      setIsModalEditContactVisible(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleAddFromImport = () => {
    if (canImport) {
      setIsModalExcelVisible(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  function openDashBoard() {
    if (canViewDash) {
      setshowDashBoard(true);
    } else {
      setshowDashBoard(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }
  function openAiModel() {
    if (canViewDash) {
      setshowAichat(true);
    } else {
      setshowAichat(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }
  function openDeleteModel(id: number) {
    if (canDelete) {
      setContactId(id);
      setIsDeleteConfirmation(true);
    } else {
      setIsDeleteConfirmation(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }

  function openPinModel(id: number) {
    if (canView) {
      setContactId(id);
      setIsPinConfirmation({ show: true, type: "pin" });
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }

  function openUnPinModel(id: number) {
    if (canView) {
      setContactId(id);
      setIsPinConfirmation({ show: true, type: "unpin" });
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }
  const handelDeleteContact = async () => {
    if (await deleteContactApi(contactId)) {
      setShowRightSide(false);
      setIsDeleteConfirmation(false);
      fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setCheckToken
      );
    }
  };

  const handelPinContact = async () => {
    if (isPinConfirmation.type === "pin") {
      if (await pinContactApi(contactId, 1)) {
        setIsPinConfirmation({ show: false, type: "pin" });
        fetchDataUser(
          0,
          "",
          setUsers,
          itemsPerPage,
          setNoDataFound,
          setLoading,
          token,
          localId,
          setContactId,
          setSelectedLabelIds,
          setCheckToken
        );
      }
    } else if (isPinConfirmation.type === "unpin") {
      if (await pinContactApi(contactId, 2)) {
        setIsPinConfirmation({ show: false, type: null }); // Close modal after action
        fetchDataUser(
          0,
          "",
          setUsers,
          itemsPerPage,
          setNoDataFound,
          setLoading,
          token,
          localId,
          setContactId,
          setSelectedLabelIds,
          setCheckToken
        );
      }
    }
    setIsPinConfirmation({ show: false, type: null }); // Close modal after action
  };

  const [selectedButton, setSelectedButton] = useState<string>("all");

  const handleButtonClick = (buttonType: string) => {
    setSelectedButton(buttonType);

    if (buttonType === "all") {
      fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setCheckToken
      );
    } else if (buttonType === "pinned") {
      fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setCheckToken,
        filterParams.filterData,
        filterParams.checkedOptions,
        filterParams.checkedSourceTypes,
        filterParams.startSearchDate,
        filterParams.endSearchDate,
        filterParams.checkedOptionsStageStatus,
        filterParams.checkedOptionsUser,
        1
      );
    } else if (buttonType === "unread") {
      fetchDataUser(
        0,
        "",
        setUsers,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        localId,
        setContactId,
        setSelectedLabelIds,
        setCheckToken,
        filterParams.filterData,
        filterParams.checkedOptions,
        filterParams.checkedSourceTypes,
        filterParams.startSearchDate,
        filterParams.endSearchDate,
        filterParams.checkedOptionsStageStatus,
        filterParams.checkedOptionsUser,
        0,
        1
      );
    }
  };

  const handleQrCode = () => {
    setShowQr(true);
  };
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.CREATE_CONTACT
      ) {
        e.preventDefault();
        setShowCreateContact(true);
        setCreateContactTrigger((prev) => prev + 1);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.ALL_INQUIRY_LIST
      ) {
        e.preventDefault();
        setShowListAllInquiry(true);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.DASHBOARD
      ) {
        e.preventDefault();
        openDashBoard();
        setshowDashBoard(true);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.FILTER
      ) {
        e.preventDefault();
        openFilterLabel();
        setIsModalFilterVisible(true);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.REMINDER
      ) {
        e.preventDefault();
        setShowListAllReminder(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useEffect(() => {
    if (createContactTrigger > 1) {
      handleChangeAddContact();
    }
  }, [createContactTrigger]);

  const [notificationCount, setNotificationCount] = useState(0);

  return (
    <>
      {noDataFound1 ? (
        <LoginView />
      ) : (
        <>
          {isVisible ? (
            <>
              <div className="ig-messaging-layout">
                {/* Left nav */}
                <div className="ig-nav-column">
                  <div className="ig-nav-header">
                    <h3>Messages</h3>
                  </div>
                  <div className="ig-nav-buttons">
                    <button 
                      className={`ig-nav-btn ${showDashBoard ? 'active' : ''}`}
                      onClick={openDashBoard}
                    >
                      <svg viewBox="0 0 24 24" width="24" height="24">
                        <path fill="currentColor" d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/>
                      </svg>
                      <span>Dashboard</span>
                    </button>
                    
                    <button 
                      className={`ig-nav-btn ${showAichat ? 'active' : ''}`}
                      onClick={openAiModel}
                    >
                      <svg viewBox="0 0 24 24" width="24" height="24">
                        <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                      </svg>
                      <span>AI Chat</span>
                    </button>
                    
                    <button 
                      className={`ig-nav-btn ${showNewChat ? 'active' : ''}`}
                      onClick={openForm}
                    >
                      <svg viewBox="0 0 24 24" width="24" height="24">
                        <path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
                      </svg>
                      <span>New Chat</span>
                    </button>
                    
                    <button 
                      className={`ig-nav-btn ${showStatus ? 'active' : ''}`}
                      onClick={openStatus}
                    >
                      <svg viewBox="0 0 24 24" width="24" height="24">
                        <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                      </svg>
                      <span>Status</span>
                    </button>
                    
                    <button 
                      className={`ig-nav-btn ${showSetting ? 'active' : ''}`}
                      onClick={openSettings}
                    >
                      <svg viewBox="0 0 24 24" width="24" height="24">
                        <path fill="currentColor" d="M19.14,12.94c0.04-0.3,0.06-0.61,0.06-0.94c0-0.32-0.02-0.64-0.07-0.94l2.03-1.58c0.18-0.14,0.23-0.41,0.12-0.61 l-1.92-3.32c-0.12-0.22-0.37-0.29-0.59-0.22l-2.39,0.96c-0.5-0.38-1.03-0.7-1.62-0.94L14.4,2.81c-0.04-0.24-0.24-0.41-0.48-0.41 h-3.84c-0.24,0-0.43,0.17-0.47,0.41L9.25,5.35C8.66,5.59,8.12,5.92,7.63,6.29L5.24,5.33c-0.22-0.08-0.47,0-0.59,0.22L2.74,8.87 C2.62,9.08,2.66,9.34,2.86,9.48l2.03,1.58C4.84,11.36,4.8,11.69,4.8,12s0.02,0.64,0.07,0.94l-2.03,1.58 c-0.18,0.14-0.23,0.41-0.12,0.61l1.92,3.32c0.12,0.22,0.37,0.29,0.59,0.22l2.39-0.96c0.5,0.38,1.03,0.7,1.62,0.94l0.36,2.54 c0.05,0.24,0.24,0.41,0.48,0.41h3.84c0.24,0,0.44-0.17,0.47-0.41l0.36-2.54c0.59-0.24,1.13-0.56,1.62-0.94l2.39,0.96 c0.22,0.08,0.47,0,0.59-0.22l1.92-3.32c0.12-0.22,0.07-0.47-0.12-0.61L19.14,12.94z M12,15.6c-1.98,0-3.6-1.62-3.6-3.6 s1.62-3.6,3.6-3.6s3.6,1.62,3.6,3.6S13.98,15.6,12,15.6z"/>
                      </svg>
                      <span>Settings</span>
                    </button>
                  </div>
                </div>

                {/* Middle column: Settings or Contacts */}
                <div className="ig-contacts-column" style={{ overflowY: 'auto', height: '100vh' }}>
                  {showSetting ? (
                    <Setting
                      isSettingOpen={showSetting}
                      closeSettings={() => setshowSetting(false)}
                      profileDetail={loginById}
                    />
                  ) : (
                    <>
                      {/* Contacts List */}
                      <div className="ig-contacts-header">
                        <div className="ig-contacts-search">
                          <div className="search-bar">
                            <div>
                              <button className="search">
                                <span>
                                  <svg viewBox="0 0 24 24" width="24" height="24">
                                    <path fill="currentColor" d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"/>
                                  </svg>
                                </span>
                              </button>
                              <input
                                type="text"
                                placeholder="Search contacts"
                                value={searchTerm}
                                onChange={handleSearchChange}
                              />
                            </div>
                          </div>
                        </div>
                        
                        <div className="ig-filter-buttons">
                          <button
                            className={`ig-filter-btn ig-btn ${selectedButton === "all" ? "active" : ""}`}
                            onClick={() => handleButtonClick("all")}
                          >
                            All
                          </button>
                          <button
                            className={`ig-filter-btn ig-btn ${selectedButton === "pinned" ? "active" : ""}`}
                            onClick={() => handleButtonClick("pinned")}
                          >
                            Pinned
                          </button>
                          <button
                            className={`ig-filter-btn ig-btn ${selectedButton === "unread" ? "active" : ""}`}
                            onClick={() => handleButtonClick("unread")}
                          >
                            Unread
                          </button>
                        </div>
                      </div>

                      {/* Status Stories */}
                      <div className="ig-status-section">
                        <div className="ig-status-header">
                          <h4>Recent Status</h4>
                        </div>
                        <div className="ig-status-list">
                          {user.slice(0, 5).map((item, index) => (
                            <div key={index} className="ig-status-item">
                              <div className="ig-status-avatar">
                                <img
                                  src={ require("../../assets/images/no_image.jpeg")}
                                  alt={item.person_name}
                                />
                              </div>
                              <span className="ig-status-name">{item.person_name}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Contacts List */}
                      <div className="ig-contacts-list" ref={listInnerRef}>
                        {loading ? (
                          Array.from({ length: 8 }).map((_, index) => (
                            <div className="ig-contact-skeleton" key={index}>
                              <div className="ig-contact-avatar-skeleton"></div>
                              <div className="ig-contact-info-skeleton">
                                <div className="ig-contact-name-skeleton"></div>
                                <div className="ig-contact-message-skeleton"></div>
                              </div>
                            </div>
                          ))
                        ) : (
                          user.map((item, idx) => (
                            <div
                              key={idx}
                              className={`ig-contact-item ${contInfo?.id === item.id ? 'active' : ''}`}
                              onClick={() => openRightSide(item)}
                            >
                              <div className="ig-contact-avatar">
                                <img
                                  src={ require("../../assets/images/no_image.jpeg")}
                                  alt={item.person_name}
                                />
                                {item.is_unread === 1 && (
                                  <div className="ig-unread-badge"></div>
                                )}
                              </div>
                              <div className="ig-contact-info">
                                <div className="ig-contact-header">
                                  <h4 className="ig-contact-name">{item.person_name}</h4>
                                  <span className="ig-contact-time">
                                    {item.created_date_time
                                      ? convertDateTimeFormat(item.created_date_time).time
                                      : ""}
                                  </span>
                                </div>
                                <div className="ig-contact-message">
                                  <span>{ "No messages yet"}</span>
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </>
                  )}
                </div>

                {/* Right column: Chat or empty if Settings is open */}
                <div className="ig-chat-column" style={{ background: '#000' }}>
                  {!showSetting && (
                    <RightView
                      openCreateContact={() => setIsCreateContact(true)}
                      closeCreateContact={() => setIsCreateContact(false)}
                      showInquiryAllList={() => setShowListAllInquiry(true)}
                      showReminder={() => setShowListAllReminder(true)}
                      showNotes={() => setShowListNote(true)}
                      showFilterContact={openFilterLabel}
                      showMyCompany={openMyCompany}
                      showDashboard={() => setshowDashBoard(true)}
                      showAichat={() => setshowAichat(true)}
                      getData={contInfo}
                      isDashBoardOpen={showDashBoard}
                      closeDashboard={() => setshowDashBoard(false)}
                      isAiModelopen={showAichat}
                      closeisAiModel={() => setshowAichat(false)}
                      contactsReload={setIsLoadContact}
                      userInfo={userInfo}
                      setEditorContentToEdit={setEditorContentToEdit}
                      editorContentToEdit={editorContentToEdit}
                      setNoDataFound1={setNoDataFound1}
                    />
                  )}
                </div>
              </div>

              {/* Modals and other components */}
              {showGroup && (
                <Group
                  isGroupOpen={showGroup}
                  closeGroup={() => setShowGroup(false)}
                />
              )}
              {showStarred && (
                <Starred
                  isStarredOpen={showStarred}
                  closeStarred={() => setshowStarred(false)}
                />
              )}
              {showNewChat && (
                <NewChat
                  isNewChatOpen={showNewChat}
                  closeForm={() => setshowNewChat(false)}
                />
              )}
              {showStatus && (
                <Status
                  isStatusShow={showStatus}
                  closeStatus={() => setShowStatus(false)}
                />
              )}
              {showListAllInquiry && (
                <ListInquiryView
                  isListInquiry={showListAllInquiry}
                  closeListInquiry={() => setShowListAllInquiry(false)}
                  isModelOpen={"InquiryAllList"}
                  setNoDataFound1={setNoDataFound1}
                />
              )}
              {showListCompany && (
                <ListCompanyView
                  isCompanyOpen={showListCompany}
                  closeCompany={() => setShowListCompany(false)}
                />
              )}
              {showListAllReminder && (
                <ListReminderView
                  isReminderOpen={showListAllReminder}
                  closeReminder={() => setShowListAllReminder(false)}
                />
              )}
              {showListnote && (
                <ListNoteView
                  isNoteOpen={showListnote}
                  closeNote={() => setShowListNote(false)}
                />
              )}
              {showListMyCompany && (
                <ListMyCompanyView
                  isCompanyOpen={showListMyCompany}
                  closeCompany={() => setShowListMyCompany(false)}
                  companyInfo={companyLists}
                />
              )}
            </>
          ) : null}

          {isOrderCreateFromContactShow && (
            <OrderCreateModal
              show={isOrderCreateFromContactShow}
              onHide={() => setIsOrderCreateFromContactShow(false)}
              handleSubmit={() => setIsOrderCreateFromContactShow(false)}
              title={"Create"}
              message={"Please Enter Your Order Details"}
              btn1={"CANCEL"}
              btn2={"Approve"}
              Contact={contactInfoOrder}
              isOrderShowNum={isOrderShowFromContactType}
            />
          )}

          {isModalExcelVisible && (
            <ImportExcelForContactModal
              show={isModalExcelVisible}
              onHide={() => setIsModalExcelVisible(false)}
              handleSubmit={() => handleConfirmImportExcel()}
              title={"Import Excel For Contact"}
              message={"Please Import excel as per sample excel"}
              btn1="Cancel"
              btn2="Import"
              sampleLocation="sampleContact.xlsx"
              potions={1}
            />
          )}

          {isModalVisible && (
            <CheckBoxModal
              show={isModalVisible}
              onHide={handleModalClose}
              handleSubmit={handleConfirm}
              title="Assign your label"
              message="Please select the labels for this contact."
              btn1="Cancel"
              btn2="Submit"
              options={options}
              selectedLabelIds={user.find((item) => item.id === contactId)?.lable}
              contactId={contactId}
              getOptionColor={(option) => option.color || "#eeeeee"}
              getOptionName={(option) => option.lable_name}
              showColorBadge={true}
            />
          )}

          {isModalAssignStatusVisible && (
            <RadioButtonModal
              show={isModalAssignStatusVisible}
              onHide={() => setIsModalAssignStatusVisible(false)}
              handleSubmit={handleConfirmRadioButton}
              title="Assign your Status"
              message="Please select the Status for this contact."
              btn1="Cancel"
              btn2="Submit"
              options={optionRadioButtonStatus}
              selectedLabelIds={
                user.find((item) => item.id === statusAssignContactId)
                  ?.contact_status
              }
              contactId={contactId}
              getOptionColor={(option) => option.color || "#eeeeee"}
              getOptionName={(option) => option.name}
              showColorBadge={true}
            />
          )}

          {isModalEditContactVisible && (
            <CreateContactView
              show={isModalEditContactVisible}
              onHide={() => setIsModalEditContactVisible(false)}
              headerName={"Edit Contact"}
              contactData={contInfoEdit}
              setIsCreateContact1={setIsModalEditContactVisible}
            />
          )}
          {isModalAssignUserVisible && (
            <CheckBoxModal
              show={isModalAssignUserVisible}
              onHide={() => setIsModalAssignUserVisible(false)}
              handleSubmit={handleConfirmAssignUser}
              title="Assign your User"
              message="Please select the Users for this contact."
              btn1="Cancel"
              btn2="Submit"
              options={optionJoinCompany}
              selectedLabelIds={
                user.find((item) => item.id === userAssignContactId)
                  ?.assinged_to_work_a_application_id
              }
              contactId={contactId}
              getOptionName={(option) => option.username}
              showColorBadge={false}
            />
          )}
          {isModalFilterVisible && (
            <CheckBoxFilterModal
              show={isModalFilterVisible}
              onHide={handleModalClose}
              handleSubmit={handleConfirmFilter}
              title="Filter your Contact"
              message="Please select the Labels , Source and Demography for the Contact."
              btn1="Clear"
              btn2="Apply"
              filtersToShow={[1, 2, 3, 4, 5, 6]}
              pageId={1}
            />
          )}

          {isDeleteConfirmation && (
            <ConfirmationModal
              show={isDeleteConfirmation}
              onHide={() => setIsDeleteConfirmation(false)}
              handleSubmit={() => handelDeleteContact()}
              title={"Delete this Contact"}
              message={"Are you sure you want Delete this Contact?"}
              btn1="CANCEL"
              btn2="DELETE CONTACT"
            />
          )}
          {isPinConfirmation.show && (
            <ConfirmationModal
              show={isPinConfirmation.show}
              onHide={() => setIsPinConfirmation({ show: false, type: null })}
              handleSubmit={() => handelPinContact()}
              title={
                isPinConfirmation.type === "pin"
                  ? "Pin this Contact"
                  : "UnPin this Contact"
              }
              message={
                isPinConfirmation.type === "pin"
                  ? "Are you sure you want to Pin this Contact?"
                  : "Are you sure you want to UnPin this Contact?"
              }
              btn1="CANCEL"
              btn2="Apply"
            />
          )}
        </>
      )}
    </>
  );
};

export default LeftSideView;
