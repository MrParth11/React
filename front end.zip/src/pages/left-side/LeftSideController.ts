import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../helpers/AppConstants";
import { TReactSetState } from "../../helpers/AppType";
import { axiosInstance } from "../../services/axiosInstance";
import { IStageStatusView } from "./header/Setting/stage-status/StageStatusController";

export interface ICompanyTeam {
  id: number;
  username: string;
  recovery_email: string;
  recovery_mobile: string;
  created_date_time: string;
  company_flag: number;
  profile_pic: string;
  daily_in_time?: string; // Added for EditTeamMemberView
  daily_out_time?: string; // Added for EditTeamMemberView
  per_hour_salary?: string; // Added for EditTeamMemberView
  reporting_employee?: number; // Added for EditTeamMemberView
  department?: number; // Added for EditTeamMemberView
}

export interface ICompany {
  [x: string]: any;
  invitation_key: string;
}

export interface IUserList {
  id: number;
  person_name: string;
  mobile_number: string;
  company_name?: string;
  email_id?: string;
  country?: string;
  state?: string;
  district?: string;
  city?: string;
  area?: string;
  pincode?: string;
  address?: string;
  status?: number;
  country_name: string;
  state_name: string;
  city_name: string;
  created_date_time: string;
  source_name: string;
  source_name_color: string;
  lable: any;
  label_color: string;
  label_name: string;
  assinged_to_work_a_application_id: string;
  contact_status: number;
  stage_status_name: string;
  stage_status_color: string;
  area_name: string;
  assinged_to_price_list: number;
  shipping_address: string;
  gst_number: string;
  is_unread: number;
  is_pin: number;
  a_application_login_id: number;
}

export interface ILoginData {
  username: string;
  recovery_mobile?: string;
  profile_pic: string;
  login_pin: string;
}

// Interface for attendance history, used in AttendanceHistory.tsx
export interface IAttendanceHistory {
  date: string;
  messages: {
    attendance_status: number; // 1 for IN, 2 for OUT
    attendanceTime: string;
    total_working_hour: string;
  }[];
}

export const fetchDataUser = async (
  page: number,
  term: string,
  setUsers: TReactSetState<IUserList[]>,
  itemsPerPage: number,
  setNoDataFound: TReactSetState<boolean>,
  setLoading: TReactSetState<boolean>,
  token: string | null,
  localId: string | null,
  setContactId: TReactSetState<number | undefined>,
  setSelectedLabelIds: TReactSetState<any>,
  setCheckToken: TReactSetState<boolean>,
  filterData?: any,
  checkedOptionsLabel?: any,
  checkedSourceTypes?: any,
  startSearchDate?: string,
  endSearchDate?: string,
  checkedOptionsStageStatus?: any,
  checkedOptionsUser?: any,
  isPin?: number,
  isUnread?: number
) => {
  const start: number = page * itemsPerPage;
  try {
    const { data } = await axiosInstance.post(
      "Contact",
      {
        ul: start,
        ll: itemsPerPage,
        searchTerm: term || "",
        a_application_login_id: Number(localId),
        labelFilter: checkedOptionsLabel,
        sourceTypeFilter: checkedSourceTypes,
        country: filterData?.country,
        state: filterData?.state,
        city: filterData?.city,
        area: filterData?.area,
        startDate: startSearchDate,
        endDate: endSearchDate,
        statusFilter: checkedOptionsStageStatus,
        userFilter: checkedOptionsUser,
        isPin: isPin,
        isUnread: isUnread,
      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": localId,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        if (page === 0) {
          setLoading(true);
          setUsers(data.data.item);
          setContactId(data.data.item[0]?.id);
          setSelectedLabelIds(data.data.item[0]?.lable);
        } else {
          setLoading(false);
          setUsers((prevUsers) => [...prevUsers, ...data.data.item]);
        }
      } else {
        console.log("test--------1");
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      console.log("test--------2");
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
    setNoDataFound(data.data.item.length === 0);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const fetchDataIndiaMart = async (
  setLoading: TReactSetState<boolean>
) => {
  const getUUID = await localStorage.getItem("UUID");
  try {
    const { data } = await axiosInstance.post(
      "India-mart",
      {
        a_application_login_id: getUUID,
        source_type_id: -1,
      },
      {
        headers: {
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
    setLoading(true);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const fetchGoogleSheetForFacebook = async (
  setLoading: TReactSetState<boolean>
) => {
  const getUUID = await localStorage.getItem("UUID");
  setLoading(true);

  try {
    const { data } = await axiosInstance.post(
      "google-sheet-for-facebook",
      {
        a_application_login_id: getUUID,
        source_type_id: -2,
      },
      {
        headers: {
          "x-tenant-id": getUUID,
        },
      }
    );

    if (data.code !== 200) {
      throw new Error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }

    if (data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      throw new Error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }

    return data;
  } catch (error: any) {
    const errorMessage =
      error.response?.data?.ack_msg ||
      error.response?.data?.developer_msg ||
      error.message ||
      MESSAGE_UNKNOWN_ERROR_OCCURRED;
    toast.error(errorMessage);
    throw error;
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const fetchWhatsAppApiWebhook = async (
  setLoading: TReactSetState<boolean>
) => {
  try {
    const { data } = await axiosInstance.post("execute-webhook");
    setLoading(true);
  } catch (error: any) {
    setLoading(false);
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const fetchGetByIdUser = async (
  localId: string | null,
  setLoginById: TReactSetState<ILoginData | undefined>
) => {
  const token = localStorage.getItem("token");

  try {
    const { data } = await axiosInstance.post(
      "loginId",
      {
        loginId: localId,
      },
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setLoginById(data.data);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const upateCheckBox = async (
  hasOneData: number | undefined,
  selectedOptions: any,
  setLoading: TReactSetState<boolean>
) => {
  const requestData = {
    table: "contact_masters",
    where: `{"id":"${hasOneData}"}`,
    data: `{"lable":"${selectedOptions}"}`,
  };
  setLoading(false);
  const getUUID = localStorage.getItem("UUID");
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setLoading(true);
      } else {
        setLoading(false);
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const updateStageStatusRadioButton = async (
  hasOneData: number | undefined,
  selectedOptions: any,
  setLoading: TReactSetState<boolean>
) => {
  const requestData = {
    table: "contact_masters",
    where: `{"id":"${hasOneData}"}`,
    data: `{"contact_status":"${selectedOptions}"}`,
  };
  setLoading(false);
  const getUUID = localStorage.getItem("UUID");
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setLoading(true);
      } else {
        setLoading(false);
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const updateUserCheckBox = async (
  hasOneData: number | undefined,
  selectedOptions: any,
  setLoading: TReactSetState<boolean>
) => {
  const requestData = {
    table: "contact_masters",
    where: `{"id":"${hasOneData}"}`,
    data: `{"assinged_to_work_a_application_id":"${selectedOptions}"}`,
  };
  setLoading(false);
  const getUUID = localStorage.getItem("UUID");
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setLoading(true);
      } else {
        setLoading(false);
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const fetchAllCompanyApi = async (
  setCompanyTeamLists: TReactSetState<any[]>
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    a_application_login_id: getUUID,
  };

  try {
    const data = await axiosInstance.post("my-team", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });

    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setCompanyTeamLists([]);
      return;
    }
    console.log("data.data.data.item", data.data.data.item);

    const filteredTeamList = data.data.data.item.filter(
      (user: any) => String(user.id) !== String(getUUID)
    );

    console.log("Filtered data:", filteredTeamList);

    setCompanyTeamLists(filteredTeamList);
  } catch (error: any) {
    toast.error(error?.message || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchStageStatusApi = async (
  setStageStatusList: TReactSetState<IStageStatusView[]>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "stage_status_masters",
    columns: "id,name,color,order_type,display_order_type",
    where: ["isDelete=0", `a_application_login_id=${getUUID}||0`, "order_type=1"],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setStageStatusList([]);
    }
    setStageStatusList(data.data.data);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateIsUnRead = async (
  contactId: number | undefined,
  setLoading: TReactSetState<boolean>
) => {
  const requestData = {
    table: "contact_masters",
    where: `{"id":"${contactId}"}`,
    data: `{"is_unread":"1"}`,
  };
  setLoading(false);
  const getUUID = localStorage.getItem("UUID");
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setLoading(true);
      } else {
        setLoading(false);
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const logOutApi = async (
  setIsCloseConfirmation: TReactSetState<boolean>
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const requestData = { a_application_login_id: getUUID };
  try {
    const data = await axiosInstance.post("logout", requestData, {
      headers: {
        Authorization: `${token}`,
      },
    });
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      window.location.reload();
      localStorage.clear();
      setIsCloseConfirmation(false);
    } else {
      setIsCloseConfirmation(true);
      toast.error(data.data.ack_msg);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const deleteContactApi = async (contactId: number | undefined) => {
  const requestData = {
    table: "contact_masters",
    where: `{"id":${contactId}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID");
  try {
    const data = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const pinContactApi = async (
  contactId: number | undefined,
  request_flag: number
) => {
  const requestData = {
    table: "contact_masters",
    where: `{"id":${contactId}}`,
    data: JSON.stringify({
      is_pin: request_flag === 1 ? 1 : 0,
    }),
  };
  const getUUID = localStorage.getItem("UUID");

  try {
    const data = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchCompanyTeamApi = async (
  setCompanyTeamLists: TReactSetState<ICompanyTeam[]>,
  companyMastersId: number,
  searchTerm: string
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    company_masters_id: companyMastersId,
    searchTerm: searchTerm,
  };
  try {
    const data = await axiosInstance.post("my-team", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID, // Added for consistency
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setCompanyTeamLists([]);
    }
    setCompanyTeamLists(data.data.data.item);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchCompanyKeyApi = async (
  setCompanyLists: TReactSetState<ICompany | undefined>
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    a_application_login_id: getUUID,
  };
  try {
    const data = await axiosInstance.post("company", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setCompanyLists(undefined);
    }

    setCompanyLists(data.data.data.item[0]);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

// Function to fetch attendance history for a team member
export const fetchAttendanceHistory = async (
  setAttendanceHistory: TReactSetState<IAttendanceHistory[]>,
  selectDate: Date[] | undefined,
  companyTeamInfoId: number | undefined
) => {
  const getUUID = localStorage.getItem("UUID");
  const token = localStorage.getItem("token");

  if (!selectDate || selectDate.length !== 2 || !companyTeamInfoId) {
    setAttendanceHistory([]);
    return;
  }

  const startDate = selectDate[0]
    .toLocaleDateString("en-CA", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    })
    .replace(/\//g, "-");
  const endDate = selectDate[1]
    .toLocaleDateString("en-CA", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    })
    .replace(/\//g, "-");

  const requestData = {
    a_application_login_id: getUUID,
    startDate: startDate,
    endDate: endDate,
    team_member_id: companyTeamInfoId,
  };

  try {
    const response = await axiosInstance.post("attendance-history", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });

    const result = response.data;
    if (result.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setAttendanceHistory([]);
      return;
    }

    // Normalize the data to match IAttendanceHistory interface
    const normalizedData: IAttendanceHistory[] = result.data.map((item: any) => ({
      date: item.date,
      messages: item.messages.map((msg: any) => ({
        attendance_status: msg.attendance_status, // 1 for IN, 2 for OUT
        attendanceTime: msg.time,
        total_working_hour: msg.total_working_hour || "00:00:00",
      })),
    }));

    setAttendanceHistory(normalizedData);
  } catch (error: any) {
    console.error("Error fetching attendance history:", error);
    toast.error(MESSAGE_UNKNOWN_ERROR_OCCURRED);
    setAttendanceHistory([]);
  }
};