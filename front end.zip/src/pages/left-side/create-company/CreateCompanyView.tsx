import React, { useContext, useEffect, useRef, useState } from "react";
import { Formik, Field, Form, ErrorMessage, FormikErrors } from "formik";

import {
  createCompany,
  createCompanyInitialValues,
  createCompanyValidationSchema,
  fetchCategoryB2BApi,
  fetchCityApiForCompany,
  // fetchCountryApiForCompany,
  fetchStateApiForCompany,
  fetchSubCategoryB2BApi,
  handelSendOtpForEmailVerifyCompany,
  ICreateCompany,
  updateCompany,
} from "./CreateCompanyController";
import { AppContext } from "../../../common/AppContext";
import OtpConfirmationModal from "../../../components/model/OtpConfirmationModal";
import FormikCustomSearchDropdown from "../../../components/FormikCustomSearchDropdown";
import { SingleValue } from "react-select";
import { IOption } from "../../../helpers/AppInterface";
import { toast, ToastContainer } from "react-toastify";
import { TOnChangeInput } from "../../../helpers/AppType";
import { Link } from "react-router-dom";
import { clear } from "console";
import { BIG_TEXT_LENGTH, SMALL_TEXT_LENGTH, TEXTAREA_TEXT_LENGTH } from "../../../helpers/AppConstants";
import { openInNewTab } from "../../../common/SharedFunction";
import CustomSearchDropdown from "../../../components/CustomSearchDropdown";

const CreateCompanyView = ({
  show,
  onHide,
  companyToEdit,
  setRefresh,
  headerName,
  mobileNumber,
  isShowApiKey,
}: any) => {
  const { setCheckPlan, isSetCheckPlan } = useContext(AppContext)!;
  const [isEmailVerifyConfirmation, setIsEmailVerifyCloseConfirmation] =
    useState(false);
  const [headerPreview, setHeaderPreview] = useState<string | null>(null);
  const [footerPreview, setFooterPreview] = useState<string | null>(null);
  const [logPreview, setLogPreview] = useState<string | null>(null);
  const [catalogPreview, setCataLogPreview] = useState<string | null>(null);
  const [catalogview, setCataLogView] = useState<string | null>(null);

  const [countriesList, setCountriesList] = useState([]);
  const [categoryList, setCategoryList] = useState([]);
  const [subCategoryList, setSubCategoryList] = useState([]);

  const [stateList, setStateList] = useState([]);
  const [cityList, setCityList] = useState([]);

  const [selectedStateId, setSelectedStateId] = useState<number>();
  const [selectedCategoryId, setSelectedCategoryId] = useState<number>();
  const [selectedSubCategoryId, setSelectedSubCategoryId] = useState<number>();

  const [selectedCityId, setSelectedCityId] = useState<number>();
  const [isOpenThirdParty, setIsOpenThirdParty] = useState(false);
  const [isOpenMailSetup, setIsOpenMailSetup] = useState(false);
  const [isOpenPrefix, setIsOpenPrefix] = useState(false);
  const [selectedCurrency, setSelectedCurrency] =
  useState<SingleValue<IOption> | null>(null);
  const categoryRef = useRef<HTMLDivElement>(null);
const subCategoryRef = useRef<HTMLDivElement>(null);
const companyNameRef = useRef<HTMLDivElement>(null);
const emailRef = useRef<HTMLDivElement>(null);


const validateImageDimensions = (
  file: File,
  width: number,
  height: number,
  callback: (isValid: boolean) => void
) => {
  // Check if the file is an image
  if (!file.type.startsWith("image/")) {
    console.warn("Invalid file type for image validation:", file.type);
    toast.error("Please upload a valid image file (PNG, JPG, or JPEG).");
    callback(false);
    return;
  }

  try {
    const img = new Image();
    img.src = URL.createObjectURL(file);

    img.onload = () => {
      try {
        if (img.width === width && img.height === height) {
          callback(true);
        } else {
          callback(false);
        }
      } catch (error) {
        console.error("Error processing image dimensions:", error);
        callback(false);
      } finally {
        URL.revokeObjectURL(img.src);
      }
    };

    img.onerror = () => {
      console.error("Failed to load image for dimension validation:", file.name);
      toast.error("Could not load the image. Please try another file.");
      callback(false);
      URL.revokeObjectURL(img.src);
    };
  } catch (error) {
    console.error("Error in validateImageDimensions:", error);
    toast.error("An error occurred while validating the image.");
    callback(false);
  }
};
  const countryOptions = countriesList.map((category: any) => ({
    value: category.id,
    label: category.country_name,
  }));
  const defaultCountry = countryOptions.find((c) => c.value === 101);
  const handleCountriesChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("country_id", selectedOption.value);
      setSelectedStateId(selectedOption.value as number);
    } else {
      setFieldValue("country_id", "");
      setSelectedStateId(undefined);
    }
  };
  const handleCategoryChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("category_id_b2b", selectedOption.value);
      setSelectedCategoryId(selectedOption.value as number);
    } else {
      setSelectedCategoryId(undefined);
    }
  };
  const handleSateChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("state_id", selectedOption.value);
      setSelectedCityId(selectedOption.value as number);
    } else {
      setFieldValue("state_id", "");
      setSelectedCityId(undefined);
    }
  };
  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);
  const handleCurrencyChange = (
    selectedOption: SingleValue<IOption> | null
  ) => {
    setSelectedCurrency(selectedOption);
  };

 const fieldRefs: Record<string, React.RefObject<HTMLElement>> = {
  company_name: companyNameRef,
  company_email: emailRef,
  category_id_b2b: categoryRef,
  sub_category_id_b2b: subCategoryRef,
  // Add more as needed
};

const handleSubmit = async (values: any) => {
  console.log("values", values);

  if (companyToEdit?.id) {
    updateCompany(
      values,
      setRefresh,
      companyToEdit,
      onHide,
      values.headerImg,
      values.footerImg,
      values.company_logo,
      values.company_catalog
    );
    handelClose()
  } else {
    createCompany(
      values,
      setRefresh,
      onHide,
      mobileNumber,
      setCheckPlan,
      isSetCheckPlan
    );
  }
};

  
  const handelClose = () => {
    setHeaderPreview("");
    onHide();
    setFooterPreview("");
    setLogPreview("");
    setCataLogPreview("");
    setCataLogView("");
  };
  useEffect(() => {
    fetchCategoryB2BApi(setCategoryList);

    if (companyToEdit) {
      setSelectedCategoryId(companyToEdit?.category_id_b2b);
    }
    if (companyToEdit?.country_id) {
      setSelectedStateId(companyToEdit?.country_id || undefined);
    } else {
      setSelectedStateId(defaultCountry?.value);
    }
  }, [companyToEdit?.country_id, show]);

  useEffect(() => {
    if (selectedStateId) {
      const fetchState = async () => {
        try {
          await fetchStateApiForCompany(setStateList, selectedStateId);
          if (companyToEdit) {
            setSelectedCityId(companyToEdit?.state_id);
          }
        } catch (error) {
          console.error("Error fetching city options:", error);
        }
      };
      fetchState();
    }
  }, [companyToEdit, selectedStateId]);

  useEffect(() => {
    if (selectedCategoryId) {
      const fetchSubCategory = async () => {
        try {
          await fetchSubCategoryB2BApi(setSubCategoryList, selectedCategoryId);
        } catch (error) {
          console.error("Error fetching city options:", error);
        }
      };
      fetchSubCategory();
    }
  }, [companyToEdit, selectedCategoryId]);
  useEffect(() => {
    if (selectedCityId) {
      const fetchCities = async () => {
        try {
          await fetchCityApiForCompany(setCityList, selectedCityId);
        } catch (error) {
          console.error("Error fetching city options:", error);
        }
      };
      fetchCities();
    }
  }, [selectedCityId]);

  const stateOptions = stateList.map((category: any) => ({
    value: category.id,
    label: category.state_name,
  }));
  const cityOptions = cityList.map((category: any) => ({
    value: category.id,
    label: category.city_name,
  }));

  const categoryOptions =
    categoryList &&
    categoryList.map((category: any) => ({
      value: category.id,
      label: category.category_name_b2b,
    }));

  const subCategoryOptions =
    subCategoryList &&
    subCategoryList.map((category: any) => ({
      value: category.id,
      label: category.sub_category_name_b2b,
    }));

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>, fieldName: string, setFieldValue: { (field: string, value: any, shouldValidate?: boolean): Promise<void | FormikErrors<ICreateCompany>>; (field: string, value: any, shouldValidate?: boolean): Promise<void | FormikErrors<ICreateCompany>>; (field: string, value: any, shouldValidate?: boolean): Promise<void | FormikErrors<ICreateCompany>>; (field: string, value: any, shouldValidate?: boolean): Promise<void | FormikErrors<ICreateCompany>>; (arg0: any, arg1: any): void; }, setPreview: { (value: React.SetStateAction<string | null>): void; (value: React.SetStateAction<string | null>): void; (value: React.SetStateAction<string | null>): void; (value: React.SetStateAction<string | null>): void; (arg0: string): void; }) => {
    const file = event.currentTarget.files?.[0];
    if (file) {
  if (fieldName === "headerImg" || fieldName === "footerImg") {
  validateImageDimensions(file, 600, 90, (isValid) => {
    if (isValid) {
      setFieldValue(fieldName, file);
      setPreview(URL.createObjectURL(file));
    } else {
      event.currentTarget.value = ""; // Error: event is not in scope in the callback
    }
  });

      } else {
        setFieldValue(fieldName, file);
        setPreview(URL.createObjectURL(file));
        if (fieldName === "company_catalog") {
          setCataLogView(file.name);
        }
      }
    }
  };
  
  const currencyOptions = [
    // { label: "USD - US Dollar", value: 1 }, // USD → ID 1
    // { label: "EUR - Euro", value: 2 },
    { label: "INR - Indian Rupee", value: 3, disabled: true },
    // { label: "JPY - Japanese Yen", value: 4 },
    // { label: "GBP - British Pound", value: 5 },
    // { label: "AUD - Australian Dollar", value: 6 },
    // { label: "CAD - Canadian Dollar", value: 7 },
    // { label: "CHF - Swiss Franc", value: 8 },
    // { label: "CNY - Chinese Yuan", value: 9 },
    // { label: "ZAR - South African Rand", value: 10 }
  ];
  
  const defaultCurrency = currencyOptions.find((c) => c.value === 3);




  return (
    <React.Fragment>
    <ToastContainer />
      {show && (
        <div className="modal1">
          <div className="modal-content1">
            <div className="d-flex align-items-center justify-content-between">
            <div className="d-flex justify-content-center align-items-center col-9">

                <h2 className="modal-title1 form_header_text" style={{ paddingLeft: "30%" }}>{headerName}</h2>
              </div>

              <div className="d-flex align-items-center justify-content-end col-3">
                <p
                  className="landing-page-text"
                  style={{ cursor: "pointer", color: "blue", fontSize: "13px" }}
                  onClick={() => openInNewTab("/videoTutorial", 16)}
                >
                  Learn More :
                  <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#0000FF">
                    <path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" />
                  </svg>
                </p>

                <span className="close ms-3 pb-3" onClick={handelClose} style={{ cursor: "pointer" }}>
                  &times;
                </span>
              </div>
            </div>


            <p className="text-center " style={{ color: "#999" }}>
              Please Enter Your Company Detail.
            </p>

            <Formik
              enableReinitialize
              initialValues={createCompanyInitialValues(
                companyToEdit,
                mobileNumber,
                defaultCountry,
                defaultCurrency
              )}
              validationSchema={createCompanyValidationSchema()}
              onSubmit={handleSubmit} 
            >
              {({ errors, touched, setFieldValue, values }) => (
                <Form>
                  <div className="mt-3 d-flex justify-content-center">
                    <div className="mb-3 py-4  ">
                      <div className="row  mx-0 px-2 gy-3  d-flex justify-content-center">
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="category_id_b2b"
                              className="mb-1 form_label"
                            >
                              Business Category
                              <span className="text-danger">*</span>
                            </label>
                            <FormikCustomSearchDropdown
                              name="category_id_b2b"
                              options={categoryOptions}
                              className={`  ${errors.category_id_b2b &&
                                touched.category_id_b2b &&
                                "is-invalid input-box-error"
                                }`}
                              onChange={handleCategoryChange}
                            />
                            <ErrorMessage
                              name="category_id_b2b"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="sub_category_id_b2b"
                              className="mb-1 form_label"
                            >
                              Business Sub Category
                              <span className="text-danger">*</span>
                            </label>
                            <FormikCustomSearchDropdown
                              name="sub_category_id_b2b"
                              options={subCategoryOptions}
                              className={`  ${errors.sub_category_id_b2b &&
                                touched.sub_category_id_b2b &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="sub_category_id_b2b"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        {isShowApiKey === 1 && (
                          <div className="col-6 ">
                            <div className="add-source-of-type-section">
                              <p>
                                Company Logo
                                <small className="text-danger ps-2">
                                  Best Size(521 X 512px)
                                </small>
                              </p>
                            </div>
                            <div className="imgBox-product">
                              <label htmlFor="input-files-company-log">
                                {logPreview ? (
                                  <img
                                    src={logPreview}
                                    alt=""
                                    className="imgBox-product-cover animate__animated animate__fadeIn"
                                  />
                                ) : values.company_logo ? (
                                  <img
                                    src={values.company_logo}
                                    alt=""
                                    className="imgBox-product-cover animate__animated animate__fadeIn"
                                  />
                                ) : (
                                  <img
                                    src={require("../../../assets/images/logo.jpg")}
                                    alt="Instagram Style Logo"
                                    className="imgBox-product-cover animate__animated animate__fadeIn"
                                  />
                                )}

                                <div>
                                  <div className="form-group1">
                                    <input
                                      type="file"
                                      name="image"
                                      id="input-files-company-log"
                                      className="form-control-file border"
                                      onChange={(event) =>
                                        handleFileChange(
                                          event,
                                          "company_logo", // The field name you want to set
                                          setFieldValue, // Function to update the field value
                                          setLogPreview // Function to set the image preview
                                        )
                                      }
                                      style={{ display: "none" }}
                                      accept=".png,.jpg,.jpeg"
                                    />
                                  </div>
                                </div>
                              </label>
                            </div>
                          </div>
                        )}
                        {isShowApiKey === 1 && (
                          <div className="col-6">
                            <div className="add-source-of-type-section">
                              <p>Company Profile</p>
                            </div>
                            <div className=" px-2 chat-attach">
                              <label
                                style={{
                                  cursor: "pointer",
                                  display: "flex",
                                  alignItems: "center",
                                }}
                                htmlFor="file-upload-company-catalog"
                              >
                                {/* <svg
                                  height="24px"
                                  viewBox="0 -960 960 960"
                                  width="24px"
                                  fill="#5f6368"
                                >
                                  <path d="M330-240q-104 0-177-73T80-490q0-104 73-177t177-73h370q75 0 127.5 52.5T880-560q0 75-52.5 127.5T700-380H350q-46 0-78-32t-32-78q0-46 32-78t78-32h370v80H350q-13 0-21.5 8.5T320-490q0 13 8.5 21.5T350-460h350q42-1 71-29.5t29-70.5q0-42-29-71t-71-29H330q-71-1-120.5 49T160-490q0 70 49.5 119T330-320h390v80H330Z" />
                                </svg> */}
                               <div className="col-12 card p-4">
                                <div className="text-center">
                                  {catalogview ? (
                                    <span>
                                        <b>{catalogview}</b>
                                    </span>
                                 ) : (
                                     <span style={{color:"rgb(153, 153, 153)"}}>Please select file</span>
                                  )}
                                 </div>
                              </div>

                              </label>

                              <input
                                type="file"
                                id="file-upload-company-catalog"
                                onChange={(event) =>
                                  handleFileChange(
                                    event,
                                    "company_catalog", // The field name you want to set
                                    setFieldValue, // Function to update the field value
                                    setCataLogPreview // Function to set the image preview
                                  )
                                }
                                style={{ display: "none" }} // Hide the actual file input
                                accept=".pdf"
                              />
                            </div>
                            <div className="ml-2 d-flex align-items-center">
                              {catalogview ? (
                               ""
                              ) : values.company_catalog ? (
                                <Link
                                  to={values.company_catalog}
                                  target="_blank"
                                >
                                  <i>Click Hear, to View Catalog</i>
                                </Link>
                              ) : (
                                ""
                              )}
                            </div>
                          </div>
                        )}
                        <div className="col-12 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="company_name"
                              className="pb-2 form_label"
                            >
                              Company Name
                              <span className="text-danger">*</span>
                            </label>
                            <Field
                              type="text"
                              name="company_name"
                              maxLength={BIG_TEXT_LENGTH}
                              innerRef={companyNameRef}
                              className={`form-control font-size-15 rounded-1   ${errors.company_name &&
                                touched.company_name &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="company_name"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="company_email"
                              className="pb-2 form_label"
                            >
                              Email <span className="text-danger">*</span>
                            </label>

                            <div className="input-group">
                              <Field
                                type="email"
                                name="company_email"
                                maxLength={BIG_TEXT_LENGTH}
                                className={`form-control font-size-15 rounded-1 ${errors.company_email &&
                                  touched.company_email &&
                                  "is-invalid input-box-error"
                                  }`}
                              />
                              {isShowApiKey === 1 && (
                                <span
                                  className={`input-group-text ${companyToEdit?.is_email_verified === 1
                                    ? "bg-success text-white"
                                    : "bg-danger text-white"
                                    }`}
                                  style={{ height: "45px" }}
                                >
                                  <i
                                    className={`bi ${companyToEdit?.is_email_verified === 1
                                      ? "bi-check-circle"
                                      : "bi-x-circle"
                                      }`}
                                  ></i>
                                </span>
                              )}
                            </div>
                            {isShowApiKey === 1 && (
                              <div className="">
                                {companyToEdit?.is_email_verified === 1 ? (
                                  <p style={{ color: `green` }}>
                                    Your email verified successfully
                                  </p>
                                ) : (
                                  <p
                                    onClick={() =>
                                      handelSendOtpForEmailVerifyCompany(
                                        setIsEmailVerifyCloseConfirmation,
                                        companyToEdit?.id
                                      )
                                    }
                                    style={{ color: `blue` }}
                                  >
                                    <i>
                                      Please Click Hear,To Verify Your Email
                                    </i>
                                  </p>
                                )}
                              </div>
                            )}
                            <ErrorMessage
                              name="company_email"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="company_contact"
                              className="pb-2 form_label"
                            >
                              Mobile Number
                              <span className="text-danger">*</span>
                            </label>
                            <Field
                              type="text"
                              name="company_contact"
                              className={`form-control font-size-15 rounded-1   ${errors.company_contact &&
                                touched.company_contact &&
                                "is-invalid input-box-error"
                                }`}
                              disabled={true}
                            />
                            <ErrorMessage
                              name="company_contact"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>

                        {isShowApiKey === 5 ? (
                          <div className="col-12 col-md-6">
                            <div className="form-group">
                              <label
                                htmlFor="activation_code"
                                className="pb-2 form_label"
                              >
                                Activation Code
                              </label>
                              <Field
                                type="text"
                                name="activation_code"
                                className={`form-control font-size-15 rounded-1   ${errors.activation_code &&
                                  touched.activation_code &&
                                  "is-invalid input-box-error"
                                  }`}
                              />
                              <ErrorMessage
                                name="activation_code"
                                component="div"
                                className="field-error text-danger"
                              />
                            </div>
                          </div>
                        ) : (
                          <div className="col-6"></div>
                        )}
                        {isShowApiKey === 1 ? (
                          <>
                            <div className="col-6">
                              <div className="form-group">
                                <label
                                  htmlFor="country"
                                  className="mb-1 form_label"
                                >
                                  Country
                                </label>
                                <FormikCustomSearchDropdown
                                  name="country_id"
                                  options={countryOptions}
                                  className={`  ${errors.country_id &&
                                    touched.country_id &&
                                    "is-invalid input-box-error"
                                    }`}
                                  onChange={handleCountriesChange}
                                />
                                <ErrorMessage
                                  name="country_id"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="state"
                                  className="mb-1 form_label"
                                >
                                  State
                                </label>
                                <FormikCustomSearchDropdown
                                  name="state_id"
                                  options={stateOptions}
                                  className={`  ${errors.state_id &&
                                    touched.state_id &&
                                    "is-invalid input-box-error"
                                    }`}
                                  onChange={handleSateChange}
                                />
                                <ErrorMessage
                                  name="state"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>

                            <div className="col-12 col-md-6 ">
                              <div className="form-group">
                                <label
                                  htmlFor="city"
                                  className="mb-1 form_label"
                                >
                                  City
                                </label>
                                <FormikCustomSearchDropdown
                                  name="city_id"
                                  options={cityOptions}
                                  className={`  ${errors.city_id &&
                                    touched.city_id &&
                                    "is-invalid input-box-error"
                                    }`}
                                />
                                <ErrorMessage
                                  name="city_id"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6 ">
                              <div className="form-group">
                                <label
                                  htmlFor="name "
                                  className="pb-2 form_label"
                                >
                                  Address
                                </label>
                                <Field
                                  as="textarea"
                                  name="address"
                                  maxLength={TEXTAREA_TEXT_LENGTH}
                                  className={`form-control font-size-15 rounded-1   ${errors.address &&
                                    touched.address &&
                                    "is-invalid input-box-error"
                                    }`}
                                />
                                <ErrorMessage
                                  name="address"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="bank_detail "
                                  className="pb-2 form_label"
                                >
                                  Bank Details
                                </label>
                                <Field
                                  as="textarea"
                                  name="bank_detail"
                                  maxLength={TEXTAREA_TEXT_LENGTH}
                                  className={`form-control font-size-15 rounded-1   ${errors.bank_detail &&
                                    touched.bank_detail &&
                                    "is-invalid input-box-error"
                                    }`}
                                />
                                <ErrorMessage
                                  name="bank_detail"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="terms_and_condition "
                                  className="pb-2 form_label"
                                >
                                  Terms & Conditions
                                </label>
                                <Field
                                  as="textarea"
                                  name="terms_and_condition"
                                  maxLength={TEXTAREA_TEXT_LENGTH}
                                  className={`form-control font-size-15 rounded-1   ${errors.terms_and_condition &&
                                    touched.terms_and_condition &&
                                    "is-invalid input-box-error"
                                    }`}
                                />
                                <ErrorMessage
                                  name="terms_and_condition"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label
                                  htmlFor="gst_number "
                                  className="pb-2 form_label"
                                >
                                  GST Number
                                </label>
                                <Field
                                  type="text"
                                  name="gst_number"
                                  maxLength={SMALL_TEXT_LENGTH}
                                  className={`form-control font-size-15 rounded-1   ${errors.gst_number &&
                                    touched.gst_number &&
                                    "is-invalid input-box-error"
                                    }`}
                                />
                                <ErrorMessage
                                  name="gst_number"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>
                            <div className="col-12 col-md-6">
                              <div className="form-group">
                                <label htmlFor="currency_id" className="mb-1 form_label">
                                  Currency
                                </label>
                                <CustomSearchDropdown
                                  isDisabled={true}
                                  options={currencyOptions}
                                  defaultValue={defaultCurrency}
                                  value={selectedCurrency}
                                  onChange={() => {}}
                                  className={`${
                                    errors.currency_id && touched.currency_id && "is-invalid input-box-error"
                                  }`}
                                />
                                <ErrorMessage
                                  name="currency_id"
                                  component="div"
                                  className="field-error text-danger"
                                />
                              </div>
                            </div>

                            <div className="col-12 col-md-6"></div>
                            <div className="col-12 border rounded bg-secondary">
                              <b
                                className="cursor-pointer"
                                onClick={() =>
                                  setIsOpenThirdParty(!isOpenThirdParty)
                                }
                                style={{
                                  cursor: "pointer",
                                  display: "block",
                                  color: "#ffff",
                                }}
                              >
                                ThirdParty Integration
                                <span className="ms-2">
                                  {isOpenThirdParty ? "▲" : "▼"}
                                </span>
                                   <span className="close mt-2 ">
                    <p
                      className=""
                      style={{
                        fontSize:"15px",
                        cursor: "pointer",
                        color: "white",
                        float: "right",
                        // marginTop:"-7px"
                      }}
                      onClick={() => openInNewTab("/videoTutorial", 23)}
                    >
                     How to Generate All Key :{" "}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="20px"
                        viewBox="0 -960 960 960"
                        width="20px"
                        fill="white"
                      >
                        <path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" />
                      </svg>
                    </p>
                  </span>
                              </b>
                            </div>
                          {isOpenThirdParty && (
  <>
    <hr />
    {/* Add "HOW TO GENERATE ALL" link and video link */}
    <div className="col-12 d-flex justify-content-end mb-3">

       
    </div>

    <div className="col-12">
      <div className="form-group mb-3">
        <label htmlFor="india_mart_api_key" className="pb-2 form_label">
          India Mart API Key
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-key"></i> 
          </span>
          <Field
            as="textarea"
            name="india_mart_api_key"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.india_mart_api_key && touched.india_mart_api_key
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="india_mart_api_key"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>
 <hr />
    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label htmlFor="trade_india_user_id" className="pb-2 form_label">
          Trade India API User ID
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-person"></i> 
          </span>
          <Field
            as="textarea"
            name="trade_india_user_id"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.trade_india_user_id && touched.trade_india_user_id
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="trade_india_user_id"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>

    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label htmlFor="trade_india_profile_id" className="pb-2 form_label">
          Trade India API Profile ID
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-person"></i> 
          </span>
          <Field
            as="textarea"
            name="trade_india_profile_id"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.trade_india_profile_id && touched.trade_india_profile_id
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="trade_india_profile_id"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>

    <div className="col-12">
      <div className="form-group mb-3">
        <label htmlFor="trade_india_key" className="pb-2 form_label">
          Trade India API Key
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-key"></i>
          </span>
          <Field
            as="textarea"
            name="trade_india_key"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.trade_india_key && touched.trade_india_key
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="trade_india_key"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>
 <hr />
    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label htmlFor="whatsapp_authkey" className="pb-2 form_label">
          WhatsApp API Authkey
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-whatsapp"></i> 
          </span>
          <Field
            as="textarea"
            name="whatsapp_authkey"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.whatsapp_authkey && touched.whatsapp_authkey
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="whatsapp_authkey"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>

    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label htmlFor="whatsapp_appkey" className="pb-2 form_label">
          WhatsApp API AppKey
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-whatsapp"></i> 
          </span>
          <Field
            as="textarea"
            name="whatsapp_appkey"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.whatsapp_appkey && touched.whatsapp_appkey
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="whatsapp_appkey"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>
 <hr />
    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label htmlFor="chatgpt_appkey" className="pb-2 form_label">
          ChatGPT API Key
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-robot"></i>
          </span>
          <Field
            as="textarea"
            name="chatgpt_appkey"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.chatgpt_appkey && touched.chatgpt_appkey
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="chatgpt_appkey"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>

    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label htmlFor="gimini_appkey" className="pb-2 form_label">
          Gemini API Key 
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0"style={{height:"46px"}}>
            <i className="bi bi-robot"></i>
          </span>
          <Field
            as="textarea"
            style={{resize:"none"}}
            name="gimini_appkey"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.gimini_appkey && touched.gimini_appkey
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="gimini_appkey"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>
 <hr />
    {/* Google Sheet Section */}
    <div className="col-12 col-md-12 mb-3">
      <a
        href={require("../../../assets/sample/sampleGoogleSheet.xlsx")}
        download="sampleGoogleSheet.xlsx"
        className=""
      >
        Download Sample Google Sheet
      </a>
      <p className="text-danger mt-1">
        Data imported from Excel or Google Sheets will be recorded with the
        current date and time.
      </p>
    </div>

    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label
          htmlFor="google_lead_sheet_for_faceBook_1"
          className="pb-2 form_label"
        >
          Google Lead Sheet For FaceBook 1
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0"style={{height:"46px"}}>
            <i className="bi bi-file-earmark-spreadsheet"></i> {/* Example icon */}
          </span>
          <Field
            as="textarea"
            name="google_lead_sheet_for_faceBook_1"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.google_lead_sheet_for_faceBook_1 &&
              touched.google_lead_sheet_for_faceBook_1
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="google_lead_sheet_for_faceBook_1"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>

    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label
          htmlFor="google_lead_sheet_for_faceBook_2"
          className="pb-2 form_label"
        >
          Google Lead Sheet For FaceBook 2
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0"style={{height:"46px"}}>
            <i className="bi bi-file-earmark-spreadsheet"></i> {/* Example icon */}
          </span>
          <Field
            as="textarea"
            name="google_lead_sheet_for_faceBook_2"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.google_lead_sheet_for_faceBook_2 &&
              touched.google_lead_sheet_for_faceBook_2
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="google_lead_sheet_for_faceBook_2"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>

    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label htmlFor="google_sheet_key_3" className="pb-2 form_label">
          Google Sheet Key 3
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-file-earmark-spreadsheet"></i> {/* Example icon */}
          </span>
          <Field
            as="textarea"
            name="google_sheet_key_3"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.google_sheet_key_3 && touched.google_sheet_key_3
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="google_sheet_key_3"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>

    <div className="col-12 col-md-6">
      <div className="form-group mb-3">
        <label htmlFor="google_sheet_key_4" className="pb-2 form_label">
          Google Sheet Key 4
        </label>
        <div className="input-group">
          <span className="input-group-text bg-light border-end-0" style={{height:"46px"}}>
            <i className="bi bi-file-earmark-spreadsheet"></i> {/* Example icon */}
          </span>
          <Field
            as="textarea"
            name="google_sheet_key_4"
            className={`form-control font-size-15 rounded-1 bg-light border-start-0 ${
              errors.google_sheet_key_4 && touched.google_sheet_key_4
                ? "is-invalid input-box-error"
                : ""
            }`}
            rows={1}
          />
        </div>
        <ErrorMessage
          name="google_sheet_key_4"
          component="div"
          className="field-error text-danger"
        />
      </div>
    </div>
  </>
)}
                            <div className="col-12 border rounded bg-secondary">
                              <b
                                onClick={() =>
                                  setIsOpenMailSetup(!isOpenMailSetup)
                                }
                                style={{
                                  cursor: "pointer",
                                  display: "block",
                                  color: "#ffff",
                                }}
                              >
                                Mail Setup
                                <span className="ms-2">
                                  {isOpenMailSetup ? "▲" : "▼"}
                                </span>
                              </b>
                            </div>
                            {isOpenMailSetup && (
                              <>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="company_name"
                                      className="pb-2 form_label"
                                    >
                                      SMTP HOST
                                    </label>
                                    <Field
                                      type="text"
                                      name="host_out_going_mail"
                                      className={`form-control font-size-15 rounded-1   ${errors.host_out_going_mail &&
                                        touched.host_out_going_mail &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="host_out_going_mail"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="port_mail_setup"
                                      className="pb-2 form_label"
                                    >
                                      Email OutGoing Port
                                    </label>
                                    <Field
                                      type="text"
                                      name="port_mail_setup"
                                      className={`form-control font-size-15 rounded-1   ${errors.port_mail_setup &&
                                        touched.port_mail_setup &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="port_mail_setup"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="mail_id_setup"
                                      className="pb-2 form_label"
                                    >
                                      Email Address
                                    </label>
                                    <Field
                                      type="email"
                                      name="mail_id_setup"
                                      className={`form-control font-size-15 rounded-1   ${errors.mail_id_setup &&
                                        touched.mail_id_setup &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="mail_id_setup"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="password_mail_setup"
                                      className="pb-2 form_label"
                                    >
                                      Password
                                    </label>
                                    <Field
                                      type="password"
                                      name="password_mail_setup"
                                      className={`form-control font-size-15 rounded-1   ${errors.password_mail_setup &&
                                        touched.password_mail_setup &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="password_mail_setup"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="pop3_host"
                                      className="pb-2 form_label"
                                    >
                                      POP3 Host
                                    </label>
                                    <Field
                                      type="text"
                                      name="pop3_host"
                                      className={`form-control font-size-15 rounded-1   ${errors.pop3_host &&
                                        touched.pop3_host &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="pop3_host"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="incoming_port"
                                      className="pb-2 form_label"
                                    >
                                      Incoming Port
                                    </label>
                                    <Field
                                      type="text"
                                      name="incoming_port"
                                      className={`form-control font-size-15 rounded-1   ${errors.incoming_port &&
                                        touched.incoming_port &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="incoming_port"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                              </>
                            )}
                            <div className="col-12 border rounded bg-secondary">
                              <b
                                onClick={() => setIsOpenPrefix(!isOpenPrefix)}
                                style={{
                                  cursor: "pointer",
                                  display: "block",
                                  color: "#ffff",
                                }}
                              >
                                Set Prefix and Page
                                <span className="ms-2">
                                  {isOpenPrefix ? "▲" : "▼"}
                                </span>
                              </b>
                            </div>
                            {isOpenPrefix && (
                              <>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="invoice_prefix"
                                      className="pb-2 form_label"
                                    >
                                      Invoice Prefix
                                    </label>
                                    <Field
                                      type="text"
                                      name="invoice_prefix"
                                      className={`form-control font-size-15 rounded-1   ${errors.invoice_prefix &&
                                        touched.invoice_prefix &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="invoice_prefix"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="quotation_prefix"
                                      className="pb-2 form_label"
                                    >
                                      Quotation Prefix
                                    </label>
                                    <Field
                                      type="text"
                                      name="quotation_prefix"
                                      className={`form-control font-size-15 rounded-1   ${errors.quotation_prefix &&
                                        touched.quotation_prefix &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="quotation_prefix"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="order_prefix"
                                      className="pb-2 form_label"
                                    >
                                      Order Prefix
                                    </label>
                                    <Field
                                      type="text"
                                      name="order_prefix"
                                      className={`form-control font-size-15 rounded-1   ${errors.order_prefix &&
                                        touched.order_prefix &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="order_prefix"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="workorder_prefix"
                                      className="pb-2 form_label"
                                    >
                                      Workorder Prefix
                                    </label>
                                    <Field
                                      type="text"
                                      name="workorder_prefix"
                                      className={`form-control font-size-15 rounded-1   ${errors.order_prefix &&
                                        touched.order_prefix &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="workorder_prefix"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">
                                  <div className="form-group">
                                    <label
                                      htmlFor="purchase_prefix"
                                      className="pb-2 form_label"
                                    >
                                      Purchase Prefix
                                    </label>
                                    <Field
                                      type="text"
                                      name="purchase_prefix"
                                      className={`form-control font-size-15 rounded-1   ${errors.purchase_prefix &&
                                        touched.purchase_prefix &&
                                        "is-invalid input-box-error"
                                        }`}
                                    />
                                    <ErrorMessage
                                      name="purchase_prefix"
                                      component="div"
                                      className="field-error text-danger"
                                    />
                                  </div>
                                </div>
                                <div className="col-12 col-md-6 ">

                                </div>
                                <div className="col-12">
                                  {/* Header Image Upload */}
                                  <label htmlFor="input-files-header">
                                    <p>
                                      Header Image
                                      <small>
                                        (minimum image size 600 PX x 90 PX)
                                      </small>
                                    </p>
                                    {headerPreview ? (
                                      <img
                                        src={headerPreview}
                                        alt=""
                                        className="imgBox-company"
                                      />
                                    ) : values.header_img ? (
                                      <img
                                        src={values.header_img}
                                        alt=""
                                        className="imgBox-company "
                                      />
                                    ) : (
                                      <img
                                        src={require("../../../assets/images/header.png")}
                                        alt=""
                                        className="imgBox-company "
                                      />
                                    )}
                                    <div>
                                      <div className="form-group1">
                                        <input
                                          type="file"
                                          name="image"
                                          id="input-files-header"
                                          className="form-control-file border"
                                          onChange={(event) =>
                                            handleFileChange(
                                              event,
                                              "headerImg", // The field name you want to set
                                              setFieldValue, // Function to update the field value
                                              setHeaderPreview // Function to set the image preview
                                            )
                                          }
                                          style={{ display: "none" }}
                                          accept=".png,.jpg,.jpeg"
                                        />
                                      </div>
                                    </div>
                                  </label>
                                </div>
                                {/* Footer Image Upload */}
                                <div className="col-12">
                                  <label htmlFor="input-files-footer">
                                    <p>
                                      Footer Image
                                      <small>
                                        (minimum image size 600 PX x 90 PX)
                                      </small>
                                    </p>
                                    {/* <small> minimum image size 500 x 120</small> */}
                                    {footerPreview ? (
                                      <img
                                        src={footerPreview}
                                        alt=""
                                        className="imgBox-company"
                                      />
                                    ) : values.footer_img ? (
                                      <img
                                        src={values.footer_img}
                                        alt=""
                                        className="imgBox-company"
                                      />
                                    ) : (
                                      <img
                                        src={require("../../../assets/images/footer.png")}
                                        alt=""
                                        className="imgBox-company"
                                      />
                                    )}
                                    <div>
                                      <div className="form-group1">
                                        <input
                                          type="file"
                                          name="image"
                                          id="input-files-footer"
                                          className="form-control-file border"
                                          onChange={(event) =>
                                            handleFileChange(
                                              event,
                                              "footerImg", // The field name you want to set
                                              setFieldValue, // Function to update the field value
                                              setFooterPreview // Function to set the image preview
                                            )
                                          }
                                          style={{ display: "none" }}
                                          accept=".png,.jpg,.jpeg"
                                        />
                                      </div>
                                    </div>
                                  </label>
                                </div>
                              </>
                            )}
                          </>
                        ) : (
                          ""
                        )}
                        <div className="col-12 col-12 pt-4 d-flex justify-content-center">
                          <button
                            className="border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label"
                            onClick={handelClose}
                          >
                            Close
                          </button>
                          <button
                            type="submit"
                            className="btn btn-primary px-4 py-2 ms-2  text-light form_label rounded-1"
                            style={{
                              backgroundColor: "#f58634",
                            }}
                          >
                            {isShowApiKey === 1
                              ? "Save Company"
                              : "Create Company"}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      )}
      <OtpConfirmationModal
        show={isEmailVerifyConfirmation}
        onHide={() => setIsEmailVerifyCloseConfirmation(false)}
        handleSubmit={() => setIsEmailVerifyCloseConfirmation(false)}
        title={`Verify Email`}
        message={`Are you sure you want  Verify  this ${companyToEdit?.company_email} Email?`}
        btn1="CANCEL"
        btn2="verify"
        profileId={companyToEdit?.id}
        position={4}
      />
    </React.Fragment>
  );
};

export default CreateCompanyView;
function validateImageDimensions(file: File, arg1: number, arg2: number, arg3: (isValid: any) => void) {
  throw new Error("Function not implemented.");
}

