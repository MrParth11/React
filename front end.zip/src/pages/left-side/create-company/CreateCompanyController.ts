import * as Yup from "yup";
import {
  axiosInstance,
  axiosInstanceFormData,
  axiosInstanceSmallOfficeB2B,
} from "../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  DEFAULT_TOKEN_B2B,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";
import { toast } from "react-toastify";
import {
  checkDuplication,
  checkDuplicationWithoutApplicationLogin,
} from "../../../common/SharedFunction";
import { TReactSetState } from "../../../helpers/AppType";

export interface ICreateCompany {
  id?: number;
  company_name: string;
  company_email: string;
  company_contact: string;
  trade_india_user_id: string;
  trade_india_profile_id: string;
  trade_india_key: string;
  india_mart_api_key: string;
  whatsapp_authkey: string;
  whatsapp_appkey: string;
  chatgpt_appkey: string;
  gimini_appkey: string;
  google_lead_sheet_for_faceBook_1: string;
  google_lead_sheet_for_faceBook_2: string;
  google_sheet_key_3: string;
  google_sheet_key_4: string;
  host_out_going_mail: string;
  port_mail_setup: string;
  mail_id_setup: string;
  password_mail_setup: string;
  plan_id?: number;
  invitation_key?: number;
  activation_code?: string;
  is_email_verified?: number;
  invoice_prefix: string;
  order_prefix: string;
  workorder_prefix: string;
  quotation_prefix: string;
  purchase_prefix: string;
  category_id_b2b: string;
  sub_category_id_b2b: string;
  gst_number: string;
  address: string;
  country_id: string;
  state_id: string;
  city_id: string;
  currency_id: string;
  bank_detail: string;
  terms_and_condition: string;
  header_img: string;
  footer_img: string;
  company_logo: string;
  company_catalog: string;
  pop3_host:string
  incoming_port:string
}
const formatText = (input: string) =>
  input
    .replace(/<br\s*\/?>/gi, "\n") // Replace <br> or <br/> with \n
    .replace(/<[^>]*>/g, ""); // Remove other HTML tags
export const createCompanyInitialValues = (
companyToEdit: ICreateCompany | undefined, mobileNumber: any, defaultCountry: any, defaultCurrency: { label: string; value: number; } | undefined): ICreateCompany => ({
  company_name: companyToEdit?.company_name || "",
  trade_india_user_id: companyToEdit?.trade_india_user_id || "",
  trade_india_profile_id: companyToEdit?.trade_india_profile_id || "",
  trade_india_key: companyToEdit?.trade_india_key || "",
  india_mart_api_key: companyToEdit?.india_mart_api_key || "",
  whatsapp_authkey: companyToEdit?.whatsapp_authkey || "",
  whatsapp_appkey: companyToEdit?.whatsapp_appkey || "",
  chatgpt_appkey: companyToEdit?.chatgpt_appkey || "",
  gimini_appkey: companyToEdit?.gimini_appkey || "",
  company_email: companyToEdit?.company_email || "",
  company_contact: companyToEdit?.company_contact || mobileNumber,
  google_lead_sheet_for_faceBook_1:
    companyToEdit?.google_lead_sheet_for_faceBook_1 || "",
  google_lead_sheet_for_faceBook_2:
    companyToEdit?.google_lead_sheet_for_faceBook_2 || "",
  google_sheet_key_3: companyToEdit?.google_sheet_key_3 || "",
  google_sheet_key_4: companyToEdit?.google_sheet_key_4 || "",
  host_out_going_mail: companyToEdit?.host_out_going_mail || "",
  port_mail_setup: companyToEdit?.port_mail_setup || "",
  mail_id_setup: companyToEdit?.mail_id_setup || "",
  password_mail_setup: companyToEdit?.password_mail_setup || "",
  invoice_prefix: companyToEdit?.invoice_prefix || "",
  order_prefix: companyToEdit?.order_prefix || "",
  workorder_prefix: companyToEdit?.workorder_prefix || "",
  quotation_prefix: companyToEdit?.quotation_prefix || "",
  purchase_prefix: companyToEdit?.purchase_prefix || "",
  gst_number: companyToEdit?.gst_number || "",
  address: companyToEdit?.address || "",
  //defaultCountry
  country_id: companyToEdit?.country_id || "",
  state_id: companyToEdit?.state_id || "",
  city_id: companyToEdit?.city_id || "",
   currency_id: companyToEdit?.currency_id || "INR",
  bank_detail: companyToEdit?.bank_detail
    ? formatText(companyToEdit?.bank_detail)
    : "Bank Name :\nBank Account No :\nBank IFSC Code :\nBank Branch :",
  terms_and_condition: companyToEdit?.terms_and_condition
    ? formatText(companyToEdit?.terms_and_condition)
    : "",
  header_img: companyToEdit?.header_img || "",
  footer_img: companyToEdit?.footer_img || "",
  category_id_b2b: companyToEdit?.category_id_b2b || "",
  sub_category_id_b2b: companyToEdit?.sub_category_id_b2b || "",
  company_logo: companyToEdit?.company_logo || "",
  company_catalog: companyToEdit?.company_catalog || "",
  incoming_port:companyToEdit?.incoming_port || "",
  pop3_host:companyToEdit?.pop3_host || ""
});

export const createCompanyValidationSchema = () =>
  Yup.object().shape({
    company_name: Yup.string()
      .min(3, "Minimum 3 Characters Required")
      .max(25, "Maximum 25 Characters Allowed")
      .required("Company Name is Required"),
    company_email: Yup.string()
      .email("Please write proper Email")
      .required("Mail is Required"),
    gst_number: Yup.string()
      .max(15, "Max GST number 15")
      .min(15, "Min GST number 15"),
    company_contact: Yup.string()
      .max(15, "Max mobile number 15")
      .min(10, "Min mobile number 10"),
    mail_id_setup: Yup.string().email("Please write proper Mail"),
    category_id_b2b: Yup.string().required("Category is Required"),
    sub_category_id_b2b: Yup.string().required("Sub category is Required"),
  });

export const createCompany = async (
  values: ICreateCompany,
  setRefresh: TReactSetState<boolean>,
  onHide: any,
  mobileNumber: number,
  setCheckPlan: TReactSetState<ICreateCompany | undefined>,
  isSetCheckPlan: TReactSetState<boolean>
) => {
  setCheckPlan(undefined);

  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    activation_code: values.activation_code,
    company_name: values.company_name,
    company_contact: values.company_contact || mobileNumber,
    company_email: values.company_email,
    category_id_b2b: values.category_id_b2b,
    sub_category_id_b2b: values.sub_category_id_b2b,
    a_application_login_id: getUUID,
  };
  isSetCheckPlan(false);

  setRefresh(false);
  try {
    const { data } = await axiosInstance.post("createCompany", requestData);
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        onHide();
        setRefresh(true);
        isSetCheckPlan(true);
        setCheckPlan(data.data.item);
        if (values.activation_code) {
          const getUserName = await localStorage.getItem("USERNAME");
          const planBody = data.data.item
          const requestData = {
            plan_month: planBody.months,
            plan_number: planBody.plan_id,
            a_application_login_id: Number(getUUID),
            application_login_name:getUserName
          };
          setRefresh(true);
        }
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateCompany = async (
  values: ICreateCompany,
  setRefresh: TReactSetState<boolean>,
  companyId: any,
  onHide: any,
  headerImg: any,
  footerImg: any,
  companyLog: any,
  companyCatalog: any
) => {
  const token = localStorage.getItem("token");
  const validityEmail =
    values.company_email === companyId.company_email ? "2" : "0";
  const toCheckIsmailVerify =
    Number(validityEmail) === 2
      ? companyId.is_email_verified === 1
        ? 1
        : "0"
      : "0";

  const requestData = {
    table: "company_masters",
    where: `{"id":${companyId.id}}`,
    data: JSON.stringify({
      company_name: values.company_name,
      company_contact: values.company_contact,
      company_email: values.company_email,
      trade_india_user_id: values.trade_india_user_id,
      trade_india_profile_id: values.trade_india_profile_id,
      trade_india_key: values.trade_india_key,
      india_mart_api_key: values.india_mart_api_key,
      whatsapp_authkey: values.whatsapp_authkey,
      whatsapp_appkey: values.whatsapp_appkey,
      chatgpt_appkey: values.chatgpt_appkey,
      gimini_appkey: values.gimini_appkey,
      google_lead_sheet_for_faceBook_1: values.google_lead_sheet_for_faceBook_1,
      google_lead_sheet_for_faceBook_2: values.google_lead_sheet_for_faceBook_2,
      google_sheet_key_3: values.google_sheet_key_3,
      google_sheet_key_4: values.google_sheet_key_4,
      host_out_going_mail: values.host_out_going_mail,
      port_mail_setup: values.port_mail_setup,
      mail_id_setup: values.mail_id_setup,
      password_mail_setup: values.password_mail_setup,
      order_prefix: values.order_prefix,
       workorder_prefix: values.workorder_prefix,
      quotation_prefix: values.quotation_prefix,
      invoice_prefix: values.invoice_prefix,

      is_email_verified: toCheckIsmailVerify,
    }),
  };
  setRefresh(false);

  const formData = new FormData();
  formData.append("catalog_pdf", companyCatalog);

  formData.append("company_logo", companyLog);

  formData.append("header_img", headerImg);
  formData.append("footer_img", footerImg);
  formData.append("company_id", companyId.id);
  formData.append("company_name", values.company_name);
  formData.append("company_email", values.company_email);
  formData.append("trade_india_user_id", values.trade_india_profile_id);
  formData.append("trade_india_profile_id", values.trade_india_profile_id);
  formData.append("trade_india_key", values.trade_india_key);
  formData.append("india_mart_api_key", values.india_mart_api_key);
  formData.append("whatsapp_authkey", values.whatsapp_authkey);
  formData.append("whatsapp_appkey", values.whatsapp_appkey);
  formData.append("chatgpt_appkey", values.chatgpt_appkey);
  formData.append("gimini_appkey", values.gimini_appkey);
  formData.append(
    "google_lead_sheet_for_faceBook_1",
    values.google_lead_sheet_for_faceBook_1
  );
  formData.append(
    "google_lead_sheet_for_faceBook_2",
    values.google_lead_sheet_for_faceBook_2
  );
  formData.append("google_sheet_key_3", values.google_sheet_key_3);
  formData.append("google_sheet_key_4", values.google_sheet_key_4);
  formData.append("host_out_going_mail", values.host_out_going_mail);
  formData.append("port_mail_setup", values.port_mail_setup);
  formData.append("mail_id_setup", values.mail_id_setup);
  formData.append("password_mail_setup", values.password_mail_setup);
  formData.append("order_prefix", values.order_prefix);
  formData.append("workorder_prefix", values.workorder_prefix);
  formData.append("purchase_prefix", values.purchase_prefix);
  formData.append("quotation_prefix", values.quotation_prefix);
  formData.append("invoice_prefix", values.invoice_prefix);
  formData.append("gst_number", values.gst_number);
  formData.append("address", values.address);
  formData.append("country_id", values.country_id);
  formData.append("incoming_port", values.incoming_port);
  formData.append("pop3_host", values.pop3_host);
  formData.append("category_id_b2b", String(values.category_id_b2b));
  formData.append("sub_category_id_b2b", String(values.sub_category_id_b2b));
  formData.append("state_id", values.state_id);
  formData.append("city_id", values.city_id);
    formData.append("currency_id", values.currency_id);
  formData.append("bank_detail", values.bank_detail.replace(/\n/g, "<br>"));
  formData.append(
    "terms_and_condition",
    values.terms_and_condition.replace(/\n/g, "<br>")
  );


  try {
    const data = await axiosInstanceFormData.post(
      "editCompany",

      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data", // Set content type for FormData
          Authorization: token,
        },
      }
    );

    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      onHide();
      setRefresh(true);
    } else {
      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const handelSendOtpForEmailVerifyCompany = async (
  setIsEmailVerifyCloseConfirmation: TReactSetState<boolean>,
  companyId: number
) => {
  const token = await localStorage.getItem("token");
  console.log("companyId", companyId);

  setIsEmailVerifyCloseConfirmation(true);
  try {
    const response = await axiosInstance.post(
      "otpSendEmailVerifyCompany",
      {
        company_id: companyId,
      },
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );
    if (response.data.code === 200) {
      if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsEmailVerifyCloseConfirmation(true);
      } else {
        toast.error(response.data.ack_msg);
      }
    } else {
      toast.error(response.data.ack_msg);
    }
  } catch (error) {
    setIsEmailVerifyCloseConfirmation(false);

    toast.error("Failed to send OTP. Please try again.");
  }
};

export const fetchStateApiForCompany = async (
  setStateList: any,
  selectedCountryId: any
) => {
  console.log("selectedCountryId", selectedCountryId);

  const requestData = {
    table: "a_states",
    columns: "id,state_name",
    where: `{"country_id": "${selectedCountryId}"}`,
  };

  const getUUID = localStorage.getItem("UUID")

  try {
    const response = await axiosInstance.post("commonGet", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,
        },
      }
    );

    setStateList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setStateList([]);
  }
};
export const fetchCityApiForCompany = async (
  setCityList: TReactSetState<any>,
  selectedStateId: any
) => {
  const requestData = {
    table: "a_cities",
    columns: "id,city_name",
    where: `{"state_id": ${selectedStateId}}`,
  };
  const getUUID = localStorage.getItem("UUID");

  try {
    const response = await axiosInstance.post("commonGet", requestData , 
      {
        headers: {
          "x-tenant-id": getUUID,

        },
        }

    );

    setCityList(response.data.data); // Assuming API response is an array of countries
  } catch (error) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setCityList([]);
  }
};

export const fetchCategoryB2BApi = async (
  setCategoryList: TReactSetState<any>
) => {
  try {
    const response = await axiosInstanceSmallOfficeB2B.post(
      "category-b2b",
      {},
      {
        headers: {
          Authorization: DEFAULT_TOKEN_B2B,
        },
      }
    );

    if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setCategoryList(response.data.data.item);
    } else {
      setCategoryList([]);
      toast.error(MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setCategoryList([]);
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchSubCategoryB2BApi = async (
  setSubCategoryList: TReactSetState<any>,
  categoryId: number
) => {
  try {
    const response = await axiosInstanceSmallOfficeB2B.post(
      "subCategory-b2b",
      {
        category_id: categoryId,
      },
      {
        headers: {
          Authorization: DEFAULT_TOKEN_B2B,
        },
      }
    );

    if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setSubCategoryList(response.data.data.item);
    } else {
      setSubCategoryList([]);
      toast.error(MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    console.error("Error fetching countries:", error);
    // Handle error (e.g., show error message, clear filtered list)
    setSubCategoryList([]);
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
