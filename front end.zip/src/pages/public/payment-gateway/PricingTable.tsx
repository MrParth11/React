import React, { useEffect, useState } from "react";
import displayRazorpay from "./PaymentGateway";
import {
  fetchApiApplicationPage,
  fetchApiPlan,
  IAppPage,
  IPlanList,
  updateCompanyForPlan,
} from "./PricingTableController";
import StepCompanyView from "../step-company/StepCompanyView";
interface IPropPricingTable {
  companyId: number | undefined;
  companyName: string | undefined;
  companyEmailId: string | undefined;
  companyContact: string | undefined;
  planAmount?: number;
  checkCompanyAlreadyExists?: number;
}
const PricingTable = ({
  companyId,
  companyName,
  companyEmailId,
  companyContact,
  planAmount,
  checkCompanyAlreadyExists,
}: IPropPricingTable) => {
  let isGroupOpen;
  const loadScript = (src: string) => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = () => {
        resolve(true);
      };
      script.onerror = () => {
        resolve(false);
      };
      document.body.appendChild(script);
    });
  };

  useEffect(() => {
    loadScript("https://checkout.razorpay.com/v1/checkout.js");
  }, []);
  const [planList, setPlanList] = useState<IPlanList[]>([]);
  const [appPageList, setAppPageList] = useState<IAppPage[]>([]);
  const [showMenu, setShowMenu] = useState(false);
  interface IPlan {
    id: number;
    name: string;
    price: string;
    features: string[];
    buttonName: string;
  }
  interface IGreyedOutFeaturesByPlan {
    [planName: string]: number[];
  }
  const plans: IPlan[] = [
    {
      id: 1,
      name: "Free",
      price: "₹00.00/year",
      features: [
        "Smart Dashboard",
        "Create Company & Join Company",
        "Contact / Lead Management",
        "Category & Product Master",
        "Source / Status / Label Master",
        "Import & Export Contact History",
        "Lead Management",
        "Reminder & Task Management",
        "Third Party Lead Integration",
        "Price List Management",
        "Quotation & Order Management",
        "Assign Lead To Team Member",
        "Search & Filter Communication History",
        "WhatsApp Integration",
        "Personal Notes Management",
        "Payment History",
        "Reports & Statistics",
        "Rights Based User Access Limitation",
        "Server Installation",
        "Support Period",
        "Support Type",
        "License Period",
      ],
      buttonName: "Start Now",
    },
    {
      id: 2,
      name: "Starter Pack",
      price: "₹149.00/year",
      features: [
        "Smart Dashboard",
        "Create Company & Join Company",
        "Contact / Lead Management",
        "Category & Product Master",
        "Source / Status / Label Master",
        "Import & Export Contact History",
        "Lead Management",
        "Reminder & Task Management",
        "Third Party Lead Integration",
        "Price List Management",
        "Quotation & Order Management",
        "Assign Lead To Team Member",
        "Search & Filter Communication History",
        "WhatsApp Integration",
        "Personal Notes Management",
        "Payment History",
        "Reports & Statistics",
        "Rights Based User Access Limitation",
        "Server Installation",
        "Support Period",
        "Support Type",
        "License Period",
      ],
      buttonName: "Pay Now",
    },
    {
      id: 3,
      name: "Business Pack",
      price: "₹249.00/year",
      features: [
        "Smart Dashboard", //0
        "Create Company & Join Company", //1
        "Contact / Lead Management", //2
        "Category & Product Master", //3
        "Source / Status / Label Master", //4
        "Import & Export Contact History", //5
        "Lead Management", //6
        "Reminder & Task Management", //7
        "Third Party Lead Integration", //8
        "Price List Management", //9
        "Quotation & Order Management", //10
        "Assign Lead To Team Member", //11
        "Search & Filter Communication History", //12
        "WhatsApp Integration", //13
        "Personal Notes Management", //14
        "Payment History", //15
        "Reports & Statistics", //16
        "Rights Based User Access Limitation", //17
        "Server Installation", //18
        "Support Period", //19
        "Support Type", //20
        "License Period", //21
      ],
      buttonName: "Pay Now",
    },
  ].filter((plan) => !(planAmount === 1 && plan.id === 1));
  const features = [
    "Smart Dashboard",
    "Create Company & Join Company",
    "Contact / Lead Management",
    "Category & Product Master",
    "Source / Status / Label Master",
    "Import & Export Contact History",
    "Lead Management",
    "Reminder & Task Management",
    "Third Party Lead Integration",
    "Price List Management",
    "Quotation & Order Management",
    "Assign Lead To Team Member",
    "Search & Filter Communication History",
    "WhatsApp Integration",
    "Personal Notes Management",
    "Payment History",
    "Reports & Statistics",
    "Rights Based User Access Limitation",
    "Server Installation",
    "Support Period",
    "Support Type",
    "License Period",
  ];

  useEffect(() => {
    fetchApiPlan(setPlanList);
    fetchApiApplicationPage(setAppPageList);
  }, []);
  const handleChoosePlan = async (item: IPlanList) => {
    if (item.plan_id === 1) {
      // alert("i have choose free plan");
      await updateCompanyForPlan(
        setShowMenu,
        companyId,
        item.plan_id,
        item.months
      );
    } else {
      displayRazorpay(
        setShowMenu,
        item.plan_amount,
        companyId,
        item.plan_id,
        companyName,
        companyEmailId,
        companyContact,
        item.months
      );
    }
  };
  const greyedOutFeaturesByPlan: IGreyedOutFeaturesByPlan = {
    "Starter Pack": [9, 10, 14, 15],
    "Business Pack": [15],
  };

  const isGreyedOut = (planName: string, idx: number): boolean => {
    return greyedOutFeaturesByPlan[planName]?.includes(idx) || false;
  };

  const planList1 = [
    {
      plan_id: 1,
      plan_name: "Free",
      plan_amount: 0,
      months: 1,
      plan_pages: [
        { page_name: "Contact", dataLimit: 24000 },
        { page_name: "Inquiry", dataLimit: 0 },
        { page_name: "Insight", dataLimit: 0 },
        { page_name: "Reminder", dataLimit: 0 },
        { page_name: "Personal Note", dataLimit: 0 },
        { page_name: "Category", dataLimit: 0 },
      ],
    },
    {
      plan_id: 2,
      plan_name: "Starter Pack",
      plan_amount: 149,
      months: 2,
      plan_pages: [
        { page_name: "Contact", dataLimit: 25000 },
        { page_name: "Inquiry", dataLimit: 0 },
        { page_name: "Insight", dataLimit: 0 },
        { page_name: "Reminder", dataLimit: 0 },
        { page_name: "Personal Note", dataLimit: 0 },
        { page_name: "Category", dataLimit: 0 },
        { page_name: "Product", dataLimit: 0 },
        { page_name: "Price List", dataLimit: 0 },
        { page_name: "Price List Item", dataLimit: 0 },
      ],
    },
    {
      plan_id: 3,
      plan_name: "Business Pack",
      plan_amount: 249,
      months: 3,
      plan_pages: [
        { page_name: "Contact", dataLimit: 25000 },
        { page_name: "Inquiry", dataLimit: 0 },
        { page_name: "Insight", dataLimit: 0 },
        { page_name: "Reminder", dataLimit: 0 },
        { page_name: "Personal Note", dataLimit: 0 },
        { page_name: "Category", dataLimit: 0 },
        { page_name: "Product", dataLimit: 0 },
        { page_name: "Price List", dataLimit: 5000 },
        { page_name: "Price List Item", dataLimit: 0 },
        { page_name: "Source", dataLimit: 0 },
        { page_name: "Lable", dataLimit: 0 },
        { page_name: "Status", dataLimit: 0 },
        { page_name: "Contact Message History", dataLimit: 0 },
        { page_name: "Quotation", dataLimit: 0 },
        { page_name: "Order", dataLimit: 0 },
        { page_name: "Invoice", dataLimit: 0 },
        { page_name: "Email", dataLimit: 0 },
        { page_name: "Account History", dataLimit: 0 },
        { page_name: "Purchase", dataLimit: 0 },
      ],
    },
  ];

  const appPageList1 = [
    { id: 1, page_name: "Contact" },
    { id: 2, page_name: "Inquiry" },
    { id: 3, page_name: "Insight" },
    { id: 4, page_name: "Reminder" },
    { id: 5, page_name: "Personal Note" },
    { id: 6, page_name: "Category" },
    { id: 7, page_name: "Product" },
    { id: 8, page_name: "Price List" },
    { id: 9, page_name: "Price List Item" },
    { id: 10, page_name: "Source" },
    { id: 11, page_name: "Label" },
    { id: 12, page_name: "Status" },
    { id: 13, page_name: "Contact Message History" },
    { id: 14, page_name: "Quotation" },
    { id: 15, page_name: "Order" },
    { id: 16, page_name: "Invoice" },
    { id: 17, page_name: "Email" },
    { id: 18, page_name: "Account History" },
    { id: 19, page_name: "Purchase" },
  ];

  const handleLogout = () => {
    window.location.reload();
    localStorage.clear();
  };

  const person_limit = ["For Two users", "For Small Team", "For Big Team"];
  const discount_price = [
    "₹ 4,999/- Per Year",
    "₹ 9,999/- Per Year",
    "₹ 17,000/- Per Year",
  ];

  return (
    <>
      {showMenu || checkCompanyAlreadyExists === 4 ? (
          <StepCompanyView isVisibleStepCompany={true} companyId={companyId} />
      ) : (
        <>
          <div className="main-pricing w-100 px-2 mx-2">
            <div className="Intro-Left1 ">
              <div className="row ">
                <div className="text-center pt-3">
                  <img
                    src={require("../../../assets/images/smalll_office_log.png")}
                    width={200}
                    alt=""
                  />
                </div>

                <div>
                  <p className="text-center h1 fw-bold mt-4">
                    Best Pricing <span style={{ color: "#f58634" }}>Plans</span>
                  </p>
                </div>
                <div className="d-flex justify-content-center">
                  <p
                    className="py-2 text-center"
                    style={{ color: "black", width: "90%" }}
                  >
                    Discover the best pricing plans designed for every budget.
                    <br />
                    Choose a plan that suits your business and unlock powerful
                    CRM features to enhance your productivity.
                  </p>
                </div>
              </div>
              <div className="row mx-3">
                <div className="d-flex justify-content-center align-items-center w-100">
                  {planList &&
                    planList
                      .filter((plan) =>
                        planAmount !== undefined
                          ? plan.plan_amount > planAmount
                          : true
                      )
                      .map((plan, index) => (
                        <div className="m-2" key={index}>
                          <div className="card text-left shadow">
                            <div
                              className="card-header mb-0"
                              style={{
                                backgroundColor: "rgb(207, 207, 207)",
                              }}
                            >
                              <h4 className="my-0">{plan.plan_name}</h4>
                              <p>{person_limit[index]}</p>
                            </div>
                            <div
                              className="card-body"
                              style={{ backgroundColor: "#f0f2f5" }}
                            >
                              <h1
                                className="card-title pricing-card-title"
                                style={{ color: "#f58634" }}
                              >
                                ₹ {plan.plan_amount.toFixed(2)}/year
                              </h1>
                              <del>{discount_price[index]}</del>
                              <ul className=" mt-3 ps-0">
                                {plan.plan_pages.map((feature, index) => (
                                  <li key={index} style={{ listStyle: "none" }}>
                                    {feature.is_allow === 1 ? (
                                      feature.page_name
                                    ) : (
                                      <del
                                        style={{ color: "rgb(153, 153, 153)" }}
                                      >
                                        {feature.page_name}
                                      </del>
                                    )}
                                    &nbsp;
                                    {feature.dataLimit > 0
                                      ? `(${feature.dataLimit})`
                                      : ""}
                                  </li>
                                ))}
                              </ul>
                              <button
                                type="button"
                                className="btn btn-lg btn-primary m-1"
                                onClick={() => handleChoosePlan(plan)}
                                style={{
                                  backgroundColor: "#f58634",
                                  fontSize: "18px",
                                  paddingInline: "15px",
                                  borderRadius: "30px",
                                }}
                              >
                                Start Trial Now
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                </div>
              </div>
              <div className="d-flex justify-content-center align-items-center">
                <span
                  style={{
                    color: "blue",
                    cursor: "pointer",
                    marginBottom: "8px",
                  }}
                  onClick={handleLogout}
                >
                  <u>Logout Here</u>
                </span>
                <button className="btn  ms-2" title="logout"></button>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default PricingTable;
