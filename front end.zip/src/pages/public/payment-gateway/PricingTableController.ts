import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";
import { TReactSetState } from "../../../helpers/AppType";
import { axiosInstance } from "../../../services/axiosInstance";
interface IPlanPage {
  page_name: string;
  dataLimit: number;
  is_allow: number
}
export interface IPlanList {
  plan_id: number;
  plan_name: string;
  plan_amount: number;
  months: number;
  plan_pages: [IPlanPage];
}

export interface IAppPage {
  id: number;
  page_name: string;
}
export const updateCompanyForPlan = async (
  setRefresh: TReactSetState<boolean>,
  companyId: number | string | undefined,
  planNumber: number,
  planMonth: number
) => {

  const getUUID = await localStorage.getItem("UUID");
  const getUserName = await localStorage.getItem("USERNAME");

  const requestData = {
    plan_month: planMonth,
    company_id: companyId,
    plan_number: planNumber,
    a_application_login_id: Number(getUUID),
    application_login_name: getUserName
  };
  setRefresh(false);
  try {
    const data = await axiosInstance.post("createPlane", requestData);

    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setRefresh(true);
      console.log("data", data.data);

      const storeToken = data.data?.data?.token;
      console.log("storeToken", storeToken);
      localStorage.setItem("token", storeToken);
    } else {
      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }

};
export const createCompanyVsPlan = async (
  setRefresh: TReactSetState<boolean>,
  paymentId: string,
  orderId: string,
  razorpaySignature: string,
  amount: string | number
) => {
  console.log("teststts", amount);

  const date = new Date();

  // Format the date as YYYY-MM-DD
  const formattedDate = `${date.getFullYear()}-${String(
    date.getMonth() + 1
  ).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;

  const getUUID = await localStorage.getItem("UUID");

  const requestDataCompanyVsPlan = {
    table: "company_vs_plans",
    data: JSON.stringify({
      razorpay_payment_id: paymentId,
      razorpay_order_id: orderId,
      razorpay_signature: razorpaySignature,
      amount: amount,
      created_date_time: formattedDate,
      a_application_login_id: getUUID,
    }),
  };
  console.log("requestDataCompanyVsPlan", requestDataCompanyVsPlan.data);

  setRefresh(false);
  try {
    const data = await axiosInstance.post(
      "mainCommonCreate",
      requestDataCompanyVsPlan
    );

    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setRefresh(true);
    } else {
      toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchApiPlan = async (
  setPlanList: TReactSetState<IPlanList[]>
) => {
  const requestData = {
    // table: "plan_masters",
    // columns: "id,plan_name,plan_amount,months",
    // where: `{"isDelete": "0"}`,
  };

  try {
    const response = await axiosInstance.post("getPlanDetail", requestData);
    if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setPlanList(response.data.data.item);
    } else {
      toast.error(response.data.ack_msg || DEFAULT_STATUS_CODE_SUCCESS);
      setPlanList([]);
    }
  } catch (error: any) {
    console.error("Error fetching countries:", error);
    toast.error(error || DEFAULT_STATUS_CODE_SUCCESS);
    setPlanList([]);
  }
};

export const fetchApiApplicationPage = async (
  setAppPageList: TReactSetState<IAppPage[]>
) => {
  const requestData = {
    table: "a_application_pages",
    columns: "id,page_name",
    where: `{"isDelete": "0"}`,
  };

  try {
    const response = await axiosInstance.post("mainCommonGet", requestData);
    if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setAppPageList(response.data.data);
    } else {
      toast.error(response.data.ack_msg || DEFAULT_STATUS_CODE_SUCCESS);
      setAppPageList([]);
    }
  } catch (error: any) {
    console.error("Error fetching countries:", error);
    toast.error(error || DEFAULT_STATUS_CODE_SUCCESS);
    setAppPageList([]);
  }
};
