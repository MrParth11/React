

import { toast } from "react-toastify";
import { TReactSetState } from "../../../helpers/AppType";
import { axiosInstance } from "../../../services/axiosInstance";
import {
  createCompanyVsPlan,
  updateCompanyForPlan,
} from "./PricingTableController";


interface RazorpayData {
  data: any;
  currency: string;
  amount: number;
  id: string;
}


interface RazorpayOptions {
  key: string;
  currency: string;
  amount: number;
  name: string;
  description: string;
  image: string;
  order_id: string;
  handler: (response: {
    razorpay_payment_id: string;
    razorpay_order_id: string;
    razorpay_signature: string;
  }) => void;
  prefill: {
    name: string | undefined;
    email: string | undefined;
    contact: string | undefined;
  };
}

export default async function displayRazorpay(
  setShowMenu: TReactSetState<boolean>,
  planPrice: string | number,
  companyId: number | undefined,
  planId: number,
  companyName: string | undefined,
  companyEmailId: string | undefined,
  companyContact: string | undefined,
  planMonth: number
) {
  try {
    const numericPrice = Number(planPrice) * 100;
    const { data }: { data: RazorpayData } =
      await axiosInstance.post<RazorpayData>("razorpay", {
        companyId,
        planId,
        amount: numericPrice,
      });

    console.log(data.data.item.id);

    const options: RazorpayOptions = {
      key: process.env.RAZORPAY_KEY_ID || "rzp_test_FtIPFB2iQ5SQgh",
      currency: data.currency,
      amount: Number(planPrice),
      name: "CBT",
      description: "Wallet Transaction",
      image: "http://localhost:1337/logo.png",
      order_id: data.data.item.id,
      handler: async function (response) {
        try {
          const verifyResponse = await axiosInstance.post("/verify-payment-razorpay", {
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_order_id: response.razorpay_order_id,
            razorpay_signature: response.razorpay_signature,
          });
          if (verifyResponse.data.ack === 1) {
            await updateCompanyForPlan(setShowMenu, companyId, planId, planMonth);
            await createCompanyVsPlan(
              setShowMenu,
              response.razorpay_payment_id,
              response.razorpay_order_id,
              response.razorpay_signature,
              planPrice
            );
          } else {
            toast.error(verifyResponse.data.ack_msg)
          }
        } catch (error) {
          console.error("Error in handler:", error);
          toast.error("")
        }
      },

      prefill: {
        name: companyName,
        email: companyEmailId,
        contact: companyContact || "00000000",
      },
    };
    const Razorpay = (window as any).Razorpay;
    if (Razorpay) {
      const paymentObject = new Razorpay(options);
      paymentObject.open();
    } else {
      console.error("Razorpay SDK is not loaded.");
    }
  } catch (error) {
    console.error("Error fetching Razorpay data:", error);
  }
}
