import React, { useState, useEffect, useContext } from "react";
import {
  OTPSubmit,
  IOTPVerifyViewProps,
  IUserInfo,
} from "./OTPVerificationController";
import OTPInput from "react-otp-input";

import RegistrationView from "../resternation/RegistrationView";

import LoginView from "../login/LoginView";
import PublicCompanyView from "../public-company/PublicCompanyView";
import { AppContext } from "../../../common/AppContext";
import PricingTable from "../payment-gateway/PricingTable";
import { Link } from "react-router-dom";
import StepCompanyView from "../step-company/StepCompanyView";
import LeftSideView from "../../left-side/LeftSideView";

const OTPVerificationView = ({
  handleSubmit,
  mobileNumber,
  setShowMenu,
  position,
}: IOTPVerifyViewProps) => {
  const [count, setCount] = useState(30);
  const [intervalNumber, setIntervalNumber] = useState<
    NodeJS.Timeout | undefined
  >();
  let isGroupOpen;

  const [isButtonVisible, setIsButtonVisible] = useState(false);
  const [clickCount, setClickCount] = useState(0);
  const [countResend, setCountResend] = useState(3);
  const [showMenu1, setShowMenu1] = useState(false);
  const [otp, setOtp] = useState("");
  const [showRegistration, setShowRegistration] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [checkCompanyAlreadyExists, setCheckCompanyAlreadyExists] = useState(0);
  const [userInfo, setUserInfo] = useState<IUserInfo>();
  const { checkPlan, setCheckPlan } = useContext(AppContext)!;
  const [showRenewPlan, setShowRenewPlan] = useState(false);
  const [showRenewPlanFromLogin, setShowRenewPlanFromLogin] = useState(false);

  const [companyData, setCompanyData] = useState<any>();

  useEffect(() => {
    startTimer();
    return () => {
      if (intervalNumber) clearInterval(intervalNumber);
    };
  }, []);

  useEffect(() => {
    if (count === 0 || clickCount === countResend) {
      clearInterval(intervalNumber);
      setIsButtonVisible(true);
    }
  }, [count, intervalNumber, clickCount, countResend]);

  const startTimer = () => {
    const interval = setInterval(() => {
      setCount((prevCount) => prevCount - 1);
    }, 1000);
    setIntervalNumber(interval);
  };

  const handleButtonClick = () => {
    clearInterval(intervalNumber);
    setCount(30);
    setClickCount((prevCount) => prevCount + 1);
    setIsButtonVisible(false);
    restCountDown();
    handleSubmit(false);
  };

  const restCountDown = () => {
    setIsButtonVisible(false);
    const intervals = setInterval(() => {
      setCount((prevCount) => prevCount - 1);
    }, 1000);
    setIntervalNumber(intervals);
  };

  const OtpHandleSubmit = async () => {
    await OTPSubmit(
      otp,
      mobileNumber,
      setShowMenu,
      position,
      setShowMenu1,
      setCheckCompanyAlreadyExists,
      setUserInfo,
      setCompanyData,
      setShowRenewPlan,
      setShowRenewPlanFromLogin
    );
  };

  return (
    <>
      {checkCompanyAlreadyExists === 4 ? (
        <StepCompanyView
          isVisibleStepCompany={true}
          companyId={companyData?.id}
        />
      ) : (
        <>
          {showRenewPlan && checkCompanyAlreadyExists === 2 ? (
            <PricingTable
              companyId={companyData?.id}
              companyName={companyData?.company_name}
              companyEmailId={companyData?.company_email}
              companyContact={companyData?.company_contact}
              checkCompanyAlreadyExists={checkCompanyAlreadyExists}
            />
          ) : (
            <>
              {showLogin ? (
                <LoginView pageRedirect={showLogin} />
              ) : (
                <>
                  {showMenu1 ? (
                    <>
                      {checkCompanyAlreadyExists === 1 ? (
                        <>
                          {showRenewPlanFromLogin ? (
                            <PricingTable
                              companyId={companyData?.id}
                              companyName={companyData?.company_name}
                              companyEmailId={companyData?.company_email}
                              companyContact={companyData?.company_contact}
                              planAmount={0}
                              checkCompanyAlreadyExists={
                                checkCompanyAlreadyExists
                              }
                            />
                          ) : (
                            <LeftSideView
                              isVisible={!isGroupOpen}
                              userInfo={userInfo}
                            />
                          )}
                        </>
                      ) : (
                        <PublicCompanyView
                          showCompany={true}
                          mobileNumber={mobileNumber}
                          checkCompanyAlreadyExists={checkCompanyAlreadyExists}
                        />
                      )}
                    </>
                  ) : (
                    <>
                      {showRegistration ? (
                        <RegistrationView pageRedirect={showRegistration} />
                      ) : (
                        <div className="col-12 d-flex justify-content-center align-items-center Intro-Left1">
                          <div className="row d-flex justify-content-center align-items-center h-100 px-0 mx-0">
                            <div>
                              <div className="row justify-content-center mx-0 px-0 ">
                                <div className="col-12 ">
                                  <div className="px-0 ">
                                    <div className="px-5 mx-0">
                                      <div className=" text-center">
                                        <img
                                          src={require("../../../assets/images/logo.jpg")}
                                          width={200}
                                          alt="Instagram Style Logo"
                                        />
                                      </div>
                                      <div className="">
                                        <div className="">
                                          <p className="text-center h2 fw-bold mb-3  mt-4">
                                            Verify OTP
                                          </p>
                                        </div>
                                        <div className="">
                                          <p
                                            className="font-size-17"
                                            style={{
                                              color: "#999",
                                              textAlign: "center",
                                            }}
                                          >
                                            Check
                                            <b
                                              style={{
                                                color: "#000",
                                              }}
                                            >
                                              &nbsp; WhatsApp & Email
                                            </b>
                                            &nbsp; for the 6-digit OTP <br />
                                            <span
                                              style={{
                                                display: "block",
                                                textAlign: "center",
                                              }}
                                            >
                                              sent to &nbsp;
                                              {mobileNumber.replace(
                                                /.(?=.{4,}$)/g,
                                                "*"
                                              )}
                                            </span>
                                          </p>
                                        </div>

                                        <div className=" text-center  py-3">
                                          <label
                                            htmlFor="OTP"
                                            className="  mb-2 fw-bold"
                                          >
                                            Enter OTP
                                            <span className="text-danger">
                                              *
                                            </span>
                                          </label>

                                          <span
                                            style={{ margin: "8px" }}
                                            className="d-flex justify-content-center"
                                          >
                                            <OTPInput
                                              value={otp}
                                              onChange={setOtp}
                                              numInputs={6}
                                              renderSeparator={
                                                <span style={{ margin: "5px" }}>
                                                  -
                                                </span>
                                              }
                                              renderInput={(props, index) => (
                                                <input
                                                  {...props}
                                                  style={{
                                                    height: "45px",
                                                    width: "45px",
                                                    textAlign: "center",
                                                  }}
                                                  onKeyDown={(e) => {
                                                    if (e.key === "Enter") {
                                                      e.preventDefault();
                                                      OtpHandleSubmit();
                                                    }
                                                  }}
                                                  autoFocus={index === 0}
                                                />
                                              )}
                                            />
                                          </span>
                                        </div>
                                        <div className="d-flex justify-content-center">
                                          <p className="font-size-15">
                                            Didn't get OTP? &nbsp;
                                          </p>
                                          {clickCount < countResend && (
                                            <div>
                                              {isButtonVisible ? (
                                                <div>
                                                  <p
                                                    className="text-primary font-size-15 fw-bold rounded-1  cursor_pointer"
                                                    onClick={() =>
                                                      handleSubmit(false)
                                                    }
                                                  >
                                                    Resend |
                                                    <span
                                                      onClick={() =>
                                                        setShowLogin(true)
                                                      }
                                                    >
                                                      &nbsp;Change Number
                                                    </span>
                                                  </p>
                                                </div>
                                              ) : (
                                                <p className="user-select-none">
                                                  Resend Time {count}
                                                </p>
                                              )}
                                            </div>
                                          )}
                                        </div>

                                        <div className="mt-3">
                                          <button
                                            className="btn text-light w-100 py-2 rounded-1 fw_500"
                                            onClick={OtpHandleSubmit} // Ensure this triggers the OTP submission
                                            style={{
                                              backgroundColor: "#f58634",
                                            }}
                                          >
                                            Verify OTP
                                          </button>
                                        </div>

                                        <div className="d-flex justify-content-center mt-4">
                                          Are you new user?
                                          <span
                                            className=" text-primary font-size-15 fw-bold  cursor_pointer"
                                            style={{
                                              marginLeft: "5px",
                                              color: "blue",
                                              fontStyle: "italic",
                                            }}
                                            onClick={() =>
                                              setShowRegistration(true)
                                            }
                                          >
                                            Create an Account
                                          </span>
                                        </div>
                                        <div className="d-flex justify-content-center mt-2 ">
                                          <p>
                                            <Link
                                              to="/PrivacyPolicy"
                                              target="_blank"
                                            >
                                              Privacy Policy
                                            </Link>
                                            &nbsp;|&nbsp;
                                            <Link
                                              to="ContactUs"
                                              target="_blank"
                                            >
                                              Contact Us
                                            </Link>
                                          </p>
                                        </div>
                                        <small className="d-flex justify-content-center ">
                                          VS 1.0.1
                                        </small>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </>
              )}
            </>
          )}
        </>
      )}
    </>
  );
};

export default OTPVerificationView;
