import React, { useContext, useEffect, useState } from "react";
import LoginView from "./login/LoginView";
import { axiosInstance } from "../../services/axiosInstance";
import { toast } from "react-toastify";
import { MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../helpers/AppConstants";
import { AppContext } from "../../common/AppContext";
import PageView from "./payment-gateway/PricingTable";
import PricingTable from "./payment-gateway/PricingTable";
import Maintenance from "../../components/Maintenance";
import { Link } from "react-router-dom";
import LeftSideView from "../left-side/LeftSideView";

const Index = () => {
  let isGroupOpen;
  const [timestamp, setTimestamp] = useState(true);
  const { checkToken, setCheckToken, setCheckPlan, isSetCheckPlan, checkPlan  , setPermissions} =
    useContext(AppContext)!;
  const [checkToken1, setCheckToken1] = useState(false);
  const [showRenewPlan, setShowRenewPlan] = useState(false);
  const [isMaintenanceMode, setIsMaintenanceMode] = useState(false);
useEffect(() => {
    const token = localStorage.getItem("token");

    const LoginSubmit = async () => {
      const getUUID = await localStorage.getItem("UUID");

      if (!getUUID || getUUID === "") {
        setCheckToken1(true);
      } else {
        setCheckToken1(false);
      }
      try {
        const response = await axiosInstance.post(
          "onLoad",
          {
            a_application_login_id: getUUID, 
          },
          {
            headers: token ? { Authorization: `${token}` } : {}, 
          }
        );
        if (response.data.ack === -1) {
          setIsMaintenanceMode(true);
        }
        if (response.data.ack === 1) {
          setCheckToken(false);
          setPermissions(response.data.data.resultRights)
          if (response.data.data.expiryDays) {

            if (
              response.data.data.expiryDays === -1 ||
              response.data.data.expiryDays === -2
            ) {
              isSetCheckPlan(false);
              setShowRenewPlan(false);
            }

            if (response.data?.data?.expiryMsg) {
              toast.error(response.data?.data?.expiryMsg, {
                theme: "colored",
              });
            }
          
          } else {
            console.log("testststs---------2", response.data.data.item);
        
            isSetCheckPlan(true);
            setShowRenewPlan(true);
            setCheckPlan(response.data.data.item);
          }
          // }
        } else {
          setCheckToken(true);
          localStorage.clear();
        }
      } catch (error: any) {
        if (error.response && error.response.status === 401) {
          setCheckToken(true); 
        } else {
          toast.error(error?.response?.data?.ack_msg);
        }
      }
    };
    LoginSubmit();
    if (!token || token === "" || null) {
      setCheckToken(true);
    } else {
    }

    const interval = setInterval(() => {
      setTimestamp(false);
    }, 1000);
    return () => clearInterval(interval);
  }, [setCheckToken]);
  if (isMaintenanceMode) {
    return <Maintenance />;
  }

  return (
    <div className="body">
      <div className="media">
        <div className="pt-4">
          <img
            width={200}
            src={require("../../assets/images/logo.jpg")}
            alt="Instagram Style Logo"
          />
          <h1 className="logo-main-text-small ">Let's Move Small To Big</h1>
        </div>
        <h1 className="pt-2">
          For a better experience, install our app on your mobile!
        </h1>

        <div className="pt-3">
          <Link to="https://apps.apple.com/in" target="_blank">
            <img
              className="w-50"
              alt="ios"
              src={require("../../assets/images/appleIos.png")}
            />
          </Link>
          <Link to="https://play.google.com/store/apps" target="_blank">
            <img
              className="w-50"
              alt="android"
              src={require("../../assets/images/android.png")}
            />
          </Link>
        </div>
      </div>
      {timestamp ? (
        <div className="container main ">
          <div className="d-flex  align-items-center  Intro-Left1">
            <div className="col-12 text-center">
              <img
                width={200}
                src={require("../../assets/images/logo.jpg")}
                alt="Instagram Style Logo"
              />

              <h1 className="logo-main-text p-3">Let's Move Small To Big</h1>
            </div>
          </div>
        </div>
      ) : (
        <>
          {checkToken || checkToken1 ? (
            <div className="container main ">
              <LoginView />
           </div>
          ) : (
            <>
            
              {showRenewPlan ? (
                   <div className="container main ">
                <PricingTable
                  companyId={checkPlan?.id}
                  companyName={checkPlan?.company_name}
                  companyEmailId={checkPlan?.company_email}
                  companyContact={checkPlan?.company_contact}
                  planAmount={0}
                />
               </div>
              ) : (
             <div className="container main ">
                  <LeftSideView isVisible={!isGroupOpen} />
</div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
};

export default Index;
