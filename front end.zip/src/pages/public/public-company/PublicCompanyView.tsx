import React, { useState, useEffect, useContext } from "react";
// import { OTPSubmit, IOTPVerifyViewProps } from "./OTPVerificationController";
import OTPInput from "react-otp-input";

import RegistrationView from "../resternation/RegistrationView";

import LoginView from "../login/LoginView";
import { TOnChangeInput } from "../../../helpers/AppType";
import { publicCreateVaiLinkCompany } from "./PublicCompanyController";
import { AppContext } from "../../../common/AppContext";
import PricingTable from "../payment-gateway/PricingTable";
import { Link } from "react-router-dom";
import StepCompanyView from "../step-company/StepCompanyView";
import LeftSideView from "../../left-side/LeftSideView";
import CreateCompanyView from "../../left-side/create-company/CreateCompanyView";

const PublicCompanyView = ({
  showCompany,
  mobileNumber,
  checkCompanyAlreadyExists,
}: any) => {
  let isGroupOpen;
  const { checkPlan, isCheckPlan } = useContext(AppContext)!;
  useEffect(() => {
    console.log("checkPlan updated:", checkPlan);
  }, [checkPlan]);

  const [showRegistration, setShowRegistration] = useState(false);
  const [showMenu1, setShowMenu1] = useState(false);
  const [isCreateCompany, setIsCreateCompany] = useState(false);
  const [isJoinCompany, setIsJoinCompany] = useState(false);
  const [refresh, setRefresh] = useState(false);
  const [joinInput, setJoinInput] = useState("");
  const [joinError, setJoinError] = useState("");
  const handelChangeJoinCompany = (event: TOnChangeInput) => {
    const value = event.target.value;
    setJoinInput(value);
    setJoinError(value ? "" : "Invitation key is Required");
  };
  const handleJoinCompany = () => {
    setIsJoinCompany(true);


  };
  const joinHandleSubmit = async () => {
    if (!joinInput) setJoinError("Invitation key is Required");
    if (joinInput) {
      publicCreateVaiLinkCompany(joinInput, setShowMenu1);
    }

  };

  return (
    <>
      {showCompany ? (
        <>

          {typeof checkPlan === "object" &&
            checkPlan?.plan_id === 0 &&
            isCheckPlan === true ? (
            <PricingTable
              companyId={checkPlan?.id}
              companyName={checkPlan?.company_name}
              companyEmailId={checkPlan?.company_email}
              companyContact={checkPlan?.company_contact}
            />
          ) : (

            <>
              {refresh ?
                < StepCompanyView isVisibleStepCompany={true} companyId={checkPlan?.id} />
                :
                <>
                  {showMenu1 || isCheckPlan === true ? (
                 <>
                      <LeftSideView isVisible={!isGroupOpen} />
                   </> 
                  ) : (
                    <>
                      {showRegistration ? (
                        <RegistrationView pageRedirect={showRegistration} />
                      ) : (
                        <div className="col-12 d-flex justify-content-center align-items-center Intro-Left1">
                          <div className="row d-flex justify-content-center align-items-center h-100 px-0 mx-0">
                            <div>
                              <div
                                className="row justify-content-center mx-0 px-0 "

                              >
                                <div className="col-12 ">
                                  <div className="px-0 ">
                                    <div className="px-5 mx-0">
                                      <div className=" text-center">
                                        <img
                                          src={require("../../../assets/images/logo.jpg")}
                                          width={200}
                                          alt="Instagram Style Logo"
                                        />

                                      </div>

                                      <div className="">
                                        <div className="">
                                          <p className="text-center h2 fw-bold mb-3  mt-4">
                                            Company Setup
                                          </p>
                                        </div>
                                        <div className="">
                                          <p
                                            className="d-flex align-items-center justify-content-center font-size-19"
                                            style={{ color: "#999" }}
                                          >
                                            Please Enter your Company Detail.
                                          </p>
                                        </div>
                                        <div className=" row justify-content-center mx-0 px-0 ">
                                          <div
                                            className="col-5 d-flex align-items-center justify-content-center"
                                            onClick={handleJoinCompany}
                                            style={{
                                              border: "2px solid",
                                              borderColor: isJoinCompany ? "green" : "gray",
                                              height: "125px"
                                            }}
                                          >

                                            <div className="text-center"
                                              style={{
                                                height: "100%",
                                                display: "flex",
                                                alignItems: "center",
                                                justifyContent: "center"
                                              }}>
                                              <div>
                                                <img
                                                  src={require("../../../assets/images/join.png")}
                                                  width={50}
                                                  alt="Join"
                                                  
                                                  style={{ cursor: "pointer" }}
                                                />
                                              </div>

                                            </div>

                                          </div>

                                          <div className="col-1 text-center d-flex align-items-center justify-content-center">
                                            <span style={{ fontWeight: "bold" }}>OR</span>
                                          </div>

                                          <div className="col-5 d-flex align-items-center justify-content-center"
                                            style={{ border: "1px solid black", height: "125px" }}>
                                            <div className="text-center"
                                              style={{
                                                height: "100%",
                                                display: "flex",
                                                alignItems: "center",
                                                justifyContent: "center"
                                              }}>
                                              <img
                                                src={require("../../../assets/icons/Company.png")}
                                                width={50}
                                                alt="Create"
                                                onClick={() => setIsCreateCompany(true)}
                                                style={{ cursor: "pointer" }}
                                              />
                                            </div>
                                          </div>
                                        </div>
                                        <div style={{
                                          display: "flex",
                                          justifyContent: "space-evenly",
                                          textAlign: "center",
                                          paddingBottom: "2px",
                                          width: "400px",

                                        }}>
                                          <div className="w-50"><label className="p-3   mb-2 fw-bold">Join Company</label></div>
                                          <div className="w-50"><label className="p-3   mb-2 fw-bold">Create Company</label></div>
                                        </div>


                                        {isJoinCompany && (
                                          <div className=" text-center pt-2">
                                            <label className="  mb-2 fw-bold">
                                              Enter Invitation Key
                                              <span className="text-danger">*</span>
                                            </label>
                                            <div className="d-flex justify-content-center mb-2 ">
                                              <p
                                                style={{
                                                  fontSize: "14px",
                                                  marginBottom: "0px",
                                                }}
                                              >
                                                Please Contact the Company Admin for
                                                an Invitation key
                                              </p>
                                            </div>
                                            <div className="search-bar ">
                                              <div className="add-source-of-type-section ">
                                                <input
                                                  type="text"
                                                  title="join company"
                                                  placeholder="Enter Invitation key"
                                                  value={joinInput}
                                                  onChange={(e) =>
                                                    handelChangeJoinCompany(e)
                                                  }
                                                  className="form-control"
                                                />
                                              </div>
                                            </div>
                                            <div className="mt-3">
                                              <button
                                                className="btn text-light w-100 py-2  rounded-1 fw_500"
                                                onClick={joinHandleSubmit}
                                                style={{ backgroundColor: "#f58634" }}
                                              >
                                                Join Company
                                              </button>
                                            </div>
                                          </div>



                                        )}

                                        {joinError && (
                                          <span className="text-danger">
                                            {joinError}
                                          </span>
                                        )}
                                        <div className="d-flex justify-content-center mt-2 ">
                                          <p>
                                            <Link
                                              to="/PrivacyPolicy"
                                              target="_blank"
                                            >
                                              Privacy Policy
                                            </Link>
                                            &nbsp;|&nbsp;
                                            <Link to="ContactUs" target="_blank">
                                              Contact Us
                                            </Link>
                                          </p>
                                        </div>
                                        <small className="d-flex justify-content-center ">
                                          VS 1.0.1
                                        </small>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </>
              }
            </>
          )}
          <CreateCompanyView
            show={isCreateCompany}
            onHide={() => setIsCreateCompany(false)}
            setRefresh={setRefresh}
            headerName={"Create Your Own Company"}
            mobileNumber={mobileNumber}
            isShowApiKey={5}
          />

        </>
      ) : (
        ""
      )}
    </>
  );
};

export default PublicCompanyView;
