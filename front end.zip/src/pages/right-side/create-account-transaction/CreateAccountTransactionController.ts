import * as Yup from "yup";
import { axiosInstance } from "../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";
import { toast } from "react-toastify";
import { formatDateTimeSendDataBase } from "../../../common/SharedFunction";
import { IAccountTransaction } from "../list-account-transaction/ListAccounTransactionController";
import { TReactSetState } from "../../../helpers/AppType";

export const paymentTypesList = [
  { id: "1", type_name: "Credit" },
  { id: "2", type_name: "Debit" },
];
export const paymentModeList = [
  { id: "1", mode_name: "Cash" },
  { id: "2", mode_name: "Cheque" },
  { id: "3", mode_name: "Online" },
  { id: "4", mode_name: "UPI" },
  { id: "-1", mode_name: "Other" },

];
export interface ICreateAccountTransaction {
  type: string;
  mode: string;
  amount: number | string;
  payment_date_time: string | Date
  remark: string;
}

const formatDateTimeLocal = (dateTime: string | undefined): string => {
  if (!dateTime) return "";
  const date = new Date(dateTime);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  return `${year}-${month}-${day}T${hours}:${minutes}`;
};
const formatDateForDateTimeLocal = (dateString: any) => {
  if (!dateString) return "";

  // Assuming input format is "DD-MM-YYYY HH:mm"
  const [datePart, timePart] = dateString.split(" ");
  const [day, month, year] = datePart.split("-");

  // Reformat to "YYYY-MM-DDTHH:mm"
  return `${year}-${month}-${day}T${timePart}`;
};
const formatRemark = (input: string) =>
  input
    .replace(/<br\s*\/?>/gi, "\n") // Replace <br> or <br/> with \n
    .replace(/<[^>]*>/g, ""); // Remove other HTML tags
export const createAccountTransactionInitialValues = (
  accountTransactionToEdit: IAccountTransaction | undefined
): ICreateAccountTransaction => ({
  type: accountTransactionToEdit?.type || "",
  mode: accountTransactionToEdit?.mode || "",
  amount: accountTransactionToEdit?.amount || " ",
  payment_date_time: accountTransactionToEdit?.payment_date_time
    ? formatDateForDateTimeLocal(accountTransactionToEdit.payment_date_time)
    : "",
  remark: accountTransactionToEdit?.remark
    ? formatRemark(accountTransactionToEdit.remark)
    : "",
});

export const createAccountTransactionValidationSchema = () =>
  Yup.object().shape({
    amount: Yup.number()
      .transform((value, originalValue) =>
        typeof originalValue === "string" && originalValue.trim() === "" ? null : value
      )
      .typeError("Amount must be a valid number") // Prevents non-numeric strings
      .test("not-zero", "Amount cannot be 0", (value) => value !== 0)
      .required("Amount is required"),
    type: Yup.string().required("Payment Type is required"),
    mode: Yup.string().required("Payment By is required"),
    payment_date_time: Yup.string().required("Payment Date & Time is required")

  });

export const createAccountTransaction = async (
  values: ICreateAccountTransaction,
  contact_id: number,
  onHide: () => void,
  setRefreshTransactions: TReactSetState<boolean>
) => {

  console.log("values", values);

  const getUUID = await localStorage.getItem("UUID");
  const convertPaymentDateTimeDate = formatDateTimeSendDataBase(
    new Date(values.payment_date_time)
  );
  const currentDateTime = new Date();
  const formattedDateTime = formatDateTimeSendDataBase(currentDateTime);

  try {
    const requestData = {
      table: "account_transactions",
      data: JSON.stringify({
        a_application_login_id: getUUID,
        contact_masters_id: contact_id,
        amount: values.amount,
        type: values.type,
        mode: values.mode,
        remark: values.remark,
        payment_date_time: convertPaymentDateTimeDate,
        created_date_time: formattedDateTime,
      }),
    };

    const { data } = await axiosInstance.post("commonCreate", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        toast.success(data.ack_msg);
        setRefreshTransactions(true)
        onHide();
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateAccountTransaction = async (
  values: ICreateAccountTransaction,
  onHide: () => void,
  accountTransactionItemId: number,
  setRefreshTransactions: TReactSetState<boolean>
) => {


  console.log("values.remark", values.remark);

  const convertPaymentDateTimeDate = formatDateTimeSendDataBase(
    new Date(values.payment_date_time)
  );

  try {
    const requestData = {
      table: "account_transactions",
      where: `{"id":"${accountTransactionItemId}"}`,
      data: JSON.stringify({
        amount: values.amount,
        type: values.type,
        mode: values.mode,
        remark: values.remark.replace(/\n/g, "<br>"),
        payment_date_time: convertPaymentDateTimeDate,
      }),
    };
    const getUUID = localStorage.getItem("UUID")

    const { data } = await axiosInstance.post("commonUpdate", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        toast.success(data.ack_msg);
        setRefreshTransactions(true)
        onHide();
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
