import { ErrorMessage, Field, Form, Formik } from "formik";
import React, { useEffect } from "react";
import FormikCustomSearchDropdown from "../../../components/FormikCustomSearchDropdown";
import {
  createAccountTransaction,
  createAccountTransactionInitialValues,
  createAccountTransactionValidationSchema,
  ICreateAccountTransaction,
  paymentModeList,
  paymentTypesList,
  updateAccountTransaction,
} from "./CreateAccountTransactionController";
import { IAccountTransaction } from "../list-account-transaction/ListAccounTransactionController";
import { TReactSetState } from "../../../helpers/AppType";
import { BIG_TEXT_LENGTH, MINI_TEXT_LENGTH } from "../../../helpers/AppConstants";
import { openInNewTab } from "../../../common/SharedFunction";
interface IPropsCreateInquiry {
  show: boolean;
  onHide: () => void;
  accountTransactionItem?: IAccountTransaction;
  contact_id: any;
  headerName: string;
  setRefreshTransactions: TReactSetState<boolean>
}
const CreateAccountTransactionView = ({
  show,
  onHide,
  accountTransactionItem,
  contact_id,
  headerName,
  setRefreshTransactions
}: IPropsCreateInquiry) => {
  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);
  const handleSubmit = async (values: ICreateAccountTransaction) => {

    if (accountTransactionItem?.id) {
      updateAccountTransaction(values, onHide, accountTransactionItem.id, setRefreshTransactions);
    } else {
      createAccountTransaction(values, contact_id, onHide, setRefreshTransactions);
    }
  };
  const paymentTypesOptions = paymentTypesList.map((itemType) => ({
    value: Number(itemType.id),
    label: itemType.type_name,
  }));
  const paymentModeOptions = paymentModeList.map((itemMode) => ({
    value: Number(itemMode.id),
    label: itemMode.mode_name,
  }));
  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1">
            <div className="d-flex align-items-center justify-content-end">
                          <span>
                            <p
                              className="landing-page-text text-end"
                              style={{ cursor: "pointer", color: "var(--ig-accent)", float: "right", fontSize: "13px" }}
                              onClick={() => openInNewTab("/videoTutorial", 14)}
                            >
                              Learn More : <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#0000FF"><path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" /></svg>
                            </p>
                          </span>
            
                          <span className="close ms-3 pb-3" onClick={onHide}>
                            &times;
                          </span>
                        </div>
            
            <h2 className="modal-title1 form_header_text">{headerName}</h2>
            <p className="text-center " style={{ color: "var(--ig-border)" }}>
              Please enter your Account Transaction detail.
            </p>
            <Formik
              enableReinitialize
              initialValues={createAccountTransactionInitialValues(
                accountTransactionItem
              )}
              validationSchema={createAccountTransactionValidationSchema()}
              onSubmit={handleSubmit}
            >
              {({ errors, touched, validateForm }) => (
                <Form>
                  <div className="  mt-3    d-flex justify-content-center">
                    <div className="mb-3 py-4  ">
                      <div className="row  mx-0 px-2 gy-3  d-flex justify-content-center">
                        <div className="col-6 col-md-6 ">
                          <div className="form-group">
                            <label htmlFor="type" className="mb-1 form_label">
                              Payment Type <span className="text-danger">*</span>
                            </label>
                            <FormikCustomSearchDropdown
                              name="type"
                              options={paymentTypesOptions}
                              className={`  ${errors.type &&
                                touched.type &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="type"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 col-md-6 ">
                          <div className="form-group">
                            <label htmlFor="mode" className="mb-1 form_label">
                              Payment By <span className="text-danger">*</span>
                            </label>
                            <FormikCustomSearchDropdown
                              name="mode"
                              options={paymentModeOptions}
                              className={`  ${errors.mode &&
                                touched.mode &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="mode"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 col-md-6">
                          <div className="form-group">
                            <label htmlFor="amount" className="pb-2 form_label">
                              Amount <span className="text-danger">*</span>
                            </label>
                            <Field
                              type="text"
                              name="amount"
                              maxlength={MINI_TEXT_LENGTH}
                              className={`form-control font-size-15 rounded-1   ${errors.amount &&
                                touched.amount &&
                                "is-invalid input-box-error"
                                }`}
                              onInput={(e: { target: { value: string } }) => {
                                e.target.value = e.target.value.replace(
                                  /[^0-9.]/g,
                                  ""
                                );
                                if (
                                  (e.target.value.match(/\./g) || []).length > 1
                                ) {
                                  e.target.value = e.target.value.slice(0, -1); // Remove extra dots
                                }
                              }}
                            />
                            <ErrorMessage
                              name="amount"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="payment_date_time"
                              className="pb-2 form_label"
                            >
                              Payment Date & Time <span className="text-danger">*</span>
                            </label>
                            <Field
                              type="datetime-local"
                              name="payment_date_time"
                              className={`form-control font-size-15 rounded-1   ${errors.payment_date_time &&
                                touched.payment_date_time &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="payment_date_time"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 col-md-6">
                          <div className="form-group">
                            <label htmlFor="remark" className="pb-2 form_label">
                              Remark
                            </label>
                            <Field
                              as="textarea"
                              name="remark"
                              maxlength={BIG_TEXT_LENGTH}
                              className={`form-control font-size-15 rounded-1   ${errors.remark &&
                                touched.remark &&
                                "is-invalid input-box-error"
                                }`}
                            />
                            <ErrorMessage
                              name="remark"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>

                        <div className="col-6"></div>
                        <div className="col-12 col-12 pt-4 d-flex justify-content-center">
                          <button className="ig-btn border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label" onClick={onHide}>
                            Close
                          </button>
                          <button type="submit" className="ig-btn btn btn-primary px-4 py-2 ms-2  text-light form_label rounded-1" style={{ backgroundColor: "#f58634" }}>
                            Save Account Transaction
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default CreateAccountTransactionView;
