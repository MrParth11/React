import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useContext,
  useLayoutEffect,
} from "react";
import RightSideProfile from "./Profile";
import RightSearch from "./Search";
import ConfirmationModal from "../../components/model/ConfirmationModal";
import ContactStatistic from "./contact-statistics/ContactStatistic";
import {
  fetchCompanyTeamApi,
  fetchWhatsAppApiWebhook,
  ICompanyTeam,
  IUserList,
} from "../left-side/LeftSideController";
import pdfIcon from "../../assets/images/pdfIcon.png";
import pngIcon from "../../assets/images/pngIcon.png";
import jpgIcon from "../../assets/images/jpgIcon.png";
import docxIcon from "../../assets/images/docxIcon.png";
import Mp4Icon from "../../assets/images/Mp4Icon.png";
import MkvIcon from "../../assets/images/MkvIcon.png";
import MpgIcon from "../../assets/images/MpgIcon.png";
import TxtIcon from "../../assets/images/TxtIcon.png";
import PptxIcon from "../../assets/images/PptxIcon.png";
import PptIcon from "../../assets/images/PptIcon.png";
import CsvIcon from "../../assets/images/CsvIcon.png";
import RarIcon from "../../assets/images/RarIcon.png";
import PsdIcon from "../../assets/images/PsdIcon.png";
import XmlIcon from "../../assets/images/XmlIcon.png";
import zipIcon from "../../assets/images/zipIcon.png";
import svgIcon from "../../assets/images/svgIcon.png";
import excelIcon from "../../assets/images/excelIcon.png";
import mp3Icon from "../../assets/images/music-file.png";
import micIcon from "../../assets/images/micIcon.png";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

import {
  IMessageList,
  TMessage,
  TMessagesByDate,
  createReminder,
  deleteContact,
  deleteMessages,
  fetchCompanyForRightSideViewApi,
  fetchGetByIdUser,
  fetchMessageData,
  insertAttendance,
  insertMessage,
  viewAttendanceStatus,
} from "./RightViewController";
import { axiosInstance } from "../../services/axiosInstance";
import {
  BIG_TEXT_LENGTH,
  DEFAULT_MESSAGE_ERROR_PERMISSION,
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../helpers/AppConstants";
import { toast } from "react-toastify";
import {
  TOnChangeTextArea,
  TOnKeyboardEvent,
  TReactSetState,
} from "../../helpers/AppType";
import SafeHtml from "../../components/SafeHtml";
import CustomEditor from "../../components/CustomEditor";
import ListInquiryView from "./list-inquiry/ListInquiryView";
import ReminderModal from "../../components/model/ReminderModal";
import {
  formatDate,
  formatDateAndTime,
  formatDateTimeSendDataBase,
  formatTimeToAmPm,
  openInNewTab,
} from "../../common/SharedFunction";
import EmailSendView from "./EmailSend/EmailSendView";
import { AppContext } from "../../common/AppContext";
import axios from "axios";
import DashboardView from "../dashboard/DashboardView";
import { IUserInfo } from "../public/otp-verification/OTPVerificationController";
import {
  fetchCompanyApi,
  ICompany,
} from "../left-side/list-company/ListCompanyController";
import PricingTable from "../public/payment-gateway/PricingTable";
import ListAccountTransactionView from "./list-account-transaction/ListAccountTransactionView";
import ListOrderView from "./list-order/ListOrderView";
import DateTimeRangePicker from "../../components/DateTimeRangePicker";
import useCheckUserPermission from "../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE, SHORT_KEY } from "../../helpers/AppEnum";
import ImageViewer from "../../components/ImageViewer";
import AiModelView from "../aimodel/AiModelView";
import useSpeechRecognition from "../voice/Voice";
import CreateConntect from "../../pages/left-side/create-contact/CreateContactView";
import { Link } from "react-router-dom";
import IntroductionVideo from "../../components/IntroductionVideo";

interface IPropRightView {
  openCreateContact: () => void;
  closeCreateContact: () => void;
  showInquiryAllList: () => void;
  showReminder: () => void;
  showMyCompany: () => void;
  showNotes: () => void;
  showFilterContact: () => void;
  showDashboard: () => void;
  showAichat: () => void;
  isDashBoardOpen: boolean;
  closeDashboard: () => void;
  isAiModelopen: boolean;
  closeisAiModel: () => void;
  getData?: IUserList;
  contactsReload: TReactSetState<boolean>;
  userInfo?: IUserInfo;
  setEditorContentToEdit: any;
  editorContentToEdit: any;
  setNoDataFound1: TReactSetState<boolean>;
}
const RightView = ({
  openCreateContact,
  closeCreateContact,
  showInquiryAllList,
  showNotes,
  showReminder,
  showMyCompany,
  showFilterContact,
  showDashboard,
  showAichat,
  isDashBoardOpen,
  closeDashboard,
  isAiModelopen,
  closeisAiModel,
  getData,
  contactsReload,
  userInfo,
  setEditorContentToEdit,
  editorContentToEdit,
  setNoDataFound1,
}: IPropRightView) => {
  const {
    voice,
    startListening,
    stopListening,
    isListening,
    setVoice,
    hasRecognitionSupport,
  } = useSpeechRecognition(0);
  const { isEditContact, showRightSide, setShowRightSide } =
    useContext(AppContext)!;
  const [showCreateNote, setShowCreateNote] = useState(false);
  const dropdownRef = useRef<HTMLButtonElement>(null);

  const dropdownRefRightMsg = useRef<Record<number, HTMLUListElement | null>>(
    {}
  );
  const dropdownRefLeftMsg = useRef<Record<number, HTMLUListElement | null>>(
    {}
  );
  const messageListRef = useRef<HTMLDivElement | null>(null);
  const dropdownCreateOrderRef = useRef<HTMLButtonElement>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [dropdownOpenCreateOrder, setDropdownOpenCreateOrder] = useState(false);
  const [dropdownOpenMsg, setDropdownOpenMsg] = useState<any>(null);
  const [dropdownOpenMsgLeft, setDropdownOpenMsgLeft] = useState<any>(null);
  const [noDataFound, setNoDataFound] = useState(false);
  const prevVoiceRef = useRef("");
  const [isCloseConfirmation, setIsCloseConfirmation] = useState(false);
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [isMoveToMeConfirmation, setIsMoveToMeConfirmation] = useState(false);
  const [isMoveToClientConfirmation, setIsMoveToClientConfirmation] =
    useState(false);

  const [deleteMsgId, setDeleteMsgId] = useState<number>();
  const [isReminderConfirmationStatus, setIsReminderConfirmationStatus] =
    useState(false);
  const [isReminderConfirmationStatus1, setIsReminderConfirmationStatus1] =
    useState<TMessage>();
  const [isReminderConfirmation, setIsReminderConfirmation] = useState(false);
  // console.log("isReminderConfirmation",isReminderConfirmation);

  const [isEmailConfirmation, setIsEmailConfirmation] = useState(false);
  const [showListOrder, setShowListOrder] = useState(false);
  const [reminderForMsgId, setReminderForMsgId] = useState<number>();
  const [moveForMsgId, setMoveForMsgId] = useState<number>();

  const [isClearConfirmation, setIsClearConfirmation] = useState(false);
  const [optionConfirmation, setOptionConfirmation] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showListInquiry, setShowListInquiry] = useState(false);
  const [showListAccountTransaction, setShowListAccountTransaction] =
    useState(false);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewInfo, setViewInfo] = useState(false);
  const [messageList, setMessageList] = useState<TMessagesByDate[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [hasOneData, setHasOneData] = useState<any>();
  const [hasOneData1, setHasOneData1] = useState<any>();
  const [sendMessageTextboxValue, setSendMessageTextboxValue] = useState("");
  const [isToggledButton, setIsToggledButton] = useState(false);
  const [messageSide, setMessageSide] = useState(1);
  const [isLoadedMessage, setIsLoadedMessage] = useState(false);
  const [searchTerm, setSearchTerm] = useState<string>("");

  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(
    null
  );
  const [searchOpen, setSearchOpen] = useState(false);
  const [isShowExtension, setIsShowExtension] = useState("");
  const [isCreateContact1, setIsCreateContact1] = useState(true);
  const [loginById, setLoginById] = useState<any>();
  const [companyId, setCompanyId] = useState<any>();
  const [showRenewPlan, setShowRenewPlan] = useState(false);
  const [renewPlanItem, setRenewPlanItem] = useState<ICompany>();
  const [checkedReminder, setCheckedReminder] = useState(false);
  const [checkedAttachment, setCheckedAttachment] = useState(false);
  const [selectDate, setSelectDate] = useState<Date[]>([]);
  const [startDateForUl, setStartDateForUl] = useState<string>("2024-12-02");
  const [isOrderShowNum, setIsOrderShowNum] = useState(0);
  const [getCompanyId, setGetCompanyId] = useState(0);
  const [imageViewData, setImageViewData] = useState<TMessage>();
  const [isWhatsAppAuto, setIsWhatsAppAuto] = useState(false);
  const [createContactTrigger, setCreateContactTrigger] = useState(0);
  const [editorContent, setEditorContent] = useState<string>("");
  const [editorContentToEditId, setEditorContentToEditId] = useState(0);
  // const [checkAttendance, setCheckAttendance] = useState(1);
  const [savedAttendance, setSavedAttendance] = useState(2);
  const [sortkeycreateQuotation, setSortkeyCreateQuotation] = useState(0);
  const [sortkeycreateOrder, setSortkeyCreateOrder] = useState(0);
  const [sortkeycreateInvoice, setSortkeyCreateInvoice] = useState(0);
  const [sortkeycreatePurchase, setSortkeyCreatePurchase] = useState(0);
  const [companyLists, setCompanyLists] = useState<ICompany[]>([]);
  const [companyJoinOrCreate, setCompanyJoinOrCreate] = useState();
  // const [isSendActive, setIsSendActive] = useState(false);

  const getUUID = localStorage.getItem("UUID");
  const canViewInq = useCheckUserPermission(
    PAGE_ID.INQUIRY,
    PERMISSION_TYPE.VIEW
  );

  const canViewInsight = useCheckUserPermission(
    PAGE_ID.INSIGHT,
    PERMISSION_TYPE.VIEW
  );
  const canViewAiModel = useCheckUserPermission(
    PAGE_ID.AI_ASSISTANT,
    PERMISSION_TYPE.VIEW
  );

  const canViewFilterContact = useCheckUserPermission(
    PAGE_ID.CONTACT,
    PERMISSION_TYPE.VIEW
  );

  const canViewReminder = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.VIEW
  );
  const canAddContact = useCheckUserPermission(
    PAGE_ID.CONTACT,
    PERMISSION_TYPE.ADD
  );

  const canAdd = useCheckUserPermission(
    PAGE_ID.CONTACT_MESSAGE_HISTORY,
    PERMISSION_TYPE.ADD
  );
  const canEdit = useCheckUserPermission(
    PAGE_ID.CONTACT_MESSAGE_HISTORY,
    PERMISSION_TYPE.EDIT
  );
  const canDelete = useCheckUserPermission(
    PAGE_ID.CONTACT_MESSAGE_HISTORY,
    PERMISSION_TYPE.DELETE
  );
  const canAddReminder = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.ADD
  );
  const canApproveReminder = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.APPROVE
  );
  const canViewQuo = useCheckUserPermission(
    PAGE_ID.QUOTATION,
    PERMISSION_TYPE.VIEW
  );
  const canViewOrder = useCheckUserPermission(
    PAGE_ID.ORDER,
    PERMISSION_TYPE.VIEW
  );
  const canViewInv = useCheckUserPermission(
    PAGE_ID.INVOICE,
    PERMISSION_TYPE.VIEW
  );
  const canViewPurchase = useCheckUserPermission(
    PAGE_ID.PURCHASE,
    PERMISSION_TYPE.VIEW
  );

  const canAddMail = useCheckUserPermission(PAGE_ID.EMAIL, PERMISSION_TYPE.ADD);
  const canViewAccHis = useCheckUserPermission(
    PAGE_ID.ACCOUNT_HISTORY,
    PERMISSION_TYPE.VIEW
  );

  const canAddAttendance = useCheckUserPermission(
    PAGE_ID.ATTENDANCE,
    PERMISSION_TYPE.ADD
  );

  const canViewVoiceControl = useCheckUserPermission(
    PAGE_ID.VOICE_CONTROL,
    PERMISSION_TYPE.VIEW
  );

  // const canViewAttendance = useCheckUserPermission(
  //   PAGE_ID.ATTENDANCE,
  //   PERMISSION_TYPE.VIEW
  // );

  useEffect(() => {
    fetchCompanyApi(
      setCompanyLists,
      "",
      setNoDataFound,
      setCompanyJoinOrCreate
    );
  }, []);

  function openSearch() {
    setSearchOpen(!searchOpen);
  }

  function openChatAbout() {
    setShowProfile(true);
  }
  const contact_statistics = () => {
    setIsModalOpen(true);
  };

  const handleClick = () => {
    setShowCreateNote(true);
  };

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const toggleDropdownCreate = () => {
    setDropdownOpenCreateOrder(!dropdownOpenCreateOrder);
  };
  const toggleDropdownMsg = (id: number) => {
    setHasOneData(id);
    setDropdownOpenMsg((prev: any) => !prev);
  };

  const toggleReminder = (id: number) => {
    if (canAddReminder) {
      setReminderForMsgId(id);
      setIsReminderConfirmation(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const toggleMoveToMe = (id: number) => {
    setMoveForMsgId(id);
    setIsMoveToMeConfirmation(true);
  };
  const toggleMoveToClient = (id: number) => {
    setMoveForMsgId(id);
    setIsMoveToClientConfirmation(true);
  };
  const toggleDropdownMsgLeft = (id: number) => {
    setHasOneData1(id);
    setDropdownOpenMsgLeft((prev: any) => (prev === id ? null : id));
  };

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        dropdownCreateOrderRef.current &&
        !dropdownCreateOrderRef.current.contains(event.target as Node)
      ) {
        setDropdownOpenCreateOrder(false);
      }
    };

    document.addEventListener("click", handleOutsideClick);

    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, [dropdownCreateOrderRef]);
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener("click", handleOutsideClick);

    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, [dropdownRef]);

  useEffect(() => {
    if (getData?.id) {
      setSearchOpen(false);
      setCheckedReminder(false);
      setSearchTerm("");
      setCheckedAttachment(false);
      setSelectDate([]);
    } else {
      return undefined;
    }
  }, [getData?.id]);
  useEffect(() => {
    if (dropdownOpenMsgLeft !== null || dropdownOpenMsg !== null) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [dropdownOpenMsgLeft, dropdownOpenMsg]);
  useEffect(() => {
    viewAttendanceStatus(setSavedAttendance, setLoading);
  }, []);

  const allMessages = messageList.flatMap((item) => item.messages);

  const lastThreeMessages = allMessages.slice(-3);

  const filteredItemIds = lastThreeMessages.map((item) => item.id);

  const getFileExtension = (fileName: string): string => {
    return fileName.split(".").pop()?.toLowerCase() || "";
  };

  const getIconForExtension = (extension: string): string => {
    switch (extension) {
      case "pdf":
        return pdfIcon;
      case "png":
        return pngIcon;
      case "svg":
        return svgIcon;
      case "xlsx":
      case "xls":
        return excelIcon;
      case "jpg":
      case "jpeg":
        return jpgIcon;
      case "docx":
      case "doc":
        return docxIcon;
      case "mp4":
        return Mp4Icon;
      case "mkv":
        return MkvIcon;
      case "mpeg":
      case "mpg":
        return MpgIcon;
      case "txt":
        return TxtIcon;
      case "pptx":
        return PptxIcon;
      case "ppt":
        return PptIcon;
      case "csv":
        return CsvIcon;
      case "rar":
        return RarIcon;
      case "psd":
        return PsdIcon;
      case "xml":
        return XmlIcon;
      case "zip":
        return zipIcon;
      case "mp3":
      case "m4a":
        return mp3Icon;
      case "ogg":
      case "wav":
        return micIcon;
      default:
        return "";
    }
  };
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setSearchTerm(value);
    if (value.length >= 3 || value === "") {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
      setSearchTimeout(
        setTimeout(() => {
          fetchMessageData(
            setNoDataFound,
            value.trim(),
            setLoading,
            setMessageList,
            setHasMore,
            currentPage,
            setNoDataFound1,
            getData?.id,
            checkedReminder,
            checkedAttachment,
            selectDate,
            startDateForUl,
            setGetCompanyId
          );
          setCurrentPage(0);
        }, 1000)
      );
    }
  };

  const handleSearchClear = () => {
    setSearchTerm("");
    setSelectDate([]);
    setCheckedAttachment(false);
    setCheckedReminder(false);
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }
    setSearchOpen(!searchOpen);
    setSearchTimeout(
      setTimeout(() => {
        fetchMessageData(
          setNoDataFound,
          "",
          setLoading,
          setMessageList,
          setHasMore,
          currentPage,
          setNoDataFound1,
          getData?.id,
          checkedReminder,
          checkedAttachment,
          selectDate,
          startDateForUl,
          setGetCompanyId
        );
        setCurrentPage(0);
      }, 1000)
    );
  };

  const handelChangeDeleteRight = (id: number) => {
    if (canDelete) {
      setIsDeleteConfirmation(true);
      setDeleteMsgId(id);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  useEffect(() => {
    if (getData?.id) {
      setIsCreateContact1(true);
    } else {
      setIsCreateContact1(false);
    }
  }, [getData?.id]);
  const handleDownload = async (item: any) => {
    try {
      const fileUrl = `${item.media_url}`;
      const response = await axios.get(fileUrl, { responseType: "blob" });
      const fileName = item.media_name ? item.media_name : item.media_url;
      const blob = new Blob([response.data], {
        type: response.headers["content-type"],
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading the file", error);
    }
  };

  const handleChangeImgViewer = (item: TMessage) => {
    setImageViewData(item);
    setViewerOpen(true);
  };
  const handleViewinfo = () => {
    setViewInfo(true);
  };

  const observer = useRef<IntersectionObserver | null>(null);

  const lastElementRef = useCallback(
    (node: Element | null) => {
      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
          setCurrentPage((prevPage) => prevPage + 1);
        }
      });

      if (node) observer.current.observe(node);
    },
    [hasMore, loading]
  );
  const [prevScrollHeight, setPrevScrollHeight] = useState<number>(0); // To store scroll height before loading

  useEffect(() => {
    if (getData?.id || isEmailConfirmation === true) {
      fetchMessageData(
        setNoDataFound,
        searchTerm,
        setLoading,
        setMessageList,
        setHasMore,
        currentPage,
        setNoDataFound1,
        getData?.id,
        checkedReminder,
        checkedAttachment,
        selectDate,
        "-1",
        setGetCompanyId
      );
      // if (messageListRef.current && prevScrollHeight > 0) {
      //   messageListRef.current.scrollTop =
      //     messageListRef.current.scrollHeight - prevScrollHeight;
      // }
    }
    fetchGetByIdUser(setLoginById);
    fetchCompanyForRightSideViewApi(setCompanyId);
  }, [
    currentPage,
    getData?.id,
    isDeleteConfirmation,
    isLoadedMessage,
    isReminderConfirmationStatus,
    isReminderConfirmation,
    isEmailConfirmation,
    checkedReminder,
    checkedAttachment,
    selectDate,
    searchTerm,
  ]);
  const handleChangeEdit = (itemsDis: TMessage) => {
    if (canEdit) {
      if (getData?.id) {
        setEditorContentToEditId(itemsDis.id);
        setEditorContentToEdit(itemsDis?.description);
        setDropdownOpenMsgLeft(null);
        setDropdownOpenMsg(null);
      } else {
        setEditorContentToEdit("");
      }
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelChangeRenewPlan = (item: ICompany) => {
    setShowRenewPlan(true);
    setRenewPlanItem(item);
  };
  const openInTab = (path: string) => {
    const baseURL = window.location.origin;
    window.open(`${baseURL}${path}`, "_blank");
  };

  const handelSearchDateChange = (selectedDates: Date[] | undefined) => {
    console.log("handelSearchChange", selectedDates);

    setSelectDate(selectedDates || []);
    fetchMessageData(
      setNoDataFound,
      searchTerm,
      setLoading,
      setMessageList,
      setHasMore,
      currentPage,
      setNoDataFound1,
      getData?.id,
      checkedReminder,
      checkedAttachment,
      selectedDates,
      startDateForUl,
      setGetCompanyId
    );
  };
  const handleLoadMore = () => {
    console.log("endDateForLl", startDateForUl);

    const currentEndDate = new Date();
    const newStartDate = currentEndDate.toISOString().split("T")[0];
    console.log("newEndDate", newStartDate);
    const lastDate = messageList[0].date;
    const lastDateObj = new Date(lastDate);
    lastDateObj.setDate(lastDateObj.getDate() - 1);
    const nextDate = lastDateObj.toISOString().split("T")[0];

    console.log("nextDate", nextDate);
    setStartDateForUl(nextDate);
    fetchMessageData(
      setNoDataFound,
      searchTerm,
      setLoading,
      setMessageList,
      setHasMore,
      currentPage,
      setNoDataFound1,
      getData?.id,
      checkedReminder,
      checkedAttachment,
      selectDate,
      nextDate,
      setGetCompanyId
    );
  };
  const [isAtBottom, setIsAtBottom] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const handleScroll = () => {
    if (!containerRef.current) return;
    const bottom =
      containerRef.current.scrollHeight ===
      containerRef.current.scrollTop + containerRef.current.clientHeight;
    setIsAtBottom(bottom);
  };
  const handelChangeShowModelQuotation = () => {
    if (canViewQuo) {
      setIsOrderShowNum(1);
      setDropdownOpenCreateOrder(false);

      setShowListOrder(true);
    } else {
      setDropdownOpenCreateOrder(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelChangeShowModelOrder = () => {
    if (canViewOrder) {
      setIsOrderShowNum(2);
      setShowListOrder(true);
      setDropdownOpenCreateOrder(false);
    } else {
      setDropdownOpenCreateOrder(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelChangeShowModelInvoice = () => {
    if (canViewInv) {
      setIsOrderShowNum(3);
      setShowListOrder(true);
      setDropdownOpenCreateOrder(false);
    } else {
      setDropdownOpenCreateOrder(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handelChangeShowModelPurchase = () => {
    if (canViewPurchase) {
      setIsOrderShowNum(4);
      setShowListOrder(true);
      setDropdownOpenCreateOrder(false);
    } else {
      setDropdownOpenCreateOrder(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleChangeMoveMsg = async (msgSide: number) => {
    const requestData = {
      table: "contact_message_histories",
      where: `{"id":"${moveForMsgId}" }`,
      data: `{"message_side":"${msgSide}"}`,
    };
    try {
      const { data } = await axiosInstance.post("commonUpdate", requestData, {
        headers: {
          "x-tenant-id": getUUID,
        },
      });
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          if (msgSide === 1) {
            setIsMoveToMeConfirmation(false);
          } else {
            setIsMoveToClientConfirmation(false);
          }
          fetchMessageData(
            setNoDataFound,
            searchTerm,
            setLoading,
            setMessageList,
            setHasMore,
            currentPage,
            setNoDataFound1,
            getData?.id,
            checkedReminder,
            checkedAttachment,
            selectDate,
            "-1",
            setGetCompanyId
          );
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };

  // function openModelClearMsg() {
  //   console.log("getCompanyId", getCompanyId);
  //   if (getCompanyId === Number(getUUID)) {
  //     setIsClearConfirmation(true);
  //   } else {
  //     setIsClearConfirmation(false);

  //     toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
  //   }
  // }

  function openMailMode() {
    if (canAddMail) {
      setIsEmailConfirmation(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }

  const handleAttendance = async () => {
    if (canAddAttendance) {
      setLoading(true);
      setTimeout(async () => {
        const nextStatus =
          savedAttendance === 1 ? 2 : savedAttendance === 0 ? 1 : 1;
        await insertAttendance(nextStatus); // check in/out db ma insert thay
        // await setCheckAttendance(nextStatus);
        await setSavedAttendance(nextStatus); // db mathi last entry lai ne aave che
        setLoading(false);
      }, 500);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.ACCOUNT_HISTORY
      ) {
        e.preventDefault();
        setShowListAccountTransaction(true);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.QUOTATION_LIST
      ) {
        e.preventDefault();
        setIsOrderShowNum(1);
        setSortkeyCreateQuotation((prev) => prev + 1);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.SALES_ORDER_LIST
      ) {
        e.preventDefault();
        setIsOrderShowNum(2);
        setSortkeyCreateOrder((prev) => prev + 1);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.SALES_INVOICE_LIST
      ) {
        e.preventDefault();
        setIsOrderShowNum(3);
        setSortkeyCreateInvoice((prev) => prev + 1);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.SALES_PURCHASE_LIST
      ) {
        e.preventDefault();
        setIsOrderShowNum(4);
        setSortkeyCreatePurchase((prev) => prev + 1);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.MAIL
      ) {
        e.preventDefault();
        setIsEmailConfirmation(true);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.MY_INVOICE_LIST
      ) {
        e.preventDefault();
        setShowListInquiry(true);
      } else if (
        e.ctrlKey &&
        e.shiftKey &&
        e.key.toLowerCase() === SHORT_KEY.MY_TEAM
      ) {
        e.preventDefault();
        showMyCompany();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useEffect(() => {
    if (sortkeycreateQuotation > 1) {
      handelChangeShowModelQuotation();
    }
  }, [sortkeycreateQuotation]);
  useEffect(() => {
    if (sortkeycreateOrder > 1) {
      handelChangeShowModelOrder();
    }
  }, [sortkeycreateOrder]);
  useEffect(() => {
    if (sortkeycreateInvoice > 1) {
      handelChangeShowModelInvoice();
    }
  }, [sortkeycreateInvoice]);
  useEffect(() => {
    if (sortkeycreatePurchase > 1) {
      handelChangeShowModelPurchase();
    }
  }, [sortkeycreatePurchase]);
  useEffect(() => {
    if (!voice) return;
    const lowerVoice = voice.toLowerCase();
    if (lowerVoice.includes("purchase")) {
      handelChangeShowModelPurchase();
    }
    if (lowerVoice.includes("create contact")) {
      openCreateContact();
    }
    if (
      lowerVoice.includes("reminder") ||
      lowerVoice.includes("open reminder") ||
      lowerVoice.includes("create reminder")
    ) {
      showReminder();
    }
    if (
      lowerVoice.includes("open view insight") ||
      lowerVoice.includes("open view inside") ||
      lowerVoice.includes("open view dashboard")
    ) {
      showDashboard();
    }
    if (
      lowerVoice.includes("open my team") ||
      lowerVoice.includes("open my company")
    ) {
      showMyCompany();
    }
    if (
      lowerVoice.includes("open inquiry list") ||
      lowerVoice.includes("open enquiry list")
    ) {
      showInquiryAllList();
    }
    if (
      lowerVoice.includes("open personal notes") ||
      lowerVoice.includes("open personal note")
    ) {
      showNotes();
    }

    if (lowerVoice.includes("refresh")) {
      window.location.reload();
    }
    if (lowerVoice.includes("close")) {
      closeCreateContact();
    }

    setVoice("");
  }, [voice]);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messageList]);

  // Add/fix all missing handler functions before the return statement:
  const handleClickOutside = (event: MouseEvent) => {
    const clickedOutsideLeft = Object.values(dropdownRefLeftMsg.current).every(
      (ref) => ref && !ref.contains(event.target as Node)
    );
    const clickedOutsideRight = Object.values(
      dropdownRefRightMsg.current
    ).every((ref) => ref && !ref.contains(event.target as Node));

    if (clickedOutsideLeft) {
      setDropdownOpenMsgLeft(null);
    }

    if (clickedOutsideRight) {
      setDropdownOpenMsg(null);
    }
  };

  const handleChangeStatusOfReminderLeft = (messageData: TMessage) => {
    if (canApproveReminder) {
      setIsReminderConfirmationStatus(true);
      setIsReminderConfirmationStatus1(messageData);
      setDropdownOpenMsgLeft(null);
      setDropdownOpenMsg(null);
    } else {
      setIsReminderConfirmationStatus(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleChangeStatusOfReminder1 = (messageData: TMessage) => {
    if (canApproveReminder) {
      setIsReminderConfirmationStatus(true);
      setIsReminderConfirmationStatus1(messageData);
      setDropdownOpenMsgLeft(null);
      setDropdownOpenMsg(null);
    } else {
      setIsReminderConfirmationStatus(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  // Define all missing handler functions if not already present:
  const handleEditorChange = (fieldName: string, html: string) => {
    if (getData?.id) {
      setEditorContent("");
    } else {
      setEditorContent(html);
    }
  };

  const handleSend = async (html: string) => {
    if (getData?.id) {
      setEditorContentToEdit("");
      setEditorContentToEditId(0);
    }
    const getUserName = localStorage.getItem("USERNAME");
    if (editorContentToEditId) {
      setIsLoadedMessage(false);
      if (html.trim()) {
        const requestData = {
          table: "contact_message_histories",
          where: `{"id":"${editorContentToEditId}"}`,
          data: JSON.stringify({
            description: html,
          }),
        };
        try {
          const data = await axiosInstance.post("commonUpdate", requestData, {
            headers: {
              "x-tenant-id": getUUID,
            },
          });
          if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
            setIsLoadedMessage(true);
            setEditorContentToEdit("");
            setEditorContentToEditId(0);
          } else {
            return false;
          }
        } catch (error: any) {
          toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } else {
      setIsLoadedMessage(false);
      if (html.trim()) {
        const getUUID = await localStorage.getItem("UUID");
        const date = new Date();
        const formattedDateTime = `${date.getFullYear()}-${String(
          date.getMonth() + 1
        ).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(
          date.getHours()
        ).padStart(2, "0")}:${String(date.getMinutes()).padStart(
          2,
          "0"
        )}:${String(date.getSeconds()).padStart(2, "0")}`;
        const requestData = {
          table: "contact_message_histories",
          data: JSON.stringify({
            message_side: messageSide,
            a_application_login_id: Number(getUUID),
            description: html, // Include the HTML content here
            contact_masters_id: getData?.id,
            application_login_name: getUserName,
            message_type_id: 0,
            entry_flag: isWhatsAppAuto ? 1 : 0,
          }),
          ...(isWhatsAppAuto ? { request_flag: "msg" } : {}),
        };
        try {
          const data = await axiosInstance.post("commonCreate", requestData, {
            headers: {
              "x-tenant-id": getUUID,
            },
          });
          if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
            setIsLoadedMessage(true);
          } else {
            return false;
          }
        } catch (error: any) {
          toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    }
  };

  const handleChangeToggleButton = () => {
    setIsToggledButton(!isToggledButton);
    setMessageSide(isToggledButton ? 1 : 2);
  };

  const handleWhatsAppToggle = (checked: boolean) => {
    setIsWhatsAppAuto(checked);
  };

  const handleRefreshMessages = async () => {
    try {
      await fetchWhatsAppApiWebhook(setLoading);
      if (getData?.id) {
        await fetchMessageData(
          setNoDataFound,
          "",
          setLoading,
          setMessageList,
          setHasMore,
          0,
          setNoDataFound1,
          getData?.id,
          checkedReminder,
          checkedAttachment,
          selectDate,
          "-1",
          setGetCompanyId
        );
      }
    } catch (error) {
      console.error("Error refreshing contacts:", error);
    }
  };

  const handleClearMessages = async () => {
    setIsLoadedMessage(false);
    if (await deleteMessages(getData?.id)) {
      setIsLoadedMessage(true);
    }
    setIsClearConfirmation(false);
  };

  const handleDeleteContact = async () => {
    contactsReload(false);
    if (await deleteContact(getData?.id)) {
      setShowRightSide(false);
      setIsCloseConfirmation(false);
      contactsReload(true);
      setShowProfile(false);
    }
  };

  const handleDeleteMessage = async () => {
    const requestData = {
      table: "contact_message_histories",
      where: `{"id":"${deleteMsgId}"}`,
      data: `{"isDelete":"1"}`,
    };
    const getUUID = localStorage.getItem("UUID");
    try {
      const { data } = await axiosInstance.post("commonUpdate", requestData, {
        headers: {
          "x-tenant-id": getUUID,
        },
      });
      if (data.code === 200) {
        if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          setIsDeleteConfirmation(false);
        } else {
          toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };

  const handleChangeStatusOfReminder = handleChangeStatusOfReminder1;

  const handleReminder = async (data: { dateTime: string; remark: string; status: string; selectedCategory: any; }) => {
    if (
      data.dateTime.trim() &&
      data.remark.trim() &&
      data.selectedCategory !== null &&
      data.selectedCategory !== false
    ) {
      createReminder(
        data,
        getData?.id,
        reminderForMsgId,
        setIsReminderConfirmation
      );
    } else {
      toast.error("Please enter Date and Time, Remark, and Select Team Member");
      setIsReminderConfirmation(true);
    }
  };

  return (
    <>
      <div className="Right-Container" style={{ flex: "70%", display: "flex" ,background: " var(--ig-accent) " }}>
        {isDashBoardOpen ? (
          <DashboardView
            isDashBoardOpen={isDashBoardOpen}
            closeDashboard={closeDashboard}
            companyInfo={companyLists}
            contactData={getData}
          />
        ) : (
          <>
            {isAiModelopen ? (
              <AiModelView
                isAiModelopen={isAiModelopen}
                closeisAiModel={closeisAiModel}
              />
            ) : isCreateContact1 && showRightSide ? (
              <>
                <div
                  className="rightSide"
                  style={{ display: "flex" }}
                  id="rightSide"
                >
                  <div className="header">
                    <div
                      className="imgText"
                      role="button"
                      onClick={openChatAbout}
                    >
                      <div
                        className="imgBox"
                        style={{ backgroundColor: "#CFCFCF" }}
                      >
                        <div
                          className="text-uppercase "
                          style={{ paddingTop: "12px" }}
                        >
                          {getData &&
                            (getData?.person_name?.[0] || "") +
                              (getData?.person_name?.[1] || "")}
                        </div>
                      </div>

                      <h4
                        title={getData?.person_name}
                        aria-label={getData?.person_name}
                      >
                        {getData?.person_name}
                        <br />
                        <span className="thanks">
                          {getData?.mobile_number}
                          {getData?.mobile_number ? "," : ""}
                        </span>
                        <span className="thanks">
                          {getData?.email_id}
                          {getData?.email_id ? "," : ""}
                        </span>
                        <span className="thanks">
                          {getData?.country_name}
                          {getData?.country_name ? "," : ""}
                        </span>
                        <span className="thanks">
                          {getData?.state_name}
                          {getData?.state_name ? "," : ""}
                        </span>
                        <span className="thanks">{getData?.city_name}</span>
                      </h4>
                    </div>
                    <div className="d-flex">
                      <button
                        className="icons "
                        onClick={toggleDropdownCreate}
                        ref={dropdownCreateOrderRef}
                      >
                        <span title="Order List">
                          <svg
                            viewBox="0 0 1024 1024"
                            version="1.1"
                            width="24px"
                            height="24px"
                            fill="currentColor"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path d="M619.085 285.768H400.596c-22.056 0-40-17.944-40-40v-81.995c0-22.056 17.944-40 40-40h218.488c22.056 0 40 17.944 40 40v81.995c0.001 22.056-17.944 40-39.999 40z m-198.489-60h178.488v-41.995H420.596v41.995z" />
                            <path d="M773.485 900.228h-522.97c-38.599 0-70-31.401-70-70V257.267c0-38.598 31.401-70 70-70h41.486c16.568 0 30 13.431 30 30 0 16.568-13.432 30-30 30h-41.486c-5.514 0-10 4.486-10 10v572.961c0 5.514 4.486 10 10 10h522.97c5.514 0 10-4.486 10-10V257.267c0-5.514-4.486-10-10-10h-45.806c-16.568 0-30-13.432-30-30 0-16.569 13.432-30 30-30h45.806c38.598 0 70 31.402 70 70v572.961c0 38.598-31.402 70-70 70z" />
                            <path d="M660.515 442.511h-297.03c-16.568 0-30-13.432-30-30s13.432-30 30-30h297.03c16.568 0 30 13.432 30 30s-13.431 30-30 30zM563.485 592.031h-200c-16.568 0-30-13.432-30-30s13.432-30 30-30h200c16.568 0 30 13.432 30 30s-13.432 30-30 30zM563.485 741.552h-200c-16.568 0-30-13.432-30-30s13.432-30 30-30h200c16.568 0 30 13.432 30 30s-13.432 30-30 30z" />
                          </svg>
                        </span>
                        <div className="dropdown-icon">
                          <ul
                            className={`drop-order ${
                              dropdownOpenCreateOrder ? "isVisible" : "isHidden"
                            }`}
                          >
                            <li
                              className="listItem"
                              role="button"
                              onClick={handelChangeShowModelQuotation}
                            >
                              Quotation
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              onClick={handelChangeShowModelOrder}
                            >
                              Sales Order
                            </li>

                            <li
                              className="listItem"
                              role="button"
                              data-bs-toggle="modal"
                              data-bs-target="#clear-modal"
                              onClick={handelChangeShowModelInvoice}
                            >
                              Sales Invoice
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              data-bs-toggle="modal"
                              data-bs-target="#clear-modal"
                              onClick={handelChangeShowModelPurchase}
                            >
                              Purchase Invoice
                            </li>
                          </ul>
                        </div>
                      </button>
                      <button className="icons mx-2" onClick={openMailMode}>
                        <span title="Send Mail">
                          <svg
                            height="24px"
                            viewBox="0 -960 960 960"
                            width="24px"
                            fill="currentColor"
                          >
                            <path d="M160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v480q0 33-23.5 56.5T800-160H160Zm320-280L160-640v400h640v-400L480-440Zm0-80 320-200H160l320 200ZM160-640v-80 480-400Z" />
                          </svg>
                        </span>
                      </button>
                      <button
                        className="icons"
                        onClick={() =>
                          canViewInq
                            ? setShowListInquiry(true)
                            : toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)
                        }
                      >
                        <span title="Your Inquiry List">
                          <svg
                            height="26px"
                            viewBox="0 -960 960 960"
                            width="26px"
                            fill="currentColor"
                          >
                            <path d="M640-400q-50 0-85-35t-35-85q0-50 35-85t85-35q50 0 85 35t35 85q0 50-35 85t-85 35ZM400-160v-76q0-21 10-40t28-30q45-27 95.5-40.5T640-360q56 0 106.5 13.5T842-306q18 11 28 30t10 40v76H400Zm86-80h308q-35-20-74-30t-80-10q-41 0-80 10t-74 30Zm154-240q17 0 28.5-11.5T680-520q0-17-11.5-28.5T640-560q-17 0-28.5 11.5T600-520q0 17 11.5 28.5T640-480Zm0-40Zm0 280ZM120-400v-80h320v80H120Zm0-320v-80h480v80H120Zm324 160H120v-80h360q-14 17-22.5 37T444-560Z" />
                          </svg>
                        </span>
                      </button>
                      <button
                        className="icons"
                        onClick={() =>
                          canViewAccHis
                            ? setShowListAccountTransaction(true)
                            : toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)
                        }
                      >
                        <span title="Your Account Transaction List">
                          <svg
                            height="22px"
                            viewBox="0 -960 960 960"
                            width="22px"
                            fill="currentColor"
                          >
                            <path d="M200-280v-280h80v280h-80Zm240 0v-280h80v280h-80ZM80-120v-80h800v80H80Zm600-160v-280h80v280h-80ZM80-640v-80l400-200 400 200v80H80Zm178-80h444-444Zm0 0h444L480-830 258-720Z" />
                          </svg>
                        </span>
                      </button>
                      <button
                        className="icons pP"
                        onClick={handleRefreshMessages}
                        title="Refresh"
                      >
                        <svg width="28" height="28" viewBox="0 0 50 50">
                          <path
                            fill="currentColor"
                            d="M25 38c-7.2 0-13-5.8-13-13 0-3.2 1.2-6.2 3.3-8.6l1.5 1.3C15 19.7 14 22.3 14 25c0 6.1 4.9 11 11 11 1.6 0 3.1-.3 4.6-1l.8 1.8c-1.7.8-3.5 1.2-5.4 1.2z"
                          />
                          <path
                            fill="currentColor"
                            d="M34.7 33.7l-1.5-1.3c1.8-2 2.8-4.6 2.8-7.3 0-6.1-4.9-11-11-11-1.6 0-3.1.3-4.6 1l-.8-1.8c1.7-.8 3.5-1.2 5.4-1.2 7.2 0 13 5.8 13 13 0 3.1-1.2 6.2-3.3 8.6z"
                          />
                          <path fill="currentColor" d="M18 24h-2v-6h-6v-2h8z" />
                          <path fill="currentColor" d="M40 34h-8v-8h2v6h6z" />
                        </svg>
                      </button>
                      <div className="chat-side">
                        <button
                          className="icons pP"
                          onClick={openSearch}
                          title="Search"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            width="24"
                            height="24"
                            className=""
                          >
                            <path
                              fill="currentColor"
                              d="M15.9 14.3H15l-.3-.3c1-1.1 1.6-2.7 1.6-4.3 0-3.7-3-6.7-6.7-6.7S3 6 3 9.7s3 6.7 6.7 6.7c1.6 0 3.2-.6 4.3-1.6l.3.3v.8l5.1 5.1 1.5-1.5-5-5.2zm-6.2 0c-2.6 0-4.6-2.1-4.6-4.6s2.1-4.6 4.6-4.6 4.6 2.1 4.6 4.6-2 4.6-4.6 4.6z"
                            ></path>
                          </svg>
                        </button>

                        <div className="dropdown-icon">
                          <button
                            className="pressed icons pP"
                            id="dropDown"
                            onClick={toggleDropdown}
                            ref={dropdownRef}
                          >
                            <svg
                              viewBox="0 0 24 24"
                              width="24"
                              height="24"
                              className=""
                            >
                              <path
                                fill="currentColor"
                                d="M12 7a2 2 0 1 0-.001-4.001A2 2 0 0 0 12 7zm0 2a2 2 0 1 0-.001 3.999A2 2 0 0 0 12 9zm0 6a2 2 0 1 0-.001 3.999A2 2 0 0 0 12 15z"
                              ></path>
                            </svg>
                          </button>
                          <ul
                            className={`drop ${
                              dropdownOpen ? "isVisible" : "isHidden"
                            }`}
                            id="drop"
                          >
                            <li
                              className="listItem"
                              role="button"
                              onClick={openChatAbout}
                            >
                              Contact info
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              onClick={() => setShowRightSide(false)}
                              id="closeChat"
                            >
                              Close chat
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              onClick={contact_statistics}
                              id="closeChat"
                            >
                              Statistics
                            </li>
                            {/* {getCompanyId === Number(getUUID) ? (
                              <li
                                className="listItem"
                                role="button"
                                data-bs-toggle="modal"
                                data-bs-target="#clear-modal"
                                onClick={openModelClearMsg}
                              >
                                Clear messages
                              </li>
                            ) : (
                              <span></span>
                            )} */}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  {searchOpen && (
                    <div className="header-search" style={{ zIndex: "1" }}>
                      <div className="search-bar" style={{ width: "40%" }}>
                        <div className=" d-flex justify-content-between">
                          <button className="search">
                            <span className="">
                              <svg
                                viewBox="0 0 24 24"
                                width="24"
                                height="24"
                                className=""
                              >
                                <path
                                  fill="currentColor"
                                  d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"
                                ></path>
                              </svg>
                            </span>
                          </button>

                          <span className="go-back">
                            <svg
                              viewBox="0 0 24 24"
                              width="24"
                              height="24"
                              className=""
                            >
                              <path
                                fill="currentColor"
                                d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                              ></path>
                            </svg>
                          </span>

                          <input
                            type="text"
                            title="Search or start new chat"
                            aria-label="Search or start new chat"
                            placeholder="Search message"
                            maxLength={BIG_TEXT_LENGTH}
                            value={searchTerm}
                            onChange={handleSearchChange}
                            className="search-message-input"
                          />
                        </div>
                      </div>
                      <div
                        className="d-flex align-items-center justify-content-between "
                        style={{ width: "55%" }}
                      >
                        <div className="">
                          <input
                            className="custom-checkbox"
                            type="checkbox"
                            checked={checkedReminder}
                            onChange={(e) =>
                              setCheckedReminder(e.target.checked)
                            }
                          />
                          <label className="p-2  header-search-front">
                            Reminders
                          </label>
                        </div>
                        <div>
                          <input
                            className="custom-checkbox"
                            type="checkbox"
                            onChange={(e) =>
                              setCheckedAttachment(e.target.checked)
                            }
                          />
                          <label className="p-2 header-search-front">
                            Attachment
                          </label>
                        </div>
                        <div>
                          <DateTimeRangePicker
                            value={selectDate}
                            onChange={handelSearchDateChange}
                            showTime={false}
                            numberOfMonthsShow={1}
                          />
                          <span className="p-1">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              height="22px"
                              viewBox="0 -960 960 960"
                              width="22px"
                              fill="#5f6368"
                            >
                              <path d="M200-80q-33 0-56.5-23.5T120-160v-560q0-33 23.5-56.5T200-800h40v-80h80v80h320v-80h80v80h40q33 0 56.5 23.5T840-720v560q0 33-23.5 56.5T760-80H200Zm0-80h560v-400H200v400Zm0-480h560v-80H200v80Zm0 0v-80 80Zm280 240q-17 0-28.5-11.5T440-440q0-17 11.5-28.5T480-480q17 0 28.5 11.5T520-440q0 17-11.5 28.5T480-400Zm-160 0q-17 0-28.5-11.5T280-440q0-17 11.5-28.5T320-480q17 0 28.5 11.5T360-440q0 17-11.5 28.5T320-400Zm320 0q-17 0-28.5-11.5T600-440q0-17 11.5-28.5T640-480q17 0 28.5 11.5T680-440q0 17-11.5 28.5T640-400ZM480-240q-17 0-28.5-11.5T440-280q0-17 11.5-28.5T480-320q17 0 28.5 11.5T520-280q0 17-11.5 28.5T480-240Zm-160 0q-17 0-28.5-11.5T280-280q0-17 11.5-28.5T320-320q17 0 28.5 11.5T360-280q0 17-11.5 28.5T320-240Zm320 0q-17 0-28.5-11.5T600-280q0-17 11.5-28.5T640-320q17 0 28.5 11.5T680-280q0 17-11.5 28.5T640-240Z" />
                            </svg>
                          </span>
                        </div>

                        <span
                          role="button"
                          className="p-1"
                          onClick={handleSearchClear}
                        >
                          <svg
                            height="24px"
                            viewBox="0 -960 960 960"
                            width="24px"
                            fill="#5f6368"
                          >
                            <path d="M280-80q-83 0-141.5-58.5T80-280q0-83 58.5-141.5T280-480q83 0 141.5 58.5T480-280q0 83-58.5 141.5T280-80Zm544-40L568-376q-12-13-25.5-26.5T516-428q38-24 61-64t23-88q0-75-52.5-127.5T420-760q-75 0-127.5 52.5T240-580q0 6 .5 11.5T242-557q-18 2-39.5 8T164-535q-2-11-3-22t-1-23q0-109 75.5-184.5T420-840q109 0 184.5 75.5T680-580q0 43-13.5 81.5T629-428l251 252-56 56Zm-615-61 71-71 70 71 29-28-71-71 71-71-28-28-71 71-71-71-28 28 71 71-71 71 28 28Z" />
                          </svg>
                        </span>
                      </div>
                    </div>
                  )}
                  <div className="ig-chat-main-area">
                    <div className="ig-chat-scroll-area" ref={containerRef} onScroll={handleScroll}>
                      {hasMore && (
                        <div className="ig-load-more-wrapper">
                          <button
                            onClick={handleLoadMore}
                            className="btn text-light rounded-5 fw_500"
                            style={{ backgroundColor: "var(--ig-primary)", margin: "16px auto", display: "block" }}
                          >
                            Load More
                          </button>
                        </div>
                      )}
                      {loading ? (
                        <div className="d-flex justify-content-center h-50">
                          <div
                            className="spinner-border text-secondary "
                            role="status"
                          ></div>
                        </div>
                      ) : (
                        <>
                          {searchTerm && noDataFound && (
                            <div className="d-flex justify-content-center h-75">
                              <p className="no_found">No data found</p>
                            </div>
                          )}
                          {messageList &&
                            [...messageList].reverse().map((group, index) => (
                              <div>
                                <div className="chat__date-wrapper" key={index}>
                                  <span className="chat__date">
                                    {group.date
                                      ? new Date(group.date)
                                          .toLocaleDateString("en-GB", {
                                            weekday: "long",
                                            year: "numeric",
                                            month: "2-digit",
                                            day: "2-digit",
                                          })
                                          .replace(/\//g, "-")
                                      : ""}
                                  </span>
                                </div>
                                {group &&
                                  group.messages.map((message, index1) => {
                                    const extension = getFileExtension(
                                      message.media_name
                                    );
                                    const icon = getIconForExtension(extension);
                                    return (
                                      <div key={index1}>
                                        <>
                                          {message.message_side === 2 && (
                                            <>
                                              {message.isDelete === 1 ? (
                                                <p
                                                  className="chatMessageDelete frnd-chat-delete"
                                                  style={{ maxWidth: "45%" }}
                                                >
                                                  Deleted By --
                                                  {message.application_login_name}
                                                </p>
                                              ) : (
                                                <>
                                                  <div
                                                    className="chatMessage frnd-chat"
                                                    style={{
                                                      maxWidth: "45%",
                                                      height: "100%",
                                                      flexDirection: "column",
                                                    }}
                                                  >
                                                    <div
                                                      style={{
                                                        display: "flex",
                                                        justifyContent: "end",
                                                        paddingRight: "10px",
                                                      }}
                                                    >
                                                      <span className="chat__msg-filler2">
                                                        {message.is_reminder ? (
                                                          <span
                                                            role="button"
                                                            onClick={() =>
                                                              handleChangeStatusOfReminderLeft(
                                                                message
                                                              )
                                                            }
                                                          >
                                                            <svg
                                                              height="16px"
                                                              viewBox="0 -960 960 960"
                                                              width="16 px"
                                                              className=""
                                                              fill="currentColor"
                                                            >
                                                              <path d="M480-80q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-440q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-800q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-440q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-80Zm0-360Zm112 168 56-56-128-128v-184h-80v216l152 152ZM224-866l56 56-170 170-56-56 170-170Zm512 0 170 170-56 56-170-170 56-56ZM480-160q117 0 198.5-81.5T760-440q0-117-81.5-198.5T480-720q-117 0-198.5 81.5T200-440q0 117 81.5 198.5T480-160Z" />
                                                            </svg>
                                                          </span>
                                                        ) : (
                                                          "  "
                                                        )}
                                                      </span>
                                                      <span className="chat__msg-filler2">
                                                        {message.entry_flag ===
                                                          1 && (
                                                          <span role="button">
                                                            <img
                                                              src={require("../../assets/images/whatsapp.png")}
                                                              width={20}
                                                              alt=""
                                                            />
                                                          </span>
                                                        )}
                                                      </span>
                                                    </div>
                                                    <div
                                                      style={{
                                                        width: "100%",
                                                      }}
                                                    >
                                                      <span>
                                                        <SafeHtml
                                                          htmlContent={
                                                            message.description
                                                          }
                                                        />
                                                      </span>
                                                      {extension === "png" ||
                                                      extension === "jpg" ||
                                                      extension === "jpeg" ? (
                                                        <span
                                                          onClick={() =>
                                                            handleChangeImgViewer(
                                                              message
                                                            )
                                                          }
                                                          style={{
                                                            cursor: "pointer",
                                                          }}
                                                        >
                                                          <span
                                                            className="d-flex justify-content-center"
                                                            style={{
                                                              maxHeight: "30vh",
                                                            }}
                                                          >
                                                            <img
                                                              src={`${message.media_url}`}
                                                              alt="Avatar"
                                                              className="align-text-top w-100"
                                                            />
                                                          </span>
                                                        </span>
                                                      ) : extension === "ogg" ||
                                                        extension === "wav" ||
                                                        extension === "mp3" ? (
                                                        <audio
                                                          controls
                                                          src={`${message.media_url}`}
                                                        ></audio>
                                                      ) : (
                                                        <span
                                                          onClick={() => message}
                                                          style={{
                                                            cursor: "pointer",
                                                            paddingRight: "6px",
                                                          }}
                                                        >
                                                          {icon && (
                                                            <img
                                                              src={icon}
                                                              alt={`${extension} icon`}
                                                              style={{
                                                                width: 30,
                                                                verticalAlign:
                                                                  "text-top",
                                                              }}
                                                            />
                                                          )}
                                                          <span>
                                                            {message.media_name}
                                                          </span>
                                                          {extension && (
                                                            <span className="px-3">
                                                              <svg
                                                                viewBox="0 -960 960 960"
                                                                width="20px"
                                                                fill="#5f6368"
                                                              >
                                                                <path d="M280-280h400v-80H280v80Zm200-120 160-160-56-56-64 62v-166h-80v166l-64-62-56 56 160 160Zm0 320q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z" />
                                                              </svg>
                                                            </span>
                                                          )}
                                                        </span>
                                                      )}
                                                    </div>
                                                    <span className="chat__msg-filler"></span>
                                                    <span className="status1">
                                                      <span>
                                                        {message.created_date_time
                                                          ? formatTimeToAmPm(
                                                              message.created_date_time
                                                            )
                                                          : ""}
                                                      </span>
                                                    </span>

                                                    <span className="status1 ">
                                                      <span>
                                                        <i>
                                                          {message.entry_flag ===
                                                          1 ? (
                                                            <>
                                                              {
                                                                message.contact_name
                                                              }
                                                            </>
                                                          ) : (
                                                            <>
                                                              {
                                                                message.application_login_name
                                                              }
                                                            </>
                                                          )}
                                                        </i>
                                                      </span>
                                                    </span>
                                                    <div>
                                                      <ul
                                                        className={`${
                                                          filteredItemIds.includes(
                                                            message.id
                                                          )
                                                            ? "drop_msg1"
                                                            : "drop_msg_left"
                                                        } ${
                                                          hasOneData1 ===
                                                            message.id &&
                                                          dropdownOpenMsgLeft
                                                            ? "isVisible"
                                                            : "isHidden"
                                                        }`}
                                                        ref={(el) =>
                                                          (dropdownRefLeftMsg.current[
                                                            message.id
                                                          ] = el)
                                                        }
                                                      >
                                                        {message.message_type_id ===
                                                        0 ? (
                                                          <li
                                                            className="drop_listItem"
                                                            role="button"
                                                            onClick={() =>
                                                              handleChangeEdit(
                                                                message
                                                              )
                                                            }
                                                          >
                                                            Edit
                                                          </li>
                                                        ) : (
                                                          <span></span>
                                                        )}
                                                        <li
                                                          className="drop_listItem"
                                                          role="button"
                                                          onClick={() => { setDeleteMsgId(message.id); setIsDeleteConfirmation(true); }}
                                                        >
                                                          Delete
                                                        </li>

                                                        {!message.is_reminder &&
                                                        (message.message_type_id ===
                                                          0 ||
                                                          message.message_type_id ===
                                                            2) ? (
                                                          <li
                                                            className="drop_listItem"
                                                            role="button"
                                                            onClick={() =>
                                                              toggleReminder(
                                                                message.id
                                                              )
                                                            }
                                                          >
                                                            Reminders
                                                          </li>
                                                        ) : (
                                                          <span></span>
                                                        )}

                                                        <li
                                                          className="drop_listItem"
                                                          role="button"
                                                          onClick={() =>
                                                            toggleMoveToMe(
                                                              message.id
                                                            )
                                                          }
                                                        >
                                                          Move to Me
                                                        </li>
                                                      </ul>
                                                    </div>
                                                    <button
                                                      aria-label="Message options"
                                                      className="chat__msg-options"
                                                      onClick={() =>
                                                        toggleDropdownMsgLeft(
                                                          message.id
                                                        )
                                                      }
                                                    >
                                                      <svg
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 19 20"
                                                        width="19"
                                                        height="20"
                                                        className="chat__msg-options-icon"
                                                      >
                                                        <path
                                                          fill="currentColor"
                                                          d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                                        ></path>
                                                      </svg>
                                                    </button>
                                                  </div>
                                                </>
                                              )}
                                            </>
                                          )}
                                          {message.message_side === 1 && (
                                            <>
                                              {message.isDelete === 1 ? (
                                                <p
                                                  className="chatMessageDelete my-chat-delete"
                                                  style={{ maxWidth: "45%" }}
                                                >
                                                  Deleted By --
                                                  {message.application_login_name}
                                                </p>
                                              ) : (
                                                <div
                                                  className="chatMessage my-chat"
                                                  style={{
                                                    maxWidth: "45%",
                                                    height: "100%",
                                                    flexDirection: "column",
                                                  }}
                                                >
                                                  <div
                                                    style={{
                                                      display: "flex",
                                                      justifyContent: "end",
                                                      paddingRight: "10px",
                                                    }}
                                                  >
                                                    <span className="chat__msg-filler2">
                                                      {message.is_reminder &&
                                                      message.message_type_id ===
                                                        0 ? (
                                                        <span
                                                          role="button"
                                                          onClick={() =>
                                                            handleChangeStatusOfReminder1(
                                                              message
                                                            )
                                                          }
                                                        >
                                                          <svg
                                                            height="16px"
                                                            viewBox="0 -960 960 960"
                                                            width="16 px"
                                                            className=""
                                                            fill="currentColor"
                                                          >
                                                            <path d="M480-80q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-440q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-800q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-440q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-80Zm0-360Zm112 168 56-56-128-128v-184h-80v216l152 152ZM224-866l56 56-170 170-56-56 170-170Zm512 0 170 170-56 56-170-170 56-56ZM480-160q117 0 198.5-81.5T760-440q0-117-81.5-198.5T480-720q-117 0-198.5 81.5T200-440q0 117 81.5 198.5T480-160Z" />
                                                          </svg>
                                                        </span>
                                                      ) : (
                                                        "  "
                                                      )}
                                                      {message.entry_flag ===
                                                        1 && (
                                                        <span role="button">
                                                          <img
                                                            src={require("../../assets/images/whatsapp.png")}
                                                            width={20}
                                                            alt=""
                                                          />
                                                        </span>
                                                      )}
                                                      {message.entry_flag ===
                                                        2 && (
                                                        <span role="button">
                                                          <svg
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            height="20px"
                                                            viewBox="0 -960 960 960"
                                                            width="20px"
                                                            fill="#5f6368"
                                                          >
                                                            <path d="M480-440 160-640v400h360v80H160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v280h-80v-200L480-440Zm0-80 320-200H160l320 200ZM760-40l-56-56 63-64H600v-80h167l-64-64 57-56 160 160L760-40ZM160-640v440-240 3-283 80Z" />
                                                          </svg>
                                                        </span>
                                                      )}
                                                    </span>
                                                  </div>
                                                  <span>
                                                    {message.message_type_id ===
                                                    1 ? (
                                                      <></>
                                                    ) : (
                                                      ""
                                                    )}
                                                  </span>

                                                  <span>
                                                    <SafeHtml
                                                      htmlContent={
                                                        message.description
                                                      }
                                                    />
                                                  </span>

                                                  {extension === "png" ||
                                                  extension === "jpg" ||
                                                  extension === "jpeg" ? (
                                                    <span
                                                      onClick={() =>
                                                        handleChangeImgViewer(
                                                          message
                                                        )
                                                      }
                                                      style={{
                                                        cursor: "pointer",
                                                        // paddingRight: "6px",
                                                      }}
                                                    >
                                                      <span
                                                        className="d-flex justify-content-center"
                                                        style={{
                                                          maxHeight: "30vh",
                                                        }}
                                                      >
                                                        <img
                                                          src={`${message.media_url}`}
                                                          alt="Avatar"
                                                          className="align-text-top w-100"
                                                        />
                                                      </span>
                                                    </span>
                                                  ) : extension === "ogg" ||
                                                    extension === "wav" ||
                                                    extension === "mp3" ? (
                                                    <audio
                                                      controls
                                                      src={`${message.media_url}`}
                                                    ></audio>
                                                  ) : (
                                                    <span
                                                      onClick={() =>
                                                        handleDownload(message)
                                                      }
                                                      style={{
                                                        cursor: "pointer",
                                                        paddingRight: "6px",
                                                      }}
                                                    >
                                                      {icon && (
                                                        <img
                                                          src={icon}
                                                          alt={`${extension} icon`}
                                                          style={{
                                                            width: 30,
                                                            verticalAlign:
                                                              "text-top",
                                                          }}
                                                        />
                                                      )}
                                                      <span>
                                                        {message.media_name}
                                                      </span>
                                                      {extension && (
                                                        <span className="px-3">
                                                          <svg
                                                            viewBox="0 -960 960 960"
                                                            width="20px"
                                                            fill="#5f6368"
                                                          >
                                                            <path d="M280-280h400v-80H280v80Zm200-120 160-160-56-56-64 62v-166h-80v166l-64-62-56 56 160 160Zm0 320q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z" />
                                                          </svg>
                                                        </span>
                                                      )}
                                                    </span>
                                                  )}
                                                  <span className="chat__msg-filler"></span>

                                                  <span className="status1">
                                                    <span>
                                                      {message.created_date_time
                                                        ? formatTimeToAmPm(
                                                            message.created_date_time
                                                          )
                                                        : ""}
                                                    </span>
                                                  </span>
                                                  <span className="status1">
                                                    <span className="">
                                                      <i>
                                                        {
                                                          message.application_login_name
                                                        }
                                                      </i>
                                                    </span>
                                                  </span>
                                                  <div>
                                                    <ul
                                                      className={`${
                                                        filteredItemIds.includes(
                                                          message.id
                                                        )
                                                          ? "drop_msg1"
                                                          : "drop_msg"
                                                      } ${
                                                        hasOneData ===
                                                          message.id &&
                                                        dropdownOpenMsg
                                                          ? "isVisible"
                                                          : "isHidden"
                                                      }`}
                                                      ref={(el) =>
                                                        (dropdownRefRightMsg.current[
                                                          message.id
                                                        ] = el)
                                                      }
                                                    >
                                                      {message.message_type_id ===
                                                      0 ? (
                                                        <li
                                                          className="drop_listItem"
                                                          role="button"
                                                          onClick={() =>
                                                            handleChangeEdit(
                                                              message
                                                            )
                                                          }
                                                        >
                                                          Edit
                                                        </li>
                                                      ) : (
                                                        <span></span>
                                                      )}
                                                      <li
                                                        className="drop_listItem"
                                                        role="button"
                                                        onClick={() => { setDeleteMsgId(message.id); setIsDeleteConfirmation(true); }}
                                                      >
                                                        Delete
                                                      </li>

                                                      {!message.is_reminder &&
                                                      (message.message_type_id ===
                                                        0 ||
                                                        message.message_type_id ===
                                                          2) ? (
                                                        <li
                                                          className="drop_listItem"
                                                          role="button"
                                                          onClick={() =>
                                                            toggleReminder(
                                                              message.id
                                                            )
                                                          }
                                                        >
                                                          Reminders
                                                        </li>
                                                      ) : (
                                                        <span></span>
                                                      )}
                                                      <li
                                                        className="drop_listItem"
                                                        role="button"
                                                        onClick={() =>
                                                          toggleMoveToClient(
                                                            message.id
                                                          )
                                                        }
                                                      >
                                                        Move to Client
                                                      </li>
                                                    </ul>
                                                  </div>
                                                  <button
                                                    id="dropDown2"
                                                    className="chat__msg-options"
                                                    onClick={() =>
                                                      toggleDropdownMsg(
                                                        message.id
                                                      )
                                                    }
                                                  >
                                                    <svg
                                                      xmlns="http://www.w3.org/2000/svg"
                                                      viewBox="0 0 19 20"
                                                      width="19"
                                                      height="20"
                                                      className="chat__msg-options-icon"
                                                    >
                                                      <path
                                                        fill="currentColor"
                                                        d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                                      ></path>
                                                    </svg>
                                                  </button>
                                                </div>
                                              )}
                                            </>
                                          )}
                                        </>
                                      </div>
                                    );
                                  })}
                              </div>
                            ))}
                          {/* )
                          )} */}
                          <div ref={messagesEndRef}> </div>
                        </>
                      )}
                    </div>
                    <CustomEditor
                      fieldName="myField"
                      text={editorContent}
                      onChange={handleEditorChange}
                      onSend={handleSend}
                      isToggledButton={isToggledButton}
                      handleChangeToggleButton={handleChangeToggleButton}
                      contactData={getData}
                      setIsLoadedMessage={setIsLoadedMessage}
                      editMsg={editorContentToEdit}
                      isWhatsAppAuto={isWhatsAppAuto}
                      handleWhatsAppToggle={handleWhatsAppToggle}
                      setIsWhatsAppAuto={setIsWhatsAppAuto}
                    />
                  </div>
                </div>
                <RightSideProfile
                  isProfile={showProfile}
                  closeChatAbout={() => setShowProfile(false)}
                  getInfo={getData}
                  deleteContact={() => setIsCloseConfirmation(true)}
                  setIsCreateContact1={setIsCreateContact1}
                  // handelRefreshMessages={handelRefreshMessages}
                />
              </>
            ) : (
              <div className="Intro-Left" id="Intro-Left" style={{backgroundColor: "var(--ig-primary)",color: "var(--ig-text)"}}>
                <div className="intro ">
                  <div className="intro-svg py-3">
                    <img
                      src={require("../../assets/images/smalll_office_log.png")}
                      width={200}
                      alt=""
                    />
                  </div>

                  <div className="pb-4">
                    <div className="text-center">
                      <h4 className="logo-main-text">
                        Let's Move Small To Big
                      </h4>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="text-center">
                      <h4 className="user-info-text">
                        {loginById && "Welcome, " + loginById?.username}
                      </h4>
                    </div>
                    <div className="ICON pt-4 ig-icon-row">
                      <div className="ig-icon-col">
                        <button className="icons" onClick={() => canViewInsight ? showDashboard() : toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)}>
                          <span title="View Insight">
                            {/* SVG here */}
                          </span>
                        </button>
                        <div className="ig-icon-label">View Insight</div>
                      </div>
                      <div className="ig-icon-col">
                        <button className="icons" onClick={() => canViewReminder ? showReminder() : toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)}>
                          <span title="Reminder">
                            {/* SVG here */}
                          </span>
                        </button>
                        <div className="ig-icon-label">Reminders</div>
                      </div>
                      <div className="ig-icon-col">
                        <button className="icons" onClick={() => canViewReminder ? showMyCompany() : toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)}>
                          <span title="My Team">
                            {/* SVG here */}
                          </span>
                        </button>
                        <div className="ig-icon-label">My Team</div>
                      </div>
                      <div className="ig-icon-col">
                        <button className="icons" onClick={() => canViewInq ? showInquiryAllList() : toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)}>
                          <span title="All Inquiry">
                            {/* SVG here */}
                          </span>
                        </button>
                        <div className="ig-icon-label">All Inquiries</div>
                      </div>
                      <div className="ig-icon-col">
                        <button className="icons" onClick={showNotes}>
                          <span title="Personal Notes">
                            {/* SVG here */}
                          </span>
                        </button>
                        <div className="ig-icon-label">Personal Notes</div>
                      </div>
                    </div>
                    <div className="intro1">
                      {companyId &&
                        companyId.map((item: any, index: number) => (
                          <div
                            className="d-flex align-items-center "
                            style={{ marginLeft: "10px" }}
                            key={index}
                          >
                            <h4 className="landing-page-text pe-1"style={{color:"var(--ig-text)"}} >
                              Plan Expiry Date :&nbsp;
                              {item.plan_expiry_date
                                ? formatDate(item.plan_expiry_date)
                                : ""}
                            </h4>
                            <p
                              style={{ backgroundColor: "var(--ig-accent)", color: "white" }}
                            >
                              {item.expiry_msg ? item.expiry_msg : ""}
                            </p>
                            {item.plan_expiry_flag === 1 ? (
                              <button
                                className="btn btn-secondary"
                                onClick={() => handelChangeRenewPlan(item)}
                              >
                                Renew Plan
                              </button>
                            ) : (
                              ""
                            )}
                          </div>
                        ))}
                    </div>

                    <div
                      className="col-8"
                                                  style={{
                        display: "flex",
                        border: "0px solid black",
                        justifyContent: "space-evenly",
                        textAlign: "center",
                        marginLeft: "100px",
                      }}
                    >
                      {/* <h4
                        className="col-5 landing-page-text"
                        style={{ cursor: "pointer", color: "blue" }}
                        onClick={() => openInTab("/cronSetting")} // Pass id 1
                      >
                        <u>Cron Setting</u>&nbsp;| &nbsp;
                      </h4> */}
                      <h4
                        className="col-3 landing-page-text"
                        style={{ cursor: "pointer", color: "blue" }}
                        onClick={() => openInNewTab("/instructionView", 1)} // Pass id 1
                      >
                        <u>VS 1.0.1</u>&nbsp;&nbsp;&nbsp;&nbsp;|
                      </h4>
                      <h4
                        className="col-3 landing-page-text"
                        style={{ cursor: "pointer", color: "blue" }}
                        onClick={() => openInNewTab("/shortcutkey", 1)}
                      >
                        <u>Shortcut</u>&nbsp;&nbsp;&nbsp;&nbsp;|
                      </h4>
                      <h4
                        className="col-4 landing-page-text"
                        style={{ cursor: "pointer", color: "blue" }}
                        onClick={() => openInNewTab("/videoTutorial", 17)}
                      >
                        <u>Video Tutorial</u>
                      </h4>
                    </div>

                    <div
                      className="d-flex justify-content-center"
                      style={{ marginLeft: "10px" }}
                    >
                      <p>
                        <Link
                          to="/PrivacyPolicy"
                          target="_blank"
                          style={{ cursor: "pointer", color: "blue" }}
                        >
                          Privacy Policy
                        </Link>
                        &nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
                        <Link
                          to="/ContactUs"
                          target="_blank"
                          style={{ cursor: "pointer", color: "blue" }}
                        >
                          Contact Us
                        </Link>
                      </p>
                    </div>
                  </div>

                  {loading ? (
                    <div>
                      <Skeleton
                        width={50}
                        height={50}
                        circle={true}
                        duration={5}
                      />
                    </div>
                  ) : (
                    <>
                      <div style={{ marginLeft: "10px" }}>
                        <button
                          onClick={handleAttendance}
                          className="btn  text-light rounded-5 fw_500"
                          style={
                            savedAttendance === 2 || savedAttendance === 0
                              ? {
                                  backgroundColor: "var(--ig-secondary)",
                                  borderRadius: "50%",
                                  padding: "10px",
                                }
                              : {
                                  backgroundColor: "green",
                                  borderRadius: "50%",
                                  padding: "10px",
                                }
                          }
                          title={
                            savedAttendance == 2 ? "Check In" : "Check Out"
                          }
                        >
                          {savedAttendance === 2 || savedAttendance === 0 ? (
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              height="24px"
                              viewBox="0 -960 960 960"
                              width="24px"
                              fill="#1f1f1f"
                            >
                              <path d="M481-781q106 0 200 45.5T838-604q7 9 4.5 16t-8.5 12q-6 5-14 4.5t-14-8.5q-55-78-141.5-119.5T481-741q-97 0-182 41.5T158-580q-6 9-14 10t-14-4q-7-5-8.5-12.5T126-602q62-85 155.5-132T481-781Zm0 94q135 0 232 90t97 223q0 50-35.5 83.5T688-257q-51 0-87.5-33.5T564-374q0-33-24.5-55.5T481-452q-34 0-58.5 22.5T398-374q0 97 57.5 162T604-121q9 3 12 10t1 15q-2 7-8 12t-15 3q-104-26-170-103.5T358-374q0-50 36-84t87-34q51 0 87 34t36 84q0 33 25 55.5t59 22.5q34 0 58-22.5t24-55.5q0-116-85-195t-203-79q-118 0-203 79t-85 194q0 24 4.5 60t21.5 84q3 9-.5 16T208-205q-8 3-15.5-.5T182-217q-15-39-21.5-77.5T154-374q0-133 96.5-223T481-687Zm0-192q64 0 125 15.5T724-819q9 5 10.5 12t-1.5 14q-3 7-10 11t-17-1q-53-27-109.5-41.5T481-839q-58 0-114 13.5T260-783q-8 5-16 2.5T232-791q-4-8-2-14.5t10-11.5q56-30 117-46t124-16Zm0 289q93 0 160 62.5T708-374q0 9-5.5 14.5T688-354q-8 0-14-5.5t-6-14.5q0-75-55.5-125.5T481-550q-76 0-130.5 50.5T296-374q0 81 28 137.5T406-123q6 6 6 14t-6 14q-6 6-14 6t-14-6q-59-62-90.5-126.5T256-374q0-91 66-153.5T481-590Zm-1 196q9 0 14.5 6t5.5 14q0 75 54 123t126 48q6 0 17-1t23-3q9-2 15.5 2.5T744-191q2 8-3 14t-13 8q-18 5-31.5 5.5t-16.5.5q-89 0-154.5-60T460-374q0-8 5.5-14t14.5-6Z" />
                            </svg>
                          ) : (
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              height="24px"
                              viewBox="0 -960 960 960"
                              width="24px"
                              fill="#fff"
                            >
                              <path d="M481-781q106 0 200 45.5T838-604q7 9 4.5 16t-8.5 12q-6 5-14 4.5t-14-8.5q-55-78-141.5-119.5T481-741q-97 0-182 41.5T158-580q-6 9-14 10t-14-4q-7-5-8.5-12.5T126-602q62-85 155.5-132T481-781Zm0 94q135 0 232 90t97 223q0 50-35.5 83.5T688-257q-51 0-87.5-33.5T564-374q0-33-24.5-55.5T481-452q-34 0-58.5 22.5T398-374q0 97 57.5 162T604-121q9 3 12 10t1 15q-2 7-8 12t-15 3q-104-26-170-103.5T358-374q0-50 36-84t87-34q51 0 87 34t36 84q0 33 25 55.5t59 22.5q34 0 58-22.5t24-55.5q0-116-85-195t-203-79q-118 0-203 79t-85 194q0 24 4.5 60t21.5 84q3 9-.5 16T208-205q-8 3-15.5-.5T182-217q-15-39-21.5-77.5T154-374q0-133 96.5-223T481-687Zm0-192q64 0 125 15.5T724-819q9 5 10.5 12t-1.5 14q-3 7-10 11t-17-1q-53-27-109.5-41.5T481-839q-58 0-114 13.5T260-783q-8 5-16 2.5T232-791q-4-8-2-14.5t10-11.5q56-30 117-46t124-16Zm0 289q93 0 160 62.5T708-374q0 9-5.5 14.5T688-354q-8 0-14-5.5t-6-14.5q0-75-55.5-125.5T481-550q-76 0-130.5 50.5T296-374q0 81 28 137.5T406-123q6 6 6 14t-6 14q-6 6-14 6t-14-6q-59-62-90.5-126.5T256-374q0-91 66-153.5T481-590Zm-1 196q9 0 14.5 6t5.5 14q0 75 54 123t126 48q6 0 17-1t23-3q9-2 15.5 2.5T744-191q2 8-3 14t-13 8q-18 5-31.5 5.5t-16.5.5q-89 0-154.5-60T460-374q0-8 5.5-14t14.5-6Z" />
                            </svg>
                          )}
                        </button>
                        <button
                          className="icons"
                          style={{
                            borderRadius: "50%",
                            padding: "10px",
                            zIndex: "1",
                            background: isListening ? "green" : "var(--ig-secondary)",
                            margin: "10px",
                            position: "relative",
                          }}
                          onClick={() => {
                            if (!canViewVoiceControl) {
                              toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
                              return;
                            }
                            isListening ? stopListening() : startListening();
                          }}
                          title={
                            isListening ? "Stop Listening" : "Start Listening"
                          }
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            height="24px"
                            viewBox="0 0 24 24"
                            width="24px"
                            fill={isListening ? "#fff" : "#1f1f1f"}
                          >
                            <path d="M0 0h24v24H0z" fill="none" />
                            <path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z" />
                          </svg>

                          {isListening && (
                            <div
                              className="text-xs text-red-500 mt-1"
                              style={{
                                position: "absolute",
                                bottom: -20,
                                left: "50%",
                                transform: "translateX(-50%)",
                                whiteSpace: "nowrap",
                              }}
                            ></div>
                          )}
                        </button>
                        <button
                          className="icons "
                          style={{
                            borderRadius: "50%",
                            padding: "10px",
                            background: "var(--ig-secondary)",
                          }}
                          onClick={() =>
                            canViewAiModel
                              ? showAichat()
                              : toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION)
                          }
                        >
                          <span title="Small Office AI">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              height="24px"
                              viewBox="0 -960 960 960"
                              width="24px"
                              fill="#1f1f1f"
                            >
                              <path d="M852-212 732-332l56-56 120 120-56 56ZM708-692l-56-56 120-120 56 56-120 120Zm-456 0L132-812l56-56 120 120-56 56ZM108-212l-56-56 120-120 56 56-120 120Zm246-75 126-76 126 77-33-144 111-96-146-13-58-136-58 135-146 13 111 97-33 143ZM233-120l65-281L80-590l288-25 112-265 112 265 288 25-218 189 65 281-247-149-247 149Zm247-361Z" />
                            </svg>
                          </span>
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}
          </>
        )}
        <>
          {getData?.id ? (
            <ListInquiryView
              isListInquiry={showListInquiry}
              closeListInquiry={() => setShowListInquiry(false)}
              contactData={getData}
              isModelOpen={"InquiryList"}
              setNoDataFound1={setNoDataFound1}
            />
          ) : (
            ""
          )}
        </>

        <>
          {getData?.id ? (
            <ListAccountTransactionView
              isListAccountTransaction={showListAccountTransaction}
              closeListAccountTransaction={() =>
                setShowListAccountTransaction(false)
              }
              contactData={getData}
              setNoDataFound1={setNoDataFound1}
            />
          ) : (
            ""
          )}
        </>
        <>
          {getData?.id ? (
            <ListOrderView
              isListOrder={showListOrder}
              closeListOrder={() => setShowListOrder(false)}
              contactData={getData}
              isOrderShowNum={isOrderShowNum}
            />
          ) : (
            ""
          )}
        </>
        {showRenewPlan && (
          <PricingTable
            companyId={renewPlanItem?.id}
            companyName={renewPlanItem?.company_name}
            companyEmailId={renewPlanItem?.company_email}
            companyContact={renewPlanItem?.company_contact}
            planAmount={0}
          />
        )}
        <RightSearch
          isSearchShow={showSearch}
          closeSearch={() => setShowSearch(false)}
        />
        {optionConfirmation && (
          <ConfirmationModal
            show={optionConfirmation}
            onHide={() => setOptionConfirmation(false)}
            handleSubmit={() => "jhj"}
            title={"Mute Shayam for..."}
            btn1="CANCEL"
            btn2="MUTE NOTIFICATIION"
            isoption={true}
            opt1={"8 Hours"}
            opt2={"1 Week"}
            opt3={"Always"}
          />
        )}
        {isClearConfirmation && (
          <ConfirmationModal
            show={isClearConfirmation}
            onHide={() => setIsClearConfirmation(false)}
            handleSubmit={() => handleClearMessages()}
            title={"Clear this chats"}
            message={"Are you sure you want Clear this Chats?"}
            btn1="CANCEL"
            btn2="CLEAR CHATS"
          />
        )}
        {isCloseConfirmation && (
          <ConfirmationModal
            show={isCloseConfirmation}
            onHide={() => setIsCloseConfirmation(false)}
            handleSubmit={() => handleDeleteContact()}
            title={"Delete this Contact"}
            message={"Are you sure you want Delete this Contact?"}
            btn1="CANCEL"
            btn2="DELETE CONTACT"
          />
        )}
        {isDeleteConfirmation && (
          <ConfirmationModal
            show={isDeleteConfirmation}
            onHide={() => setIsDeleteConfirmation(false)}
            handleSubmit={handleDeleteMessage}
            title={"Delete this message"}
            message={"Are you sure you want delete this message? "}
            btn1="CANCEL"
            btn2="DELETE"
          />
        )}
        {isMoveToMeConfirmation && (
          <ConfirmationModal
            show={isMoveToMeConfirmation}
            onHide={() => setIsMoveToMeConfirmation(false)}
            handleSubmit={() => handleChangeMoveMsg(1)}
            title={"Move this message to Me"}
            message={"Are you sure you want Move this message to Me? "}
            btn1="No"
            btn2="Yes"
          />
        )}
        {isMoveToClientConfirmation && (
          <ConfirmationModal
            show={isMoveToClientConfirmation}
            onHide={() => setIsMoveToClientConfirmation(false)}
            handleSubmit={() => handleChangeMoveMsg(2)}
            title={"Move this message to Client"}
            message={"Are you sure you want Move this message to Client? "}
            btn1="No"
            btn2="Yes"
          />
        )}
        {isReminderConfirmationStatus && (
          <ConfirmationModal
            show={isReminderConfirmationStatus}
            onHide={() => setIsReminderConfirmationStatus(false)}
            handleSubmit={() => {
              if (isReminderConfirmationStatus1) {
                handleChangeStatusOfReminder(isReminderConfirmationStatus1);
              }
            }}
            title={"Are you sure you want to complete this Reminder?"}
            message={`Remark : ${isReminderConfirmationStatus1 && isReminderConfirmationStatus1.reminder_remark}`}
            btn1="CANCEL"
            btn2="Complete Reminder Now"
            message1={`Reminder Date : ${isReminderConfirmationStatus1 && formatDateAndTime(isReminderConfirmationStatus1.reminder_data_time)}`}
          />
        )}
        {isReminderConfirmation && (
          <ReminderModal
            show={isReminderConfirmation}
            onHide={() => setIsReminderConfirmation(false)}
            handleSubmit={handleReminder}
            title={" Set Reminder "}
            message={"Are you sure you want delete this message? "}
            btn1="CANCEL"
            btn2="set Reminder"
            ContactMessageId={reminderForMsgId}
            request_flag="2"
          />
        )}

        {isEmailConfirmation && (
          <EmailSendView
            show={isEmailConfirmation}
            onHide={() => setIsEmailConfirmation(false)}
            title={"Send Email"}
            btn1="CANCEL"
            btn2="Send Email"
            contactInfo={getData}
            setLoading={setLoading}
          />
        )}

        {viewerOpen && (
          <ImageViewer
            image={imageViewData}
            onClose={() => setViewerOpen(false)}
          />
        )}
        {isModalOpen && (
          <>
            <ContactStatistic
              show={isModalOpen}
              onHide={() => setIsModalOpen(false)}
              getInfo={getData}
            />
          </>
        )}
      </div>
      {/* <IntroductionVideo /> */}
    </>
  );
};

export default RightView;
