import React, { useEffect, useState } from "react";
import {
  Formik,
  Field,
  Form,
  ErrorMessage,
  FormikErrors,
  FormikTouched,
} from "formik";
import {
  createInquiry,
  createInquiryInitialValues,
  createInquiryValidationSchema,
  fetchCustomInqFromApiForInquiry,
  ICreateInquiry,
  ICustomFromList,
  updateInquiry,
} from "./CreateInquiryController";
import { axiosInstance } from "../../../services/axiosInstance";
import { TReactSetState } from "../../../helpers/AppType";
import FormikCustomSearchDropdown from "../../../components/FormikCustomSearchDropdown";
import { SingleValue } from "react-select";
import { IOption } from "../../../helpers/AppInterface";
import useCheckUserPermission from "../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../helpers/AppEnum";
import { BIG_TEXT_LENGTH, MINI_TEXT_LENGTH } from "../../../helpers/AppConstants";
import { openInNewTab } from "../../../common/SharedFunction";
interface IPropsCreateInquiry {
  show: boolean;
  onHide: () => void;
  contactData?: any;
  setRefreshInquiry: any;
  contact_id: any;
  headerName: string;
}
const CreateInquiryView = ({
  show,
  onHide,
  setRefreshInquiry,
  contactData,
  contact_id,
  headerName,
}: IPropsCreateInquiry) => {

  const [categoryList, setCategoryList] = useState<any>([]);
  const [productList, setProductList] = useState<any>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number>();
  const [customFormList, setCustomFromList] = useState<ICustomFromList[]>([]);
  const [isSwitchActive, setIsSwitchActive] = useState(false);
  const [datasorce, setDataScorce] = useState<any[]>([]);
  const canViewCategory = useCheckUserPermission(
    PAGE_ID.CATEGORY,
    PERMISSION_TYPE.VIEW
  );
  const canViewProduct = useCheckUserPermission(
    PAGE_ID.PRODUCT,
    PERMISSION_TYPE.VIEW
  );

  const canViewSource = useCheckUserPermission(
    PAGE_ID.SOURCE,
    PERMISSION_TYPE.VIEW
  );
  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior for Enter key
      }
    };

    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [show]);

  const [sourceOfTypesList, setSourceOfTypesList] = useState([]);
  const requirementTypesList = [
    { id: "0", requirement_name: "One time" },
    { id: "1", requirement_name: "Recurring" },
  ];
  const handleSubmit = async (values: ICreateInquiry) => {
    console.log("value", values);
    if (contactData?.id) {
      updateInquiry(values, setRefreshInquiry, contactData, onHide);
    } else {
      createInquiry(values, setRefreshInquiry, contact_id, onHide);
    }
  };

  const fetchSourceTypeApi = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const token = await localStorage.getItem("token");
    const requestData = {
      a_application_login_id: getUUID,
    };
    if (canViewSource) {
      try {
        const response = await axiosInstance.post(
          "sourceOfTypes",
          requestData,
          {
            headers: {
              Authorization: `${token}`,
              "x-tenant-id": getUUID,
            },
          }
        );
        setSourceOfTypesList(response.data.data.item); // Assuming API response is an array of countries
      } catch (error) {
        console.error("Error fetching countries:", error);
        setSourceOfTypesList([]);
      }
    }
  };

  const fetchCategoryApiForInquiry = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "categories",
      columns: "id,category_name",
      where: ["isDelete=0", `a_application_login_id=${getUUID}||0`],
      request_flag: 0,
      order: `{"id":"DESC"}`,
    };
    if (canViewCategory) {
      try {
        const response = await axiosInstance.post("commonGet", requestData,
          {
            headers: {
              "x-tenant-id": getUUID,

            },
          }
        );

        setCategoryList(response.data.data); // Assuming API response is an array of countries
      } catch (error) {
        console.error("Error fetching countries:", error);
        setCategoryList([]);
      }
    }
  };
  const handleSourceTypeChange = async (event: any, setFieldValue: any) => {
    const { value } = event.target;
    setFieldValue("source_type_id", value);
  };
  const fetchProductApiForInquiry = async () => {
    const getUUID = await localStorage.getItem("UUID");
    const requestData = {
      table: "products",
      columns: "id,product_name",
      where: [
        "isDelete=0",
        `category_id=${selectedCategoryId}`,
        `a_application_login_id=${getUUID}||0`,
      ],
      request_flag: 0,
      order: `{"id":"DESC"}`,
    };
    if (canViewProduct) {
      try {
        const response = await axiosInstance.post("commonGet", requestData, {
          headers: {
            "x-tenant-id": getUUID,

          },
        });

        setProductList(response.data.data); // Assuming API response is an array of countries
      } catch (error) {
        console.error("Error fetching countries:", error);
        setProductList([]);
      }
    }
  };
  const handleCountriesChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    if (selectedOption) {
      setFieldValue("category_id", selectedOption.value);
      setSelectedCategoryId(selectedOption.value as number);
    } else {
      setFieldValue("category_id", "");
      setSelectedCategoryId(undefined);
      setProductList([]);
    }
  };

  const handleDropChange = async (
    selectedOption: SingleValue<IOption>,
    setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  ) => {
    console.log("selectedOption", selectedOption);
  };
  useEffect(() => {
    const fetchData = async () => {
      if (contactData?.category_id && !selectedCategoryId) {
        setSelectedCategoryId(contactData?.category_id || undefined);
        await fetchProductApiForInquiry();
        await fetchCategoryApiForInquiry();
        await fetchSourceTypeApi();
      } else if (contactData?.category_id) {
        setSelectedCategoryId(selectedCategoryId || undefined);
        await fetchProductApiForInquiry();
        await fetchCategoryApiForInquiry();
      } else {
        if (selectedCategoryId) {
          setSelectedCategoryId(undefined);
          await fetchProductApiForInquiry();
        } else {
          await fetchSourceTypeApi();
          await fetchCategoryApiForInquiry();
        }
      }
    };

    fetchData();
  }, [contactData?.category_id, selectedCategoryId, show]);

  useEffect(() => {
    fetchCustomInqFromApiForInquiry(setCustomFromList, setDataScorce);
  }, [show]);
  const categoryOptions = categoryList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.category_name,
  }));

  const dropDownOptions =
    datasorce &&
    datasorce.map((item) => ({
      value: item,
      label: item,
    }));

  const productOptions = productList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.product_name,
  }));
  const requirementTypesOptions = requirementTypesList.map((itemState) => ({
    value: itemState.id,
    label: itemState.requirement_name,
  }));
  const sourceTypeOptions = sourceOfTypesList.map((itemState: any) => ({
    value: itemState.id,
    label: itemState.source_name,
  }));

  const renderInputField = (
    item: {
      data_type: number;
      display_order: number;
      required_or_not: number;
      data_sorce: string;
    },
    name: string,
    fieldName: string,
    setFieldValue: any,
    error: FormikErrors<ICreateInquiry>,
    touched: FormikTouched<ICreateInquiry>
  ) => {

    switch (item.data_type) {
      case 1:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>
              <Field
                type="text"
                name={fieldName}
                className={`form-control`}
                onInput={(e: React.ChangeEvent<HTMLInputElement>) => {
                  e.target.value = e.target.value.replace(/[^0-9]/g, ""); // Allows only numbers
                }}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 2:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>
              <Field
                type="text"
                name={fieldName}
                className={`form-control font-size-15 rounded-1  `}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 3:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                as="textarea"
                name={fieldName}
                className={`form-control`}
                rows={1}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 4:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                type="date"
                name={fieldName}
                className={`form-control font-size-15 rounded-1`}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 5:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                type="datetime-local"
                name={fieldName}
                className={`form-control font-size-15 rounded-1`}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 6:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                type="time"
                name={fieldName}
                className={`form-control font-size-15 rounded-1`}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 7:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field name={fieldName}>
                {({ field, form }: any) => (
                  <div className="form-check form-switch">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="descriptionSwitch"
                      {...field}
                      checked={field.value === true} // Ensure the checked state is correctly set
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        form.setFieldValue(fieldName, e.target.checked);
                      }}
                    />
                    <ErrorMessage
                      name={fieldName}
                      component="div"
                      className="field-error text-danger"
                    />
                  </div>
                )}
              </Field>

            </div>
          </div>
        );
      case 8:
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <Field
                type="text"
                name={fieldName}
                className={`form-control`}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  let value = e.target.value;

                  if (!/^\d*\.?\d*$/.test(value)) {
                    value = value.replace(/[^0-9.]/g, ""); // Remove non-numeric & extra dots
                  }
                  const decimalCount = (value.match(/\./g) || []).length;
                  if (decimalCount > 1) {
                    value = value.slice(0, -1); // Remove extra decimal point
                  }

                  setFieldValue(fieldName, value);
                }}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 9:
        const getDataSourceForDropDown = item.data_sorce
          ?.split(",")
          .map((item: any) => item.replace(/"/g, ""));

        const dropDownOptions =
          getDataSourceForDropDown &&
          getDataSourceForDropDown.map((item) => ({
            value: item,
            label: item,
          }));
        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>

              <FormikCustomSearchDropdown
                name={fieldName}
                options={dropDownOptions}
                className={` `}
                onChange={handleDropChange}
              />
              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      case 10:
        const getDataSourceForRadio = item.data_sorce
          ?.split(",")
          .map((item: any) => item.replace(/"/g, ""));

        return (
          <div className="col-6">
            <div className="form-group">
              <label htmlFor="name " className="pb-2 form_label">
                {name}
                {item.required_or_not === 1 && (
                  <span className="text-danger">*</span>
                )}
              </label>
              <div className="mt-1">
                <div>
                  {getDataSourceForRadio &&
                    getDataSourceForRadio.map((option, index) => (
                      <label key={index} className="p-1">
                        <Field type="radio" name={fieldName} value={option} />
                        {option}
                      </label>
                    ))}
                </div>
              </div>

              <ErrorMessage
                name={fieldName}
                component="div"
                className="field-error text-danger"
              />
            </div>
          </div>
        );
      default:
        return "No More filed Add";
    }
  };
  return (
    <React.Fragment>
      {show && (
        <div className="modal1 ">
          <div className="modal-content1">
            <div className="d-flex align-items-center justify-content-end">
              <span>
                <p
                  className="landing-page-text text-end"
                  style={{ cursor: "pointer", color: "var(--ig-accent)", float: "right", fontSize: "13px" }}
                  onClick={() => openInNewTab("/videoTutorial", 13)}
                >
                  Learn More : <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#0000FF"><path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" /></svg>
                </p>
              </span>

              <span className="close ms-3 pb-3" onClick={onHide}>
                &times;
              </span>
            </div>

            <h2 className="modal-title1 form_header_text">{headerName}</h2>
            <p className="text-center " style={{ color: "var(--ig-border)" }}>
              Please enter your inquiry detail.
            </p>
            <Formik
              enableReinitialize
              initialValues={createInquiryInitialValues(
                contactData,
                setIsSwitchActive
              )}
              validationSchema={createInquiryValidationSchema(customFormList)}
              onSubmit={handleSubmit}
            >
              {({ errors, touched, validateForm, setFieldValue }) => (
                <Form>
                  <div className="  mt-3    d-flex justify-content-center">
                    <div className="mb-3 py-4  ">
                      <div
                        className="row  mx-0 px-2 gy-3  d-flex justify-content-center"
                        style={{ maxHeight: "600px", overflowX: "scroll" }}
                      >
                        <div className="col-6 col-md-6 ">
                          <div className="form-group">
                            <label
                              htmlFor="category_id"
                              className="pb-2 mb-1 form_label"
                            >
                              Product Category Name
                            </label>
                            <FormikCustomSearchDropdown
                              name="category_id"
                              options={categoryOptions}
                              className={`  ${errors.category_id &&
                                touched.category_id &&
                                "is-invalid input-box-error"
                                }`}
                              onChange={handleCountriesChange}
                            />
                            <ErrorMessage
                              name="category_id"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 col-md-6 ">
                          <div className="form-group">
                            <label htmlFor="name " className="pb-2 form_label">
                              Product Name
                            </label>
                            <FormikCustomSearchDropdown
                              name="product_id"
                              options={productOptions}
                              className={`  ${errors.product_id &&
                                touched.product_id &&
                                "is-invalid input-box-error"
                                }`}
                            />

                            <ErrorMessage
                              name="product_id"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 col-md-6 ">
                          <div className="form-group">
                            <label htmlFor="name " className="pb-2 form_label">
                              Required Quantity

                            </label>
                            <Field
                              type="text"
                              name="qty"
                              maxlength={MINI_TEXT_LENGTH}
                              className={`form-control font-size-15 rounded-1   ${errors.qty &&
                                touched.qty &&
                                "is-invalid input-box-error"
                                }`}

                              onChange={(
                                e: React.ChangeEvent<HTMLInputElement>
                              ) => {
                                let value = e.target.value;
                                if (!/^\d*\.?\d*$/.test(value)) {
                                  value = value.replace(/[^0-9.]/g, ""); // Remove non-numeric & extra dots
                                }

                                // Ensure only one decimal point exists
                                const decimalCount = (value.match(/\./g) || [])
                                  .length;
                                if (decimalCount > 1) {
                                  value = value.slice(0, -1); // Remove extra decimal point
                                }

                                setFieldValue("qty", value);
                              }}
                            />
                            <ErrorMessage
                              name="qty"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 col-md-6 ">
                          <div className="form-group">
                            <label htmlFor="static" className="mb-1 form_label">
                              Requirement Type
                            </label>
                            <FormikCustomSearchDropdown
                              name="static"
                              options={requirementTypesOptions}
                              className={`  ${errors.static &&
                                touched.static &&
                                "is-invalid input-box-error"
                                }`}
                            />

                            <ErrorMessage
                              name="static"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 col-md-6">
                          <div className="form-group">
                            <label
                              htmlFor="description"
                              className="pb-2 form_label"
                            >
                              Description <span className="text-danger">*</span>
                            </label>
                            <Field
                              as="textarea"
                              name="description"
                              maxlength={BIG_TEXT_LENGTH}
                              className={`form-control ${errors.description && touched.description
                                ? "is-invalid input-box-error"
                                : ""
                                }`}
                              rows={1}
                            />
                            <ErrorMessage
                              name="description"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        <div className="col-6 ">
                          <div className="form-group">
                            <label htmlFor="city" className="mb-1 form_label">
                              Source type
                            </label>
                            <FormikCustomSearchDropdown
                              name="source_type_id"
                              options={sourceTypeOptions}
                              className={`  ${errors.source_type_id &&
                                touched.source_type_id &&
                                "is-invalid input-box-error"
                                }`}

                            />

                            <ErrorMessage
                              name="source_type_id"
                              component="div"
                              className="field-error text-danger"
                            />
                          </div>
                        </div>
                        {customFormList.length > 0 &&

                          <div className="col-12 border rounded bg-secondary">

                            <b

                              style={{
                                cursor: "pointer",
                                display: "block",
                                color: "var(--ig-accent)",
                              }}
                            >
                              More Inquiry Information
                              <span className="ms-2">
                              </span>
                            </b>
                          </div>
                        }
                        <div className="row mt-2">
                          {customFormList &&
                            customFormList.map((item) => (
                              <React.Fragment key={item.reference_column_name}>
                                {renderInputField(
                                  item,
                                  item.title,
                                  item.reference_column_name,
                                  setFieldValue,
                                  errors,
                                  touched
                                )}
                              </React.Fragment>
                            ))}
                        </div>

                      </div>
                      <div className="col-12 col-12 pt-4 d-flex justify-content-center">

                        <button
                          className="border border-1 bg-danger px-4 me-2 py-2 text-light rounded-1 form_label"

                          onClick={onHide}
                        >
                          Close
                        </button>
                        <button
                          type="submit"
                          className="btn btn-primary px-4 py-2 ms-2  text-light form_label rounded-1"

                          style={{
                            backgroundColor: "#f58634",
                          }}
                        >
                          Save Inquiry
                        </button>
                      </div>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default CreateInquiryView;
