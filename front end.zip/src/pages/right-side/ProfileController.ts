export interface IUserOne {
  id: number;
  person_name: string;
  mobile_number: string;
  company_name?: string;
  email_id?: string;
  country?: string;
  state?: string;
  district?: string;
  city?: string;
  area?: string;
  pincode?: string;
  address?: string;
  status?: number;
}
