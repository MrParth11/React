import React, { useEffect, useRef, useState } from "react";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import { useTheme } from "../../../components/ThemeContext";
import {
  convertDateTimeFormat,
  formatDateAndTime,
} from "../../../common/SharedFunction";
import {
  createReminderForInquiry,
  fetchInquiryApi,
  fetchStageStatusForInquiryApi,
  handleChangeStatusOfReminderForInquiry,
  IInquiry,
  updateCheckBox,
  updateStageStatusForInquiriesRadioButton,
} from "./ListInquiryController";
import CreateInquiryView from "../create-inquiry/CreateInquiryView";
import SafeHtml from "../../../components/SafeHtml";
import CheckBoxModal from "../../../components/model/CheckBoxModal";

import { axiosInstance } from "../../../services/axiosInstance";
import {
  DEFAULT_MESSAGE_ERROR_PERMISSION,
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
  SMALL_TEXT_LENGTH,
} from "../../../helpers/AppConstants";
import { toast } from "react-toastify";
import ConfirmationModal from "../../../components/model/ConfirmationModal";
import ReminderModal from "../../../components/model/ReminderModal";
import ExcelExport from "../../../components/ExcelExport";
import CheckBoxFilterModal from "../../../components/model/CheckBoxFilterModal";
import RadioButtonModal from "../../../components/model/RadioButtonModal";
import { TReactSetState } from "../../../helpers/AppType";
import useCheckUserPermission from "../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../helpers/AppEnum";
import { fetchLabelApi } from "../../left-side/header/Setting/label/LabelController";
interface IPropsListInquiry {
  isListInquiry: boolean;
  closeListInquiry: () => void;
  contactData?: any;
  isModelOpen: any;
  setNoDataFound1: TReactSetState<boolean>;
}

const ListInquiryView = ({
  isListInquiry,
  closeListInquiry,
  contactData,
  isModelOpen,
  setNoDataFound1,
}: IPropsListInquiry) => {
  const listInnerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<Record<number, HTMLUListElement | null>>({});

  let itemsPerPage: number = 7;
  const token = localStorage.getItem("token");

  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [contactSelections, setContactSelections] = useState<{
    [key: number]: any[];
  }>({});

  const [searchTerm, setSearchTerm] = useState<string>("");
  const [inquiryList, setInquiryList] = useState<IInquiry[]>([]);
  const { darkMode } = useTheme();
  const [noDataFound, setNoDataFound] = useState(false);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(
    null
  );
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const [options, setOptions] = useState<any[]>([]);
  const [hasOneData, setHasOneData] = useState<number>();
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [isCreateInquiry, setIsCreateInquiry] = useState(false);
  const [isSetReminderConfirmation, setIsSetReminderConfirmation] =
    useState(false);

  const [labelDropdownOpen, setLabelDropdownOpen] = useState<any>(null);
  const [inquiryId, setInquiryId] = useState<number>();
  const [inquiryToEdit, setInquiryToiEdit] = useState<IInquiry>();
  const [editInquiry, setEditInquiry] = useState(false);
  const [refreshInquiry, setRefreshInquiry] = useState(false);
  const [statusAssignContactId, setStatusAssignContactId] = useState<number>();
  const [isModalAssignStatusVisible, setIsModalAssignStatusVisible] =
    useState<boolean>(false);
  const [isReminderConfirmationStatus, setIsReminderConfirmationStatus] =
    useState(false);
  const [reminderData, setReminderData] = useState<IInquiry>();
  const [selectedLabelIds, setSelectedLabelIds] = useState<string | undefined>(
    ""
  );
  const [isModalFilterVisible, setIsModalFilterVisible] =
    useState<boolean>(false);
  const [hasData, setHasData] = useState<boolean>(false);
  const [optionRadioButtonStatus, setOptionRadioButtonStatus] = useState<any[]>(
    []
  );
  const [filterParams, setFilterParams] = useState({
    checkedOptions: null,
    checkedSourceTypes: null,
    startSearchDate: "",
    endSearchDate: "",
    checkedOptionsStageStatus: "",
    selectedCategoryId: "",
    selectedProductId: "",
  });

  const canView = useCheckUserPermission(PAGE_ID.INQUIRY, PERMISSION_TYPE.VIEW);

  const canEdit = useCheckUserPermission(PAGE_ID.INQUIRY, PERMISSION_TYPE.EDIT);

  const canAdd = useCheckUserPermission(PAGE_ID.INQUIRY, PERMISSION_TYPE.ADD);

  const canShare = useCheckUserPermission(
    PAGE_ID.INQUIRY,
    PERMISSION_TYPE.SHARE
  );
  const canDelete = useCheckUserPermission(
    PAGE_ID.INQUIRY,
    PERMISSION_TYPE.DELETE
  );
  const canViewLabel = useCheckUserPermission(
    PAGE_ID.LABEL,
    PERMISSION_TYPE.VIEW
  );
  const canViewStatus = useCheckUserPermission(
    PAGE_ID.STATUS,
    PERMISSION_TYPE.VIEW
  );

  const canAddReminder = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.ADD
  );
  useEffect(() => {
    const handleScroll = () => {
      if (
        listInnerRef.current &&
        listInnerRef.current.scrollTop + listInnerRef.current.clientHeight ===
        listInnerRef.current.scrollHeight
      ) {
        if (inquiryList.length < (currentPage + 1) * itemsPerPage + 1) {
          fetchInquiryApi(
            currentPage + 1,
            searchTerm,
            setInquiryList,
            itemsPerPage,
            setNoDataFound,
            setLoading,
            token,
            contactData?.id,
            setInquiryId,
            setSelectedLabelIds,
            setNoDataFound1,
            filterParams.checkedOptions,
            filterParams.checkedSourceTypes,
            filterParams.startSearchDate,
            filterParams.endSearchDate,
            filterParams.checkedOptionsStageStatus,
            filterParams.selectedCategoryId,
            filterParams.selectedProductId
          );
        }
        setCurrentPage((prevPage) => prevPage + 1);
      }
    };

    const listInnerElement = listInnerRef.current;

    if (listInnerElement) {
      listInnerElement.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (listInnerElement) {
        listInnerElement.removeEventListener("scroll", handleScroll);
      }
    };
  }, [inquiryList.length]);

  useEffect(() => {
    if (isListInquiry) {
      fetchInquiryApi(
        0,
        "",
        setInquiryList,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        contactData?.id,
        setInquiryId,
        setSelectedLabelIds,
        setNoDataFound1
      );
      // }
      if (options) {
        fetchLabelApi(setOptions, setLoading);
      }
      if (isModalAssignStatusVisible) {
        fetchStageStatusForInquiryApi(setOptionRadioButtonStatus);
      }
    }
  }, [token, isListInquiry, isModalAssignStatusVisible]);
  useEffect(() => {
    if (contactData?.id) {
      closeListInquiry();
    } else {
      return undefined;
    }
  }, [contactData?.id]);
  const toggleDropdownLabel = (id: number) => {
    setInquiryId(id);
    setHasOneData(id);
    setLabelDropdownOpen((prevId: any) => (prevId === id ? null : id));
  };
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setSearchTerm(value);
    if (value.length >= 3 || value === "") {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
      setSearchTimeout(
        setTimeout(() => {
          fetchInquiryApi(
            0,
            value,
            setInquiryList,
            itemsPerPage,
            setNoDataFound,
            setLoading,
            token,
            contactData?.id,
            setInquiryId,
            setSelectedLabelIds,
            setNoDataFound1
          );
          setCurrentPage(0);
        }, 1000)
      );
    }
  };

  const handleModalClose = () => {
    if (isModalVisible) {
      setIsModalVisible(false);
    } else {
      setIsModalFilterVisible(false);
    }
  };
  const handleModalClose1 = () => {
    closeListInquiry();
  };
  const handleConfirm = async (
    contactId: number | undefined,
    checkedOptions: any[]
  ) => {
    if (contactId === undefined) return;

    await updateCheckBox(contactId, checkedOptions);
    fetchInquiryApi(
      0,
      "",
      setInquiryList,
      itemsPerPage,
      setNoDataFound,
      setLoading,
      token,
      contactData?.id,
      setInquiryId,
      setSelectedLabelIds,
      setNoDataFound1
    );
    setLabelDropdownOpen(null);
    setContactSelections((prev) => ({
      ...prev,
      [contactId]: checkedOptions,
    }));
    setIsModalVisible(false);
  };
  const handleModalOpen = (id: number | undefined) => {
    if (canViewLabel) {
      if (contactData) {
        setInquiryId(id);
        setIsModalVisible(true);
      }
      setInquiryId(id);
      setIsModalVisible(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleClickOutside = (event: { target: any }) => {
    const clickedOutside = Object.values(dropdownRef.current).every(
      (ref) => ref && !ref.contains(event.target)
    );
    if (clickedOutside) {
      setLabelDropdownOpen(null);
    }
  };

  useEffect(() => {
    if (labelDropdownOpen !== null) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [labelDropdownOpen]);

  const handleDeleteInquiry = async () => {
    const requestData = {
      table: "inquiries",
      where: `{"id":${inquiryId}}`,
      data: `{"isDelete":"1"}`,
    };
    const getUUID = localStorage.getItem("UUID")
    try {
      const data = await axiosInstance.post("commonUpdate", requestData, {
        headers: {
          "x-tenant-id": getUUID,

        },
      });
      if (data.data.code === 200) {
        if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          setIsDeleteConfirmation(false);
          fetchInquiryApi(
            0,
            "",
            setInquiryList,
            itemsPerPage,
            setNoDataFound,
            setLoading,
            token,
            contactData?.id,
            setInquiryId,
            setSelectedLabelIds,
            setNoDataFound1
          );
        } else {
          toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };
  const handelRefreshInquiry = async () => {
    setTimeout(() => {
      fetchInquiryApi(
        0,
        "",
        setInquiryList,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        contactData?.id,
        setInquiryId,
        setSelectedLabelIds,
        setNoDataFound1
      );
      setCurrentPage(0);
    }, 100);
  };

  useEffect(() => {
    if (refreshInquiry && canView) {
      fetchInquiryApi(
        0,
        "",
        setInquiryList,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        contactData?.id,
        setInquiryId,
        setSelectedLabelIds,
        setNoDataFound1
      );
      setRefreshInquiry(false);
    }
  }, [refreshInquiry, canView]);
  const handleConfirmFilter = async (
    filterData: any,
    checkedOptions: any,
    checkedSourceTypes: any,
    startSearchDate: string,
    endSearchDate: string,
    checkedOptionsStageStatus: any,
    checkedOptionsUser: any,
    selectedCategoryId: any,
    selectedProductId: any
  ) => {
    console.log("selectedCategoryId", selectedCategoryId, selectedProductId);
    setFilterParams({
      checkedOptions,
      checkedSourceTypes,
      startSearchDate,
      endSearchDate,
      checkedOptionsStageStatus,
      selectedCategoryId,
      selectedProductId,
    });
    setHasData(
      checkedOptions?.length > 0 ||
      checkedSourceTypes?.length > 0 ||
      startSearchDate !== "" ||
      endSearchDate !== "" ||
      checkedOptionsStageStatus?.length > 0 ||
      selectedCategoryId !== null ||
      selectedProductId !== null
    );

    setTimeout(() => {
      fetchInquiryApi(
        0,
        "",
        setInquiryList,
        itemsPerPage,
        setNoDataFound,
        setLoading,
        token,
        contactData?.id,
        setInquiryId,
        setSelectedLabelIds,
        setNoDataFound1,
        checkedOptions,
        checkedSourceTypes,
        startSearchDate,
        endSearchDate,
        checkedOptionsStageStatus,
        selectedCategoryId,
        selectedProductId
      );
      setCurrentPage(0);
    }, 100);
    setIsModalFilterVisible(false);
  };
  const columns = [
    "ID",
    "Contact Person",
    "Category Name",
    "Product Name",
    "Quantity",
    "Requirement Type",
    "Description",
    "Source Name",
    "Inquiry Date Time",
    "create Date",
  ];
  const prepareExportData = inquiryList.map((item) => ({
    ID: item.id,
    "Contact Person": item.contact_person_name || "",
    "Category Name": item.category_name || "",
    "Product Name": item.product_name || "",
    Quantity: item.qty || "",
    "Requirement Type": item.static === 0 ? "One Time" : "Recurring",
    Description: item.description || "",
    "Source Name": item.source_name || "",
    "Inquiry Date Time": item.inquiry_date_time || "",
    "create Date": item.create_date_time || "",
  }));
  const handleModalOpenStatusAssign = (id: number | undefined) => {
    if (canViewStatus) {
      setStatusAssignContactId(id);
      setIsModalAssignStatusVisible(true);
    } else {
      setIsModalAssignStatusVisible(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleConfirmInquiriesRadioButton = async (checkedOptions: any[]) => {
    if (statusAssignContactId === undefined) return;

    await updateStageStatusForInquiriesRadioButton(
      statusAssignContactId,
      checkedOptions,
      setLoading
    );
    fetchInquiryApi(
      0,
      "",
      setInquiryList,
      itemsPerPage,
      setNoDataFound,
      setLoading,
      token,
      contactData?.id,
      setInquiryId,
      setSelectedLabelIds,
      setNoDataFound1
    );
    setContactSelections((prev) => ({
      ...prev,
      [statusAssignContactId]: checkedOptions,
    }));
    setIsModalAssignStatusVisible(false);
  };

  const handleModalOpenReminder = (id: number | undefined) => {
    if (canAddReminder) {
      setInquiryId(id);
      setIsSetReminderConfirmation(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
    setLabelDropdownOpen(null);
  };
  const handleReminder = async (data: {
    dateTime: string;
    remark: string;
    status: string;
    selectedCategory: any;
  }) => {
    if (
      data.dateTime.trim() &&
      data.remark.trim() &&
      data.selectedCategory !== null &&
      data.selectedCategory !== false
    ) {
      createReminderForInquiry(
        data,
        contactData?.id,
        inquiryId,
        setIsSetReminderConfirmation,
        setRefreshInquiry
      );
    } else {
      toast.error("Please enter Date and Time, Remark, and Select Team Member");
      setIsSetReminderConfirmation(true);
    }
  };
  const handleChangeStatusOfReminder = (messageData: IInquiry) => {
    setIsReminderConfirmationStatus(true);
    setReminderData(messageData);
  };

  const handleExportClick = () => {
    if (canShare) {
      ExcelExport({
        data: prepareExportData,
        columns: columns,
        fileName: "inquiry_",
      });
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelFilterInq = () => {
    if (canView) {
      setIsModalFilterVisible(true);
    } else {
      setIsModalFilterVisible(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handelChangeEdit = (inquiryDataById: IInquiry) => {
    if (canEdit) {
      setEditInquiry(true);
      setInquiryToiEdit(inquiryDataById);
    } else {
      setEditInquiry(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleChangeDeleInquiry = () => {
    if (canDelete) {
      setIsDeleteConfirmation(true);
    } else {
      setIsDeleteConfirmation(false);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleChangeAddInquiry = () => {
    canAdd
      ? setIsCreateInquiry(true)
      : toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
  };

  return (
    <>
      {isListInquiry ? (
        <>
          <div className="leftSide " id="search-message">
            <div className="header-Chat">
              <div className="ICON">
                <button className="icons ig-btn" onClick={handleModalClose1}>
                  <span className="text-white" title="Close">
                    <svg
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path d="m19.1 17.2-5.3-5.3 5.3-5.3-1.8-1.8-5.3 5.4-5.3-5.3-1.8 1.7 5.3 5.3-5.3 5.3L6.7 19l5.3-5.3 5.3 5.3 1.8-1.8z"></path>
                    </svg>
                  </span>
                </button>
              </div>

              <div className="newText w-100">
                <h2>{contactData ? "My Inquiry List" : "All Inquiry List"}</h2>
              </div>
              <div className="w-100 text-end">
                {contactData && (
                  <button className="icons ig-btn" onClick={handleChangeAddInquiry}>
                    <span title="Create Inquiry" className="text-white">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="26px"
                        viewBox="0 -960 960 960"
                        width="26px"
                        fill="currentColor"
                      >
                        <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                      </svg>
                    </span>
                  </button>
                )}
                {contactData ? (
                  <span></span>
                ) : (
                  <button
                    className="icons pP ig-btn"
                    style={{ marginBottom: "50px" }}
                    onClick={handelFilterInq}
                  >
                    <span className="text-white" title="Filter">
                      <svg
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="24px"
                        fill={hasData ? "red" : "currentColor"}
                      >
                        <path d="M440-160q-17 0-28.5-11.5T400-200v-240L168-736q-15-20-4.5-42t36.5-22h560q26 0 36.5 22t-4.5 42L560-440v240q0 17-11.5 28.5T520-160h-80Zm40-308 198-252H282l198 252Zm0 0Z" />
                      </svg>
                    </span>
                  </button>
                )}
                <button
                  className="icons pP ig-btn"
                  style={{ marginBottom: "50px" }}
                  onClick={handleExportClick}
                >

                  <span className="text-white" title="Inquiry Export">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="24px"
                      viewBox="0 -960 960 960"
                      width="24px"
                      fill="currentColor"
                    >
                      <path d="M480-480ZM202-65l-56-57 118-118h-90v-80h226v226h-80v-89L202-65Zm278-15v-80h240v-440H520v-200H240v400h-80v-400q0-33 23.5-56.5T240-880h320l240 240v480q0 33-23.5 56.5T720-80H480Z" />
                    </svg>
                  </span>
                </button>
                <button
                  className="icons pP ig-btn"
                  style={{ marginBottom: "50px" }}
                  onClick={handelRefreshInquiry}
                >
                  <span className="text-white" title="Refresh">
                    <svg width="30" height="30" viewBox="0 0 50 50">
                      <path
                        fill="currentColor"
                        d="M25 38c-7.2 0-13-5.8-13-13 0-3.2 1.2-6.2 3.3-8.6l1.5 1.3C15 19.7 14 22.3 14 25c0 6.1 4.9 11 11 11 1.6 0 3.1-.3 4.6-1l.8 1.8c-1.7.8-3.5 1.2-5.4 1.2z"
                      />
                      <path
                        fill="currentColor"
                        d="M34.7 33.7l-1.5-1.3c1.8-2 2.8-4.6 2.8-7.3 0-6.1-4.9-11-11-11-1.6 0-3.1.3-4.6 1l-.8-1.8c1.7-.8 3.5-1.2 5.4-1.2 7.2 0 13 5.8 13 13 0 3.1-1.2 6.2-3.3 8.6z"
                      />
                      <path fill="currentColor" d="M18 24h-2v-6h-6v-2h8z" />
                      <path fill="currentColor" d="M40 34h-8v-8h2v6h6z" />
                    </svg>
                  </span>
                </button>
              </div>
            </div>
            {canView ? (
              <div className="search-bar">
                <div>
                  <button className="search ig-btn">
                    <span className="">
                      <svg
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        className=""
                      >
                        <path
                          fill="currentColor"
                          d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"
                        ></path>
                      </svg>
                    </span>
                  </button>

                  <span className="go-back">
                    <svg
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path
                        fill="currentColor"
                        d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                      ></path>
                    </svg>
                  </span>

                  <input
                    type="text"
                    title="Search or start new chat"
                    aria-label="Search or start new chat"
                    placeholder="Search Inquiry"
                    maxLength={SMALL_TEXT_LENGTH}
                    value={searchTerm}
                    onChange={handleSearchChange}
                  />
                </div>
              </div>
            ) : (
              <span></span>
            )}

            <div
              className="chats"
              style={{ height: "calc(90% - 112px)" }}
              ref={listInnerRef}
            >
              <>
                {loading ? (
                  Array.from({ length: 12 }).map((_, index) => (
                    <button key={index} className="block chat-list ig-btn">
                      <div className="h-text">
                        <div className="head">
                          <h4 className="inquiry-front">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                          </h4>
                          <h4
                            className="text-end"
                          >
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={30}
                              height={10}
                            />
                          </h4>
                        </div>

                        <div className="head">
                          <h4 className="inquiry-front">
                            <Skeleton
                              width={100}
                              style={{
                                opacity: darkMode ? "" : 0.5,
                                marginLeft: "10px",
                              }}
                            // height={10}
                            />
                          </h4>
                          <p className="time">
                            <Skeleton
                              width={80}
                              style={{ opacity: darkMode ? "" : 0.5 }}
                              height={10}
                            />
                          </p>
                        </div>
                        <button className="icon-more float-end">
                          <Skeleton
                            style={{
                              marginLeft: "10px",
                              opacity: darkMode ? "" : 0.5,
                            }}
                            width={30}
                          />
                        </button>
                        <div className="head">
                          <h4 className="inquiry-front">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                          </h4>
                        </div>
                        <div className="head">
                          <Skeleton
                            style={{
                              marginLeft: "10px",
                              opacity: darkMode ? "" : 0.5,
                            }}
                            width={100}
                          />
                        </div>

                        <div className="">
                          <label className="float-start inquiry-front">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                          </label>
                          <br />
                          <p className=" d-flex justify-content-between text-break text-start inquiry-front">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                            <div className="">
                              <span className="badge rounded-pill">
                                <Skeleton
                                  style={{
                                    marginLeft: "10px",
                                    opacity: darkMode ? "" : 0.5,
                                  }}
                                  width={40}
                                />
                              </span>
                            </div>
                          </p>
                        </div>
                      </div>
                    </button>
                  ))
                ) :
                  canView ? (
                    inquiryList &&
                    inquiryList.map((item, index) => (
                      <>
                        <div key={item.id}>
                          <ul
                            ref={(el) => (dropdownRef.current[item.id] = el)}
                            className={`right_label_dropLeft ${inquiryId === item.id && labelDropdownOpen
                              ? "isVisible"
                              : "isHidden"
                              }`}
                            style={{ width: "160px" }}
                          >
                            <li
                              className="listItem"
                              onClick={() => handleModalOpen(item.id)}
                            >
                              Assign label
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              onClick={() => handleModalOpenStatusAssign(item.id)}
                            >
                              Assign Status/Stage
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              onClick={() => handelChangeEdit(item)}
                            >
                              Edit
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              onClick={handleChangeDeleInquiry}
                            >
                              Delete
                            </li>
                            {item.is_reminder ? (
                              <span></span>
                            ) : (
                              <li
                                className="listItem"
                                role="button"
                                onClick={() => handleModalOpenReminder(item.id)}
                              >
                                Reminder
                              </li>
                            )}
                          </ul>
                        </div>

                        <button
                          key={index}
                          className="block chat-list"
                        >
                          <div className="h-text">
                            <div className="head">
                              <div className="d-flex align-items-center">
                                <h4
                                  className="text-start"
                                  style={{ fontSize: "16px" }}
                                >
                                  <b>#{item.id}</b>
                                </h4>
                                <ul
                                  style={{
                                    marginBottom: "0px",
                                    paddingLeft: "0px",
                                  }}
                                  className="px-2"
                                >
                                  {item.label_color
                                    ? item.label_color
                                      .split(",")
                                      .map((color, index) => (
                                        <li
                                          key={index}
                                          style={{
                                            listStyleType: "none", // Remove default bullet points
                                            display: "inline-block",
                                            marginRight: "2px",
                                          }}
                                        >
                                          <span
                                            style={{
                                              background: color,
                                              display: "inline-block",
                                              width: "10px",
                                              height: "10px",
                                              borderRadius: "50%",
                                              marginRight: "-5px",
                                            }}
                                            title={
                                              item.label_name.split(",")[index]
                                            }
                                          ></span>
                                        </li>
                                      ))
                                    : <span></span>}
                                </ul>
                              </div>

                              <button
                                className="icon-more float-end"
                                onClick={() => toggleDropdownLabel(item.id)}
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  viewBox="0 0 19 20"
                                  width="19"
                                  height="20"
                                  className="hide animate__animated animate__fadeInUp"
                                >
                                  <path
                                    fill="currentColor"
                                    d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                  ></path>
                                </svg>
                              </button>
                            </div>
                            <div className="head">
                              <h4 className="inquiry-front">
                                <b> Contact Name </b> :
                                {item.contact_person_name
                                  ? item.contact_person_name
                                  : ""}
                              </h4>
                            </div>
                            {item.is_reminder ? (
                              <button className="icon-more float-end">
                                <span
                                  role="button"
                                  onClick={() =>
                                    handleChangeStatusOfReminder(item)
                                  }
                                >
                                  <svg
                                    height="16px"
                                    viewBox="0 -960 960 960"
                                    width="16 px"
                                    className=""
                                    fill="currentColor"
                                  >
                                    <path d="M480-80q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-440q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-800q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-440q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-80Zm0-360Zm112 168 56-56-128-128v-184h-80v216l152 152ZM224-866l56 56-170 170-56-56 170-170Zm512 0 170 170-56 56-170-170 56-56ZM480-160q117 0 198.5-81.5T760-440q0-117-81.5-198.5T480-720q-117 0-198.5 81.5T200-440q0 117 81.5 198.5T480-160Z" />
                                  </svg>
                                </span>
                              </button>
                            ) : (
                              <span></span>
                            )}
                            <div className="head">
                              <h4 className="inquiry-front">
                                <b> Product Category Name </b> :
                                {item.category_name ? item.category_name : ""}
                              </h4>
                            </div>

                            <div className="head">
                              <h4 className="inquiry-front">
                                <b>Product Name</b> :
                                {item.product_name ? item.product_name : ""}
                              </h4>
                              <div className="text-end">
                                <span
                                  style={{
                                    backgroundColor: item.source_name_color
                                      ? item.source_name_color
                                      : "#eeeeee ",
                                  }}
                                  className="badge rounded-pill"
                                >
                                  {item.source_name}
                                </span>
                              </div>
                            </div>
                            <div className="head">

                              <h4 className="inquiry-front">
                                <b>Required Quantity </b> :
                                {item.qty ? item.qty : ""}
                              </h4>
                              <div className="text-end">
                                <span
                                  style={{
                                    backgroundColor: item.stage_status_color
                                      ? item.stage_status_color
                                      : "#eeeeee ",
                                  }}
                                  className="badge rounded-pill"
                                >
                                  {item.stage_status_name}
                                </span>
                              </div>
                            </div>
                            <div className="head">
                              <h4 className="inquiry-front">
                                <b>Requirement Type </b>:
                                {item.static === 0 ? "One Time" : " Recurring"}
                              </h4>
                            </div>

                            <div className="">
                              <label className="float-start inquiry-front">
                                <b>Description : </b>
                              </label>
                              <br />
                              <p className=" d-flex justify-content-between text-break text-start inquiry-front">
                                {item.description ? (
                                  <SafeHtml htmlContent={item.description} />
                                ) : (
                                  ""
                                )}
                              </p>
                            </div>
                            <div className=" text-end">
                              <p className="contact-text">
                                {item.create_date_time
                                  ? convertDateTimeFormat(item.create_date_time)
                                    .date
                                  : ""}
                              </p>
                            </div>
                            <div className=" text-end">
                              <p className="contact-text">
                                {item.create_date_time
                                  ? convertDateTimeFormat(item.create_date_time)
                                    .time
                                  : ""}
                              </p>
                            </div>
                          </div>
                        </button>
                      </>
                    ))
                  ) : (
                    <p className="text-danger p-1">
                      {DEFAULT_MESSAGE_ERROR_PERMISSION}
                    </p>
                  )}
              </>
              {(searchTerm || hasData) && noDataFound && (
                <p className="no_found">No data found</p>
              )}
            </div>
          </div>
        </>
      ) : null}
      {editInquiry && (
        <CreateInquiryView
          show={editInquiry}
          onHide={() => setEditInquiry(false)}
          setRefreshInquiry={setRefreshInquiry}
          contactData={inquiryToEdit}
          contact_id={contactData?.id}
          headerName="Edit Inquiry"
        />
      )}
      {contactData ? (
        <CheckBoxModal
          show={isModalVisible}
          onHide={handleModalClose}
          handleSubmit={handleConfirm}
          title="Assign your label"
          message="Please select the labels for this Inquiry."
          btn1="Cancel"
          btn2="Submit"
          options={options}
          selectedLabelIds={
            inquiryList.find((item) => item.id === inquiryId)?.label_id
          }
          contactId={inquiryId}
          getOptionColor={(option) => option.color || "#eeeeee"}
          getOptionName={(option) => option.lable_name}
          showColorBadge={true}
        />
      ) : (
        <CheckBoxModal
          show={isModalVisible}
          onHide={handleModalClose}
          handleSubmit={handleConfirm}
          title="Assign your label"
          message="Please select the labels for this Inquiry."
          btn1="Cancel"
          btn2="Submit"
          options={options}
          selectedLabelIds={
            inquiryList.find((item) => item.id === inquiryId)?.label_id
          }
          contactId={inquiryId}
          getOptionColor={(option) => option.color || "#eeeeee"}
          getOptionName={(option) => option.lable_name}
          showColorBadge={true}
        />
      )}
      {isSetReminderConfirmation && (
        <ReminderModal
          show={isSetReminderConfirmation}
          onHide={() => setIsSetReminderConfirmation(false)}
          handleSubmit={handleReminder}
          title={` Set Reminder of Inquiry`}
          message={"Are you sure you want delete is message? "}
          btn1="CANCEL"
          btn2="set Reminder"
          request_flag="3"
        />
      )}
      <RadioButtonModal
        show={isModalAssignStatusVisible}
        onHide={() => setIsModalAssignStatusVisible(false)}
        handleSubmit={handleConfirmInquiriesRadioButton}
        title="Assign your Status"
        message="Please select the Status for this Inquiry."
        btn1="Cancel"
        btn2="Submit"
        options={optionRadioButtonStatus}
        selectedLabelIds={
          inquiryList.find((item) => item.id === statusAssignContactId)
            ?.contact_status
        }
        contactId={statusAssignContactId}
        getOptionColor={(option) => option.color || "#eeeeee"}
        getOptionName={(option) => option.name}
        showColorBadge={true}
      />
      {isReminderConfirmationStatus && (
        <ConfirmationModal
          show={isReminderConfirmationStatus}
          onHide={() => setIsReminderConfirmationStatus(false)}
          handleSubmit={() =>
            handleChangeStatusOfReminderForInquiry(
              inquiryId,
              setIsReminderConfirmationStatus,
              setRefreshInquiry
            )
          }
          title={"Are you sure you want to complete this Reminder?"}
          message={`Remark : ${reminderData && reminderData.reminder_remark}`}
          btn1="CANCEL"
          btn2="Complete Reminder Now"
          message1={`Reminder Date : ${reminderData && formatDateAndTime(reminderData.reminder_data_time)
            }`}
        />
      )}
      {isDeleteConfirmation && (
        <ConfirmationModal
          show={isDeleteConfirmation}
          onHide={() => setIsDeleteConfirmation(false)}
          handleSubmit={handleDeleteInquiry}
          title={"Delete this Inquiry"}
          message={"Are You Sure You Want To Delete This Inquiry?"}
          btn1="CANCEL"
          btn2="DELETE"
        />
      )}
      <CreateInquiryView
        show={isCreateInquiry}
        onHide={() => setIsCreateInquiry(false)}
        setRefreshInquiry={setRefreshInquiry}
        contact_id={contactData?.id}
        headerName="Create Inquiry"
      />
      <CheckBoxFilterModal
        show={isModalFilterVisible}
        onHide={handleModalClose}
        handleSubmit={handleConfirmFilter}
        title="Filter your Inquiry"
        message="Please select  the labels , source , Status and Category / Product for the Inquiry."
        btn1="Clear"
        btn2="Apply"
        filtersToShow={[1, 2, 3, 4, 7]}
        pageId={2}
      />
    </>
  );
};

export default ListInquiryView;
