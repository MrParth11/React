import React, { useEffect, useRef, useState } from "react";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import { useTheme } from "../../../components/ThemeContext";
import {
  convertDateTimeFormat,
  formatDate,
  formatDateAndTime,
  formatDateTimeSendDataBase,
} from "../../../common/SharedFunction";  
import { axiosInstance } from "../../../services/axiosInstance";
import {
  DEFAULT_MESSAGE_ERROR_PERMISSION,
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";
import { toast } from "react-toastify";
import ConfirmationModal from "../../../components/model/ConfirmationModal";
import CheckBoxFilterModal from "../../../components/model/CheckBoxFilterModal";
import { TReactSetState } from "../../../helpers/AppType";
import CreateAccountTransactionView from "../create-account-transaction/CreateAccountTransactionView";
import {
  fetchApiAccountTransitions,
  IAccountTransaction,
} from "./ListAccounTransactionController";
import {
  paymentModeList,
  paymentTypesList,
} from "../create-account-transaction/CreateAccountTransactionController";
import SafeHtml from "../../../components/SafeHtml";
import useCheckUserPermission from "../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../helpers/AppEnum";
import { date } from "yup";

interface IPropsListAccountTransaction {
  isListAccountTransaction: boolean;
  closeListAccountTransaction: () => void;
  contactData?: any;
  setNoDataFound1: TReactSetState<boolean>;
}

const ListAccountTransactionView = ({
  isListAccountTransaction,
  closeListAccountTransaction,
  contactData,
  setNoDataFound1,
}: IPropsListAccountTransaction) => {
  const listInnerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<Record<number, HTMLUListElement | null>>({});
  const dropdownContactRef = useRef<Record<number, HTMLUListElement | null>>(
    {}
  );
  let itemsPerPage: number = 10;

  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const { darkMode } = useTheme();
  const [noDataFound, setNoDataFound] = useState(false);
  const [accountTransactionList, setAccountTransactionList] = useState<
    IAccountTransaction[]
  >([]);

  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [isApproveConfirmation, setIsApproveConfirmation] = useState(false);

  const [editInquiry, setEditInquiry] = useState(false);
  const [isCreateAccountTransaction, setIsCreateAccountTransaction] =
    useState(false);
  const [isEditAccountTransaction, setIsEditAccountTransaction] =
    useState(false);

  const [debitDropdownOpen, setDebitDropdownOpen] = useState<any>(null);
  const [creditDropdownOpen, setCreditDropdownOpen] = useState<any>(null);
  const [creditDropdownOpenId, setCreditDropdownOpenId] = useState<number>();
  const [debitDropdownOpenId, setDebitDropdownOpenId] = useState<number>();
  const [filterParams, setFilterParams] = useState({
    startSearchDate: "",
    endSearchDate: "",
  });
  const [approveId, setApproveId] = useState<number>();
  const [accountTransactionDeleteId, setAccountTransactionDeleteId] =
    useState<number>();

  const [accountTransactionItemId, setAccountTransactionItemId] =
    useState<IAccountTransaction>();

  const [isModalFilterVisible, setIsModalFilterVisible] =
    useState<boolean>(false);
  const [hasData, setHasData] = useState<boolean>(false);
  const [closingBalance, setClosingBalance] = useState<number>(0);
  const [refreshTransactions, setRefreshTransactions] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(
    null
  );

  const canAdd = useCheckUserPermission(
    PAGE_ID.ACCOUNT_HISTORY,
    PERMISSION_TYPE.ADD
  );

  const canEdit = useCheckUserPermission(
    PAGE_ID.ACCOUNT_HISTORY,
    PERMISSION_TYPE.EDIT
  );
  const canDelete = useCheckUserPermission(
    PAGE_ID.ACCOUNT_HISTORY,
    PERMISSION_TYPE.DELETE
  );
  const canApprove = useCheckUserPermission(
    PAGE_ID.ACCOUNT_HISTORY,
    PERMISSION_TYPE.APPROVE
  );

  useEffect(() => {
    const handleScroll = () => {
      if (
        listInnerRef.current &&
        listInnerRef.current.scrollTop + listInnerRef.current.clientHeight ===
        listInnerRef.current.scrollHeight
      ) {
        if (
          accountTransactionList.length <
          (currentPage + 1) * itemsPerPage + 1
        ) {
          fetchApiAccountTransitions(
            currentPage + 1,
            searchTerm,
            setAccountTransactionList,
            itemsPerPage,
            setLoading,
            contactData.id,
            setClosingBalance,
            filterParams.startSearchDate,
            filterParams.endSearchDate
          );
        }
        setCurrentPage((prevPage) => prevPage + 1);
      }
    };

    const listInnerElement = listInnerRef.current;

    if (listInnerElement) {
      listInnerElement.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (listInnerElement) {
        listInnerElement.removeEventListener("scroll", handleScroll);
      }
    };
  }, [currentPage, accountTransactionList.length, searchTerm, itemsPerPage]);

  useEffect(() => {
    if (contactData?.id) {
      setClosingBalance(0);
      setAccountTransactionList([]);
      closeListAccountTransaction();
    } else {
      return undefined;
    }
  }, [contactData?.id]);

  const handleModalClose = () => {
    if (isModalVisible) {
      setIsModalVisible(false);
    } else {
      setIsModalFilterVisible(false);
    }
  };

  const handleClickOutside = (event: { target: any }) => {
    const clickedOutside = Object.values(dropdownRef.current).every(
      (ref) => ref && !ref.contains(event.target)
    );
    if (clickedOutside) {
      setDebitDropdownOpen(null);
    }
  };

  useEffect(() => {
    if (debitDropdownOpen !== null) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [debitDropdownOpen]);

  const handleClickOutside1 = (event: { target: any }) => {
    const clickedOutside = Object.values(dropdownContactRef.current).every(
      (ref) => ref && !ref.contains(event.target)
    );
    if (clickedOutside) {
      setCreditDropdownOpen(null);
    }
  };

  useEffect(() => {
    if (creditDropdownOpen !== null) {
      document.addEventListener("mousedown", handleClickOutside1);
    } else {
      document.removeEventListener("mousedown", handleClickOutside1);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside1);
    };
  }, [creditDropdownOpen]);
  const handleDeleteAccountTransaction = async () => {
    const requestData = {
      table: "account_transactions",
      where: `{"id":${accountTransactionDeleteId}}`,
      data: `{"isDelete":"1"}`,
    };
    const getUUID = localStorage.getItem("UUID")
    try {
      const data = await axiosInstance.post("commonUpdate", requestData,
        {
          headers: {
            "x-tenant-id": getUUID,

          },
        }
      );
      if (data.data.code === 200) {
        if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          setIsDeleteConfirmation(false);
          fetchApiAccountTransitions(
            0,
            "",
            setAccountTransactionList,
            itemsPerPage,
            setLoading,
            contactData.id,
            setClosingBalance,
            filterParams.startSearchDate,
            filterParams.endSearchDate
          );
        } else {
          toast.error(data.data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      }
    } catch (error: any) {
      toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  };

const handleApproveAccountTransaction = async () => {
  try {
    const currentDateTime = new Date();
    const formattedDateTime = formatDateTimeSendDataBase(currentDateTime);
    const getUUID = await localStorage.getItem("UUID");
    const token = await localStorage.getItem("token");

    const requestData = {
      table: "account_transactions",
      where: JSON.stringify({ id: approveId }),
      data: JSON.stringify({
        approve_by_a_application_login_id: getUUID,
        approve_date_time: formattedDateTime,
      }),
      a_application_login_id: getUUID, // Ensure this is sent
    };

    const { data } = await axiosInstance.post("accountTransactionUpdate", requestData, {
      headers: {
        Authorization: token,
        "x-tenant-id": getUUID,
      },
    });

    if (data.code === 200 && data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setIsApproveConfirmation(false);
      fetchApiAccountTransitions(
        0,
        "",
        setAccountTransactionList,
        itemsPerPage,
        setLoading,
        contactData.id,
        setClosingBalance,
        filterParams.startSearchDate,
        filterParams.endSearchDate
      );
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    console.error("Transaction approval error:", error);
    toast.error(error.message || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

  const handelRefreshAccountTransition = async () => {
    fetchApiAccountTransitions(
      0,
      "",
      setAccountTransactionList,
      itemsPerPage,
      setLoading,
      contactData.id,
      setClosingBalance,
      filterParams.startSearchDate,
      filterParams.endSearchDate
    );
  };


  const handleConfirmFilter = async (
    filterData: any,
    checkedOptions: any,
    checkedSourceTypes: any,
    startSearchDate: string,
    endSearchDate: string,
    checkedOptionsStageStatus: any,
    checkedOptionsUser: any,
    selectedCategoryId: any,
    selectedProductId: any
  ) => {
    console.log("selectedCategoryId", selectedCategoryId, selectedProductId);
    setFilterParams({
      startSearchDate,
      endSearchDate,
    });

    setHasData(startSearchDate !== "" || endSearchDate !== "");
    await fetchApiAccountTransitions(
      0,
      "",
      setAccountTransactionList,
      itemsPerPage,
      setLoading,
      contactData.id,
      setClosingBalance,
      startSearchDate,
      endSearchDate
    );

    setIsModalFilterVisible(false);
  };

  const handelChangeAccountTractionApprove = (id: number) => {
    if (canApprove) {
      setApproveId(id);
      setIsApproveConfirmation(true);
    } else {
      setIsApproveConfirmation(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelChangeAccountTractionEdit = (itemId: IAccountTransaction) => {
    if (canEdit) {
      setAccountTransactionItemId(itemId);
      setIsEditAccountTransaction(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handelChangeAccountTractionDelete = (id: number) => {
    if (canDelete) {
      setAccountTransactionDeleteId(id);
      setIsDeleteConfirmation(true);
    } else {
      setIsDeleteConfirmation(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const toggleDropdownDebit = (id: number) => {
    setDebitDropdownOpenId(id);
    setDebitDropdownOpen((prevId: any) => (prevId === id ? null : id));
  };

  const toggleDropdownCredit = (id: number) => {
    console.log("sjdjdjkdk", id);

    setCreditDropdownOpenId(id);
    setCreditDropdownOpen((prevId: any) => (prevId === id ? null : id));
  };
  useEffect(() => {
    if (isListAccountTransaction && contactData.id) {
      fetchApiAccountTransitions(
        0,
        "",
        setAccountTransactionList,
        itemsPerPage,
        setLoading,
        contactData.id,
        setClosingBalance,
        filterParams.startSearchDate,
        filterParams.endSearchDate
      );
      setClosingBalance(0);
      setAccountTransactionList([]);
    }
  }, [isListAccountTransaction]);
  useEffect(() => {
    if (refreshTransactions) {
      fetchApiAccountTransitions(
        0,
        "",
        setAccountTransactionList,
        itemsPerPage,
        setLoading,
        contactData.id,
        setClosingBalance,
        filterParams.startSearchDate,
        filterParams.endSearchDate
      );
      setRefreshTransactions(false);
    }
  }, [refreshTransactions]);

  function openSearch() {
    setSearchOpen(!searchOpen);
  }

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setSearchTerm(value);
    if (value.length >= 3 || value === "") {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
      setSearchTimeout(
        setTimeout(() => {
          fetchApiAccountTransitions(
            0,
            value,
            setAccountTransactionList,
            itemsPerPage,
            setLoading,
            contactData.id,
            setClosingBalance,
            filterParams.startSearchDate,
            filterParams.endSearchDate
          );
          setCurrentPage(0);
        }, 1000)
      );
    }
  };

  const handleSearchClear = () => {
    setSearchTerm("");
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }
    setSearchOpen(!searchOpen);
    setSearchTimeout(
      setTimeout(() => {
        fetchApiAccountTransitions(
          0,
          "",
          setAccountTransactionList,
          itemsPerPage,
          setLoading,
          contactData.id,
          setClosingBalance,
          filterParams.startSearchDate,
          filterParams.endSearchDate
        );
        setCurrentPage(0);
      }, 1000)
    );
  };
  function openModelAdd() {
    if (canAdd) {
      setIsCreateAccountTransaction(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  }
  function closingBalancedate() {

    const rawDate = filterParams.endSearchDate || new Date();
    const date = new Date(rawDate);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;

  }


  return (
    <>
      {isListAccountTransaction ? (
        <>
          <div className="leftSide " id="search-message">
            <div className="header-Chat">
              <div className="ICON">
                <button
                  className="icons"
                  onClick={() => closeListAccountTransaction()}
                >
                  <span className="text-white" title="Close">
                    <svg
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path d="m19.1 17.2-5.3-5.3 5.3-5.3-1.8-1.8-5.3 5.4-5.3-5.3-1.8 1.7 5.3 5.3-5.3 5.3L6.7 19l5.3-5.3 5.3 5.3 1.8-1.8z"></path>
                    </svg>
                  </span>
                </button>
              </div>

              <div className="newText " style={{ width: "90%" }}>
                <h2> Account History</h2>
              </div>
              <div className="w-100 text-end">
                <button
                  className="icons text-white"
                  onClick={openSearch}
                  title="Search"
                >
                  <svg viewBox="0 0 24 24" width="24" height="24" className="">
                    <path
                      fill="currentColor"
                      d="M15.9 14.3H15l-.3-.3c1-1.1 1.6-2.7 1.6-4.3 0-3.7-3-6.7-6.7-6.7S3 6 3 9.7s3 6.7 6.7 6.7c1.6 0 3.2-.6 4.3-1.6l.3.3v.8l5.1 5.1 1.5-1.5-5-5.2zm-6.2 0c-2.6 0-4.6-2.1-4.6-4.6s2.1-4.6 4.6-4.6 4.6 2.1 4.6 4.6-2 4.6-4.6 4.6z"
                    ></path>
                  </svg>
                </button>

                <button className="icons text-white" onClick={openModelAdd}>
                  <span title="Create Account Transaction">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="26px"
                      viewBox="0 -960 960 960"
                      width="26px"
                      fill="currentColor"
                    >
                      <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                    </svg>
                  </span>
                </button>
                <button
                  className="icons pP"
                  style={{ marginBottom: "50px" }}
                  onClick={() => setIsModalFilterVisible(true)}
                >
                  <span className="text-white" title="Filter">
                    <svg
                      height="24px"
                      viewBox="0 -960 960 960"
                      width="24px"
                      fill={hasData ? "red" : "currentColor"}
                    >
                      <path d="M440-160q-17 0-28.5-11.5T400-200v-240L168-736q-15-20-4.5-42t36.5-22h560q26 0 36.5 22t-4.5 42L560-440v240q0 17-11.5 28.5T520-160h-80Zm40-308 198-252H282l198 252Zm0 0Z" />
                    </svg>
                  </span>
                </button>
                <button
                  className="icons pP"
                  style={{ marginBottom: "50px" }}
                  // onClick={() => setIsModalFilterVisible(true)}
                >
                  <span className="text-white" title="Download">
                    <svg
                      height="24px"
                      viewBox="0 -960 960 960"
                      width="24px"
                      fill="currentColor"
                    >
                      <path d="M480-320 280-520l56-58 104 104v-326h80v326l104-104 56 58-200 200ZM240-160q-33 0-56.5-23.5T160-240v-120h80v120h480v-120h80v120q0 33-23.5 56.5T720-160H240Z" />
                    </svg>
                  </span>
                </button>

                <button
                  className="icons pP"
                  style={{ marginBottom: "50px" }}
                  onClick={handelRefreshAccountTransition}
                >
                  <span className="text-white" title="Refresh">
                    <svg width="30" height="30" viewBox="0 0 50 50">
                      <path
                        fill="currentColor"
                        d="M25 38c-7.2 0-13-5.8-13-13 0-3.2 1.2-6.2 3.3-8.6l1.5 1.3C15 19.7 14 22.3 14 25c0 6.1 4.9 11 11 11 1.6 0 3.1-.3 4.6-1l.8 1.8c-1.7.8-3.5 1.2-5.4 1.2z"
                      />
                      <path
                        fill="currentColor"
                        d="M34.7 33.7l-1.5-1.3c1.8-2 2.8-4.6 2.8-7.3 0-6.1-4.9-11-11-11-1.6 0-3.1.3-4.6 1l-.8-1.8c1.7-.8 3.5-1.2 5.4-1.2 7.2 0 13 5.8 13 13 0 3.1-1.2 6.2-3.3 8.6z"
                      />
                      <path fill="currentColor" d="M18 24h-2v-6h-6v-2h8z" />
                      <path fill="currentColor" d="M40 34h-8v-8h2v6h6z" />
                    </svg>
                  </span>
                </button>
              </div>
            </div>
            {searchOpen && (
              <div className="header-search" style={{ zIndex: "1" }}>
                <div className="search-bar">
                  <div className=" d-flex justify-content-between">
                    <button className="search">
                      <span className="">
                        <svg
                          viewBox="0 0 24 24"
                          width="24"
                          height="24"
                          className=""
                        >
                          <path
                            fill="currentColor"
                            d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"
                          ></path>
                        </svg>
                      </span>
                    </button>

                    <span className="go-back">
                      <svg
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        className=""
                      >
                        <path
                          fill="currentColor"
                          d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                        ></path>
                      </svg>
                    </span>

                    <input
                      type="text"
                      title="Search "
                      aria-label="Search or start new chat"
                      placeholder="Search"
                      value={searchTerm}
                      onChange={handleSearchChange}
                      className="search-message-input"
                    />

                    <span
                      role="button"
                      className="p-1"
                      onClick={handleSearchClear}
                    >
                      <svg
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="24px"
                        fill="#5f6368"
                      >
                        <path d="M280-80q-83 0-141.5-58.5T80-280q0-83 58.5-141.5T280-480q83 0 141.5 58.5T480-280q0 83-58.5 141.5T280-80Zm544-40L568-376q-12-13-25.5-26.5T516-428q38-24 61-64t23-88q0-75-52.5-127.5T420-760q-75 0-127.5 52.5T240-580q0 6 .5 11.5T242-557q-18 2-39.5 8T164-535q-2-11-3-22t-1-23q0-109 75.5-184.5T420-840q109 0 184.5 75.5T680-580q0 43-13.5 81.5T629-428l251 252-56 56Zm-615-61 71-71 70 71 29-28-71-71 71-71-28-28-71 71-71-71-28 28 71 71-71 71 28 28Z" />
                      </svg>
                    </span>
                  </div>
                </div>
              </div>
            )}


            <div
              className="chats"
              style={{ height: "550px" }}
              ref={listInnerRef}
            >
              <div className="row p-2">
                {loading && isListAccountTransaction && contactData.id ? (
                  Array.from({ length: 12 }).map((_, index) => (
                    <button key={index} className="block chat-list">
                      <div className="h-text">
                        <div className="head">
                          <h4 className="inquiry-front">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                          </h4>
                          <h4
                            className="text-end"
                          >
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={30}
                              height={10}
                            />
                          </h4>
                        </div>

                        <div className="head">
                          <h4 className="inquiry-front">
                            <Skeleton
                              width={100}
                              style={{
                                opacity: darkMode ? "" : 0.5,
                                marginLeft: "10px",
                              }}
                            />
                          </h4>
                          <p className="time">
                            <Skeleton
                              width={80}
                              style={{ opacity: darkMode ? "" : 0.5 }}
                              height={10}
                            />
                          </p>
                        </div>
                        <button className="icon-more float-end">
                          <Skeleton
                            style={{
                              marginLeft: "10px",
                              opacity: darkMode ? "" : 0.5,
                            }}
                            width={30}
                          />
                        </button>
                        <div className="head">
                          <h4 className="inquiry-front">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                          </h4>
                        </div>
                        <div className="head">
                          <Skeleton
                            style={{
                              marginLeft: "10px",
                              opacity: darkMode ? "" : 0.5,
                            }}
                            width={100}
                          />
                        </div>

                        <div className="">
                          <label className="float-start inquiry-front">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                          </label>
                          <br />
                          <p className=" d-flex justify-content-between text-break text-start inquiry-front">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                            <div className="">
                              <span className="badge rounded-pill">
                                <Skeleton
                                  style={{
                                    marginLeft: "10px",
                                    opacity: darkMode ? "" : 0.5,
                                  }}
                                  width={40}
                                />
                              </span>
                            </div>
                          </p>
                        </div>
                      </div>
                    </button>
                  ))
                ) : (
                  <>
                    <button className="block chat-list">
                      <div className="h-text">
                        <div className="text-center">
                          <b>
                            Closing Balance on&nbsp;
                            {
                              filterParams.endSearchDate
                                ? formatDate(filterParams.endSearchDate)
                                : formatDate(new Date().toDateString())
                            }
                          </b>


                          <h4
                            className={`account-transaction-front-amount ${closingBalance !== undefined && closingBalance < 0
                              ? "text-danger"
                              : "text-success"
                              } `}
                          >
                            <b>
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                height="22px"
                                viewBox="0 -960 960 960"
                                width="22px"
                                fill="currentColor"
                                style={{ fontWeight: "bold" }}
                              >
                                <path d="M549-120 280-400v-80h140q53 0 91.5-34.5T558-600H240v-80h306q-17-35-50.5-57.5T420-760H240v-80h480v80H590q14 17 25 37t17 43h88v80h-81q-8 85-70 142.5T420-400h-29l269 280H549Z" />
                              </svg>
                            </b>
                            <b> {Math.abs(closingBalance)}</b>
                          </h4>
                        </div>
                      </div>
                    </button>
                    {accountTransactionList &&
                      accountTransactionList
                        .map((item, index) => (
                          <>
                            {Number(item.type) === 2 ? (
                              <>
                                <div>
                                  <ul
                                    className={`labelDropLeft 
                                   ${item.id === debitDropdownOpenId &&
                                        debitDropdownOpen
                                        ? "isVisible"
                                        : "isHidden"
                                      }
                                    `}
                                    ref={(el) =>
                                      (dropdownRef.current[item.id] = el)
                                    }
                                    style={{
                                      width: "125px",
                                    }}
                                  >
                                    <li
                                      className="listItem"
                                      role="button"
                                      onClick={() =>
                                        handelChangeAccountTractionEdit(item)
                                      }
                                    >
                                      Edit
                                    </li>
                                    <li
                                      className="listItem"
                                      role="button"
                                      onClick={() =>
                                        handelChangeAccountTractionDelete(
                                          item.id
                                        )
                                      }
                                    >
                                      Delete
                                    </li>
                                  </ul>
                                </div>
                                <button key={index} className="block chat-list">
                                  <div className="h-text">
                                    <div className="text-start">
                                      <h4 className="account-transaction-front-id ">
                                        <b>#{item.id || ""}</b>
                                      </h4>
                                    </div>
                                    <div className="text-start">
                                      <h4 className="account-transaction-front-amount text-danger ">
                                        <b>
                                          <svg
                                            xmlns="http://www.w3.org/2000/svg"
                                            height="22px"
                                            viewBox="0 -960 960 960"
                                            width="22px"
                                            fill="currentColor"
                                            style={{ fontWeight: "bold" }}
                                          >
                                            <path d="M549-120 280-400v-80h140q53 0 91.5-34.5T558-600H240v-80h306q-17-35-50.5-57.5T420-760H240v-80h480v80H590q14 17 25 37t17 43h88v80h-81q-8 85-70 142.5T420-400h-29l269 280H549Z" />
                                          </svg>
                                        </b>
                                        <b>{item.amount || ""}</b>
                                      </h4>
                                    </div>

                                    <div className="text-start">
                                      <h4 className="account-transaction-front">
                                        {paymentModeList.find(
                                          (option) =>
                                            Number(option.id) ===
                                            Number(item.mode)
                                        )?.mode_name || ""}
                                      </h4>
                                    </div>
                                    <div className="text-start">
                                      <h4
                                        className="account-transaction-front"
                                        style={{
                                          width: "100%",
                                          wordBreak: "break-word",
                                        }}
                                      >
                                        <SafeHtml htmlContent={item.remark} />
                                      </h4>
                                    </div>
                                  </div>
                                  <div className=" col-4">
                                    {item.approve_by_a_application_login_id ===
                                      0 ? (
                                      <div
                                        className="text-end"
                                        onClick={() =>
                                          handelChangeAccountTractionApprove(
                                            item.id
                                          )
                                        }
                                      >
                                        <span
                                          style={{
                                            backgroundColor: "#f58634",
                                          }}
                                          className="badge rounded-pill "
                                        >
                                         Click Here To Approve
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}
                                    <div className="text-end">
                                      <button
                                        className="icon-more"
                                        onClick={() =>
                                          toggleDropdownDebit(item.id)
                                        }
                                      >
                                        <svg
                                          xmlns="http://www.w3.org/2000/svg"
                                          viewBox="0 0 19 20"
                                          width="19"
                                          height="20"
                                          className="hide animate__animated animate__fadeInUp"
                                        >
                                          <path
                                            fill="currentColor"
                                            d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                          ></path>
                                        </svg>
                                      </button>
                                    </div>


                                    <div className="head">

                                      <div className="text-end">

                                        <p className="contact-text">
                                          {item.payment_date_time
                                            ? convertDateTimeFormat(
                                              item.payment_date_time
                                            ).date
                                            : ""}
                                        </p>
                                        <p className="contact-text">
                                          {item.payment_date_time
                                            ? convertDateTimeFormat(
                                              item.payment_date_time
                                            ).time
                                            : ""}
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                </button>
                              </>
                            ) : (
                              <>
                                <div>
                                  <ul
                                    className={`credit-drop
                                     ${creditDropdownOpenId === item.id &&
                                        creditDropdownOpen
                                        ? "isVisible"
                                        : "isHidden"
                                      }
                                   `}
                                    ref={(el) =>
                                      (dropdownContactRef.current[item.id] = el)
                                    }
                                    style={{
                                      width: "125px",
                                    }}
                                  >
                                    <li
                                      className="listItem"
                                      role="button"
                                      onClick={() =>
                                        handelChangeAccountTractionEdit(item)
                                      }
                                    >
                                      Edit
                                    </li>
                                    <li
                                      className="listItem"
                                      role="button"
                                      onClick={() =>
                                        handelChangeAccountTractionDelete(
                                          item.id
                                        )
                                      }
                                    >
                                      Delete
                                    </li>
                                  </ul>
                                </div>
                                <button key={index} className="block chat-list">
                                  <div className="col-3">
                                    {item.approve_by_a_application_login_id ===
                                      0 ? (
                                      <div
                                        className="text-start"
                                        onClick={() =>
                                          handelChangeAccountTractionApprove(
                                            item.id
                                          )
                                        }
                                      >
                                        <span
                                          style={{
                                            backgroundColor: "#f58634",
                                          }}
                                          className="badge rounded-pill "
                                        >
                                          Click Here To Approve
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}
                                    <div className="text-start">
                                      <button
                                        className="icon-more"
                                        onClick={() =>
                                          toggleDropdownCredit(item.id)
                                        }
                                      >
                                        <svg
                                          xmlns="http://www.w3.org/2000/svg"
                                          viewBox="0 0 19 20"
                                          width="19"
                                          height="20"
                                          className="hide animate__animated animate__fadeInUp"
                                        >
                                          <path
                                            fill="currentColor"
                                            d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                          ></path>
                                        </svg>
                                      </button>
                                    </div>

                                    <div className="head">

                                      <div className="text-start">

                                        <p className="contact-text">
                                          {item.payment_date_time
                                            ? convertDateTimeFormat(
                                              item.payment_date_time
                                            ).date
                                            : ""}
                                        </p>
                                        <p className="contact-text">
                                          {item.payment_date_time
                                            ? convertDateTimeFormat(
                                              item.payment_date_time
                                            ).time
                                            : ""}
                                        </p>
                                      </div>
                                    </div>
                                  </div>

                                  <div className="h-text">
                                    <div className="text-end">
                                      <h4 className="account-transaction-front-id ">
                                        <b>#{item.id || ""}</b>
                                      </h4>
                                    </div>
                                    <div className="text-end">
                                      <h4 className="account-transaction-front-amount text-success ">
                                        <b>
                                          <svg
                                            xmlns="http://www.w3.org/2000/svg"
                                            height="22px"
                                            viewBox="0 -960 960 960"
                                            width="22px"
                                            fill="currentColor"
                                            style={{ fontWeight: "bold" }}
                                          >
                                            <path d="M549-120 280-400v-80h140q53 0 91.5-34.5T558-600H240v-80h306q-17-35-50.5-57.5T420-760H240v-80h480v80H590q14 17 25 37t17 43h88v80h-81q-8 85-70 142.5T420-400h-29l269 280H549Z" />
                                          </svg>
                                        </b>
                                        <b>{item.amount || ""}</b>
                                      </h4>
                                    </div>

                                    <div
                                      className=""
                                      style={{ textAlign: "end" }}
                                    >
                                      <h4 className="account-transaction-front">
                                        {paymentModeList.find(
                                          (option) =>
                                            Number(option.id) ===
                                            Number(item.mode)
                                        )?.mode_name || ""}
                                      </h4>
                                    </div>
                                    <div
                                      className=""
                                      style={{ textAlign: "end" }}
                                    >
                                      <h4
                                        className="account-transaction-front"
                                        style={{
                                          width: "100%",
                                          wordBreak: "break-word",
                                        }}
                                      >
                                        <SafeHtml htmlContent={item.remark} />
                                      </h4>
                                    </div>
                                  </div>
                                </button>
                              </>
                            )}
                          </>
                        ))}
                  </>
                )}
              </div>

              {(searchTerm || hasData) && noDataFound && (
                <p className="no_found">No data found</p>
              )}
            </div>
          </div>
        </>
      ) : null}

      <CreateAccountTransactionView
        show={isCreateAccountTransaction}
        onHide={() => setIsCreateAccountTransaction(false)}
        accountTransactionItem={undefined}
        contact_id={contactData.id}
        headerName="Create Account Transaction"
        setRefreshTransactions={setRefreshTransactions}
      />
      <CreateAccountTransactionView
        show={isEditAccountTransaction}
        onHide={() => setIsEditAccountTransaction(false)}
        accountTransactionItem={accountTransactionItemId}
        contact_id={contactData.id}
        headerName="Edit Account Transaction"
        setRefreshTransactions={setRefreshTransactions}
      />
      {isDeleteConfirmation && (
        <ConfirmationModal
          show={isDeleteConfirmation}
          onHide={() => setIsDeleteConfirmation(false)}
          handleSubmit={handleDeleteAccountTransaction}
          title={"Delete this Account Transaction"}
          message={"Are You Sure You Want To Delete This Account Transaction?"}
          btn1="CANCEL"
          btn2="DELETE"
        />
      )}

      {isApproveConfirmation && (
        <ConfirmationModal
          show={isApproveConfirmation}
          onHide={() => setIsApproveConfirmation(false)}
          handleSubmit={handleApproveAccountTransaction}
          title={"Approve this Account Transaction"}
          message={"Are You Sure You Want To Approve This Account Transaction?"}
          btn1="CANCEL"
          btn2="Approve"
        />
      )}

      <CheckBoxFilterModal
        show={isModalFilterVisible}
        onHide={handleModalClose}
        handleSubmit={handleConfirmFilter}
        title="Filter your Account Transactions"
        message="Please select the Date for the Account Transactions."
        btn1="Clear"
        btn2="Apply"
        filtersToShow={[1]}
        pageId={0}
      />
    </>
  );
};

export default ListAccountTransactionView;
