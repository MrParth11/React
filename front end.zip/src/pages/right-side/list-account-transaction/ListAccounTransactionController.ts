import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";
import { axiosInstance } from "../../../services/axiosInstance";
import { TReactSetState } from "../../../helpers/AppType";
export interface IAccountTransaction {
  id: number;
  type: string;
  mode: string;
  amount: number;
  payment_date_time: string
  remark: string;
  created_date_time: Date;
  approve_by_a_application_login_id: number,
  approve_date_time: string
}

type TUpdateAccountTransactions = (update: IAccountTransaction[] | ((prev: IAccountTransaction[]) => IAccountTransaction[])) => void;

export const fetchApiAccountTransitions = async (
  page: number,
  term: string,
  setAccountTransactions: TUpdateAccountTransactions,
  itemsPerPage: number,
  setLoading: (loading: boolean) => void,
  contact_master_id: number | undefined,
  setClosingBalance: (balance: number) => void,
  startSearchDate: string,
  endSearchDate: string,
) => {
  const start: number = page * itemsPerPage;
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  try {
    const { data } = await axiosInstance.post(
      "accountTransactionList",
      {
        ul: start, // Upper limit based on page number
        ll: itemsPerPage, // Lower limit based on page number
        searchTerm: term,
        a_application_login_id: Number(getUUID),
        contact_master_id: contact_master_id,
        startDate: startSearchDate,
        endDate: endSearchDate
      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        if (page === 0) {
          setLoading(true);
          setAccountTransactions(data.data.item);
          setClosingBalance(data.data.closingBalance);
        } else {
          setLoading(false);
          setAccountTransactions((prevUsers) => [
            ...prevUsers,
            ...data.data.item,
          ]);
        }
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

