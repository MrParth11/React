import React, { useContext, useEffect, useState } from "react";

import { AppContext } from "../../common/AppContext";
import useCheckUserPermission from "../../hooks/useCheckUserPermission";
import { toast } from "react-toastify";
import { DEFAULT_MESSAGE_ERROR_PERMISSION } from "../../helpers/AppConstants";
import { PAGE_ID, PERMISSION_TYPE } from "../../helpers/AppEnum";
import ConfirmationModal from "../../components/model/ConfirmationModal";
import { deleteMessages, fetchMessageData } from "./RightViewController";
import { getIn } from "formik";
import { IUserList } from "../left-side/LeftSideController";
import CreateContactView from "../left-side/create-contact/CreateContactView";
interface IPropsProfile {
  isProfile: boolean;
  closeChatAbout: () => void;
  getInfo?: IUserList;
  deleteContact: () => void;
  setIsCreateContact1: any;
  // handelRefreshMessages:() => void
}

const RightSideProfile = ({
  isProfile,
  closeChatAbout,
  getInfo,
  deleteContact,
  setIsCreateContact1,
  // handelRefreshMessages
}: IPropsProfile) => {
  const { isEditContact, setIsEditContact } = useContext(AppContext)!;
  const [isClearConfirmation, setIsClearConfirmation] = useState(false);
  const [isLoadedMessage, setIsLoadedMessage] = useState(false);
  const [getCompanyId, setGetCompanyId] = useState(0);
  const [showProfile, setShowProfile] = useState(false);
  const [noDataFound, setNoDataFound] = useState(false);
const [loading, setLoading] = useState(false);
  const labelColor = getInfo?.label_color
    ? getInfo?.label_color.split(",")
    : [];
  const labelNames = getInfo?.label_name ? getInfo?.label_name.split(",") : [];
  useEffect(() => {
    if (getInfo?.id) {
      closeChatAbout();
      setIsCreateContact1(true);
    } else {
      return undefined;
    }
  }, [getInfo?.id, setIsCreateContact1]);

  const canDelete = useCheckUserPermission(PAGE_ID.CONTACT, PERMISSION_TYPE.DELETE);
  const canEdit = useCheckUserPermission(PAGE_ID.CONTACT, PERMISSION_TYPE.EDIT);

  const handleChangeEditContact = () => {
    if (canEdit) {
      setIsEditContact(true);
    } else {
      toast.error(
        DEFAULT_MESSAGE_ERROR_PERMISSION
      );
      setIsEditContact(false);
    }
  };

  const handleChangeDeleteContact = () => {
    if (canDelete) {
      deleteContact();

    } else {
      toast.error(
        DEFAULT_MESSAGE_ERROR_PERMISSION
      );
    }
  }

  const getUUID = localStorage.getItem("UUID");

  function openModelClearMsg() {
    setIsClearConfirmation(true);
  }
  const handelClearMessage = async () => {
    console.log("Clear Messages");
    console.log("data", getInfo);
    
    setIsLoadedMessage(false);
    if (await deleteMessages(getInfo?.id)) {
      setIsLoadedMessage(true);
    }
    setIsClearConfirmation(false);
    closeChatAbout();
    // if(getInfo?.id){
    //   await fetchMessageData(
    //    setNoDataFound,
    //     "",
    //     setLoading,
    //     [],
    //     false,
    //     0,
    //     false,
    //     getInfo?.id,
    //     false,
    //     false,
    //     [],
    //     "",
    //     setGetCompanyId
    //   )
    // }
    // handelRefreshMessages()

  };

  return (
    <>
      {isProfile ? (
        <>
          <div
            className="ChatAbout animate__animated animate__fadeInRight"
            id="ChatAbout"
          >
            <div className="header-Chat">
              <div className="ICON">
                <button className="icons" onClick={closeChatAbout}>
                  <span className="">
                    <svg
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path d="m19.1 17.2-5.3-5.3 5.3-5.3-1.8-1.8-5.3 5.4-5.3-5.3-1.8 1.7 5.3 5.3-5.3 5.3L6.7 19l5.3-5.3 5.3 5.3 1.8-1.8z"></path>
                    </svg>
                  </span>
                </button>
              </div>

              <div className="newText">
                <h2>Contact Info</h2>
              </div>
              <button className="icons" onClick={handleChangeEditContact}>
                <span data-testid="pencil" data-icon="pencil" className="">
                  <svg
                    viewBox="0 0 24 24"
                    width="24"
                    height="24"
                    className=""
                  >
                    <path
                      fill="currentColor"
                      d="M3.95 16.7v3.4h3.4l9.8-9.9-3.4-3.4-9.8 9.9zm15.8-9.1c.4-.4.4-.9 0-1.3l-2.1-2.1c-.4-.4-.9-.4-1.3 0l-1.6 1.6 3.4 3.4 1.6-1.6z"
                    ></path>
                  </svg>
                </span>
              </button>
            </div>
            <div className="chats-chatAbout">
              <div className="img-about">
                <div className="img-Ani">
                  <div
                    className="imgBox"
                    style={{ backgroundColor: "var(--ig-primary)" }}
                  >
                    <div
                      className="text-uppercase "
                      style={{ paddingTop: "12px" }}
                    >
                      {getInfo &&
                        (getInfo?.person_name?.[0] || "") +
                        (getInfo?.person_name?.[1] || "")}
                    </div>
                  </div>
                </div>

                <div className="text-Ani">
                  <h3>{getInfo?.person_name}</h3>
                  <p>{getInfo?.mobile_number}</p>
                </div>
              </div>
              <div className="block">
                <div className="h-text">
                  <div className="titlePro">
                    <p>Email Id</p>
                  </div>
                  <div className="bio">
                    <div className="text-inner">
                      <h4>{getInfo?.email_id}</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="block">
                <div className="h-text">
                  <div className="titlePro">
                    <p>Address</p>
                  </div>
                  <div className="bio">
                    <div className="text-inner">
                      <h4>{getInfo?.address}</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="block">
                <div className="h-text">
                  <div className="titlePro">
                    <p>Country</p>
                  </div>
                  <div className="bio">
                    <div className="text-inner">
                      <h4>{getInfo?.country_name}</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="block">
                <div className="h-text">
                  <div className="titlePro">
                    <p>State</p>
                  </div>
                  <div className="bio">
                    <div className="text-inner">
                      <h4>{getInfo?.state_name}</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="block">
                <div className="h-text">
                  <div className="titlePro">
                    <p>City</p>
                  </div>
                  <div className="bio">
                    <div className="text-inner">
                      <h4>{getInfo?.city_name}</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="block">
                <div className="h-text">
                  <div className="titlePro">
                    <p>Pin Code</p>
                  </div>
                  <div className="bio">
                    <div className="text-inner">
                      <h4>{getInfo?.pincode}</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="block">
                <div className="h-text">
                  <div className="titlePro">
                    <p>Source Type</p>
                  </div>
                  <div className="bio">
                    <div className="text-inner">
                      <div>
                        <span
                          style={{
                            backgroundColor: getInfo?.source_name_color
                              ? getInfo.source_name_color
                              : "#eeeeee ",
                          }}
                          className="badge rounded-pill"
                        >
                          {getInfo?.source_name}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="block">
                <div className="h-text">
                  <div className="titlePro">
                    <p>Labels</p>
                  </div>
                  <div className="bio">
                    <div className="text-inner">
                      {labelNames.map((name, index) => (
                        <div
                          key={index}
                          style={{
                            backgroundColor: labelColor[index]
                              ? labelColor[index]
                              : "#eeeeee ",
                            padding: "5px 10px",
                            borderRadius: "12px",
                            margin: "2px",
                            display: "inline-block",
                          }}
                          className="badge rounded-pill"
                        >
                          {name}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bottom">
                <div className="h-text">
                  <div className="Block-head" onClick={handleChangeDeleteContact}>
                    <div className="contact-star">
                      <span className="star">
                        <svg
                          viewBox="0 0 24 24"
                          width="24"
                          height="24"
                          className=""
                        >
                          <path
                            fill="currentColor"
                            d="M6 18c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V6H6v12zM19 3h-3.5l-1-1h-5l-1 1H5v2h14V3z"
                          ></path>
                        </svg>
                      </span>
                    </div>
                    <div className="contact-text">
                      <span className="star-text">Delete Contact</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bottom">
                <div className="h-text">
                  <div className="Block-head" onClick={openModelClearMsg}>
                    <div className="contact-star">
                      <span className="star">
                        <svg
                          viewBox="0 0 24 24"
                          width="24"
                          height="24"
                          className=""
                        >
                          <path
                            fill="currentColor"
                            d="M6 18c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V6H6v12zM19 3h-3.5l-1-1h-5l-1 1H5v2h14V3z"
                          ></path>
                        </svg>
                      </span>
                    </div>
                    <div className="contact-text">
                      <span className="star-text">Clear All Data</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {isEditContact && (
            <CreateContactView
              show={isEditContact}
              onHide={() => setIsEditContact(false)}
              contactData={getInfo}
              headerName={"Edit Contact"}
              setIsCreateContact1={setIsCreateContact1}
              closeChatAbout={closeChatAbout}
            />
          )}
        </>
      ) : null}

      {isClearConfirmation && (
        <ConfirmationModal
          show={isClearConfirmation}
          onHide={() => setIsClearConfirmation(false)}
          handleSubmit={() => handelClearMessage()}
          title={"Clear this chats"}
          message={"Are you sure you want Clear this Chats?"}
          btn1="CANCEL"
          btn2="CLEAR CHATS"
        />
      )}
    </>
  );
};

export default RightSideProfile;
