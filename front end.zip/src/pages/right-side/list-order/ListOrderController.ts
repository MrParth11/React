import { toast } from "react-toastify";
import { axiosInstance } from "../../../services/axiosInstance";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../../helpers/AppConstants";
import { TReactSetState } from "../../../helpers/AppType";
import { IReminder } from "../RightViewController";
import { formatDateTimeSendDataBase } from "../../../common/SharedFunction";
import { IStageStatusView } from "../../left-side/header/Setting/stage-status/StageStatusController";

export interface IOrder {
  id: number;
  type: number;
  total_amt: number;
  total_qty: number;
  discount_pct: number;
  discount_pr: number;
  packing_forwarding_charge: number;
  transport_charge: number;
  taxable_amt: number;
  gst_amt: number;
  tcs_amt: number;
  round_off: number;
  grand_total: number;
  created_date_time: string;
  cart_status: number;
  stage_status_name: string;
  stage_status_color: string;
  to_customer_name: string;
  to_customer_phone: number;
  cart_number: string;
  cart_date: Date;
  is_reminder: number;
  reminder_data_time: string;
  reminder_remark: string;
}

export const orderTypesList = [
  { id: "1", type: "Quotation" },
  { id: "2", type: "Sales Order" },
  { id: "3", type: "Sales Invoice" },
  { id: "4", type: "Purchase Invoice" },
];

export const orderTypesSendList = [
  { id: "1", type: "quotation" },
  { id: "2", type: "order" },
  { id: "3", type: "invoice" },
  { id: "4", type: "purchase_order" },
];
export const fetchListOrderApi = async (
  setOrderList: TReactSetState<IOrder[]>,
  setNoDataFound: TReactSetState<boolean>,
  setLoading: TReactSetState<boolean>,
  contactMasterId: number,
  term: string,
  isOrderShowNum: number
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = localStorage.getItem("token");
  try {
    const { data } = await axiosInstance.post(
      "listOrder",
      {
        a_application_login_id: getUUID,
        contact_master_id: contactMasterId,
        searchTerm: term ? term.trim() : "",
        order_type: isOrderShowNum,
      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        //   if (page === 0) {
        setLoading(true);

        setOrderList(data.data.item);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
    setNoDataFound(data.data.item.length === 0);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false); // Set loading to false after minimum time
    }, 1000);
  }
};

export const fetchOrderByIdApi = async (
  cartId: number,
  setLoading: TReactSetState<boolean>,
  setOrderById: TReactSetState<IOrder | undefined>,
  setIsOrderShowNum: TReactSetState<any>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = localStorage.getItem("token");
  try {
    const { data } = await axiosInstance.post(
      "orderById",
      {
        cart_id: cartId,
        a_application_login_id: Number(getUUID)

      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setLoading(true);

        setOrderById(data.data.item);
        setIsOrderShowNum(data.data.item.cart.type);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const handleDeleteOrder = async (
  cartId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setRefreshTransactions: TReactSetState<boolean>
) => {
  const token = localStorage.getItem("token");
  const getUUID = localStorage.getItem("UUID")
  try {
    const { data } = await axiosInstance.post(
      "deleteOrder",
      {
        cart_id: cartId,
        a_application_login_id: Number(getUUID)

      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        setRefreshTransactions(true);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const handleConvertIntoOrder = async (
  cartId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setRefreshTransactions: TReactSetState<boolean>
) => {
  const token = localStorage.getItem("token");
  const getUUID = localStorage.getItem("UUID");


  try {
    const { data } = await axiosInstance.post(
      "covertOrderSystem",
      {
        cart_id: cartId,
        cart_type: 2,
        request_flag: 1,
        a_application_login_id: Number(getUUID)
      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        setRefreshTransactions(true);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const handleConvertIntoInvoice = async (
  cartId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setRefreshTransactions: TReactSetState<boolean>
) => {
  const token = localStorage.getItem("token");
  const getUUID = localStorage.getItem("UUID");

  try {
    const { data } = await axiosInstance.post(
      "covertOrderSystem",
      {
        cart_id: cartId,
        cart_type: 3,
        request_flag: 1,
        a_application_login_id: Number(getUUID)

      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        setRefreshTransactions(true);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const handleMakeNewCopy = async (
  cartType: number,
  cartId: number | undefined,
  setIsDeleteConfirmation: TReactSetState<boolean>,
  setRefreshTransactions: TReactSetState<boolean>
) => {
  const token = localStorage.getItem("token");
  const getUUID = localStorage.getItem("UUID");

  try {
    const { data } = await axiosInstance.post(
      "covertOrderSystem",
      {
        cart_id: cartId,
        cart_type: cartType,
        request_flag: 2,
        a_application_login_id: Number(getUUID)

      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsDeleteConfirmation(false);
        setRefreshTransactions(true);
        toast.success(data.ack_msg);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    } else {
      toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const fetchStageStatusForOrderApi = async (
  setStageStatusList: TReactSetState<IStageStatusView[]>,
  isOrderShowNum: number
) => {
  console.log("isOrderShowNum", isOrderShowNum);

  const condition1 = isOrderShowNum === 1;
  const condition2 = isOrderShowNum === 2;
  const condition3 = isOrderShowNum === 4;

  const orderType = condition1 ? 3 : condition2 ? 4 : condition3 ? 6 : 5;

  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "stage_status_masters",
    columns: "id,name,color,order_type,display_order_type",
    where: [
      "isDelete=0",
      `a_application_login_id=${getUUID}||0`,
      `order_type=${orderType}`,
    ],
    request_flag: 0,
    order: `{"id":"DESC"}`,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setStageStatusList([]);
    }
    setStageStatusList(data.data.data);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const updateStageStatusForOrderRadioButton = async (
  hasOneData: number | undefined,
  selectedOptions: any,
  setLoading: TReactSetState<boolean>,
  setIsModalAssignStatusVisible: TReactSetState<boolean>
) => {
  const requestData = {
    table: "carts",
    where: `{"id":"${hasOneData}"}`,
    data: `{"cart_status":"${selectedOptions}"}`,
  };
  setLoading(false);
  const getUUID = localStorage.getItem("UUID")
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,

      },
    });
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setLoading(true);
        setIsModalAssignStatusVisible(false);
      } else {
        setLoading(false);
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  } finally {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }
};

export const fetchCompanyForOrderApi = async (
  setCompanyDetail: TReactSetState<any[] | undefined>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "company_masters",
    columns: "id,company_name,company_email,terms_and_condition",
    where: `{"isDelete": 0 , "a_application_login_id":${getUUID}}`,

    request_flag: 1,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData);
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setCompanyDetail([]);
    }
    const findCompany =
      data.data.data &&
      data.data.data.map((item: any) => item.terms_and_condition);
    setCompanyDetail(findCompany);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createReminderForCart = async (
  insertObj: IReminder,
  contactId: number | undefined,
  cartId: number | undefined,
  setIsReminderConfirmation: TReactSetState<boolean>,
  findType: string,
  setRefreshCarts: TReactSetState<boolean>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const date = new Date(insertObj.dateTime);

  const formattedDateTime = `${date.getFullYear()}-${String(
    date.getMonth() + 1
  ).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(
    date.getHours()
  ).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(
    date.getSeconds()
  ).padStart(2, "0")}`;

  const requestData = {
    table: "reminder_messages",
    data: JSON.stringify({
      a_application_login_id: Number(getUUID),
      contact_masters_id: contactId,
      reminder_data_time: formattedDateTime,
      assigned_to: insertObj.selectedCategory?.value,
      remark: insertObj.remark,
      reference_id: cartId,
      reference_table: `cart_${findType}`,
    }),
  };
  try {
    const data = await axiosInstance.post("commonCreate", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setIsReminderConfirmation(false);
      setRefreshCarts(true);
      const requestDataMsg = {
        table: "carts",
        where: `{"id":${cartId}}`,
        data: `{"is_reminder":"1"}`,
      };
      try {
        const data = await axiosInstance.post("commonUpdate", requestDataMsg, {
          headers: {
            "x-tenant-id": getUUID,

          },
        });
        if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          return true;
        } else {
          return false;
        }
      } catch (error: any) {
        toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
      toast.success(data.data.ack_msg);
    } else {
      toast.error(data.data.ack_msg);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const handleChangeStatusOfReminderCompleted = async (
  cartId: number | undefined,
  setIsReminderConfirmationStatus: TReactSetState<boolean>,
  type: string,
  setRefreshCarts: TReactSetState<boolean>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const formattedDateTime = formatDateTimeSendDataBase(new Date());
  const requestData = {
    table: "reminder_messages",
    where: `{"a_application_login_id":"${getUUID}","reference_id":"${cartId}","reference_table":"cart_${type}" }`,
    data: `{"status":"1","completed_date_time":"${formattedDateTime}"}`,
  };
  try {
    const { data } = await axiosInstance.post("commonUpdate", requestData, {
      headers: {
        "x-tenant-id": getUUID,

      },
    });
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setIsReminderConfirmationStatus(false);

        const requestData = {
          table: "carts",
          where: `{"id":"${cartId}"}`,
          data: JSON.stringify({
            is_reminder: 0,
          }),
        };
        try {
          const data = await axiosInstance.post("commonUpdate", requestData, {
            headers: {
              "x-tenant-id": getUUID,

            },
          });
          if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
            setRefreshCarts(true);
            return true;
          } else {
            return false;
          }
        } catch (error: any) {
          toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
        }
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
