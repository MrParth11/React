import React, { useEffect, useRef, useState } from "react";
import Skeleton from "react-loading-skeleton";
import { useTheme } from "../../../components/ThemeContext";
import OrderCreateModal from "../../../components/model/OrderCreateModal";
import {
  createReminderForCart,
  fetchCompanyForOrderApi,
  fetchListOrderApi,
  fetchOrderByIdApi,
  fetchStageStatusForOrderApi,
  handleChangeStatusOfReminderCompleted,
  handleConvertIntoInvoice,
  handleConvertIntoOrder,
  handleDeleteOrder,
  handleMakeNewCopy,
  IOrder,
  orderTypesList,
  orderTypesSendList,
  updateStageStatusForOrderRadioButton,
} from "./ListOrderController";
import {
  convertDateTimeFormat,
  formatDate,
  formatDateAndTime,
  formatNumber,
} from "../../../common/SharedFunction";
import ConfirmationModal from "../../../components/model/ConfirmationModal";
import RadioButtonModal from "../../../components/model/RadioButtonModal";
import ReminderModal from "../../../components/model/ReminderModal";
import { toast } from "react-toastify";
import useCheckUserPermission from "../../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../../helpers/AppEnum";
import { DEFAULT_MESSAGE_ERROR_PERMISSION, SMALL_TEXT_LENGTH } from "../../../helpers/AppConstants";
interface IPropsListOrder {
  isListOrder: boolean;
  closeListOrder: () => void;
  contactData?: any;
  isOrderShowNum: number;
}

const ListOrderView = ({
  isListOrder,
  closeListOrder,
  contactData,
  isOrderShowNum,
}: IPropsListOrder) => {
  const dropdownCreateOrderRef = useRef<HTMLButtonElement>(null);
  const dropdownRef = useRef<Record<number, HTMLUListElement | null>>({});

  const [loading, setLoading] = useState(false);
  const { darkMode } = useTheme();
  const [dropdownOpenCreateOrder, setDropdownOpenCreateOrder] = useState(false);
  const [isOrderCreateShow, setIsOrderCreateShow] = useState(false);
  const [orderList, setOrderList] = useState<IOrder[]>([]);
  const [orderById, setOrderById] = useState<any>();

  const [noDataFound, setNoDataFound] = useState(false);
  const [refreshCarts, setRefreshCarts] = useState(false);
  const [orderId, setOrderId] = useState<number>();
  const [orderDropdownOpen, setOrderDropdownOpen] = useState<any>(null);
  const [isEditOrderShow, setIsEditOrderShow] = useState(false);
  const [orderIdDelete, setOrderIdDelete] = useState(0);
  const [converCartId, setConverCartId] = useState(0);
  const [makeCopyType, setMakeCopyType] = useState(0);

  const [isDeleteConfirmation, setIsDeleteConfirmation] = useState(false);
  const [isConvetIntoOrderConfirmation, setIsConvetIntoOrderConfirmation] =
    useState(false);
  const [
    isConvertIntoInvoiceConfirmation,
    setIsConvertIntoInvoiceConfirmation,
  ] = useState(false);
  const [isMakeCartCopyConfirmation, setIsMakeCartCopyConfirmation] =
    useState(false);
  const [isReminderConfirmationStatus, setIsReminderConfirmationStatus] =
    useState(false);
  const [reminderData, setReminderData] = useState<IOrder>();
  const [isOrderShowNum1, setIsOrderShowNum1] = useState(0);
  const [isModalAssignStatusVisible, setIsModalAssignStatusVisible] =
    useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [companyDetail, setCompanyDetail] = useState<any>();

  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(
    null
  ); 
  const [optionRadioButtonStatus, setOptionRadioButtonStatus] = useState<any[]>(
    []
  );
  const [statusAssignContactId, setStatusAssignContactId] = useState<number>();
  const [isSetReminderConfirmation, setIsSetReminderConfirmation] =
    useState(false);

  const canAddQuo = useCheckUserPermission(
    PAGE_ID.QUOTATION,
    PERMISSION_TYPE.ADD
  );
  const canAddOrder = useCheckUserPermission(
    PAGE_ID.ORDER,
    PERMISSION_TYPE.ADD
  );
  const canAddInv = useCheckUserPermission(
    PAGE_ID.INVOICE,
    PERMISSION_TYPE.ADD
  );
  const canAddPurchase = useCheckUserPermission(
    PAGE_ID.PURCHASE,
    PERMISSION_TYPE.ADD
  );
  const canDelQuo = useCheckUserPermission(
    PAGE_ID.QUOTATION,
    PERMISSION_TYPE.DELETE
  );
  const canDelOrder = useCheckUserPermission(
    PAGE_ID.ORDER,
    PERMISSION_TYPE.DELETE
  );
  const canDelInv = useCheckUserPermission(
    PAGE_ID.INVOICE,
    PERMISSION_TYPE.DELETE
  );
  const canDelPurchase = useCheckUserPermission(
    PAGE_ID.PURCHASE,
    PERMISSION_TYPE.DELETE
  );
  const canViewStatus = useCheckUserPermission(
    PAGE_ID.STATUS,
    PERMISSION_TYPE.VIEW
  );
  const canAddReminder = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.ADD
  );
  const canApproveReminder = useCheckUserPermission(
    PAGE_ID.REMINDER,
    PERMISSION_TYPE.APPROVE
  );
  const toggleDropdownCreate = () => {
    setDropdownOpenCreateOrder(!dropdownOpenCreateOrder);
  };

  const handelChangeShowModelQuotation = () => {
    setIsOrderShowNum1(1);
    setIsOrderCreateShow(true);
  };
  const handelChangeShowModelOrder = () => {
    setIsOrderShowNum1(2);
    setIsOrderCreateShow(true);
  };
  const handelChangeShowModelInvoice = () => {
    setIsOrderShowNum1(3);
    setIsOrderCreateShow(true);
  };

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        dropdownCreateOrderRef.current &&
        !dropdownCreateOrderRef.current.contains(event.target as Node)
      ) {
        setDropdownOpenCreateOrder(false);
      }
    };

    document.addEventListener("click", handleOutsideClick);

    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, [dropdownCreateOrderRef]);
  const handelRefreshOrder = () => {
    fetchListOrderApi(
      setOrderList,
      setNoDataFound,
      setLoading,
      contactData.id,
      "",
      isOrderShowNum
    );
  };
  useEffect(() => {
    if (contactData?.id) {
      closeListOrder();
      setSearchTerm("");
    } else {
      return undefined;
    }
  }, [contactData?.id]);
  useEffect(() => {
    fetchListOrderApi(
      setOrderList,
      setNoDataFound,
      setLoading,
      contactData.id,
      "",
      isOrderShowNum
    );
  }, [contactData.id, isListOrder, isOrderCreateShow, isOrderShowNum]);
  useEffect(() => {
    if (refreshCarts) {
      fetchListOrderApi(
        setOrderList,
        setNoDataFound,
        setLoading,
        contactData.id,
        "",
        isOrderShowNum
      );

      setRefreshCarts(false);
    }
  }, [refreshCarts]);
  useEffect(() => {
    if (isModalAssignStatusVisible) {
      fetchStageStatusForOrderApi(setOptionRadioButtonStatus, isOrderShowNum);
    }
  }, [isModalAssignStatusVisible]);
  const createOrderSubmit = () => {
    setRefreshCarts(true);
    setIsOrderCreateShow(false);
  };
  const updateOrderSubmit = () => {
    setRefreshCarts(true);
    setIsEditOrderShow(false);
  };
  const toggleDropdownOrder = (id: number) => {
    setOrderId(id);
    setOrderDropdownOpen((prevId: any) => (prevId === id ? null : id));
  };
  const handelChangeEdit = (id: number) => {
    setIsEditOrderShow(true);
    fetchOrderByIdApi(id, setLoading, setOrderById, setIsOrderShowNum1);
    setOrderDropdownOpen(null);
  };
  const handelChangeOrderDelete = (id: number) => {
    const permissionMap: Record<number, boolean> = {
      1: canDelQuo,
      2: canDelOrder,
      3: canDelInv,
      4: canDelPurchase,
    };

    if (permissionMap[isOrderShowNum]) {
      setIsDeleteConfirmation(true);
      setOrderIdDelete(id);
      setOrderDropdownOpen(null);
    } else {
      setIsDeleteConfirmation(false);
      setOrderDropdownOpen(null);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  const handleConfirmInquiriesRadioButton = async (checkedOptions: any[]) => {
    await updateStageStatusForOrderRadioButton(
      statusAssignContactId,
      checkedOptions,
      setRefreshCarts,
      setIsModalAssignStatusVisible
    );
  };

  const handleModalOpenStatusAssign = (id: number | undefined) => {
    if (canViewStatus) {
      setStatusAssignContactId(id);
      setIsModalAssignStatusVisible(true);
      setOrderDropdownOpen(null);
    } else {
      setIsModalAssignStatusVisible(false);
      setOrderDropdownOpen(null);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handleModalOpenReminder = (id: number | undefined) => {
    if (canAddReminder) {
      setOrderId(id);
      setIsSetReminderConfirmation(true);

      setOrderDropdownOpen(null);
    } else {
      setIsSetReminderConfirmation(false);

      setOrderDropdownOpen(null);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handleModalConvertIntoOrder = (id: number) => {
    if (canAddOrder) {
      setConverCartId(id);
      setIsConvetIntoOrderConfirmation(true);
      setOrderDropdownOpen(null);
    } else {
      setIsConvetIntoOrderConfirmation(false);
      setOrderDropdownOpen(null);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handleModalConvertIntoInvoice = (id: number) => {
    if (canAddInv) {
      setConverCartId(id);
      setIsConvertIntoInvoiceConfirmation(true);
      setOrderDropdownOpen(null);
    } else {
      setIsConvertIntoInvoiceConfirmation(false);

      setOrderDropdownOpen(null);
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const handleModalMakeCopy = (id: number, cartType: number) => {
    
    const permissionMap: Record<number, boolean> = {
      1: canAddQuo,
      2: canAddOrder,
      3: canAddInv,
      4: canAddPurchase,
    };

    if (permissionMap[isOrderShowNum]) {
      setConverCartId(id);
      setIsMakeCartCopyConfirmation(true);
      setMakeCopyType(cartType);
      setOrderDropdownOpen(null);
    } else {
      setIsMakeCartCopyConfirmation(false);
      setOrderDropdownOpen(null);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
    
   
  };
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setSearchTerm(value);
    if (value.length >= 3 || value === "") {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
      setSearchTimeout(
        setTimeout(() => {
          fetchListOrderApi(
            setOrderList,
            setNoDataFound,
            setLoading,
            contactData.id,
            value,
            isOrderShowNum
          );
        }, 1000)
      );
    }
  };
  const findType =
    orderTypesSendList?.find((option) => Number(option.id) === isOrderShowNum)
      ?.type || "";
  const handleReminder = async (data: {
    dateTime: string;
    remark: string;
    status: string;
    selectedCategory: any;
  }) => {
    if (
      data.dateTime.trim() &&
      data.remark.trim() &&
      data.selectedCategory !== null &&
      data.selectedCategory !== false
    ) {
      createReminderForCart(
        data,
        contactData?.id,
        orderId,
        setIsSetReminderConfirmation,
        findType,
        setRefreshCarts
      );
    } else {
      toast.error("Please enter Date and Time, Remark, and Select Team Member");
      setIsSetReminderConfirmation(true);
    }
  };
  const handleChangeStatusOfReminder = (messageData: IOrder) => {
    if (canApproveReminder) {
      setIsReminderConfirmationStatus(true);
      setReminderData(messageData);
    } else {
      setIsReminderConfirmationStatus(false);

      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };
  const symbolCurrency = "₹";
  const openModelCart = () => {
    const findTypeCart =
      Number(
        orderTypesList?.find((option) => Number(option.id) === isOrderShowNum)
          ?.id
      ) || 0;

    const permissionMap: Record<number, boolean> = {
      1: canAddQuo,
      2: canAddOrder,
      3: canAddInv,
      4: canAddPurchase,
    };

    if (permissionMap[findTypeCart]) {
      setIsOrderCreateShow(true);
    } else {
      toast.error(DEFAULT_MESSAGE_ERROR_PERMISSION);
    }
  };

  return (
    <>
      {isListOrder ? (
        <>
          <div className="leftSide " id="search-message">
            <div className="header-Chat d-flex justify-content-evenly position-relative">
              <div className="ICON w-5 position-absolute start-0">
                <button className="icons ig-btn" onClick={closeListOrder}>
                  <span className="text-white" title="Close">
                    <svg
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path d="m19.1 17.2-5.3-5.3 5.3-5.3-1.8-1.8-5.3 5.4-5.3-5.3-1.8 1.7 5.3 5.3-5.3 5.3L6.7 19l5.3-5.3 5.3 5.3 1.8-1.8z"></path>
                    </svg>
                  </span>
                </button>
              </div>

              <div className="newText w-65 " style={{
                width: "100%",
                height: "100%",
                position: "absolute",
                left:"30px"
              }}>
                <h2>
                  {orderTypesList?.find(
                    (option) => Number(option.id) === isOrderShowNum
                  )?.type || ""}
                  &nbsp; List
                </h2>
              </div>
              <div className="w-30 text-end position-absolute end-0">
                <button
                  className="icons ig-btn"
                  onClick={openModelCart}
                >
                  <span className="text-white">
                  <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="26px"
                      viewBox="0 -960 960 960"
                      width="26px"
                      fill="currentColor"
                    >
                      <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                    </svg>
                  </span>
                </button>
                <button
                  className="icons pP ig-btn"
                  style={{ marginBottom: "50px" }}
                  onClick={handelRefreshOrder}
                >
                  <span className="text-white" title="Refresh">
                    <svg width="30" height="30" viewBox="0 0 50 50">
                      <path
                        fill="currentColor"
                        d="M25 38c-7.2 0-13-5.8-13-13 0-3.2 1.2-6.2 3.3-8.6l1.5 1.3C15 19.7 14 22.3 14 25c0 6.1 4.9 11 11 11 1.6 0 3.1-.3 4.6-1l.8 1.8c-1.7.8-3.5 1.2-5.4 1.2z"
                      />
                      <path
                        fill="currentColor"
                        d="M34.7 33.7l-1.5-1.3c1.8-2 2.8-4.6 2.8-7.3 0-6.1-4.9-11-11-11-1.6 0-3.1.3-4.6 1l-.8-1.8c1.7-.8 3.5-1.2 5.4-1.2 7.2 0 13 5.8 13 13 0 3.1-1.2 6.2-3.3 8.6z"
                      />
                      <path fill="currentColor" d="M18 24h-2v-6h-6v-2h8z" />
                      <path fill="currentColor" d="M40 34h-8v-8h2v6h6z" />
                    </svg>
                  </span>
                </button>
              </div>
            </div>
            <div className="search-bar">
              <div>
                <button className="search ig-btn">
                  <span className="">
                    <svg
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path
                        fill="currentColor"
                        d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"
                      ></path>
                    </svg>
                  </span>
                </button>

                <span className="go-back">
                  <svg viewBox="0 0 24 24" width="24" height="24" className="">
                    <path
                      fill="currentColor"
                      d="m12 4 1.4 1.4L7.8 11H20v2H7.8l5.6 5.6L12 20l-8-8 8-8z"
                    ></path>
                  </svg>
                </span>

                <input
                  type="text"
                  title="Search"
                  aria-label="Search or start new chat"
                  placeholder="Search"
                  maxLength={SMALL_TEXT_LENGTH}
                  value={searchTerm}
                  onChange={handleSearchChange}
                />
              </div>
            </div>

            <div className="chats" style={{ height: "600px" }}>
              <>
                {loading
                  ? 
                    Array.from({ length: 12 }).map((_, index) => (
                      <button key={index} className="block chat-list ig-btn">
                        <div className="h-text">
                          <div className="head">
                            <h4 className="inquiry-front">
                              <Skeleton
                                style={{
                                  marginLeft: "10px",
                                  opacity: darkMode ? "" : 0.5,
                                }}
                                width={100}
                              />
                            </h4>
                            <h4
                              className="text-end"
                            >
                              <Skeleton
                                style={{
                                  marginLeft: "10px",
                                  opacity: darkMode ? "" : 0.5,
                                }}
                                width={30}
                                height={10}
                              />
                            </h4>
                          </div>

                          <div className="head">
                            <h4 className="inquiry-front">
                              <Skeleton
                                width={100}
                                style={{
                                  opacity: darkMode ? "" : 0.5,
                                  marginLeft: "10px",
                                }}
                              />
                            </h4>
                            <p className="time">
                              <Skeleton
                                width={80}
                                style={{ opacity: darkMode ? "" : 0.5 }}
                                height={10}
                              />
                            </p>
                          </div>
                          <button className="icon-more float-end ig-btn">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={30}
                            />
                          </button>
                          <div className="head">
                            <h4 className="inquiry-front">
                              <Skeleton
                                style={{
                                  marginLeft: "10px",
                                  opacity: darkMode ? "" : 0.5,
                                }}
                                width={100}
                              />
                            </h4>
                          </div>
                          <div className="head">
                            <Skeleton
                              style={{
                                marginLeft: "10px",
                                opacity: darkMode ? "" : 0.5,
                              }}
                              width={100}
                            />
                          </div>

                          <div className="">
                            <label className="float-start inquiry-front">
                              <Skeleton
                                style={{
                                  marginLeft: "10px",
                                  opacity: darkMode ? "" : 0.5,
                                }}
                                width={100}
                              />
                            </label>
                            <br />
                            <p className=" d-flex justify-content-between text-break text-start inquiry-front">
                              <Skeleton
                                style={{
                                  marginLeft: "10px",
                                  opacity: darkMode ? "" : 0.5,
                                }}
                                width={100}
                              />
                              <div className="">
                                <span className="badge rounded-pill">
                                  <Skeleton
                                    style={{
                                      marginLeft: "10px",
                                      opacity: darkMode ? "" : 0.5,
                                    }}
                                    width={40}
                                  />
                                </span>
                              </div>
                            </p>
                          </div>
                        </div>
                      </button>
                    ))
                  : 
                    orderList &&
                    orderList.map((item, index) => (
                      <>
                        <div key={item.id}>
                          <ul
                            ref={(el) => (dropdownRef.current[item.id] = el)}
                            className={`right_label_dropLeft ${
                              orderId === item.id && orderDropdownOpen
                                ? "isVisible"
                                : "isHidden"
                            }`}
                            style={{ width: "160px" }}
                          >
                            <li
                              className="listItem"
                              role="button"
                              onClick={() => handelChangeEdit(item.id)}
                            >
                              Edit / View
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              onClick={() => handelChangeOrderDelete(item.id)}
                            >
                              Delete
                            </li>
                            <li
                              className="listItem"
                              role="button"
                              onClick={() =>
                                handleModalOpenStatusAssign(item.id)
                              }
                            >
                              Assign Status
                            </li>
                            {item.is_reminder ? (
                              <span></span>
                            ) : (
                              <li
                                className="listItem"
                                role="button"
                                onClick={() => handleModalOpenReminder(item.id)}
                              >
                                Reminder
                              </li>
                            )}
                            {item.type === 1 && item.cart_number ? (
                              <li
                                className="listItem"
                                role="button"
                                onClick={() =>
                                  handleModalConvertIntoOrder(item.id)
                                }
                              >
                                Convert to Order
                              </li>
                            ) : (
                              <span></span>
                            )}
                            {item.type === 2 && item.cart_number ? (
                              <li
                                className="listItem"
                                role="button"
                                onClick={() =>
                                  handleModalConvertIntoInvoice(item.id)
                                }
                              >
                                Convert to Invoice
                              </li>
                            ) : (
                              <span></span>
                            )}
                            {item.type === 1 && item.cart_number && (
                              <li
                                className="listItem"
                                role="button"
                                onClick={() =>
                                  handleModalMakeCopy(item.id, item.type)
                                }
                              >
                                Create New Copy
                              </li>
                            )}
                            {item.type === 2 && item.cart_number && (
                              <li
                                className="listItem"
                                role="button"
                                onClick={() =>
                                  handleModalMakeCopy(item.id, item.type)
                                }
                              >
                                Create New Copy
                              </li>
                            )}
                            {item.type === 3 && item.cart_number && (
                              <li
                                className="listItem"
                                role="button"
                                onClick={() =>
                                  handleModalMakeCopy(item.id, item.type)
                                }
                              >
                                Create New Copy
                              </li>
                            )}
                            {item.type === 4 && item.cart_number && (
                              <li
                                className="listItem"
                                role="button"
                                onClick={() =>
                                  handleModalMakeCopy(item.id, item.type)
                                }
                              >
                                Create New Copy
                              </li>
                            )}
                          </ul>
                        </div>
                        <button
                          key={index}
                          className="block chat-list ig-btn"
                        >
                          <div className="h-text">
                            <div className="head">
                              <h4 className="order-text-big-front">
                                <b>
                                  #
                                  {item.cart_number
                                    ? item.cart_number
                                    : "XXXXXXX"}
                                </b>
                              </h4>
                              {item.cart_number ? (
                                <h4
                                  style={{
                                    backgroundColor: "var(--ig-accent)",
                                    border: "2px solid var(--ig-accent)",
                                    color: "black",
                                  }}
                                  className="inquiry-front badge rounded-pill"
                                >
                                  Approved
                                </h4>
                              ) : (
                                <h4
                                  style={{
                                    backgroundColor: "var(--ig-primary)",
                                    border: "2px solid var(--ig-primary)",
                                    color: "black",
                                  }}
                                  className="inquiry-front badge rounded-pill"
                                >
                                  Draft
                                </h4>
                              )}
                            </div>
                            <div className="float-end">
                              {item.is_reminder ? (
                                <span
                                  role="button"
                                  onClick={() =>
                                    handleChangeStatusOfReminder(item)
                                  }
                                >
                                  <svg
                                    height="16px"
                                    viewBox="0 -960 960 960"
                                    width="16 px"
                                    className=""
                                    fill="currentColor"
                                  >
                                    <path d="M480-80q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-440q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-800q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-440q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-80Zm0-360Zm112 168 56-56-128-128v-184h-80v216l152 152ZM224-866l56 56-170 170-56-56 170-170Zm512 0 170 170-56 56-170-170 56-56ZM480-160q117 0 198.5-81.5T760-440q0-117-81.5-198.5T480-720q-117 0-198.5 81.5T200-440q0 117 81.5 198.5T480-160Z" />
                                  </svg>
                                </span>
                              ) : (
                                <span></span>
                              )}
                            </div>
                            <div className="head">
                              <h4 className="inquiry-front">
                                <b>Customer Name</b> :
                                {item.to_customer_name
                                  ? item.to_customer_name
                                  : ""}
                              </h4>
                            </div>
                            <button
                              className="icon-more float-end ig-btn"
                              onClick={() => toggleDropdownOrder(item.id)}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 19 20"
                                width="19"
                                height="20"
                                className="hide animate__animated animate__fadeInUp"
                              >
                                <path
                                  fill="currentColor"
                                  d="M3.8 6.7l5.7 5.7 5.7-5.7 1.6 1.6-7.3 7.2-7.3-7.2 1.6-1.6z"
                                ></path>
                              </svg>
                            </button>
                            <div className="head">
                              <h4 className="inquiry-front">
                                <b>Contact Number </b> :
                                {item.to_customer_phone
                                  ? item.to_customer_phone
                                  : ""}
                              </h4>
                            </div>
                            <div className="head w-100">
                              <div>
                                <h4 className="order-text-big-front">
                                  <b>
                                    {item.grand_total
                                      ? `${symbolCurrency}  ` +
                                        formatNumber(item.grand_total, 2)
                                      : ""}
                                  </b>
                                </h4>
                              </div>
                              <div className="">
                                <span
                                  style={{
                                    backgroundColor: item.stage_status_color
                                      ? item.stage_status_color
                                      : "var(--ig-primary)",
                                  }}
                                  className="badge rounded-pill"
                                >
                                  {item.stage_status_name}
                                </span>
                              </div>
                            </div>
                            <div className="head ">
                              <div>
                                <p className="time ">
                                  {item.cart_date
                                    ? formatDate(item.cart_date)
                                    : ""}
                                </p>
                              </div>
                              <p className="time text-end">
                                <p className="contact-text">
                                  {item.created_date_time
                                    ? convertDateTimeFormat(
                                        item.created_date_time
                                      ).date
                                    : ""}
                                </p>
                                <p className="contact-text">
                                  {item.created_date_time
                                    ? convertDateTimeFormat(
                                        item.created_date_time
                                      ).time
                                    : ""}
                                </p>
                              </p>
                            </div>
                          </div>
                        </button>
                      </>
                    ))}
              </>
              {noDataFound && <p className="no_found">No data found</p>}
            </div>
          </div>
        </>
      ) : null}
      <OrderCreateModal
        show={isOrderCreateShow}
        onHide={() => setIsOrderCreateShow(false)}
        handleSubmit={createOrderSubmit}
        title={"Create"}
        message={`Please enter your  ${
          orderTypesList?.find((option) => Number(option.id) === isOrderShowNum)
            ?.type || ""
        }`}
        btn1={"CANCEL"}
        btn2={"Save & Approve"}
        Contact={contactData}
        isOrderShowNum={isOrderShowNum}
        companyDetail={companyDetail}
      />
      {isSetReminderConfirmation && (
        <ReminderModal
          show={isSetReminderConfirmation}
          onHide={() => setIsSetReminderConfirmation(false)}
          handleSubmit={handleReminder}
          title={` Set Reminder of 
                ${
                  orderTypesList?.find(
                    (option) => Number(option.id) === isOrderShowNum
                  )?.type || ""
                }`}
          message={"Are you sure you want delete is message? "}
          btn1="CANCEL"
          btn2="set Reminder"
          request_flag="4"
        />
      )}
      <OrderCreateModal
        show={isEditOrderShow}
        onHide={() => setIsEditOrderShow(false)}
        handleSubmit={updateOrderSubmit}
        title={"Edit"}
        message={`Please enter your  ${
          orderTypesList?.find((option) => Number(option.id) === isOrderShowNum)
            ?.type || ""
        }`}
        btn1={"Close"}
        btn2={"Save & Approve"}
        Contact={contactData}
        isOrderShowNum={isOrderShowNum}
        orderById={orderById}
        companyDetail={companyDetail}
      />
      {isDeleteConfirmation && (
        <ConfirmationModal
          show={isDeleteConfirmation}
          onHide={() => setIsDeleteConfirmation(false)}
          handleSubmit={() =>
            handleDeleteOrder(
              orderIdDelete,
              setIsDeleteConfirmation,
              setRefreshCarts
            )
          }
          title={`Delete this ${
            orderTypesList?.find(
              (option) => Number(option.id) === isOrderShowNum
            )?.type || ""
          }`}
          message={`Are you sure you want to Delete this ${
            orderTypesList?.find(
              (option) => Number(option.id) === isOrderShowNum
            )?.type || ""
          }?`}
          btn1="CANCEL"
          btn2="Delete"
        />
      )}
      {isReminderConfirmationStatus && (
        <ConfirmationModal
          show={isReminderConfirmationStatus}
          onHide={() => setIsReminderConfirmationStatus(false)}
          handleSubmit={() =>
            handleChangeStatusOfReminderCompleted(
              reminderData?.id,
              setIsReminderConfirmationStatus,
              findType,
              setRefreshCarts
            )
          }
          title={"Are you sure you want to complete this Reminder?"}
          message={`Remark : ${reminderData && reminderData.reminder_remark}`}
          btn1="CANCEL"
          btn2="Complete Reminder Now"
          message1={`Reminder Date : ${
            reminderData && formatDateAndTime(reminderData.reminder_data_time)
          }`}
        />
      )}
      {isConvetIntoOrderConfirmation && (
        <ConfirmationModal
          show={isConvetIntoOrderConfirmation}
          onHide={() => setIsConvetIntoOrderConfirmation(false)}
          handleSubmit={() =>
            handleConvertIntoOrder(
              converCartId,
              setIsConvetIntoOrderConfirmation,
              setRefreshCarts
            )
          }
          title={`Convert to Order`}
          message={`Are you sure you want to Convert this Quotation Into Order?`}
          btn1="CANCEL"
          btn2="Apply"
        />
      )}
      {isConvertIntoInvoiceConfirmation && (
        <ConfirmationModal
          show={isConvertIntoInvoiceConfirmation}
          onHide={() => setIsConvertIntoInvoiceConfirmation(false)}
          handleSubmit={() =>
            handleConvertIntoInvoice(
              converCartId,
              setIsConvertIntoInvoiceConfirmation,
              setRefreshCarts
            )
          }
          title={`Convert to Invoice`}
          message={`Are you sure you want to Convert this Order Into Invoice?`}
          btn1="CANCEL"
          btn2="Apply"
        />
      )}
      {isMakeCartCopyConfirmation && (
        <ConfirmationModal
          show={isMakeCartCopyConfirmation}
          onHide={() => setIsMakeCartCopyConfirmation(false)}
          handleSubmit={() =>
            handleMakeNewCopy(
              makeCopyType,
              converCartId,
              setIsMakeCartCopyConfirmation,
              setRefreshCarts
            )
          }
          title={`Create New Copy Of ${
            orderTypesList?.find(
              (option) => Number(option.id) === isOrderShowNum
            )?.type || ""
          }`}
          message={`Are you sure you want to Create New Copy Of ${
            orderTypesList?.find(
              (option) => Number(option.id) === isOrderShowNum
            )?.type || ""
          }?`}
          btn1="CANCEL"
          btn2="Apply"
        />
      )}
      <RadioButtonModal
        show={isModalAssignStatusVisible}
        onHide={() => setIsModalAssignStatusVisible(false)}
        handleSubmit={handleConfirmInquiriesRadioButton}
        title="Assign your Order"
        message="Please select the Status for this Order."
        btn1="Cancel"
        btn2="Submit"
        options={optionRadioButtonStatus}
        selectedLabelIds={
          orderList.find((item) => item.id === statusAssignContactId)
            ?.cart_status
        }
        contactId={statusAssignContactId}
        getOptionColor={(option) => option.color || "var(--ig-primary)"}
        getOptionName={(option) => option.name}
        showColorBadge={true}
      />
    </>
  );
};

export default ListOrderView;
