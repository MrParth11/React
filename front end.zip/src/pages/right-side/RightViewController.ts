import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../helpers/AppConstants";
import { TReactSetState } from "../../helpers/AppType";
import { axiosInstance } from "../../services/axiosInstance";
import { ICompany } from "../left-side/LeftSideController";


export interface IMessageList {
  id: number;
  description: string;
  current_status: number;
  created_date_time: string;
  s_timestemp?: Date;
  company_masters_id?: number;
  contact_masters_id: number;
  message_side?: number;
  lable?: string;
  message_type_id: number;
  isReminder: number;
  reminder_data_time: string;
  reminder_remark: string;
  media_name: string;
  media_url: string;
  application_login_name: string;
  contact_name: string;
  entry_flag: number;
  is_reminder: number;
  isDelete?: number;
}
export interface IInsertObj {
  message_side?: number;
  description: string;
  contact_masters_id?: number;
}

export interface IReminder {
  dateTime: string;
  remark: string;
  status: string;
  selectedCategory: any;
}

export type TMessage = {
  id: number;
  description: string;
  lable: number;
  current_status: number;
  message_type_id: number;
  created_date_time: any;
  company_masters_id: number;
  a_application_login_id: number;
  contact_masters_id: number;
  message_side: number;
  media_url: string;
  media_name: string;
  is_reminder: number;
  entry_flag: number;
  isDelete: number;
  isActive: number;
  application_login_name: string;
  contact_name: string;
  reminder_data_time: string;
  reminder_remark: string;
  isReminder: number

};
export type TMessagesByDate = {
  date: string;
  messages: TMessage[];
};

export const fetchMessageData = async (
  setNoDataFound: TReactSetState<boolean>,
  term: string,
  setLoading: TReactSetState<boolean>,
  setMessageList: TReactSetState<TMessagesByDate[]>,
  setHasMore: TReactSetState<boolean>,
  currentPage: number,
  setCheckToken: TReactSetState<boolean>,
  contactMastersId: number | undefined,
  isCheckedReminder: boolean,
  isCheckedAttachment: boolean,
  selectedDates: Date[] | undefined,
  newStartDate: any,
  setGetCompanyId: TReactSetState<number>
) => {
  const token = localStorage.getItem("token");
  try {
    setLoading(true);
    const getUUID = await localStorage.getItem("UUID");
    const itemsPerPage = 15;
    const start: number = currentPage * itemsPerPage;
    const payload: any = {
      contact_masters_id: contactMastersId,
      a_application_login_id: getUUID,
      filterAndSearch: {
        searchTerm: term,
      },
    };
    if (newStartDate) {
      payload.startDateForUl = newStartDate === "-1" ? "-1" : newStartDate
    }
    if (isCheckedReminder) {
      payload.filterAndSearch.isChecked = isCheckedReminder ? 1 : 0;
    }
    if (isCheckedAttachment) {
      payload.filterAndSearch.isCheckedAttachment = isCheckedAttachment ? 1 : 0;
    }
    if (selectedDates && selectedDates.length > 0) {
      payload.filterAndSearch.selectedDates = selectedDates;
    }
    const response = await axiosInstance.post(
      "messageHistory",
      payload,
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (response.data.code === 200) {
      if (response.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        const newItems = response.data.data.item1;
        setGetCompanyId(response.data.data.companyId)
        if (newStartDate === "-1") {
          setMessageList(newItems);

        } else {
          setMessageList((prevMessages) => [...newItems, ...prevMessages]);
        }

        if (newItems.length === 0) {
          setHasMore(true);
        } else {
          setHasMore(false);
        }
        setNoDataFound(newItems.length === 0);
      } else {
        toast.error(response.data.ack_msg || "Unknown error occurred");
      }
    } else {
      setCheckToken(true);
      console.log("test--------2");
      toast.error(response.data.ack_msg || "Unknown error occurred");
    }
  } catch (error: any) {
    toast.error(error?.response?.data?.ack_msg || "Unknown error occurred");
  }
  finally {
    setTimeout(() => {
      setLoading(false);
    }, 300);
  }
};
export const insertMessage = async (insertObj: IInsertObj) => {
  const getUUID = await localStorage.getItem("UUID");
  const date = new Date();
  // Convert to IST
  const istOffset = 5.5 * 60 * 60 * 1000; // IST offset in ms
  const istDate = new Date(date.getTime() + istOffset);
  const formattedDateTime = `${istDate.getFullYear()}-${String(
    istDate.getMonth() + 1
  ).padStart(2, "0")}-${String(istDate.getDate()).padStart(2, "0")} ${String(
    istDate.getHours()
  ).padStart(2, "0")}:${String(istDate.getMinutes()).padStart(2, "0")}:${String(
    istDate.getSeconds()
  ).padStart(2, "0")}`;
  const requestData = {
    table: "contact_message_histories",
    data: JSON.stringify({
      ...insertObj,
      created_date_time: formattedDateTime,
    }),
  };
  console.log("rerererere", requestData.data);

  try {
    const data = await axiosInstance.post("commonCreate", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,
        },
      }

    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const deleteContact = async (contact_id: number | undefined) => {
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    table: "contact_masters",
    where: `{"id":${contact_id}}`,
    data: `{"isDelete":"1"}`,
  };
  try {
    const data = await axiosInstance.post("commonUpdate", requestData,   {
      headers: {
        "x-tenant-id": getUUID,
      },
    }
);
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const deleteMessages = async (contact_id: number | undefined) => {
  const requestData = {
    table: "contact_message_histories",
    where: `{"contact_masters_id":${contact_id}}`,
    data: `{"isDelete":"1"}`,
  };
  const getUUID = localStorage.getItem("UUID")
  try {
    const data = await axiosInstance.post("commonUpdate", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const createReminder = async (
  insertObj: IReminder,
  contactId: number | undefined,
  messageId: number | undefined,
  setIsReminderConfirmation: TReactSetState<boolean>
  // selectedCategory:any
) => {
  const getUUID = await localStorage.getItem("UUID");
  const date = new Date(insertObj.dateTime);

  const formattedDateTime = `${date.getFullYear()}-${String(
    date.getMonth() + 1
  ).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(
    date.getHours()
  ).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(
    date.getSeconds()
  ).padStart(2, "0")}`;

  const requestData = {
    table: "reminder_messages",
    data: JSON.stringify({
      a_application_login_id: Number(getUUID),
      contact_masters_id: contactId,
      reminder_data_time: formattedDateTime,
      assigned_to: insertObj.selectedCategory?.value,
      assigned_to_name: insertObj.selectedCategory?.label,
      remark: insertObj.remark,
      reference_id: messageId,
      reference_table: "contact_message_histories"
    }),
  };
  try {
    const data = await axiosInstance.post("commonCreate", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      setIsReminderConfirmation(false);
      const requestDataMsg = {
        table: "contact_message_histories",
        where: `{"id":${messageId}}`,
        data: `{"is_reminder":"1"}`,
      };
      try {
        const data = await axiosInstance.post("commonUpdate", requestDataMsg, {
          headers: {
            "x-tenant-id": getUUID,

          },
        }
        );
        if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
          return true;
        } else {
          return false;
        }
      } catch (error: any) {
        toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
      toast.success(data.data.ack_msg);
    } else {
      toast.error(data.data.ack_msg);
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchGetByIdUser = async (setLoginById: TReactSetState<any>) => {
  const token = await localStorage.getItem("token");
  const localId = await localStorage.getItem("UUID");
  try {
    const { data } = await axiosInstance.post(
      "loginId",
      {
        loginId: localId,
      },
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );
    if (data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setLoginById(data.data);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchCompanyForRightSideViewApi = async (
  setCompanyLists: TReactSetState<ICompany[]>
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");
  const requestData = {
    a_application_login_id: getUUID,
  };
  try {
    const data = await axiosInstance.post("company", requestData, {
      headers: {
        Authorization: `${token}`,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setCompanyLists([]);
    }

    setCompanyLists(data.data.data.item);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const insertAttendance = async (
  checkAttendance: number
) => {

  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    attendance_status: checkAttendance,
    a_application_login_id: getUUID,
  };

  try {
    const data = await axiosInstance.post("check-attendance", requestData, {
      headers: {
        "x-tenant-id": getUUID,
        Authorization: `${token}`,
      }
    })

    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      return false
    }


  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }

}


// db mathi last entry lai aave che 
export const viewAttendanceStatus = async (
  setSavedAttendance: TReactSetState<number>,
  setLoading: TReactSetState<boolean>
) => {


  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const requestedData = {
    request_flag: 1,
    a_application_login_id: getUUID
  }
  try {
    setLoading(true);
    const data = await axiosInstance.post("view-attendance", requestedData, {
      headers: {
        "x-tenant-id": getUUID,
        Authorization: `${token}`,
      }
    })
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      return console.log("Error");
    }

    setSavedAttendance(data.data.data);

  } catch (error: any) {

    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);

  }
  finally {
    setTimeout(() => {
      setLoading(false);
    }, 300);
  }

}