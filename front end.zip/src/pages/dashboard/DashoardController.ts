import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../../helpers/AppConstants";
import { axiosInstance } from "../../services/axiosInstance";
import { TReactSetState } from "../../helpers/AppType";

export interface ISourceOfTypesForDashBoard {
  source_name: string;
  id: number;
  color: string;
}
export const fetchContactApi = async (
  setTotalContact: TReactSetState<number>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");
  try {
    const { data } = await axiosInstance.post(
      "Contact",
      {
        ul: 0, // Upper limit based on page number
        ll: 13, // Lower limit based on page number
        a_application_login_id: Number(getUUID),
      },
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );
    if (data && data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {

        setTotalContact(data?.data?.totalContactCount);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchInquiryApiForTotal = async (
  setTotalInquiry: TReactSetState<number>,
  setInquiryList: TReactSetState<any>,
  setInquiryMontList: TReactSetState<any>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  try {
    const { data } = await axiosInstance.post(
      "inquiry",
      {
        ul: 0, // Upper limit based on page number
        ll: 13, // Lower limit based on page number
        a_application_login_id: Number(getUUID),
      },
      {
        headers: {
          Authorization: `${token}`,
        },
      }
    );
    if (data && data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setTotalInquiry(data?.data?.totalInquiryCount);

        setInquiryList(data.data.sourceTypeVsInquiry);
        setInquiryMontList(data.data.inquiryVsOpportunity);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchReminderApiForTotal = async (
  setTotalReminder: TReactSetState<number>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");

  try {
    const { data } = await axiosInstance.post(
      "reminder",
      {
        ul: 0, // Upper limit based on page number
        ll: 13, // Lower limit based on page number
        a_application_login_id: Number(getUUID),
      },
      {
        headers: {
          Authorization: `${token}`,
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data && data.code === 200) {
      if (data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
        setTotalReminder(data?.data?.totalReminderCount);
      } else {
        toast.error(data.ack_msg || MESSAGE_UNKNOWN_ERROR_OCCURRED);
      }
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchSourceOfTypesApiForDashboard = async (
  setSourceOfTypesLists: TReactSetState<ISourceOfTypesForDashBoard[]>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");
  const requestData = {
    a_application_login_id: getUUID,
  };
  try {
    const data = await axiosInstance.post("sourceOfTypes", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setSourceOfTypesLists([]);
    }
    setSourceOfTypesLists(data.data.data.item);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchOrderTotal = async (
  setQuotation: React.Dispatch<React.SetStateAction<number>>,
  setOrder: TReactSetState<number>,
  setInvoice: TReactSetState<number>,
  setTotalReminder: TReactSetState<number>,
  setTotalInquiry: TReactSetState<number>,
  setInquiryList: TReactSetState<any>,
  setInquiryMontList: TReactSetState<any>,
  setTotalContact: TReactSetState<number>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");
  const requestData = {
    a_application_login_id: getUUID,
  };
  try {
    const data = await axiosInstance.post("totalOrder", requestData, {
      headers: {
        Authorization: `${token}`,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setQuotation(0);
      setOrder(0);
      setInvoice(0);
    }
    console.log("");
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const fetchAllDashoardApi = async (
  setQuotation: TReactSetState<number>,
  setOrder: TReactSetState<number>,
  setInvoice: TReactSetState<number>,
  setTotalReminder: TReactSetState<number>,
  setTotalInquiry: TReactSetState<number>,
  setInquiryList: TReactSetState<any>,
  setInquiryMontList: TReactSetState<any>,
  setTotalContact: TReactSetState<number>
) => {
  const getUUID = await localStorage.getItem("UUID");
  const token = await localStorage.getItem("token");
  const requestData = {
    a_application_login_id: getUUID,
  };
  try {
    const data = await axiosInstance.post("insight", requestData, {
      headers: {
        Authorization: `${token}`,
        "x-tenant-id": getUUID,
      },
    });
    if (data.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
      setQuotation(0);
      setOrder(0);
      setInvoice(0);
    }
    setInquiryList(data.data.data.sourceTypeVsInquiry);
    setInquiryMontList(data.data.data.inquiryVsOpportunity);
    setTotalContact(data.data.data.totalContactCount);
    setTotalInquiry(data.data.data.totalInquiryCount);
    setTotalReminder(data.data.data.totalReminderCount);
    setQuotation(data.data.data.totalQuotation);
    setOrder(data.data.data.totalOrder);
    setInvoice(data.data.data.totalInvoice);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
