import React, { useEffect, useState } from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import { useTheme } from "../../components/ThemeContext";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import {
  fetchAllDashoardApi,
  fetchSourceOfTypesApiForDashboard,
  ISourceOfTypesForDashBoard,
} from "./DashoardController";
import { Bar, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
} from "chart.js";
import { openInNewTab } from "../../common/SharedFunction";
import useCheckUserPermission from "../../hooks/useCheckUserPermission";
import { PAGE_ID, PERMISSION_TYPE } from "../../helpers/AppEnum";
import DateTimeRangePicker from "../../components/DateTimeRangePicker";
import TeamPerformanceReports from "./Reports/Team Performance/TeamPerformanceReports";
import OrderStatisticsReports from "./Reports/OrderStatisticsReports";
import { toast } from "react-toastify";
import AccountOutstandingReportsVIew from "./Reports/Account Outstanding/AccountOutstandingReportsVIew";
import { fetchAccountOutstanding } from "./Reports/Account Outstanding/AccountOutstandingReportsController";
import TeamPendingWokReportsView from "./Reports/Team Pending Work/TeamPendingWokReportsVIew";
import ProductInventoryReport from "./Reports/Product Inventory/ProductInventory";

import MultiSelect, { Option } from "../../components/MultiSelect";
import TeamAttendanceReportsView from "./Reports/Attendance & Salary Report/AttendanceReportView";
import { fetchCompanyTeamApi, ICompanyTeam } from "../left-side/LeftSideController";
import colors from "react-multi-date-picker/plugins/colors";

// Register required chart.js components
ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title
);

interface IPropDashboardView {
  isDashBoardOpen: boolean;
  closeDashboard: () => void;
  companyInfo: any;
  contactData?: any;
}

const DashboardView = ({
  isDashBoardOpen,
  closeDashboard,
  companyInfo,
  contactData,
}: IPropDashboardView) => {
  const [totalContact, setTotalContact] = useState(0);
  const [totalInquiry, setTotalInquiry] = useState(0);
  const [inquiryList, setInquiryList] = useState<any>();
  const [inquiryMontList, setInquiryMontList] = useState<any>();
  const { darkMode } = useTheme();
  const [loading, setLoading] = useState(false);
  const [totalReminder, setTotalReminder] = useState(0);
  const [quotation, setQuotation] = useState<number>(0);
  const [order, setOrder] = useState(0);
  const [invoice, setInvoice] = useState(0);
  const [sourceOfTypesList, setSourceOfTypesLists] = useState<
    ISourceOfTypesForDashBoard[]
  >([]);
  const [selectReportType, setSelectReportType] = useState("");
  const [appliedReportType, setAppliedReportType] = useState("");
  const [reportKey, setReportKey] = useState(0); // To force re-render of report components
  const [companyTeamLists, setCompanyTeamLists] = useState<ICompanyTeam[]>([]);
  const [optionSelected, setOptionSelected] = useState<Option[] | null>(null);

  // Initialize selectedDates with the current month's start and end dates
  const getCurrentMonthDateRange = () => {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return [startOfMonth, endOfMonth];
  };

  const [selectedDates, setSelectedDates] = useState<Date[] | null>(
    getCurrentMonthDateRange()
  );
  const [appliedDates, setAppliedDates] = useState<Date[] | null>(null); // Store dates after "Apply" is clicked

  const companyMasterId = companyInfo.map((item: any) => item.id);

  // Prepare chart data
  const labelsPieChart =
    sourceOfTypesList && sourceOfTypesList.map((source) => source.source_name);
  const backgroundColorPieChart =
    sourceOfTypesList && sourceOfTypesList.map((source) => source.color);

  const dataValuesPieChart = sourceOfTypesList.map((source) => {
    const found =
      inquiryList &&
      inquiryList.find(
        (data: { source_type_id: number }) => data.source_type_id === source.id
      );
    return found ? found.counts : 0;
  });

  const pieChartData = {
    labels: labelsPieChart,
    datasets: [
      {
        data: dataValuesPieChart,
        backgroundColor: backgroundColorPieChart,
      },
    ],
  };

  const pieChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    aspectRatio: 1,
    plugins: {
      legend: {
        position: "top" as const,
      },
      tooltip: {
        enabled: true,
      },
    },
  };

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const labelsBarChart =
    inquiryMontList &&
    inquiryMontList.map(
      (data: { month: number }) => monthNames[data.month - 1]
    );
  const dataValuesBarChart =
    inquiryMontList &&
    inquiryMontList.map((data: { counts: any }) => data.counts);

  const barChartData = {
    labels: labelsBarChart,
    datasets: [
      {
        label: "Sales 2025 (in INR)",
        data: [1, 1, 1, 11, 1, 1],
        backgroundColor: "rgba(75, 192, 192, 0.2)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 1,
         
      },
      {
        label: `Total Inquiry 2025`,
        data: dataValuesBarChart,
        backgroundColor: "rgba(255, 99, 132, 0.2)",
        borderColor: "rgba(255, 99, 132, 1)",
        borderWidth: 1,
      },
    ],
  };

  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top" as const,
      },
      title: {
        display: true,
        text: "Monthly Inquiry for 2025",
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const canViewReportAndStatistics = useCheckUserPermission(
    PAGE_ID.THIRD_PARTY_LEAD_GENERATION,
    PERMISSION_TYPE.VIEW
  );

  const handelRefreshDashboard = async () => {
    setLoading(true);
    try {
      await fetchAllDashoardApi(
        setQuotation,
        setOrder,
        setInvoice,
        setTotalReminder,
        setTotalInquiry,
        setInquiryList,
        setInquiryMontList,
        setTotalContact
      );
      await fetchSourceOfTypesApiForDashboard(setSourceOfTypesLists);
      await fetchAccountOutstanding;
      await fetchCompanyTeamApi(setCompanyTeamLists, companyMasterId[0], "");
    } finally {
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    }
  };

  useEffect(() => {
    handelRefreshDashboard();
  }, []);

  const handelSearchDateChange = (selectedDates: Date[] | undefined) => {
    if (
      selectedDates &&
      selectedDates.length === 2 &&
      selectedDates[0] <= selectedDates[1]
    ) {
      setSelectedDates(selectedDates || []);
    }
  };

  const openReport = () => {
    if (!selectReportType || selectReportType === "select") {
      toast.error("Please select a valid report type.");
      return;
    }

    if (!selectedDates || selectedDates.length !== 2) {
      toast.error("Please select a valid date range.");
      return;
    }

    setAppliedReportType(selectReportType);
    setAppliedDates(selectedDates); // Apply the selected dates
    setReportKey((prev) => prev + 1); // Force re-render of report components
  };

  const options = companyTeamLists.map((item) => ({
    value: item.id,
    label: item.username,
  }));
  const handleChange = (selected: Option[]) => {
    setOptionSelected(selected);
  };

  const handleReportTypeChange = (e: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setSelectReportType(e.target.value);
    setAppliedReportType(""); // Reset applied report type
    setAppliedDates(null); // Reset applied dates
  };

  const selectedTeamMemberId = optionSelected?.map((e, i) => {
    return e.value;
  });
  console.log(selectedTeamMemberId);

  return (
    <>
      {isDashBoardOpen ? (
        <div
          style={{
            flex: "60%",
            display: "flex",
            overflow: "scroll",
            // backgroundColor: "#f0f2f5",
            backgroundColor: "#121212"
          }}
          id="right"
        >
          <Container fluid className="mt-2">
            <div className="col-12 text-end mb-2">
              <div className="ICON">
                <button className="icons">
                  <p
                    className="landing-page-text"
                    style={{
                      cursor: "pointer",
                      color: "blue",
                      fontSize: "13px",
                    }}
                    onClick={() => openInNewTab("/videoTutorial", 11)}
                  >
                    Learn More :
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      height="24px"
                      viewBox="0 -960 960 960"
                      width="24px"
                      fill="#0000FF"
                    >
                      <path d="M616-242q-27 1-51.5 1.5t-43.5.5h-41q-71 0-133-2-53-2-104.5-5.5T168-257q-26-7-45-26t-26-45q-6-23-9.5-56T82-447q-2-36-2-73t2-73q2-30 5.5-63t9.5-56q7-26 26-45t45-26q23-6 74.5-9.5T347-798q62-2 133-2t133 2q53 2 104.5 5.5T792-783q26 7 45 26t26 45q6 23 9.5 56t5.5 63q2 36 2 73v17q-19-8-39-12.5t-41-4.5q-83 0-141.5 58.5T600-320q0 21 4 40.5t12 37.5ZM400-400l208-120-208-120v240Zm360 200v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z" />
                    </svg>
                  </p>
                </button>
                <button className="icons" onClick={handelRefreshDashboard}>
                  <svg width="30" height="30" viewBox="0 0 50 50">
                    <path
                      fill="currentColor"
                      d="M25 38c-7.2 0-13-5.8-13-13 0-3.2 1.2-6.2 3.3-8.6l1.5 1.3C15 19.7 14 22.3 14 25c0 6.1 4.9 11 11 11 1.6 0 3.1-.3 4.6-1l.8 1.8c-1.7.8-3.5 1.2-5.4 1.2z"
                    />
                    <path
                      fill="currentColor"
                      d="M34.7 33.7l-1.5-1.3c1.8-2 2.8-4.6 2.8-7.3 0-6.1-4.9-11-11-11-1.6 0-3.1.3-4.6 1l-.8-1.8c1.7-.8 3.5-1.2 5.4-1.2 7.2 0 13 5.8 13 13 0 3.1-1.2 6.2-3.3 8.6z"
                    />
                    <path fill="currentColor" d="M18 24h-2v-6h-6v-2h8z" />
                    <path fill="currentColor" d="M40 34h-8v-8h2v6h6z" />
                  </svg>
                </button>
                <button className="icons" onClick={closeDashboard}>
                  <span>
                    <svg
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      width="24"
                      height="24"
                      className=""
                    >
                      <path d="m19.1 17.2-5.3-5.3 5.3-5.3-1.8-1.8-5.3 5.4-5.3-5.3-1.8 1.7 5.3 5.3-5.3 5.3L6.7 19l5.3-5.3 5.3 5.3 1.8-1.8z"></path>
                    </svg>
                  </span>
                </button>
              </div>
            </div>

            {loading ? (
              <>
                <Row style={{ marginTop: "40px" }}>
                  {Array.from({ length: 4 }).map((_, index) => (
                    <Col md={3} key={index}>
                      <div className="">
                        <Skeleton
                          width="100%"
                          height={100}
                          duration={1.5}
                          style={{ opacity: darkMode ? "" : 0.5 }}
                        />
                      </div>
                    </Col>
                  ))}
                </Row>

                {Array.from({ length: 1 }).map((_, index) => (
                  <Row
                    className="mb-2"
                    key={index}
                    style={{ marginTop: "30px" }}
                  >
                    <Col md={6}>
                      <Skeleton
                        width="100%"
                        height={220}
                        duration={1.5}
                        style={{ opacity: darkMode ? "" : 0.5 }}
                      />
                    </Col>
                    <Col md={6}>
                      <Skeleton
                        width="100%"
                        height={220}
                        duration={1.5}
                        style={{ opacity: darkMode ? "" : 0.5 }}
                      />
                    </Col>
                  </Row>
                ))}

                <Row style={{ marginTop: "40px" }}>
                  <Col>
                    <Skeleton
                      width="100%"
                      height={120}
                      duration={1.5}
                      style={{ opacity: darkMode ? "" : 0.5 }}
                    />
                  </Col>
                </Row>
              </>
            ) : (
              <>
                <Row className="mb-2" >
                  <Col md={3}>
                    <Card className="text-end" style={{backgroundColor:"#262626" ,color:"#fff"}}>
                      <Card.Body >
                        <div className="" >
                          <h4 className="dash-board-text-count" style={{color:"#f5f5f5"}}>
                            {totalContact}
                          </h4>
                          <span>
                            <svg
                              width="30"
                              height="30"
                              viewBox="0 0 24 24"
                              fill="none"
                            >
                              <path
                                opacity="0.1"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M5 5C5 3.89543 5.89543 3 7 3H19C20.1046 3 21 3.89543 21 5V19C21 20.1046 20.1046 21 19 21H17.245C17.2513 20.9694 17.2519 20.937 17.2459 20.9044C17.0276 19.7209 16.6277 18.9082 15.9145 18.4054C15.2115 17.9097 14.2512 17.75 13 17.75C11.7461 17.75 10.7856 17.923 10.0828 18.4324C9.37171 18.9478 8.97232 19.7715 8.75415 20.9547C8.75134 20.9699 8.74997 20.9851 8.74996 21H7C5.89543 21 5 20.1046 5 19V5ZM9.75 12C9.75 10.2051 11.2051 8.75 13 8.75C14.7949 8.75 16.25 10.2051 16.25 12C16.25 13.7949 14.7949 15.25 13 15.25C11.2051 15.25 9.75 13.7949 9.75 12Z"
                                 fill="#f5f5f5"
                              ></path>
                              <path
                                d="M5 7V5C5 3.89543 5.89543 3 7 3H13H19C20.1046 3 21 3.89543 21 5V7V17V19C21 20.1046 20.1046 21 19 21H13H7C5.89543 21 5 20.1046 5 19V17V7Z"
                                stroke="#f5f5f5"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                              ></path>
                              <path
                                d="M16 12C16 13.6569 14.6569 15 13 15C11.3431 15 10 13.6569 10 12C10 10.3431 11.3431 9 13 9C14.6569 9 16 10.3431 16 12Z"
                                stroke="#f5f5f5"
                                stroke-width="2"
                              ></path>
                              <path
                                d="M9 21C9.42546 18.6928 10.52 18 13 18C15.48 18 16.5745 18.6425 17 20.9497"
                                stroke="#f5f5f5"
                                stroke-width="2"
                                stroke-linecap="round"
                              ></path>
                              <path
                                d="M3 7H5"
                                stroke="#f5f5f5"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                              ></path>
                              <path
                                d="M3 17H5"
                                stroke="#f5f5f5"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                              ></path>
                              <path
                                d="M3 12H5"
                                stroke="#f5f5f5"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                              ></path>
                            </svg>
                          </span>
                          <h4 className="dash-board-text" style={{color:"#f5f5f5"}}> Total Contact</h4>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col md={3}>
                    <Card className="text-end" style={{backgroundColor:"#262626" ,color:"#f5f5f5"}}>
                      <Card.Body>
                        <h4 className="dash-board-text-count" style={{color:"#f5f5f5"}}>
                          {totalInquiry}
                        </h4>

                        <span>
                          <svg
                            width="30"
                            height="30"
                            viewBox="0 0 24 24"
                             fill="#f5f5f5"
                          >
                            <path
                              d="M5.25366 13.9999L16.2419 14.0011C16.3459 14.1727 16.4732 14.3321 16.6227 14.474L17.3413 15.1561C17.3004 15.315 17.2471 15.4742 17.1814 15.6338C17.0589 15.5492 16.9118 15.4999 16.7532 15.4999H5.25366C4.83945 15.4999 4.50366 15.8357 4.50366 16.2499V17.1572C4.50366 17.8129 4.78965 18.4359 5.28683 18.8634C6.54491 19.945 8.44092 20.5011 11.0001 20.5011C11.2918 20.5011 11.5748 20.4938 11.8493 20.4794C11.931 20.9259 12.1441 21.3505 12.4808 21.6886L12.7083 21.9167C12.1668 21.973 11.5973 22.0011 11.0001 22.0011C8.11062 22.0011 5.87181 21.3445 4.30894 20.0008C3.48032 19.2884 3.00366 18.25 3.00366 17.1572V16.2499C3.00366 15.0073 4.01102 13.9999 5.25366 13.9999ZM17.0106 12.245L17.5139 11.0581C17.75 10.5015 18.3154 10.1987 18.8699 10.3143L18.9884 10.3455L19.6187 10.5469C20.2436 10.7466 20.7222 11.2819 20.8768 11.9542C21.2441 13.5518 20.8034 15.4969 19.5548 17.7896C18.3079 20.0789 16.9414 21.4553 15.455 21.9189C14.8779 22.099 14.258 21.9682 13.7916 21.5767L13.6684 21.4635L13.1897 20.9829C12.7749 20.5664 12.6894 19.9076 12.9676 19.3921L13.0382 19.2759L13.7597 18.2159C14.0436 17.7989 14.5292 17.6015 14.9971 17.7012L15.1241 17.7358L16.456 18.18C16.9876 17.7778 17.4307 17.2715 17.7856 16.6612C18.0897 16.138 18.2887 15.6078 18.3824 15.0705L18.4205 14.8013L17.3115 13.7487C16.9462 13.4019 16.8135 12.862 16.9628 12.376L17.0106 12.245L17.5139 11.0581L17.0106 12.245ZM11.0001 2.00462C13.7615 2.00462 16.0001 4.2432 16.0001 7.00462C16.0001 9.76605 13.7615 12.0046 11.0001 12.0046C8.2387 12.0046 6.00012 9.76605 6.00012 7.00462C6.00012 4.2432 8.2387 2.00462 11.0001 2.00462ZM11.0001 3.50462C9.06712 3.50462 7.50012 5.07163 7.50012 7.00462C7.50012 8.93762 9.06712 10.5046 11.0001 10.5046C12.9331 10.5046 14.5001 8.93762 14.5001 7.00462C14.5001 5.07163 12.9331 3.50462 11.0001 3.50462Z"
                               fill="#f5f5f5"
                            ></path>
                          </svg>
                        </span>
                        <h4 className="dash-board-text" style={{color:"#f5f5f5"}}>Total Inquiry</h4>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col md={3}>
                    <Card className="text-end" style={{backgroundColor:"#262626" ,color:"#f5f5f5"}}>
                      <Card.Body>
                        <h4 className="dash-board-text-count"  style={{color:"#f5f5f5"}}>
                          {totalReminder}
                        </h4>

                        <span>
                          <svg
                            height="30px"
                            viewBox="0 -960 960 960"
                            width="30px"
                            fill="#f5f5f5"
                          >
                            <path d="m612-292 56-56-148-148v-184h-80v216l172 172ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 320q133 0 226.5-93.5T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160Z" />
                          </svg>
                        </span>
                        <h4 className="dash-board-text" style={{color:"#f5f5f5"}}>Pending Reminder</h4>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col md={3}>
                    <Card className="text-end" style={{backgroundColor:"#262626" ,color:"#f5f5f5"}}>
                      <Card.Body>
                        <h4 className="dash-board-text-count" style={{color:"#f5f5f5"}}>
                          {quotation} | {order} | {invoice}
                        </h4>
                        <span>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            height="30px"
                            viewBox="0 -960 960 960"
                            width="30px"
                             fill="#f5f5f5"
                          >
                            <path d="M280-80q-33 0-56.5-23.5T200-160q0-33 23.5-56.5T280-240q33 0 56.5 23.5T360-160q0 33-23.5 56.5T280-80Zm400 0q-33 0-56.5-23.5T600-160q0-33 23.5-56.5T680-240q33 0 56.5 23.5T760-160q0 33-23.5 56.5T680-80ZM246-720l96 200h280l110-200H246Zm-38-80h590q23 0 35 20.5t1 41.5L692-482q-11 20-29.5 31T622-440H324l-44 80h480v80H280q-45 0-68-39.5t-2-78.5l54-98-144-304H40v-80h130l38 80Zm134 280h280-280Z" />
                          </svg>
                        </span>
                        <h4 className="dash-board-text" style={{color:"#f5f5f5"}}>
                          Quot. | Order | Invoice
                        </h4>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>

                {/* Second Row with Charts */}
                <Row className="mb-2">
                  <Col md={6}>
                    <Card
                      className="text-center"
                      style={{ height: "300px", borderRadius: "0px", backgroundColor:"#262626", color:"#f5f5f5" }}
                    >
                      <Card.Body>
                        <div className="" style={{ height: "220px" }}>
                          <Doughnut
                            data={pieChartData}
                            options={pieChartOptions}
                          />
                        </div>
                        <h4 className="dash-board-text mt-3" style={{color:"#f5f5f5"}}>
                          Source Type Vs Inquiry
                        </h4>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col md={6}>
                    <Card
                      className="text-center"
                      style={{ height: "300px", borderRadius: "0px", backgroundColor:"#262626"}}
                    >
                      <Card.Body>
                        <div>
                          <Bar data={barChartData} options={barChartOptions} />
                        </div>
                        <h4 className="dash-board-text mt-3" style={{color:"#f5f5f5"}}>
                          Inquiry Vs Opportunity
                        </h4>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>

                {/* Reports & Statistics Section */}
                {canViewReportAndStatistics && (
                  <Row>
                    <Col>
                      <Card
                        className="text-center"
                        style={{backgroundColor:"#262626" ,color:"#f5f5f5"}}
                      >
                        <Card.Body>
                          <h5 className="dash-board-text-count" style={{color:"#f5f5f5"}}>
                            Reports & Statistics
                          </h5>
                          <hr />
                          <div className="container-fluid d-flex ">
                            <div className="col-9 d-flex  align-items-center">
                              {/* Select Report */}
                              <div className="form-group col-11">
                                <div style={{ float: "left", width: "33%" }}>
                                  <label
                                    htmlFor="reportType"
                                    className="form-label"
                                    style={{
                                      textAlign: "left",
                                      display: "block",
                                    }}
                                  >
                                    <b>
                                      Select Report
                                      <span className="text-danger">*</span>
                                    </b>
                                  </label>
                                  <select
                                    style={{
                                      width: "90%",
                                      fontSize: "14px",
                                    }}
                                    className="form-control"
                                    name="reportType"
                                    id="reportType"
                                    value={selectReportType}
                                    onChange={handleReportTypeChange}
                                  >
                                    <option value="select">Select</option>
                                    <option value="team_performance">
                                      Team Performance
                                    </option>
                                    {/* <option value="order_statistics">
                                    Quotation / Order / Invoice / Purchase
                                    Statistics
                                  </option> */}
                                    <option value="account">
                                      Account Outstanding
                                    </option>
                                    <option value="pending">
                                      Pending Work
                                    </option>
                                    <option value="product_inventory">
                                      Product Inventory & Stock Alert
                                    </option>
                                    <option value="attendance_salary">
                                      Attendance & Salary
                                    </option>
                                    {/* <option value="team_member">
                                    Team Member
                                  </option> */}
                                  </select>
                                </div>
                                <div style={{ float: "left", width: "33%" }}>
                                  <label
                                    htmlFor="dateRange"
                                    className="form-label"
                                    style={{
                                      textAlign: "left",
                                      display: "block",
                                    }}
                                  >
                                    <b>
                                      Select Date Range
                                      <span className="text-danger">*</span>
                                    </b>
                                  </label>
                                  <div
                                    className="d-flex align-items-center"
                                    style={{
                                      fontSize: "14px",
                                      paddingBottom: "10px",
                                    }}
                                  >
                                    <DateTimeRangePicker
                                      value={
                                        selectedDates ||
                                        getCurrentMonthDateRange()
                                      }
                                      onChange={handelSearchDateChange}
                                      showTime={false}
                                      numberOfMonthsShow={1}
                                    />
                                    <span className="ms-2">
                                      <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        height="22px"
                                        viewBox="0 -960 960 960"
                                        width="22px"
                                         fill="#f5f5f5"
                                      >
                                        <path d="M200-80q-33 0-56.5-23.5T120-160v-560q0-33 23.5-56.5T200-800h40v-80h80v80h320v-80h80v80h40q33 0 56.5 23.5T840-720v560q0 33-23.5 56.5T760-80H200Zm0-80h560v-400H200v400Zm0-480h560v-80H200v80Zm0 0v-80 80Zm280 240q-17 0-28.5-11.5T440-440q0-17 11.5-28.5T480-480q17 0 28.5 11.5T520-440q0 17-11.5 28.5T480-400Zm-160 0q-17 0-28.5-11.5T280-440q0-17 11.5-28.5T320-480q17 0 28.5 11.5T360-440q0 17-11.5 28.5T320-400Zm320 0q-17 0-28.5-11.5T600-440q0-17 11.5-28.5T640-480q17 0 28.5 11.5T680-440q0 17-11.5 28.5T640-400ZM480-240q-17 0-28.5-11.5T440-280q0-17 11.5-28.5T480-320q17 0 28.5 11.5T520-280q0 17-11.5 28.5T480-240Zm-160 0q-17 0-28.5-11.5T280-280q0-17 11.5-28.5T320-320q17 0 28.5 11.5T360-280q0 17-11.5 28.5T320-240Zm320 0q-17 0-28.5-11.5T600-280q0-17 11.5-28.5T640-320q17 0 28.5 11.5T680-280q0 17-11.5 28.5T640-240Z" />
                                      </svg>
                                    </span>
                                  </div>
                                </div>
                                <div style={{ float: "left", width: "33%" }}>
                                  <label
                                    htmlFor="reportType"
                                    className="form-label"
                                    style={{
                                      textAlign: "left",
                                      display: "block",
                                    }}
                                  >
                                    <b>
                                      Team Member
                                      <span className="text-danger">*</span>
                                    </b>
                                  </label>

                                  <div
                                    className=""
                                    style={{
                                      fontSize: "14px",
                                      paddingBottom: "10px",
                                    }}
                                  >
                                    <MultiSelect
                                      key="example_id"
                                      options={options}
                                      onChange={handleChange}
                                      value={optionSelected}
                                      isSelectAll={true}
                                      menuPlacement="bottom"
                                      menuStyle={{
                                        left: "90%",
                                        right: "auto",
                                        transform: "none",
                                        height: "42px",
                                        backgroundColor: darkMode ? "#121212" : "#f5f5f5",
                                        color: darkMode ? "#f5f5f5" : "#121212",
                                      }}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="d-flex justify-content-between align-items-center">
                              <div className="form-group col-4">
                                <button
                                  type="button"
                                  className="btn btn-primary px-3 py-2 ms-2 text-light form_label rounded-1 fs-6"
                                  style={{
                                    backgroundColor: "#f58634",
                                  }}
                                  onClick={openReport}
                                >
                                  Apply
                                </button>
                              </div>
                            </div>
                          </div>

                          <hr />

                          {appliedReportType === "" && (
                            <p>Please Select a Report Type and Date Range.</p>
                          )}

                          {appliedReportType === "team_performance" &&
                            appliedDates && (
                              <TeamPerformanceReports
                                key={reportKey}
                                selectedDates={appliedDates}
                                selectedTeamMembers={
                                  optionSelected?.map((e) => String(e.value)) ||
                                  null
                                }
                              />
                            )}

                          {/* {appliedReportType === "order_statistics" &&
                            appliedDates && (
                              <OrderStatisticsReports
                                key={reportKey}
                                // selectedDates={appliedDates}
                              />
                            )} */}

                          {appliedReportType === "account" && appliedDates && (
                            <AccountOutstandingReportsVIew
                              key={reportKey}
                              selectedDates={appliedDates}
                            />
                          )}

                          {appliedReportType === "pending" && appliedDates && (
                            <TeamPendingWokReportsView
                              key={reportKey}
                              selectedDates={appliedDates}
                              selectedTeamMembers={
                                optionSelected?.map((e) => String(e.value)) ||
                                null
                              }
                            />
                          )}

                          {appliedReportType === "product_inventory" &&
                            appliedDates && (
                              <ProductInventoryReport
                                key={reportKey}
                                selectedDates={appliedDates}
                              />
                            )}
                          {appliedReportType === "attendance_salary" &&
                            appliedDates && (
                              <TeamAttendanceReportsView
                                key={reportKey}
                                selectedDates={appliedDates}
                                selectedTeamMembers={
                                  optionSelected?.map((e) => String(e.value)) ||
                                  null
                                }
                              />
                            )}
                        </Card.Body>
                      </Card>
                    </Col>
                  </Row>
                )}
              </>
            )}
          </Container>
        </div>
      ) : (
        ""
      )}
    </>
  );
};

export default DashboardView;
