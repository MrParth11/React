import React, { useState, useEffect, useRef } from "react";
import {
  DataTable,
  type DataTableFilterEvent,
  type DataTableFilterMeta,
  type DataTablePageEvent,
  type DataTableSortEvent,
  type SortOrder,
} from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as xlsx from "xlsx";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import {
  fetchAccountOutstanding,
  IAccountOutstanding,
} from "./AccountOutstandingReportsController";

interface IPropDataTableView {
  showReportTable: boolean;
  closeReportTable: () => void;
}

interface LazyTableState {
  first: number;
  rows: number;
  page: number;
  sortField?: string | null;
  sortOrder?: SortOrder | null;
  filters: DataTableFilterMeta;
}

interface IPropAccountOutstandingReports {
  selectedDates: Date[];
}

const getNestedValue = (obj: any, path: string): any => {
  try {
    return (
      path.split(".").reduce((acc, part) => {
        if (acc == null) return undefined;
        return acc[part];
      }, obj) ?? ""
    );
  } catch {
    return "";
  }
};

const AccountOutstandingReports = ({
  selectedDates,
}: IPropAccountOutstandingReports) => {
  const [loading, setLoading] = useState(false);
  const [totalRecords, setTotalRecords] = useState(0);
  const [customers, setCustomers] = useState<IAccountOutstanding[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [selectedCustomers, setSelectedCustomers] = useState<
    IAccountOutstanding[]
  >([]);
  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: {
      contact_name: { value: null, matchMode: "contains" },
      total_outstanding_amount: { value: null, matchMode: "contains" },
      outstanding_type: { value: null, matchMode: "contains" },
    },
  });
  const [accountOutstanding, setAccountOutstanding] = useState<
    IAccountOutstanding[]
  >([]);

  const dataArray: IAccountOutstanding[] = accountOutstanding
    ? accountOutstanding.map((item, index) => ({
        contact_name: item.contact_name,
        total_outstanding_amount: item.total_outstanding_amount,
        outstanding_type: item.outstanding_type,
        total_credit: item.total_credit,
        total_debit: item.total_debit,
      }))
    : [];

  useEffect(() => {
    fetchAccountOutstanding(setAccountOutstanding, selectedDates);
  }, []);

  const dt = useRef<DataTable<IAccountOutstanding[]>>(null);
  const networkTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    loadLazyData();
    return () => {
      if (networkTimeout.current) clearTimeout(networkTimeout.current);
    };
  }, [lazyState, accountOutstanding]);

  const loadLazyData = () => {
    setLoading(true);
    if (networkTimeout.current) clearTimeout(networkTimeout.current);

    networkTimeout.current = setTimeout(() => {
      let filteredData = [...dataArray];

      console.log("DEBUG: Current filters:", lazyState.filters);

      Object.entries(lazyState.filters).forEach(([field, meta]) => {
        if ("value" in meta && meta.value !== null && meta.value !== "") {
          const filterValue = meta.value.toString().toLowerCase();
          const matchMode = meta.matchMode;

          filteredData = filteredData.filter((item) => {
            const fieldValue = getNestedValue(item, field);
            if (fieldValue === undefined || fieldValue === null) return false;

            const fieldStr = fieldValue.toString().toLowerCase();

            switch (matchMode) {
              case "contains":
                return fieldStr.includes(filterValue);
              case "notContains":
                return !fieldStr.includes(filterValue);
              case "startsWith":
                return fieldStr.startsWith(filterValue);
              case "endsWith":
                return fieldStr.endsWith(filterValue);
              case "equals":
                return fieldStr === filterValue;
              case "notEquals":
                return fieldStr !== filterValue;
              default:
                return true;
            }
          });
        }
      });

      if (lazyState.sortField) {
        filteredData.sort((a, b) => {
          const aValue = getNestedValue(a, lazyState.sortField!);
          const bValue = getNestedValue(b, lazyState.sortField!);
          if (aValue === undefined || aValue === null) return 1;
          if (bValue === undefined || bValue === null) return -1;
          return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
        });
        if (lazyState.sortOrder === -1) filteredData.reverse();
      }

      const start = lazyState.first;
      const end = start + lazyState.rows;
      setCustomers(filteredData.slice(start, end));
      setTotalRecords(filteredData.length);
      console.log("DEBUG: Final customers:", filteredData.slice(start, end));
      console.log("DEBUG: Total records:", filteredData.length);
      setLoading(false);
    }, 250);
  };

  const onPage = (event: DataTablePageEvent) => {
    setLazyState((prev) => ({
      ...prev,
      first: event.first,
      rows: event.rows,
      page: event.page ?? 0,
    }));
  };

  const onSort = (event: DataTableSortEvent) => {
    setLazyState((prev) => ({
      ...prev,
      sortField: event.sortField,
      sortOrder: event.sortOrder as SortOrder,
    }));
  };

  const onFilter = (event: DataTableFilterEvent) => {
    console.log("DEBUG: onFilter triggered with filters:", event.filters);
    setLazyState((prev) => ({
      ...prev,
      first: 0,
      filters: event.filters,
    }));
  };

  const onSelectionChange = (event: { value: IAccountOutstanding[] }) => {
    const value = event.value;
    setSelectedCustomers(value);
    setSelectAll(value.length === totalRecords);
  };

  const onSelectAllChange = (event: { checked: boolean }) => {
    if (event.checked) {
      setSelectAll(true);
      setSelectedCustomers([...dataArray]);
    } else {
      setSelectAll(false);
      setSelectedCustomers([]);
    }
  };
  // Calculate totals for payable and receivable amounts
  const payableTotal = customers.reduce((sum, customer) => {
    if (customer.outstanding_type.toLowerCase() === "payable") {
      return sum + Number(customer.total_outstanding_amount);
    }
    return sum;
  }, 0);

  const receivableTotal = customers.reduce((sum, customer) => {
    if (customer.outstanding_type.toLowerCase() === "receivable") {
      return sum + Number(customer.total_outstanding_amount);
    }
    return sum;
  }, 0);

  const grandTotal = payableTotal + receivableTotal;
  const exportColumns = [
    { title: "Contact Name", dataKey: "contact_name" },
    { title: "Total Outstanding Amount", dataKey: "total_outstanding_amount" },
    { title: "Outstanding Type", dataKey: "outstanding_type" },
  ];
  const footerColumns = [
    { title: "Payable Amount", dataKey: "payableTotal" },
    { title: "Receivable Amount", dataKey: "receivableTotal" },
    { title: "Grand Total", dataKey: "grandTotal" },
  ];

  const exportPdf = () => {
    const doc = new jsPDF();
  
    const tableData = (
      selectedCustomers.length ? selectedCustomers : customers
    ).map((customer) => ({
      contact_name: customer.contact_name || "-", 
      total_outstanding_amount: customer.total_outstanding_amount ?? "-", 
      outstanding_type: customer.outstanding_type || "-",
    }));
  
    if (tableData.length === 0) {
      doc.text("No data available to export", 10, 10);
      doc.save(`customers_${new Date().getTime()}.pdf`);
      return;
    }
  
    autoTable(doc, {
      columns: exportColumns,
      body: tableData,
      foot: [
        [
          `Payable: INR ${payableTotal}`,
          `Receivable: INR ${receivableTotal}`,
          `Grand Total: INR ${grandTotal}`,
        ],
      ],
      styles: { fontSize: 10, cellPadding: 2 },
      headStyles: {
        fillColor: [41, 128, 185],
        textColor: [255, 255, 255],
        fontStyle: "bold",
      },
      footStyles: {
        fillColor: [200, 200, 200], 
        textColor: [0, 0, 0],
        fontStyle: "bold",
      },
      margin: { top: 20, left: 10, right: 10, bottom: 10 },
      didDrawPage: (data) => {
        doc.setFontSize(14);
        doc.text("Accounting Outstanding Report", data.settings.margin.left ,10); 
      },
    });
  
    doc.save(`accounting_${new Date().getTime()}.pdf`);
  };

  const exportExcel = () => {
    const exportData = (
      selectedCustomers.length ? selectedCustomers : customers
    ).map((customer) => ({
      Contact_Name: customer.contact_name || "-", 
      Total_Outstanding_Amount: customer.total_outstanding_amount ?? "-", 
      Outstanding_Type: customer.outstanding_type || "-",
    }));
  
    // Calculate totals
    const payableTotal = customers.reduce((sum, customer) => {
      if (customer.outstanding_type?.toLowerCase() === "payable") {
        return sum + Number(customer.total_outstanding_amount || 0);
      }
      return sum;
    }, 0);
  
    const receivableTotal = customers.reduce((sum, customer) => {
      if (customer.outstanding_type?.toLowerCase() === "receivable") {
        return sum + Number(customer.total_outstanding_amount || 0);
      }
      return sum;
    }, 0);
  
    const grandTotal = payableTotal + receivableTotal;
  
    const footerData = [
      {}, 
      {
        Contact_Name: `Payable: ₹ ${payableTotal}`,
        Total_Outstanding_Amount: `Receivable: ₹ ${receivableTotal}`,
        Outstanding_Type: `Grand Total: ₹ ${grandTotal}`,
      },
    ];
  
    const worksheet = xlsx.utils.json_to_sheet([...exportData, ...footerData]);
  
    worksheet["!cols"] = [
      { wch: 40 }, 
      { wch: 30 },
      { wch: 20 }, 
    ];
  
    const workbook = { Sheets: { data: worksheet }, SheetNames: ["data"] };
    const excelBuffer = xlsx.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    saveAsExcelFile(excelBuffer, "accounting");
  };

  const saveAsExcelFile = (buffer: BlobPart, fileName: string) => {
    const EXCEL_TYPE =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
    const EXCEL_EXTENSION = ".xlsx";
    const data = new Blob([buffer], { type: EXCEL_TYPE });
    saveAs(
      data,
      fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
    );
  };

  const printTable = () => {
    // Calculate totals
    const payableTotal = customers.reduce((sum, customer) => {
      if (customer.outstanding_type?.toLowerCase() === "payable") {
        return sum + Number(customer.total_outstanding_amount || 0);
      }
      return sum;
    }, 0);
  
    const receivableTotal = customers.reduce((sum, customer) => {
      if (customer.outstanding_type?.toLowerCase() === "receivable") {
        return sum + Number(customer.total_outstanding_amount || 0);
      }
      return sum;
    }, 0);
  
    const grandTotal = payableTotal + receivableTotal;
  
    const printContent = `
      <html>
        <head>
          <title>Accounting Outstanding Report</title>
          <style>
            table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; font-weight: bold; }
            h1 { text-align: center; }
            tfoot { background-color: #e6e6e6; font-weight: bold; }
            .spacer-row td { border: none; padding: 4px; }
          </style>
        </head>
        <body>
          <h1>Accounting Outstanding Report</h1>
          <table>
            <thead>
              <tr>
                ${exportColumns.map((col) => `<th>${col.title}</th>`).join("")}
              </tr>
            </thead>
            <tbody>
              ${(selectedCustomers.length ? selectedCustomers : customers)
                .map(
                  (customer) => `
                  <tr>
                    <td>${customer.contact_name || "-"}</td>
                    <td>${customer.total_outstanding_amount ?? "-"}</td>
                    <td>${customer.outstanding_type || "-"}</td>
                  </tr>
                `
                )
                .join("")}
            </tbody>
            <tfoot>
              <tr class="spacer-row"><td colspan="3"></td></tr>
              <tr>
                <td>Payable: ${payableTotal}</td>
                <td>Receivable: ${receivableTotal}</td>
                <td>Grand Total: ${grandTotal}</td>
              </tr>
            </tfoot>
          </table>
        </body>
      </html>
    `;
  
    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  // Body template for total_outstanding_amount column
  const amountBodyTemplate = (rowData: IAccountOutstanding) => {
    const isReceivable =
      rowData.outstanding_type.toLowerCase() === "receivable";
    return (
      <div
        className="d-flex justify-content-end"
        style={{
          backgroundColor: isReceivable ? "#C1D8C3" : "transparent",
          padding: "8px",
          borderRadius: "4px",
        }}
      >
        ₹{rowData.total_outstanding_amount}
      </div>
    );
  };



  const amountFooterTemplate = () => {
    return (
      <div style={{ fontWeight: "bold", padding: "8px" }}>
        Grand Total : ₹
        {grandTotal.toLocaleString("en-IN", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}
      </div>
    );
  };
  const RamountFooterTemplate = () => {
    return (
      <div style={{ fontWeight: "bold", padding: "8px" }}>
        Receivable Total : ₹
        {receivableTotal.toLocaleString("en-IN", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}
      </div>
    );
  };
  const PamountFooterTemplate = () => {
    return (
      <div style={{ fontWeight: "bold", padding: "8px" }}>
        Payable Total : ₹
        {payableTotal.toLocaleString("en-IN", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}
      </div>
    );
  };

  return (
    <div>
      <div className="d-flex align-items-center justify-content-between gap-2 mb-3">
        <h3 className="dash-board-text-count">Account Outstanding Report</h3>

        <div className="d-flex gap-2">
          <Button
            icon="pi pi-file-excel"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="success"
            rounded
            onClick={exportExcel}
            tooltip="Export Excel"
          />
          <Button
            icon="pi pi-file-pdf"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="danger"
            rounded
            onClick={exportPdf}
            tooltip="Export PDF"
          />
          <Button
            icon="pi pi-print"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="secondary"
            rounded
            onClick={printTable}
            tooltip="Print"
          />
        </div>
      </div>

      <div
        className="report_card"
        style={{
          overflow: "auto",
          width: "59vw",
        }}
      >
        <DataTable
          ref={dt}
          value={customers}
          lazy
          scrollable
          filterDisplay="row"
          dataKey="id"
          paginator
          first={lazyState.first}
          rows={lazyState.rows}
          totalRecords={totalRecords}
          onPage={onPage}
          onSort={onSort}
          sortField={lazyState.sortField ?? undefined}
          sortOrder={lazyState.sortOrder ?? undefined}
          sortMode="single"
          onFilter={onFilter}
          filters={lazyState.filters}
          loading={loading}
          selection={selectedCustomers}
          onSelectionChange={onSelectionChange}
          selectAll={selectAll}
          onSelectAllChange={onSelectAllChange}
          selectionMode="multiple"
          tableStyle={{ tableLayout: "fixed", width: "100%" }}
        >
          <Column selectionMode="multiple" headerStyle={{ width: "3rem" }} />
          <Column
            field="contact_name"
            header="Contact Name"
            sortable
            filter
            filterField="contact_name"
            filterPlaceholder="Search"
            filterMatchMode="contains"
            headerStyle={{ width: "250px" }}
            footer={PamountFooterTemplate}
          />
          <Column
            field="total_outstanding_amount"
            header="Total Outstanding Amount"
            sortable
            filter
            filterPlaceholder="Search"
            filterMatchMode="contains"
            headerStyle={{ width: "250px" }}
            body={amountBodyTemplate}
            footer={RamountFooterTemplate}
          />
          <Column
            field="outstanding_type"
            header="Outstanding Type"
            sortable
            filter
            filterField="outstanding_type"
            filterPlaceholder="Search"
            filterMatchMode="contains"
            headerStyle={{ width: "250px" }}
            footer={amountFooterTemplate}
          />
        </DataTable>
      </div>
    </div>
  );
};

export default AccountOutstandingReports;
