import { toast } from "react-toastify";
import { MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../../../helpers/AppConstants";
import { TReactSetState } from "../../../../helpers/AppType";
import { axiosInstance } from "../../../../services/axiosInstance";

export interface IAccountOutstanding {
  contact_name: string;
  total_outstanding_amount: number;
  outstanding_type: string;
  total_credit:string;
  total_debit:string;
}
export const fetchAccountOutstanding = async (
  setAccountOutstanding: TReactSetState<IAccountOutstanding[]>,
  selectedDates: Date[] | undefined
) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const requestedData = {
    selected_dates: selectedDates,
    a_application_login_id: getUUID,
  };

  // console.log("selecred_dates", selectedDates);

  try {
    const response = await axiosInstance.post(
      "/accountOutstandingReport",
      requestedData,
      {
        headers: {
          "x-tenant-id": getUUID,
          Authorization: `${token}`,
        },
      }
    );

    // console.log("response", response.data.data);
    setAccountOutstanding(response.data.data);
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
