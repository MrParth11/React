import React, { useState, useEffect, useRef } from "react";
import {
  DataTable,
  type DataTableFilterEvent,
  type DataTableFilterMeta,
  type DataTablePageEvent,
  type DataTableSortEvent,
  type SortOrder,
} from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as xlsx from "xlsx";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import {
  fetchTeamPerformance,
  IAttendanceData,
  ITaskPerformance,
} from "./TeamPerformanceReportsController";
import { log } from "console";

interface LazyTableState {
  first: number;
  rows: number;
  page: number;
  sortField?: string | null;
  sortOrder?: SortOrder | null;
  filters: DataTableFilterMeta;
}
interface ITeamPerformanceReports {
  selectedDates: Date[];
  selectedTeamMembers: string[] | null;
}

const getNestedValue = (obj: any, path: string): any => {
  try {
    return (
      path.split(".").reduce((acc, part) => {
        if (acc == null) return undefined;
        return acc[part];
      }, obj) ?? ""
    );
  } catch {
    return "";
  }
};

const TeamPerformanceReports = ({
  selectedDates,
  selectedTeamMembers,
}: ITeamPerformanceReports) => {
  const [loading, setLoading] = useState(false);
  const [totalRecords, setTotalRecords] = useState(0);
  const [customers, setCustomers] = useState<ITaskPerformance[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [selectedCustomers, setSelectedCustomers] = useState<
    ITaskPerformance[]
  >([]);

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: {
      username: { value: null, matchMode: "contains" },
      contactCount: { value: null, matchMode: "contains" },
      "quotation.total": { value: null, matchMode: "contains" },
      "order.total": { value: null, matchMode: "contains" },
      "sell_invoice.total": { value: null, matchMode: "contains" },
      "purchase_invoice.total": { value: null, matchMode: "contains" },
      "visit.totalHours": { value: null, matchMode: "contains" },
      "expense.RequestedAmount": { value: null, matchMode: "contains" },
      "pendingReminder.total": { value: null, matchMode: "contains" },
    },
  });
  const [taskPerformance, setTaskPerformance] = useState<ITaskPerformance[]>(
    []
  );
  const [attendanceData, setAttendanceData] = useState<IAttendanceData[]>([]);
  const [error, setError] = useState<string | null>(null);

  const dataArray: ITaskPerformance[] = taskPerformance
    ? taskPerformance.map((item) => ({
        username: item.username,
        contactCount: item.contactCount,
        quotation: {
          count: item.quotation.count,
          amount: item.quotation.amount,
        },
        order: {
          count: item.order.count,
          amount: item.order.amount,
        },
        sell_invoice: {
          count: item.sell_invoice.count,
          amount: item.sell_invoice.amount,
        },
        purchase_invoice: {
          count: item.purchase_invoice.count,
          amount: item.purchase_invoice.amount,
        },
        visitCount: item.visitCount,
        expense: {
          RequestedAmount: item.expense.RequestedAmount,
          PassedAmount: item.expense.PassedAmount,
        },
        salary: item.salary,
        pendingReminder: item.pendingReminder,
        attendanceData: item.attendanceData ?? [],
      }))
    : [];

  const dt = useRef<DataTable<ITaskPerformance[]>>(null);
  const networkTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setLoading(true);
    fetchTeamPerformance(
      setTaskPerformance,
      setAttendanceData,
      selectedDates,
      selectedTeamMembers
    );
  }, []);

  useEffect(() => {
    loadLazyData();
    return () => {
      if (networkTimeout.current) clearTimeout(networkTimeout.current);
    };
  }, [lazyState, taskPerformance]);

  const loadLazyData = () => {
    setLoading(true);
    if (networkTimeout.current) clearTimeout(networkTimeout.current);

    networkTimeout.current = setTimeout(() => {
      let filteredData = [...dataArray];

      Object.entries(lazyState.filters).forEach(([field, meta]) => {
        if ("value" in meta && meta.value !== null && meta.value !== "") {
          const filterValue = meta.value.toString().toLowerCase();
          const matchMode = meta.matchMode;

          filteredData = filteredData.filter((item) => {
            const fieldValue = getNestedValue(item, field);
            if (fieldValue === undefined || fieldValue === null) return false;

            const fieldStr = fieldValue.toString().toLowerCase();

            switch (matchMode) {
              case "contains":
                return fieldStr.includes(filterValue);
              case "notContains":
                return !fieldStr.includes(filterValue);
              case "startsWith":
                return fieldStr.startsWith(filterValue);
              case "endsWith":
                return fieldStr.endsWith(filterValue);
              case "equals":
                return fieldStr === filterValue;
              case "notEquals":
                return fieldStr !== filterValue;
              default:
                return true;
            }
          });
        }
      });

      if (lazyState.sortField) {
        filteredData.sort((a, b) => {
          const aValue = getNestedValue(a, lazyState.sortField!);
          const bValue = getNestedValue(b, lazyState.sortField!);
          if (aValue === undefined || aValue === null) return 1;
          if (bValue === undefined || bValue === null) return -1;
          return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
        });
        if (lazyState.sortOrder === -1) filteredData.reverse();
      }

      const start = lazyState.first;
      const end = start + lazyState.rows;
      const paginatedData = filteredData.slice(start, end);
      setCustomers(paginatedData);
      setTotalRecords(filteredData.length);
      setLoading(false);
    }, 250);
  };

  const onPage = (event: DataTablePageEvent) => {
    setLazyState((prev) => ({
      ...prev,
      first: event.first,
      rows: event.rows,
      page: event.page ?? 0,
    }));
  };

  const onSort = (event: DataTableSortEvent) => {
    setLazyState((prev) => ({
      ...prev,
      sortField: event.sortField,
      sortOrder: event.sortOrder as SortOrder,
    }));
  };

  const onFilter = (event: DataTableFilterEvent) => {
    setLazyState((prev) => ({
      ...prev,
      first: 0,
      filters: event.filters,
    }));
  };

  const onSelectionChange = (event: { value: ITaskPerformance[] }) => {
    const value = event.value;
    setSelectedCustomers(value);
    setSelectAll(value.length === totalRecords);
  };

  const onSelectAllChange = (event: { checked: boolean }) => {
    if (event.checked) {
      setSelectAll(true);
      setSelectedCustomers([...dataArray]);
    } else {
      setSelectAll(false);
      setSelectedCustomers([]);
    }
  };

  const exportColumns = [
    { title: "Team Member", dataKey: "Name" },
    { title: "New Contacts", dataKey: "Contact Total" },
    { title: "Quotation", dataKey: "Quotation" },
    { title: "Sales Order", dataKey: "Sales Order" },
    { title: "Sales Invoice", dataKey: "Sales Invoice" },
    { title: "Purchase Invoice", dataKey: "Purchase Invoice" },
    { title: "Visit", dataKey: "Visits" },
    { title: "Expense", dataKey: "Expense" },
    { title: "Pending Reminder", dataKey: "Pending Reminder Total" },
  ];
  
  const exportPdf = () => {
    const doc = new jsPDF({ orientation: 'landscape' });
  
    const tableData = (
      selectedCustomers.length ? selectedCustomers : customers
    ).map((customer) => ({
      Name: customer.username || "-",
      "Contact Total": customer.contactCount ?? "-",
      Quotation: `${customer.quotation?.count ?? "-"} (INR ${customer.quotation?.amount ?? "-"})`,
      "Sales Order": `${customer.order?.count ?? "-"} (INR ${customer.order?.amount ?? "-"})`,
      "Sales Invoice": `${customer.sell_invoice?.count ?? "-"} (INR ${customer.sell_invoice?.amount ?? "-"})`,
      "Purchase Invoice": `${customer.purchase_invoice?.count ?? "-"} (INR ${customer.purchase_invoice?.amount ?? "-"})`,
      Visits: customer.visitCount ?? "-",
      Expense: `INR ${customer.expense?.RequestedAmount ?? "-"} (INR ${customer.expense?.PassedAmount ?? "-"})`,
      "Pending Reminder Total": customer.pendingReminder ?? "-",
    }));
  
    if (tableData.length === 0) {
      doc.text("No data available to export", 10, 10);
      doc.save(`team_performance_${new Date().getTime()}.pdf`);
      return;
    }
  
    autoTable(doc, {
      columns: exportColumns,
      body: tableData,
      styles: { fontSize: 10, cellPadding: 2, font: "helvetica", halign: "left" },
      headStyles: {
        fillColor: [41, 128, 185],
        textColor: [255, 255, 255],
        fontStyle: "bold",
        halign: "left",
      },
      margin: { top: 20, left: 15, right: 10, bottom: 10 },
      didDrawPage: (data) => {
        doc.setFontSize(14);
        doc.text("Team Performance Data", data.settings.margin.left, 10);
      },
      columnStyles: {
        Name: { cellWidth: 30 },
        "Contact Total": { cellWidth: 30 },
        Quotation: { cellWidth: 25 },
        "Sales Order": { cellWidth: 25 },
        "Sales Invoice": { cellWidth: 35 },
        "Purchase Invoice": { cellWidth: 35 },
        Visits: { cellWidth: 15 },
        Expense: { cellWidth: 30 },
        "Pending Reminder Total": { cellWidth: 35 },
      },
    });
  
    doc.save(`team_performance_${new Date().getTime()}.pdf`);
  };

  const exportExcel = () => {
    const exportData = (
      selectedCustomers.length ? selectedCustomers : customers
    ).map((customer) => ({
      "Name": customer.username,
      "Contact Total": customer.contactCount,
      "Quotation Total": customer.quotation.count,
      "Quotation Amount": customer.quotation.amount,
      "Sales Invoice Count": customer.sell_invoice.count,
      "Sales Invoice Amount": customer.sell_invoice.amount,
      "Purchase Invoice Count": customer.purchase_invoice.count,
      "Purchase Invoice Amount": customer.purchase_invoice.amount,
      "Visits": customer.visitCount,
      "Expense Requested": customer.expense.RequestedAmount,
      "Expense Passed": customer.expense.PassedAmount,
      "Pending Reminder Total": customer.pendingReminder,
    }));
    const worksheet = xlsx.utils.json_to_sheet(exportData);

    worksheet["!cols"] = [
      { wpx: 150 }, // Name
      { wpx: 120 }, // Contact Total
      { wpx: 120 }, // Quotation Total
      { wpx: 120 }, // Quotation Amount
      { wpx: 120 }, // Sales Invoice Total
      { wpx: 120 }, // Sales Invoice
      { wpx: 120 }, // Purchase Invoice Total
      { wpx: 120 }, // Purchase Invoice
      { wpx: 100 }, // Visit Hours
      { wpx: 120 }, // Expense Requested
      { wpx: 120 }, // Expense Passed
      { wpx: 120 }, // Pending Reminder Total
    ];

    const workbook = { Sheets: { data: worksheet }, SheetNames: ["data"] };
    const excelBuffer = xlsx.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    saveAsExcelFile(excelBuffer, "team_performance");
  };

  const saveAsExcelFile = (buffer: BlobPart, fileName: string) => {
    const EXCEL_TYPE =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
    const EXCEL_EXTENSION = ".xlsx";
    const data = new Blob([buffer], { type: EXCEL_TYPE });
    saveAs(
      data,
      fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
    );
  };

  const printTable = () => {
    const printContent = `
      <html>
        <head>
          <title>Print Team Performance Data</title>
          <style>
            table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            h1 { text-align: center; }
          </style>
        </head>
        <body>
          <h1>Team Performance Data</h1>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Contact Total</th>
                <th>Quotation</th>
                <th>Sales Order</th>
                <th>Sales Invoice</th>
                <th>Purchase Invoice</th>
                <th>Visit</th>
                <th>Expense</th>
                <th>Pending Reminder</th>
              </tr>
            </thead>
            <tbody>
              ${(selectedCustomers.length ? selectedCustomers : customers)
                .map(
                  (customer) => `
                <tr>
                  <td>${customer.username || "N/A"}</td>
                  <td>${customer.contactCount ?? "N/A"}</td>
                  <td>${customer.quotation?.count ?? "N/A"} ( ₹${
                    customer.quotation?.amount ?? "N/A"
                  })</td>
                  <td>${customer.order?.count ?? "N/A"} ( ₹${
                    customer.order?.amount ?? "N/A"
                  })</td>
                  <td>${customer.sell_invoice?.count ?? "N/A"} ( ₹${
                    customer.sell_invoice?.amount ?? "N/A"
                  })</td>
                  <td>${customer.purchase_invoice?.count ?? "N/A"} ( ₹${
                    customer.purchase_invoice?.amount ?? "N/A"
                  })</td>
                  <td>${customer.visitCount ?? "N/A"}</td>
                  <td>${customer.expense?.RequestedAmount ?? "N/A"} ( ₹${
                    customer.expense?.PassedAmount ?? "N/A"
                  })</td>
                  <td>${customer.pendingReminder ?? "N/A"}</td>
                </tr>
              `
                )
                .join("")}
            </tbody>
          </table>
        </body>
      </html>
    `;

    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (error) {
    return (
      <div>
        <h3 className="dash-board-text-count">Team Performance Reports</h3>
        <div className="report_card" style={{ width: "59vw" }}>
          <p style={{ color: "red" }}>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="d-flex align-items-center justify-content-between gap-2 mb-3">
        <h3 className="dash-board-text-count">Team Performance Reports</h3>
        <div className="d-flex gap-2">
          <Button
            icon="pi pi-file-excel"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="success"
            rounded
            onClick={exportExcel}
            tooltip="Export Excel"
            disabled={customers.length === 0}
          />
          <Button
            icon="pi pi-file-pdf"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="danger"
            rounded
            onClick={exportPdf}
            tooltip="Export PDF"
            disabled={customers.length === 0}
          />
          <Button
            icon="pi pi-print"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="secondary"
            rounded
            onClick={printTable}
            tooltip="Print"
            disabled={customers.length === 0}
          />
        </div>
      </div>

      <div className="report_card" style={{ width: "59vw" }}>
        {customers.length === 0 && !loading ? (
          <p>No data available to display</p>
        ) : (
          <DataTable
            ref={dt}
            value={customers}
            lazy
            scrollable
            filterDisplay="row"
            dataKey="username"
            paginator
            first={lazyState.first}
            rows={lazyState.rows}
            totalRecords={totalRecords}
            onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField ?? undefined}
            sortOrder={lazyState.sortOrder ?? undefined}
            sortMode="single"
            onFilter={onFilter}
            filters={lazyState.filters}
            loading={loading}
            selection={selectedCustomers}
            onSelectionChange={onSelectionChange}
            selectAll={selectAll}
            onSelectAllChange={onSelectAllChange}
            selectionMode="multiple"
            tableStyle={{ tableLayout: "fixed", width: "100%" }}
            emptyMessage="No data found"
          >
            <Column selectionMode="multiple" headerStyle={{ width: "3rem" }} />
            <Column
              field="username"
              header="Team Member"
              sortable
              filter
              filterField="username"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px" }}
              body={(rowData: ITaskPerformance) => rowData.username || "N/A"}
            />
            <Column
              field="contactCount"
              header="New Contacts"
              sortable
              filter
              filterField="contactCount"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) =>
                rowData.contactCount ?? "N/A"
              }
            />
            <Column
              field="quotation.total"
              header="Quotation"
              sortable
              filter
              filterField="quotation.total"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) =>
                `${rowData.quotation?.count ?? "N/A"} (₹${
                  rowData.quotation?.amount ?? "N/A"
                })`
              }
            />
            <Column
              field="order.total"
              header="Sales Order"
              sortable
              filter
              filterField="order.total"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) =>
                `${rowData.order?.count ?? "N/A"} (₹${
                  rowData.order?.amount ?? "N/A"
                })`
              }
            />
            <Column
              field="sell_invoice.total"
              header="Sales Invoice"
              sortable
              filter
              filterField="sell_invoice.total"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) =>
                `${rowData.sell_invoice?.count ?? "N/A"} (₹${
                  rowData.sell_invoice?.amount ?? "N/A"
                })`
              }
            />
            <Column
              field="purchase_invoice.total"
              header="Purchase Invoice"
              sortable
              filter
              filterField="purchase_invoice.total"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) =>
                `${rowData.purchase_invoice?.count ?? "N/A"} (₹${
                  rowData.purchase_invoice?.amount ?? "N/A"
                })`
              }
            />
            <Column
              field="visit.totalHours"
              header="Visit"
              sortable
              filter
              filterField="visit.totalHours"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) => rowData.visitCount ?? "N/A"}
            />
            <Column
              field="expense.RequestedAmount"
              header="Expense"
              sortable
              filter
              filterField="expense.RequestedAmount"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) =>
                `₹${rowData.expense?.RequestedAmount ?? "N/A"} (₹${
                  rowData.expense?.PassedAmount ?? "N/A"
                })`
              }
            />
            {/* <Column
              field="salary"
              header="Attendance and Salary"
              sortable
              filter
              filterField="salary"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) => `${"X"} (₹${rowData.salary})`}
            /> */}
            <Column
              field="pendingReminder.total"
              header="Pending Reminder"
              sortable
              filter
              filterField="pendingReminder.total"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: ITaskPerformance) =>
                rowData.pendingReminder ?? "N/A"
              }
            />
          </DataTable>
        )}
      </div>
    </div>
  );
};

export default TeamPerformanceReports;
