import { toast } from "react-toastify";
import { TReactSetState } from "../../../../helpers/AppType";
import { axiosInstance } from "../../../../services/axiosInstance";
import { MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../../../helpers/AppConstants";

export interface IAttendanceMessage {
  attendance_status: number;
  a_application_login_id: number;
  check_in_out_date_time: string;
  total_working_hour: string;
  created_date_time: string;
  company_masters_id: number;
  attendanceDate: string;
  attendanceTime: string;
}

export interface IAttendanceData {
  [x: string]: any;
  messages: IAttendanceMessage[];
}

export interface ITaskPerformance {
  username: string;
  contactCount: number;
  quotation: {
    count: number;
    amount: number;
  };
  order: {
    count: number;
    amount: number;
  };
  sell_invoice: {
    count: number;
    amount: number;
  };
  purchase_invoice: {
    count: number;
    amount: number;
  };
  visitCount: number;
  expense: {
    RequestedAmount: number;
    PassedAmount: number;
  };
  salary: number;
  pendingReminder: number;
  attendanceData: IAttendanceData[];
}

export const fetchTeamPerformance = async (
  setTaskPerformance: TReactSetState<ITaskPerformance[]>,
  setAttendanceData: TReactSetState<IAttendanceData[]>,
  selectedDates: Date[] | undefined,
  selectedTeamMembers: string[] | null


): Promise<void> => {
  const token = localStorage.getItem("token");
  const getUUID = localStorage.getItem("UUID");

  const requestedData = {
    selectedDates: selectedDates,
    a_application_login_id: getUUID,
    selectedTeamMembers: selectedTeamMembers

  };

  console.log("Selected Dates:", selectedDates);

  try {
    const response = await axiosInstance.post("/getTeamPerformanceReport", requestedData, {
      headers: {
        "x-tenant-id": getUUID || "",
        Authorization: `${token}`,
      },
    });

    const items: ITaskPerformance[] = response?.data?.data?.item || [];

    console.log("Team Performance Response:", items);

    setTaskPerformance(items);

    const attendanceArray: IAttendanceData[] = items.map(item => item.attendanceData).flat().filter(Boolean);
    setAttendanceData(attendanceArray);
  } catch (error: any) {
    console.error("Fetch Team Performance Error:", error);
    toast.error(error?.response?.data?.message || error?.message || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
