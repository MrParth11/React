import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  DataTable,
  type DataTableFilterEvent,
  type DataTableFilterMeta,
  type DataTablePageEvent,
  type DataTableSortEvent,
  type SortOrder,
} from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as xlsx from "xlsx";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import {
  fetchAttendanceReport,
  IAttendanceHistory,
} from "./AttendanceReportController";

interface LazyTableState {
  first: number;
  rows: number;
  page: number;
  sortField?: string | null;
  sortOrder?: SortOrder | null;
  filters: DataTableFilterMeta;
}

interface ITeamAttendanceReports {
  selectedDates: Date[];
  selectedTeamMembers: string[] | null;
}

const getNestedValue = (obj: any, path: string): any => {
  try {
    return (
      path.split(".").reduce((acc, part) => {
        if (acc == null) return undefined;
        return acc[part];
      }, obj) ?? ""
    );
  } catch {
    return "";
  }
};

const formatDate = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const formatDateDisplay = (date: Date): string => {
  return date.toLocaleDateString("en-GB");
};

const parseWorkingHoursToMinutes = (timeStr: string): number => {
  try {
    const [hours, minutes, seconds] = timeStr.split(":").map(Number);
    if (isNaN(hours) || isNaN(minutes) || isNaN(seconds)) return 0;
    return hours * 60 + minutes + seconds / 60; // Convert to minutes
  } catch {
    return 0;
  }
};

const formatMinutesToHHMMSS = (totalMinutes: number): string => {
  if (totalMinutes <= 0) return "00:00:00";
  const hours = Math.floor(totalMinutes / 60);
  const minutes = Math.floor(totalMinutes % 60);
  const seconds = Math.round((totalMinutes % 1) * 60);
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(
    2,
    "0"
  )}:${String(seconds).padStart(2, "0")}`;
};

const calculateTotalWorkingMinutes = (
  customer: IAttendanceHistory,
  allDates: Date[]
): number => {
  let totalMinutes = 0;
  allDates.forEach((date) => {
    const formattedDate = formatDate(date);
    const attendance = customer.attendanceData?.find(
      (a) => a.date === formattedDate
    );
    if (attendance?.messages) {
      attendance.messages
        .filter((m) => m.attendanceDate === formattedDate)
        .forEach((m) => {
          if (m.total_working_hour) {
            totalMinutes += parseWorkingHoursToMinutes(m.total_working_hour);
          }
        });
    }
  });
  return Math.round(totalMinutes * 100) / 100;
};

const calculateSalary = (
  customer: IAttendanceHistory,
  allDates: Date[]
): number => {
  const totalMinutes = calculateTotalWorkingMinutes(customer, allDates);
  const salaryPerMinute = customer.salary || 0;
  return Math.round(totalMinutes * salaryPerMinute * 100) / 100;
};

const getDateRange = (start: Date, end: Date): Date[] => {
  const dates: Date[] = [];
  const current = new Date(start);
  while (current <= end) {
    dates.push(new Date(current));
    current.setDate(current.getDate() + 1);
  }
  return dates;
};

const TeamAttendanceReportsView = ({
  selectedDates,
  selectedTeamMembers,
}: ITeamAttendanceReports) => {
  const [loading, setLoading] = useState(true);
  const [totalRecords, setTotalRecords] = useState(0);
  const [customers, setCustomers] = useState<IAttendanceHistory[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [selectedCustomers, setSelectedCustomers] = useState<
    IAttendanceHistory[]
  >([]);
  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: {
      username: { value: null, matchMode: "contains" },
    },
  });
  const [attendanceReport, setAttendanceReport] = useState<
    IAttendanceHistory[]
  >([]);
  const [error, setError] = useState<string | null>(null);

  const dt = useRef<DataTable<IAttendanceHistory[]>>(null);
  const networkTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    console.log("Selected Dates:", selectedDates.map(formatDate));
    setLoading(true);
    fetchAttendanceReport(
      setAttendanceReport,
      selectedDates,
      selectedTeamMembers
    );
  }, [selectedDates]);

  const dataArray: IAttendanceHistory[] = useMemo(() => {
    const result = Array.isArray(attendanceReport) ? attendanceReport : [];
    console.log("Data Array:", result);
    return result;
  }, [attendanceReport]);

  const filteredData = useMemo(() => {
    let data = [...dataArray];
    Object.entries(lazyState.filters).forEach(([field, meta]) => {
      if ("value" in meta && meta.value !== null && meta.value !== "") {
        const filterValue = meta.value.toString().toLowerCase();
        const matchMode = meta.matchMode;

        data = data.filter((item) => {
          const fieldValue = getNestedValue(item, field);
          if (fieldValue === undefined || fieldValue === null) return false;

          const fieldStr = fieldValue.toString().toLowerCase();

          switch (matchMode) {
            case "contains":
              return fieldStr.includes(filterValue);
            case "notContains":
              return !fieldStr.includes(filterValue);
            case "startsWith":
              return fieldStr.startsWith(filterValue);
            case "endsWith":
              return fieldStr.endsWith(filterValue);
            case "equals":
              return fieldStr === filterValue;
            case "notEquals":
              return fieldStr !== filterValue;
            default:
              return true;
          }
        });
      }
    });

    if (lazyState.sortField) {
      data.sort((a, b) => {
        const aValue = getNestedValue(a, lazyState.sortField!);
        const bValue = getNestedValue(b, lazyState.sortField!);
        if (aValue === undefined || aValue === null) return 1;
        if (bValue === undefined || bValue === null) return -1;
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      });
      if (lazyState.sortOrder === -1) data.reverse();
    }
    console.log("Filtered Data:", data);
    return data;
  }, [dataArray, lazyState.filters, lazyState.sortField, lazyState.sortOrder]);

  useEffect(() => {
    loadLazyData();
    return () => {
      if (networkTimeout.current) clearTimeout(networkTimeout.current);
    };
  }, [lazyState, dataArray]);

  const loadLazyData = () => {
    setLoading(true);
    if (networkTimeout.current) clearTimeout(networkTimeout.current);

    networkTimeout.current = setTimeout(() => {
      const start = lazyState.first;
      const end = start + lazyState.rows;
      const paginatedData = filteredData.slice(start, end);
      console.log("Paginated Data (Customers):", paginatedData);
      setCustomers(paginatedData);
      setTotalRecords(filteredData.length);
      setLoading(false);
    }, 250);
  };

  const onPage = (event: DataTablePageEvent) => {
    setLazyState((prev) => ({
      ...prev,
      first: event.first,
      rows: event.rows,
      page: event.page ?? 0,
    }));
  };

  const onSort = (event: DataTableSortEvent) => {
    setLazyState((prev) => ({
      ...prev,
      sortField: event.sortField,
      sortOrder: event.sortOrder as SortOrder,
    }));
  };

  const onFilter = (event: DataTableFilterEvent) => {
    setLazyState((prev) => ({
      ...prev,
      first: 0,
      filters: event.filters,
    }));
  };

  const onSelectionChange = (event: { value: IAttendanceHistory[] }) => {
    const value = event.value;
    setSelectedCustomers(value);
    setSelectAll(value.length === totalRecords);
  };

  const onSelectAllChange = (event: { checked: boolean }) => {
    if (event.checked) {
      setSelectAll(true);
      setSelectedCustomers([...dataArray]);
    } else {
      setSelectAll(false);
      setSelectedCustomers([]);
    }
  };

  const [startDate, endDate] = selectedDates;
  const allDates = getDateRange(startDate, endDate);

  const exportColumns = [
    { title: "Name", dataKey: "username" },
    ...allDates.map((date) => ({
      title: `${formatDateDisplay(date)}`,
      dataKey: `check_in_out_${formatDate(date)}`,
    })),
    { title: "Total Working Hours", dataKey: "total_working_hours" },
    { title: "Salary", dataKey: "salary" },
  ];

  const exportPdf = () => {
    const doc = new jsPDF(
      
    ); 

    const tableData = (
      selectedCustomers.length ? selectedCustomers : customers
    ).map((customer) => {
      const row: any = { username: customer.username || "N/A" };
      allDates.forEach((date) => {
        const formattedDate = formatDate(date);
        const attendance = customer.attendanceData?.find(
          (a) => a.date === formattedDate
        );
        const times =
          attendance?.messages
            ?.filter((m) => m.attendanceDate === formattedDate)
            .map((m) => m.attendanceTime) || [];
        row[`${formattedDate}`] = times.length > 0 ? times.join(", ") : "-";
      });
      row.total_working_hours =
        formatMinutesToHHMMSS(
          calculateTotalWorkingMinutes(customer, allDates)
        ) || "00:00:00";
      row.salary = calculateSalary(customer, allDates) || "-";
      return row;
    });

    if (tableData.length === 0) {
      doc.text("No data available to export", 10, 10);
      doc.save(`team_attendance_${new Date().getTime()}.pdf`);
      return;
    }

    autoTable(doc, {
      columns: exportColumns,
      body: tableData,
      styles: {
        fontSize: 8,
        cellPadding: 1.5,
      }, // Reduced font and padding
      headStyles: {
        fillColor: [41, 128, 185],
        textColor: [255, 255, 255],
        fontStyle: "bold",
        fontSize: 8,
      },
      margin: { top: 20, left: 5, bottom: 10 }, // Minimized margins
      columnStyles: {
        username: { cellWidth: 10 }, // Name column
        ...allDates.reduce((acc, date) => {
          acc[formatDate(date)] = { cellWidth: 55 }; // 30 date columns
          return acc;
        }, {} as Record<string, { cellWidth: 55 }>),
        total_working_hours: { cellWidth: 20 },
        salary: { cellWidth: 20 },
      },
      didDrawPage: (data) => {
        doc.setFontSize(14);
        doc.text("Team Attendance Report", data.settings.margin.left, 10);
        doc.setFontSize(7);
        doc.text(
          "Note: Scroll or pan horizontally in your PDF viewer to see all 33 columns.",
          data.settings.margin.left,
          15
        );
      },
    });

    doc.save(`team_attendance_${new Date().getTime()}.pdf`);
  };

  const exportExcel = () => {
    const exportData = (
      selectedCustomers.length ? selectedCustomers : customers
    ).map((customer) => {
      const row: any = { Name: customer.username || "N/A" };
      allDates.forEach((date) => {
        const formattedDate = formatDate(date);
        const formattedDisplayDate = formatDateDisplay(date);
        const attendance = customer.attendanceData?.find(
          (a) => a.date === formattedDate
        );
        const times =
          attendance?.messages
            ?.filter((m) => m.attendanceDate === formattedDate)
            .map((m) => m.attendanceTime) || [];

        if (times.length > 0) {
          const pairedTimes = [];
          for (let i = 0; i < times.length; i += 2) {
            const pair = times.slice(i, i + 2).join(", ");
            pairedTimes.push(pair);
          }
          row[formattedDisplayDate] = pairedTimes.join("\n") || "-";
        } else {
          row[formattedDisplayDate] = "-";
        }
      });
      row["Total Working Hours"] =
        formatMinutesToHHMMSS(
          calculateTotalWorkingMinutes(customer, allDates)
        ) || "00:00:00";
      row["Salary"] = calculateSalary(customer, allDates) || "0";
      return row;
    });

    const worksheetData = [...exportData];

    const worksheet = xlsx.utils.json_to_sheet(worksheetData);

    worksheet["!cols"] = [
      { wch: 50 },
      ...allDates.map(() => ({ wch: 35 })),
      { wch: 15 },
      { wch: 15 },
    ];

    const workbook = { Sheets: { data: worksheet }, SheetNames: ["data"] };
    const excelBuffer = xlsx.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    saveAsExcelFile(excelBuffer, "team_attendance");
  };

  const saveAsExcelFile = (buffer: BlobPart, fileName: string) => {
    const EXCEL_TYPE =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
    const EXCEL_EXTENSION = ".xlsx";
    const data = new Blob([buffer], { type: EXCEL_TYPE });
    saveAs(
      data,
      fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
    );
  };

  const printTable = () => {
    const headers = [
      ...allDates.map(
        (date) => `<th>Check In/Out Times (${formatDateDisplay(date)})</th>`
      ),
      `<th>Total Working Hours</th>`,
      `<th>Salary</th>`,
    ].join("");

    const rows = (selectedCustomers.length ? selectedCustomers : customers)
      .map((customer) => {
        const cells = allDates
          .map((date) => {
            const formattedDate = formatDate(date);
            const attendance = customer.attendanceData?.find(
              (a) => a.date === formattedDate
            );
            const times =
              attendance?.messages
                ?.filter((m) => m.attendanceDate === formattedDate)
                .map((m) => m.attendanceTime) || [];
            return `<td style="border: 1px solid #ddd; padding: 8px; text-align: left">${
              times.length > 0 ? times.join(", ") : "N/A"
            }</td>`;
          })
          .join("");
        const totalHours = formatMinutesToHHMMSS(
          calculateTotalWorkingMinutes(customer, allDates)
        );
        const salary = calculateSalary(customer, allDates);
        return `<tr><td style="border: 1px solid #ddd; padding: 8px; text-align: left">${
          customer.username || "N/A"
        }</td>${cells}<td style="border: 1px solid #ddd; padding: 8px; text-align: left">${
          totalHours || "N/A"
        }</td><td>${salary || "N/A"}</td></tr>`;
      })
      .join("");

    const printContent = `
      <html>
        <head>
          <title>Team Attendance Report</title>
          <style>
            table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            h1 { text-align: center; }
          </style>
        </head>
        <body>
          <h1>Team Attendance Report</h1>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                ${headers}
              </tr>
            </thead>
            <tbody>
              ${rows}
            </tbody>
          </table>
        </body>
      </html>
    `;

    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (error) {
    return (
      <div>
        <h3 className="dash-board-text-count">Team Attendance Report</h3>
        <div className="report_card" style={{ width: "59vw" }}>
          <p style={{ color: "red" }}>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="d-flex align-items-center justify-content-between gap-2 mb-3">
        <h3 className="team-attendance-report">Team Attendance Report</h3>
        <div className="d-flex gap-2">
          <Button
            icon="pi pi-file-excel"
            className="report-button"
            style={{ backgroundColor: "green" }}
            rounded
            onClick={exportExcel}
            tooltip="Export to Excel"
            disabled={customers.length === 0}
          />
          <Button
            icon="pi pi-file-pdf"
            className="report-button"
            style={{ backgroundColor: "green" }}
            rounded
            onClick={exportPdf}
            tooltip="Export PDF"
            disabled={customers.length === 0}
          />
          <Button
            icon="pi pi-print"
            className="report-button"
            style={{ backgroundColor: "green" }}
            rounded
            onClick={printTable}
            tooltip="Print"
            disabled={customers.length === 0}
          />
        </div>
      </div>

      <div className="report-card" style={{ width: "59vw" }}>
        {loading ? (
          <p>Loading data...</p>
        ) : customers.length === 0 ? (
          <p>
            No data available to display. Please check the selected dates or API
            response.
          </p>
        ) : (
          <DataTable
            ref={dt}
            value={customers}
            lazy
            scrollable
            filterDisplay="row"
            dataKey="username"
            paginator
            first={lazyState.first}
            rows={lazyState.rows}
            totalRecords={totalRecords}
            onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField ?? undefined}
            sortOrder={lazyState.sortOrder ?? undefined}
            sortMode="single"
            onFilter={onFilter}
            filters={lazyState.filters}
            loading={loading}
            selection={selectedCustomers}
            onSelectionChange={onSelectionChange}
            selectAll={selectAll}
            onSelectAllChange={onSelectAllChange}
            selectionMode="multiple"
            tableStyle={{ tableLayout: "fixed", width: "100%" }}
            emptyMessage="No data found"
          >
            {/* <Column selectionMode="multiple" headerStyle={{ width: "3rem" }} /> */}
            <Column
              field="username"
              header="Team Member"
              // sortable
              filter
              filterField="username"
              filterPlaceholder="Search"
              // filterMatchMode="contains"
              bodyStyle={{
                padding: "8px",
                paddingRight: "50px",
              }}
              headerStyle={{
                width: "250px",
                padding: "10px",
                paddingBottom: 0,
                textAlign: "left",
                fontFamily: "Arial, sans-serif",
              }}
              body={(rowData: IAttendanceHistory) => rowData.username || "N/A"}
            />
            {allDates.map((date) => {
              const formattedDate = formatDate(date);
              const displayDate = formatDateDisplay(date);
              return (
                <Column
                  key={formattedDate}
                  header={displayDate}
                  headerStyle={{
                    textAlign: "center",
                  }}
                  bodyStyle={{
                    padding: "8px",
                  }}
                  body={(rowData: IAttendanceHistory) => {
                    const attendance = rowData.attendanceData?.find(
                      (a) => a.date === formattedDate
                    );
                    const messages =
                      attendance?.messages?.filter(
                        (m) => m.attendanceDate === formattedDate
                      ) || [];
                    console.log(
                      `Check In/Out Times for ${rowData.username} on ${formattedDate}:`,
                      messages
                    );
                    return messages.length > 0 ? (
                      <div>
                        {messages.map((m, index) => (
                          <span
                            key={index}
                            style={{
                              color:
                                m.attendance_status === 1
                                  ? "green"
                                  : m.attendance_status === 2
                                  ? "red"
                                  : "black",
                            }}
                          >
                            {m.attendanceTime}
                            {index < messages.length - 1 ? ", " : ""}
                          </span>
                        ))}
                      </div>
                    ) : (
                      "-"
                    );
                  }}
                  style={{ textAlign: "center", width: "150px" }}
                />
              );
            })}
            <Column
              field="total_working_hours"
              header="Total Working Hours"
              sortable
              filter
              filterField="total_working_hours"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px" }}
              bodyStyle={{
                padding: "8px",
              }}
              body={(rowData: IAttendanceHistory) => {
                const totalMinutes = calculateTotalWorkingMinutes(
                  rowData,
                  allDates
                );
                return totalMinutes > 0
                  ? formatMinutesToHHMMSS(totalMinutes)
                  : "00:00:00";
              }}
            />
            <Column
              field="salary"
              header="Salary"
              sortable
              filter
              filterField="salary"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "250px" }}
              bodyStyle={{
                padding: "8px",
              }}
              body={(rowData: IAttendanceHistory) => {
                const salary = calculateSalary(rowData, allDates);
                return salary > 0 ? `₹${salary}` : "₹ 0";
              }}
            />
          </DataTable>
        )}
      </div>
    </div>
  );
};

export default TeamAttendanceReportsView;
