import { toast } from "react-toastify";
import { TReactSetState } from "../../../../helpers/AppType";
import { axiosInstance } from "../../../../services/axiosInstance";
import { DEFAULT_STATUS_CODE_SUCCESS, MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../../../helpers/AppConstants";

export interface IAttendanceHistory {
    username: string;
    salary: number;
    attendanceData: [
        {
            date: string,
            messages: [
                {
                    attendance_status: number,
                    a_application_login_id: number,
                    check_in_out_date_time: string,
                    total_working_hour: string,
                    created_date_time: string,
                    company_masters_id: number,
                    attendanceDate: string,
                    attendanceTime: string
                }
            ]
        }
    ]
}

export const fetchAttendanceReport = async (
    setAttendanceReport: TReactSetState<IAttendanceHistory[]>,
    selectedDates: Date[] | undefined,
    selectedTeamMembers: string[] | null

) => {


    const token = await localStorage.getItem("token");
    const getUUID = await localStorage.getItem("UUID");

    const requestedData = {
        request_flag: 2,
        selectedDates: selectedDates,
        a_application_login_id: getUUID,
        selectedTeamMembers:selectedTeamMembers

    }
    console.log("requested Data", requestedData);
    try {
        const response = await axiosInstance.post("getTeamAttendanceReport", requestedData, {
            headers: {
                "x-tenant-id": getUUID,
                Authorization: `${token}`,
            }
        })
        console.log("response", response);

        if (response.data.ack !== DEFAULT_STATUS_CODE_SUCCESS) {
            return console.log("Error");
        }

        console.log("Data");
        setAttendanceReport(response.data.data.item);
    } catch (error: any) {

        toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);

    }
}