import { toast } from "react-toastify";
import { TReactSetState } from "../../../../helpers/AppType";
import { axiosInstance } from "../../../../services/axiosInstance";
import { MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../../../helpers/AppConstants";

export interface IProductInventory {
  name: string;
  openingStock: number;
  purchase: number;
  sales: number;
  closingStock: number;
  min_stock_quantity:number;
  max_stock_quantity:number;
}

export const fetchProductInventory = async (
  setProductInventory: TReactSetState<IProductInventory[]>,
  selectedDates: Date[] | undefined

) => {
  const token = await localStorage.getItem("token");
  const getUUID = await localStorage.getItem("UUID");

  const requestedData = {
    selectedDates: selectedDates,
    a_application_login_id: getUUID,
  };


  try {
    const response = await axiosInstance.post("/getProductInventoryReport",
      requestedData,
      {
        headers: {
          "x-tenant-id": getUUID,
          Authorization: `${token}`,
        },
      });

    console.log("response", response.data.data.items);
    setProductInventory(response.data.data.items);
  } catch (error: any) {
    toast.error(error?.message || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
