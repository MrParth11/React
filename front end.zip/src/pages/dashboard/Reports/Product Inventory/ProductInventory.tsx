import React, { useState, useEffect, useRef } from "react";
import {
  DataTable,
  type DataTableFilterEvent,
  type DataTableFilterMeta,
  type DataTablePageEvent,
  type DataTableSortEvent,
  type SortOrder,
} from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as xlsx from "xlsx";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import {
  fetchProductInventory,
  IProductInventory,
} from "./ProductInventoryController";

interface LazyTableState {
  first: number;
  rows: number;
  page: number;
  sortField?: string | null;
  sortOrder?: SortOrder | null;
  filters: DataTableFilterMeta;
}

interface IProductInventoryReports {
  selectedDates: Date[];
}

const getNestedValue = (obj: any, path: string): any => {
  try {
    return (
      path.split(".").reduce((acc, part) => {
        if (acc == null) return undefined;
        return acc[part];
      }, obj) ?? ""
    );
  } catch {
    return "";
  }
};

const ProductInventoryReport = ({
  selectedDates,
}: IProductInventoryReports) => {
  const [loading, setLoading] = useState(false);
  const [totalRecords, setTotalRecords] = useState(0);
  const [customers, setCustomers] = useState<IProductInventory[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [selectedCustomers, setSelectedCustomers] = useState<
    IProductInventory[]
  >([]);
  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: {
      name: { value: null, matchMode: "contains" },
      "openingStock.total": { value: null, matchMode: "contains" },
      "purchase.total": { value: null, matchMode: "contains" },
      "sales.total": { value: null, matchMode: "contains" },
      "closingStock.total": { value: null, matchMode: "contains" },
    },
  });
  const [productInventory, setProductInventory] = useState<IProductInventory[]>(
    []
  );
  const [error, setError] = useState<string | null>(null);

  const dataArray: IProductInventory[] = productInventory
    ? productInventory.map((item) => ({
        name: item.name,
        openingStock: item.openingStock,
        purchase: item.purchase,
        sales: item.sales,
        closingStock: item.closingStock,
        min_stock_quantity: item.min_stock_quantity,
        max_stock_quantity: item.max_stock_quantity,
      }))
    : [];

  const dt = useRef<DataTable<IProductInventory[]>>(null);
  const networkTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setLoading(true);
    fetchProductInventory(setProductInventory, selectedDates);
  }, []);

  useEffect(() => {
    loadLazyData();
    return () => {
      if (networkTimeout.current) clearTimeout(networkTimeout.current);
    };
  }, [lazyState, productInventory]);

  const loadLazyData = () => {
    setLoading(true);
    if (networkTimeout.current) clearTimeout(networkTimeout.current);

    networkTimeout.current = setTimeout(() => {
      let filteredData = [...dataArray];

      Object.entries(lazyState.filters).forEach(([field, meta]) => {
        if ("value" in meta && meta.value !== null && meta.value !== "") {
          const filterValue = meta.value.toString().toLowerCase();
          const matchMode = meta.matchMode;

          filteredData = filteredData.filter((item) => {
            const fieldValue = getNestedValue(item, field);
            if (fieldValue === undefined || fieldValue === null) return false;

            const fieldStr = fieldValue.toString().toLowerCase();

            switch (matchMode) {
              case "contains":
                return fieldStr.includes(filterValue);
              case "notContains":
                return !fieldStr.includes(filterValue);
              case "startsWith":
                return fieldStr.startsWith(filterValue);
              case "endsWith":
                return fieldStr.endsWith(filterValue);
              case "equals":
                return fieldStr === filterValue;
              case "notEquals":
                return fieldStr !== filterValue;
              default:
                return true;
            }
          });
        }
      });

      if (lazyState.sortField) {
        filteredData.sort((a, b) => {
          const aValue = getNestedValue(a, lazyState.sortField!);
          const bValue = getNestedValue(b, lazyState.sortField!);
          if (aValue === undefined || aValue === null) return 1;
          if (bValue === undefined || bValue === null) return -1;
          return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
        });
        if (lazyState.sortOrder === -1) filteredData.reverse();
      }

      const start = lazyState.first;
      const end = start + lazyState.rows;
      const paginatedData = filteredData.slice(start, end);
      setCustomers(paginatedData);
      setTotalRecords(filteredData.length);
      setLoading(false);
    }, 250);
  };

  const onPage = (event: DataTablePageEvent) => {
    setLazyState((prev) => ({
      ...prev,
      first: event.first,
      rows: event.rows,
      page: event.page ?? 0,
    }));
  };

  const onSort = (event: DataTableSortEvent) => {
    setLazyState((prev) => ({
      ...prev,
      sortField: event.sortField,
      sortOrder: event.sortOrder as SortOrder,
    }));
  };

  const onFilter = (event: DataTableFilterEvent) => {
    setLazyState((prev) => ({
      ...prev,
      first: 0,
      filters: event.filters,
    }));
  };

  const onSelectionChange = (event: { value: IProductInventory[] }) => {
    const value = event.value;
    setSelectedCustomers(value);
    setSelectAll(value.length === totalRecords);
  };

  const onSelectAllChange = (event: { checked: boolean }) => {
    if (event.checked) {
      setSelectAll(true);
      setSelectedCustomers([...dataArray]);
    } else {
      setSelectAll(false);
      setSelectedCustomers([]);
    }
  };

  const exportColumns = [
    { title: "Product Name", dataKey: "Product Name" },
    { title: "Opening Stock", dataKey: "openingStock" },
    { title: "Purchase", dataKey: "purchase" },
    { title: "Sales", dataKey: "sales" },
    { title: "Closing Stock", dataKey: "closingStock" },
  ];

  const exportPdf = () => {
    const doc = new jsPDF();
    const tableData = (
      selectedCustomers.length ? selectedCustomers : customers
    ).map((customer) => ({
      "Product Name": customer.name,
      openingStock: customer.openingStock,
      purchase: customer.purchase,
      sales: customer.sales,
      closingStock: customer.closingStock,
    }));

    if (tableData.length === 0) {
      doc.text("No data available to export", 10, 10);
      doc.save(`product_inventory_${new Date().getTime()}.pdf`);
      return;
    }

    autoTable(doc, {
      columns: exportColumns,
      body: tableData,
      styles: { fontSize: 10 },
      headStyles: { fillColor: [41, 128, 185] },
      margin: { top: 20 },
      didDrawPage: (data: any) => {
        doc.text(
          "Product Inventory and Stock Alerts Report",
          data.settings.margin.left,
          10
        );
      },
    });

    doc.save(`product_inventory_${new Date().getTime()}.pdf`);
  };

  const exportExcel = () => {
    const exportData = (
      selectedCustomers.length ? selectedCustomers : customers
    ).map((customer) => ({
      "Product Name": customer.name,
      "Opening Stock": customer.openingStock,
      Purchase: customer.purchase,
      Sales: customer.sales,
      "Closing Stock": customer.closingStock,
    }));
    const worksheet = xlsx.utils.json_to_sheet(exportData);
    worksheet["!cols"] = [
      { wpx: 150 }, // Name
      { wpx: 120 }, // Contact Total
      { wpx: 120 }, // Quotation Total
      { wpx: 120 }, // Quotation Amount
      { wpx: 120 }, // Sales Invoice Total
    ];
    const workbook = { Sheets: { data: worksheet }, SheetNames: ["data"] };
    const excelBuffer = xlsx.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    saveAsExcelFile(excelBuffer, "product_inventory");
  };

  const saveAsExcelFile = (buffer: BlobPart, fileName: string) => {
    const EXCEL_TYPE =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
    const EXCEL_EXTENSION = ".xlsx";
    const data = new Blob([buffer], { type: EXCEL_TYPE });
    saveAs(
      data,
      fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
    );
  };

  const printTable = () => {
    const printContent = `
      <html>
        <head>
          <title>Product Inventory and Stock Alerts Report</title>
          <style>
            table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            h1 { text-align: center; }
          </style>
        </head>
        <body>
          <h1>Product Inventory and Stock Alerts Report</h1>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Opening Stock</th>
                <th>Purchase</th>
                <th>Sales</th>
                <th>Closing Stock</th>
              </tr>
            </thead>
            <tbody>
              ${(selectedCustomers.length ? selectedCustomers : customers)
                .map(
                  (customer) => `
                <tr>
                  <td>${customer.name || "N/A"}</td>
                  <td>${customer.openingStock ?? "N/A"}</td>
                  <td>${customer.purchase ?? "N/A"}</td>
                  <td>${customer.sales ?? "N/A"}</td>
                  <td>${customer.closingStock ?? "N/A"}</td>
                </tr>
              `
                )
                .join("")}
            </tbody>
          </table>
        </body>
      </html>
    `;

    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const closingStockBodyTemplate = (rowData: IProductInventory) => {
    const closingStock = rowData.closingStock ?? 0;
    const minStock = rowData.min_stock_quantity ?? 0;
    const maxStock = rowData.max_stock_quantity ?? Infinity;
    
    let backgroundColor = "";
    if (closingStock < minStock) {
      backgroundColor = "#D76C82";
    } else if (closingStock > maxStock) {
      backgroundColor = "#C1D8C3";
    }

    return (
      <span style={{ backgroundColor, textAlign: "right", display: "block", paddingRight: "50px" }}>
        {closingStock ?? "N/A"}
      </span>
    );
  };

  if (error) {
    return (
      <div>
        <h3 className="dash-board-text-count">
          Product Inventory & Stock Alerts Report
        </h3>
        <div className="report_card" style={{ width: "59vw" }}>
          <p style={{ color: "red" }}>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="d-flex align-items-center justify-content-between gap-2 mb-3">
        <h3 className="dash-board-text-count">
          Product Inventory & Stock Alerts Report
        </h3>
        <div className="d-flex gap-2">
          <Button
            icon="pi pi-file-excel"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="success"
            rounded
            onClick={exportExcel}
            tooltip="Export Excel"
            disabled={customers.length === 0}
          />
          <Button
            icon="pi pi-file-pdf"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="danger"
            rounded
            onClick={exportPdf}
            tooltip="Export PDF"
            disabled={customers.length === 0}
          />
          <Button
            icon="pi pi-print"
            className="report_button"
            style={{ backgroundColor: "green" }}
            severity="secondary"
            rounded
            onClick={printTable}
            tooltip="Print"
            disabled={customers.length === 0}
          />
        </div>
      </div>

      <div className="report_card" style={{ width: "59vw" }}>
        {customers.length === 0 && !loading ? (
          <p>No data available to display</p>
        ) : (
          <DataTable
            ref={dt}
            value={customers}
            lazy
            scrollable
            filterDisplay="row"
            dataKey="name"
            paginator
            first={lazyState.first}
            rows={lazyState.rows}
            totalRecords={totalRecords}
            onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField ?? undefined}
            sortOrder={lazyState.sortOrder ?? undefined}
            sortMode="single"
            onFilter={onFilter}
            filters={lazyState.filters}
            loading={loading}
            selection={selectedCustomers}
            onSelectionChange={onSelectionChange}
            selectAll={selectAll}
            onSelectAllChange={onSelectAllChange}
            selectionMode="multiple"
            tableStyle={{ tableLayout: "fixed", width: "100%" }}
            emptyMessage="No data found"
          >
            <Column selectionMode="multiple" headerStyle={{ width: "3rem" }} />
            <Column
              field="name"
              header="Team Member"
              sortable
              filter
              filterField="name"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "200px" }}
              body={(rowData: IProductInventory) => rowData.name || "N/A"}
            />
            <Column
              field="openingStock"
              header="Opening Stock"
              sortable
              filter
              filterField="openingStock"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "200px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: IProductInventory) =>
                rowData.openingStock ?? "N/A"
              }
            />
            <Column
              field="purchase"
              header="Purchase"
              sortable
              filter
              filterField="purchase"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "200px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: IProductInventory) =>
                `${rowData.purchase ?? "N/A"}`
              }
            />
            <Column
              field="sales"
              header="Sales"
              sortable
              filter
              filterField="sales"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "200px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={(rowData: IProductInventory) => `${rowData.sales ?? "N/A"}`}
            />
            <Column
              field="closingStock"
              header="Closing Stock"
              sortable
              filter
              filterField="closingStock"
              filterPlaceholder="Search"
              filterMatchMode="contains"
              headerStyle={{ width: "200px", textAlign: "right" }}
              bodyStyle={{ textAlign: "right", paddingRight: "50px" }}
              body={closingStockBodyTemplate}
            />
          </DataTable>
        )}
      </div>
    </div>
  );
};

export default ProductInventoryReport;