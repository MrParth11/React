import { toast } from "react-toastify";
import { TReactSetState } from "../../../../helpers/AppType";
import { axiosInstance } from "../../../../services/axiosInstance";
import { MESSAGE_UNKNOWN_ERROR_OCCURRED } from "../../../../helpers/AppConstants";

export interface IPendingWork {
  username: string;
  quotation: {
    count: number;
    amount: number;
  };
  order: {
    count: number;
    amount: number;
  };
  sell_invoice: {
    count: number;
    amount: number;
  };
  purchase_invoice: {
    count: number;
    amount: number;
  };
  pendingReminder: number;
}

export const fetchPendingWork = async (
  setPendingWork: TReactSetState<IPendingWork[]>,
  selectedDates: Date[] | undefined,
  selectedTeamMembers: string[] | null


) => {
  try {
    const token = await localStorage.getItem("token");
    const getUUID = await localStorage.getItem("UUID");

    const requestedData = {
      selected_dates: selectedDates,
      a_application_login_id: getUUID,
      selectedTeamMembers: selectedTeamMembers

    };


    const response = await axiosInstance.post("/getTeamPendingWorkReport", requestedData, {
      headers: {
        "x-tenant-id": getUUID,
        Authorization: `${token}`,
      },
    });

    console.log("response", response.data.data.item);
    setPendingWork(response.data.data.item);
  } catch (error: any) {
    toast.error(error?.message || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
