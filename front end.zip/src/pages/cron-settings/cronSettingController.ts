import { TReactSetState } from "../../helpers/AppType";
import { axiosInstance } from "../../services/axiosInstance";

export interface ICronData {
  id: number;
  cron_title: string;
  cron_time: string;
  cron_start_time: string;
  cron_stop_time: string;
  created_date_time: string;
  displayCronTime: string;
}

export const addCronData = async (title: string, selectDuration: string) => {
  const requestedData = {
    cron_title: title,
    cron_time: selectDuration,
  };

  const data = await axiosInstance.post("addCron", requestedData);
  return data.data;
};

export const viewCronData = async (
  setCronData: TReactSetState<ICronData[]>
) => {
  const data = await axiosInstance.post("viewCron");
  setCronData(data.data.data.item);
};

export const startReminderNotificationCron = async (
  id: number,
  time: string,
  title: string
) => {
  const requestedData = {
    request_flag: 1,
    id: id,
    cron_time: time,
    // cron_title: title,
  };

  const data = await axiosInstance.post(
    "start-stop-reminder-notificaition",
    requestedData
  );
  return data.data;
};




export const stopCron = async (id: number) => {
  const requestedData = {
    request_flag: 2,
    id: id,
  };

  const data = await axiosInstance.post(
    "start-stop-reminder-notificaition",
    requestedData
  );
  return data.data;
};

export const startAllCron = async () => {
  try {
    const data = await axiosInstance.post("startAllCron");
    console.log("All Cron started");
    // console.log("msg", data.data.message);

    return data.data;
  } catch (error) {
    console.error("Failed to start all cron job:", error);
    return error;
  }
};

export const stopAllCron = async () => {
  try {
    const data = await axiosInstance.post("stopAllCron");
    console.log("All Cron Stopped");
    return data.data;
  } catch (error) {
    console.error("Failed to stop all cron job:", error);
    return error;
  }
};
