import React from "react";

import Index from "../pages/public/Index";
import { AppProvider } from "../common/AppContext";
import { Routes, Route, Link } from "react-router-dom";
import InstructionView from "../pages/instruction/InstructionView";
import ActivationCodeView from "../pages/public/activation-code/ActivationCodeView";
import OrderPrintViewV1 from "../pages/order-print-view/OrderPrintViewV1";
import OrderPdfViewV1 from "../pages/order-pdf-view/OrderPdfViewV1";
import PdfView from "../pages/order-pdf-view/PdfView";
import NotFound from "../components/NotFound";
import PrivacyPolicy from "../pages/privacy-policy/PrivacyPolicy";
import ContactUs from "../pages/privacy-policy/ContactUs";
import ShortcutkeyView from "../pages/short-cut-Key/Short_cut_key";
import Voice from "../pages/voice/Main";
import CronSetting from "../pages/cron-settings/cronSetting";
import VideoTutorial from "../pages/video Tutorial/VideoTutorial";
// import TeamPerformanceReports from "../pages/dashboard/Reports/TeamPerformanceReports"

const RoutesIndex = () => {
  let isGroupOpen;
  return (
    <>
      <AppProvider>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/voice" element={<Voice />} />
          <Route path="/cronSetting" element={<CronSetting />} />
          <Route path="/instructionView/:id" element={<InstructionView />} />
          <Route path="/videoTutorial/:id" element={<VideoTutorial />} />
          <Route path="/shortcutkey/:id" element={<ShortcutkeyView />} />
          <Route path="/activationCode" element={<ActivationCodeView />} />
          <Route
            path="/OrderPrintViewV1/:id/"
            element={<OrderPrintViewV1 />}
          />
          <Route
            path="/OrderPrintViewMobileV1/:id/:MobileToken/:getID"
            element={<OrderPrintViewV1 />}
          />
          <Route path="/OrderPdfViewV1/:id" element={<PdfView />} />
          <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} />
          <Route path="/ContactUs" element={<ContactUs />} />
          {/* <Route path="/fullScreenReport" element={<TeamPerformanceReports/>}></Route> */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </AppProvider>
    </>
  );
};
export default RoutesIndex;
