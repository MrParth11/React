import React, { createContext, ReactNode, useState } from 'react';
import { TReactSetState } from '../helpers/AppType';
import { ICreateCompany } from '../pages/left-side/create-company/CreateCompanyController';
interface IAppContextType {
  isEditContact: boolean;
  setIsEditContact: TReactSetState<boolean>;
  showRightSide: boolean
  setShowRightSide: TReactSetState<boolean>
  checkToken: boolean
  setCheckToken: TReactSetState<boolean>
  checkPlan: ICreateCompany | undefined
  setCheckPlan: TReactSetState<ICreateCompany | undefined>
  isCheckPlan: boolean,
  isSetCheckPlan: TReactSetState<boolean>
  permissions: any
  setPermissions: any
}
export const AppContext = createContext<IAppContextType | undefined>(undefined);

interface IAppProviderProps {
  children: ReactNode;
}
interface Permissions {
  [key: string]: boolean; // Example: { "reminder.create": true, "lead.update": false }
}

export const AppProvider: React.FC<IAppProviderProps> = ({ children }) => {

  const [isEditContact, setIsEditContact] = useState<boolean>(false);
  const [showRightSide, setShowRightSide] = useState(false);
  const [checkToken, setCheckToken] = useState(false);
  const [checkPlan, setCheckPlan] = useState<ICreateCompany | undefined>(undefined);
  const [isCheckPlan, isSetCheckPlan] = useState<boolean>(false);
  const [permissions, setPermissions] = useState<any>([]);
  const updateCheckPlan: TReactSetState<ICreateCompany | undefined> = (newPlan) => {
    setCheckPlan(newPlan);
  };

  return (
    <AppContext.Provider
      value={{
        isEditContact,
        setIsEditContact,
        showRightSide,
        setShowRightSide,
        checkToken,
        setCheckToken,
        checkPlan,
        setCheckPlan: updateCheckPlan,
        isCheckPlan,
        isSetCheckPlan,
        permissions,
        setPermissions
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
