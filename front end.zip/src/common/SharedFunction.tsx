import { toast } from "react-toastify";
import {
  DEFAULT_STATUS_CODE_SUCCESS,
  MESSAGE_UNKNOWN_ERROR_OCCURRED,
} from "../helpers/AppConstants";
import { axiosInstance } from "../services/axiosInstance";


export const checkDuplication = async (
  value: string | number,
  tableName: string,
  columnName: string,
  columnName1?: string
) => {
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    table: tableName,
    columns: "id",
    where: `{"isDelete":"0","${columnName}":"${value}","a_application_login_id":"${getUUID}"}`,


  };
  try {
    const data = await axiosInstance.post("commonGet", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const checkDuplicationTwoColum = async (
  value: string | number,
  tableName: string,
  columnName: string,
  columnName1: string,
  value1: string | number | undefined
) => {
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    table: tableName,
    columns: "id",
    where: `{"isDelete":"0","${columnName}":"${value}","${columnName1}":"${value1}","a_application_login_id":"${getUUID}"}`,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData, {
      headers: {
        "x-tenant-id": getUUID,

      },
    });
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const checkDuplicationUpdate = async (
  value: string | number,
  tableName: string,
  columnName: string,
  UpdateId: number | undefined
) => {
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    table: tableName,
    columns: "id",
    where: `{"isDelete":"0","${columnName}":"${value}","a_application_login_id":"${getUUID}","id":"${UpdateId}"}`,
    request_flag: 2,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData,

      {
        headers: {
          "x-tenant-id": getUUID,
        },
      }
    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const checkDuplicationUpdateTwoColum = async (
  value: string | number,
  tableName: string,
  columnName: string,
  columnName1: string,
  value1: string | number | undefined,
  UpdateId: number | undefined
) => {
  const getUUID = await localStorage.getItem("UUID");

  const requestData = {
    table: tableName,
    columns: "id",
    where: `{"isDelete":"0","${columnName}":"${value}","${columnName1}":${value1},"a_application_login_id":"${getUUID}","id":"${UpdateId}"}`,
    request_flag: 2,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData,
      {
        headers: {
          "x-tenant-id": getUUID,

        },
      }
    );
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};
export const checkDuplicationWithoutApplicationLogin = async (
  value: string | number,
  tableName: string,
  columnName: string
) => {
  const requestData = {
    table: tableName,
    columns: "id",
    where: `{"isDelete":"0","${columnName}":"${value}"}`,
  };
  try {
    const data = await axiosInstance.post("commonGet", requestData);
    if (data.data.ack === DEFAULT_STATUS_CODE_SUCCESS) {
      return true;
    } else {
      return false;
    }
  } catch (error: any) {
    toast.error(error || MESSAGE_UNKNOWN_ERROR_OCCURRED);
  }
};

export const formatDate = (date: any) => {
  const d = new Date(date);
  if (isNaN(d.getTime())) {
    return ""; // Return an empty string for invalid dates
  }
  const day = d.getDate().toString().padStart(2, "0");
  const month = (d.getMonth() + 1).toString().padStart(2, "0"); // Months are 0-based
  const year = d.getFullYear();

  return `${day}-${month}-${year} `;
};

export const formatTimeToAmPm = (dateTime: string): string => {
  try {
    // Convert "DD-MM-YYYY HH:mm" to "YYYY-MM-DDTHH:mm:ss"
    const [datePart, timePart] = dateTime.split(" ");
    const [day, month, year] = datePart.split("-");
    const isoDateTime = `${year}-${month}-${day}T${timePart}`;

    const date = new Date(isoDateTime);

    if (isNaN(date.getTime())) {
      throw new Error("Invalid date format");
    }

    const options: Intl.DateTimeFormatOptions = {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true, // Ensures AM/PM format
    };

    return new Intl.DateTimeFormat('en-US', options).format(date);
  } catch (error: any) {
    console.error("Error formatting time:", error.message);
    return "Invalid Date";
  }
};
export const convertTimeToAmPm = (time: string): string => {

  if (!time) {
    return "Invalid Time"
  }

  const [hours, minutes, seconds] = time.split(':').map(Number);

  let hour = hours % 12 || 12; // Convert 0 to 12 for 12 AM
  const period = hours >= 12 ? 'PM' : 'AM';


  const formattedHour = hour.toString().padStart(2, '0');
  const formattedMinute = minutes.toString().padStart(2, '0');
  const formattedSecond = seconds.toString().padStart(2, '0');

  return `${formattedHour}:${formattedMinute}:${formattedSecond} ${period}`;
};



export const formatDateAndTime = (
  date: string | Date | null | undefined
): string => {
  if (!date) return ""; // Handle null or undefined dates

  let d: Date;

  if (typeof date === "string") {
    const parts = date.split("-");
    if (parts.length === 3) {
      const [day, month, yearAndTime] = parts;
      const [year, time] = yearAndTime.split(" ");
      const [hours, minutes] = time ? time.split(":") : ["0", "0"];
      d = new Date(
        parseInt(year, 10),
        parseInt(month, 10) - 1, // Month is 0-based
        parseInt(day, 10),
        parseInt(hours, 10),
        parseInt(minutes, 10)
      );
    } else {
      return ""; // Invalid format
    }
  } else if (date instanceof Date) {
    d = date;
  } else {
    return ""; // Unsupported format
  }

  if (isNaN(d.getTime())) {
    return ""; // Return an empty string for invalid dates
  }

  const day = d.getDate().toString().padStart(2, "0");
  const month = (d.getMonth() + 1).toString().padStart(2, "0");
  const year = d.getFullYear();

  let hours = d.getHours();
  const minutes = d.getMinutes().toString().padStart(2, "0");
  const ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12 || 12; // Convert to 12-hour format and handle midnight

  return `${day}-${month}-${year} ${hours
    .toString()
    .padStart(2, "0")}:${minutes} ${ampm}`;
};
export const convertDateTimeFormat = (dateTime: string): { date: string; time: string } => {
  const [datePart, timePart] = dateTime.split(" ");
  let [hours, minutes] = timePart.split(":").map(Number);
  let period = "AM";

  if (hours >= 12) {
    period = "PM";
    if (hours > 12) {
      hours -= 12;
    }
  } else if (hours === 0) {
    hours = 12;
  }

  const formattedTime = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")} ${period}`;

  return { date: datePart, time: formattedTime };
};

export const isCurrentDateTime = (reminderDateTime: string): boolean => {
  const currentDateTime = new Date();
  const reminderDate = new Date(reminderDateTime);

  // Comparing date and time
  return (
    currentDateTime.getFullYear() === reminderDate.getFullYear() &&
    currentDateTime.getMonth() === reminderDate.getMonth() &&
    currentDateTime.getDate() === reminderDate.getDate() &&
    currentDateTime.getHours() === reminderDate.getHours() &&
    currentDateTime.getMinutes() === reminderDate.getMinutes()
  );
};
// yyyy-mm-dd HH:MM:SS
export function formatDateTimeSendDataBase(date: Date): string {
  if (!(date instanceof Date)) {
    throw new Error("Invalid date object");
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
// yyyy-mm-dd HH:MM:SS
export function formatDateSendDataBase(date: Date): string {
  if (!(date instanceof Date)) {
    throw new Error("Invalid date object");
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

export function formatNumber(number: number, decimals = 2) {
  return number.toFixed(decimals);
}

type CurrencyConfig = {
  scales: string[]; // Numbering system scales
  suffix: string; // Currency name
};

const currencyConfigs: Record<string, CurrencyConfig> = {
  INR: { scales: ["", "Thousand", "Lakh", "Crore"], suffix: "Rupees" },
  USD: { scales: ["", "Thousand", "Million", "Billion"], suffix: "Dollars" },
  EUR: { scales: ["", "Thousand", "Million", "Billion"], suffix: "Euros" },
  GBP: { scales: ["", "Thousand", "Million", "Billion"], suffix: "Pounds" },
  JPY: { scales: ["", "Thousand", "Million", "Billion"], suffix: "Yen" },
  // Add more currencies here
};

export const numberToWordsCurrency = (num: number, currency: string): string => {
  const config = currencyConfigs[currency];
  if (!config) {
    throw new Error(`Unsupported currency: ${currency}`);
  }

  const { scales, suffix } = config;

  const units = [
    "",
    "One",
    "Two",
    "Three",
    "Four",
    "Five",
    "Six",
    "Seven",
    "Eight",
    "Nine",
  ];
  const teens = [
    "Ten",
    "Eleven",
    "Twelve",
    "Thirteen",
    "Fourteen",
    "Fifteen",
    "Sixteen",
    "Seventeen",
    "Eighteen",
    "Nineteen",
  ];
  const tens = [
    "",
    "",
    "Twenty",
    "Thirty",
    "Forty",
    "Fifty",
    "Sixty",
    "Seventy",
    "Eighty",
    "Ninety",
  ];

  const numberToWords = (n: number): string => {
    if (n === 0) return "";

    let word = "";
    const hundreds = Math.floor(n / 100);
    const remainder = n % 100;
    const tensValue = Math.floor(remainder / 10);
    const unitsValue = remainder % 10;

    // Handle hundreds
    if (hundreds > 0) {
      word += units[hundreds] + " Hundred ";
    }

    // Handle tens and teens
    if (remainder >= 10 && remainder < 20) {
      word += teens[remainder - 10];
    } else {
      if (tensValue > 0) {
        word += tens[tensValue] + " ";
      }
      if (unitsValue > 0) {
        word += units[unitsValue];
      }
    }

    return word.trim();
  };

  // Split the number into chunks of three digits
  const chunks = [];
  let scaleIndex = 0;

  while (num > 0) {
    chunks.push(num % 1000);
    num = Math.floor(num / 1000);
  }

  // Convert chunks into words
  let word = "";
  for (let i = 0; i < chunks.length; i++) {
    const chunkWords = numberToWords(chunks[i]);
    if (chunkWords) {
      word = chunkWords + (scales[scaleIndex] ? " " + scales[scaleIndex] : "") + " " + word;
    }
    scaleIndex++;
  }

  return (word.trim() + ` ${suffix}`).trim();
};


export const formatTime = (seconds: number): string => {
  const hrs = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const mins = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const secs = String(seconds % 60).padStart(2, '0');
  return `${hrs}:${mins}:${secs}`;
}

export  const openInNewTab = (path: string, id?: number) => {
    const baseURL = window.location.origin;
    window.open(`${baseURL}${path}/${id}`, "_blank");
  };