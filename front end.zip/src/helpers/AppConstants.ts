export const DEFAULT_STATUS_CODE_SUCCESS = 1;
export const MESSAGE_UNKNOWN_ERROR_OCCURRED =
  "Unknown error occurred. Please try again";
export const DEFAULT_STATUS_CODE_ERROR = 0;
export const DEFAULT_TCS = 0.001;

export const DEFAULT_MESSAGE_ERROR_PERMISSION =
  "You do not have the necessary permissions to perform this action. Please Contact Your Company Owner. Or Upgrade Your Plan.";

export const DEFAULT_TOKEN_B2B = "poiuytrewq0987654321";

export const BACKEND_OF_SMALL_OFFICE_CRM_END_POINT = "http://192.168.1.5:2424";
export const BACKEND_OF_SMALL_OFFICE_WHATSAPP_WEB_END_POINT =
  "http://192.168.1.5:2525";

export const BACKEND_OF_SMALL_OFFICE_B2B_PORTAL_END_POINT =
  "http://192.168.1.5:3434";
export const INSTRUCTION_URL_ENDPOINT =
  "http://192.168.1.5:3000/smalofficecrminstruction";

export const MINI_TEXT_LENGTH = 15;
export const SMALL_TEXT_LENGTH = 20;
export const BIG_TEXT_LENGTH = 100;
export const TEXTAREA_TEXT_LENGTH = 500;
