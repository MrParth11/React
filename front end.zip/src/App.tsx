import { toast, ToastContainer } from "react-toastify";
import "./App.css";
import "./style/style.css";
import { ThemeProvider } from "./components/ThemeContext";
import RoutesIndex from "./Routes/RoutesIndex";

function App() {
  return (
    <ThemeProvider>
      <div className="app-container">
        <RoutesIndex />
      </div>
      <ToastContainer />
    </ThemeProvider>
  );
}

export default App;
