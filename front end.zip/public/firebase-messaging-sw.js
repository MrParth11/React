


importScripts("https://www.gstatic.com/firebasejs/9.15.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.15.0/firebase-messaging-compat.js");

const firebaseConfig = {
    apiKey: "AIzaSyB3qYCGqzw2mz83rvGdnRMBjFr-8VV4x4s",
    authDomain: "smalloffice-67f8e.firebaseapp.com",
    projectId: "smalloffice-67f8e",
    storageBucket: "smalloffice-67f8e.appspot.com",
    messagingSenderId: "825052312770",
    appId: "1:825052312770:web:6226436f03aa334bec775b",
    measurementId: "G-1S1DMMPBXJ"
};

firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();
messaging.onBackgroundMessage((payload) => {
    console.log("📥 Background message received:", payload);

    const notificationTitle = payload.notification?.title || "No Title";
    const notificationOptions = {
        body: payload.notification?.body || "No Body",
        icon: "/firebase-logo.png",
        data: payload.data || {},
    };
    self.registration.showNotification(notificationTitle, notificationOptions);
});
self.addEventListener("notificationclick", (event) => {
    console.log("Notification click event:", event);
    event.notification.close();

    event.waitUntil(
        clients
            .matchAll({ type: "window" })
            .then((clientList) => {
                if (clientList.length > 0) {
                    clientList[0].focus();
                } else {
                    clients.openWindow("/");
                }
            })
    );
});
